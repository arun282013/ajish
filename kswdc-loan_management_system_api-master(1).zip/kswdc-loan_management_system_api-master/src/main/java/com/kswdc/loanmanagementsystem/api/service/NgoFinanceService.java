package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Ngofinance;
import com.kswdc.loanmanagementsystem.api.value.NgoFinanceVO;


@Component
public interface NgoFinanceService {

    Integer createNgoFinance(Ngofinance NgoFinance);

    Integer updateNgoFinance(Ngofinance NgoFinance);
    Ngofinance getNgofinance(Integer id);

    // TLFamilyMember getTLFamilyMemberByTLFamilyMemberName(String tlfamilymemberName);

    Integer deleteNgofinance(Integer id);

    // List<TLFamilyMemberVO> getTLFamilyMemberList();
}
