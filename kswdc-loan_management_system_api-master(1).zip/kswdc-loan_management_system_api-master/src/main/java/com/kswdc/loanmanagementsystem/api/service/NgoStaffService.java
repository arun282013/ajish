package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.NgoStaff;
import com.kswdc.loanmanagementsystem.api.value.NgoStaffVO;


@Component
public interface NgoStaffService {

    Integer createNgoStaff(NgoStaff NgoStaff);

    Integer updateNgoStaff(NgoStaff NgoStaff);
    NgoStaff getNgoStaff(Integer id);

    // TLFamilyMember getTLFamilyMemberByTLFamilyMemberName(String tlfamilymemberName);

    Integer deleteNgoStaff(Integer id);

    // List<TLFamilyMemberVO> getTLFamilyMemberList();
}
