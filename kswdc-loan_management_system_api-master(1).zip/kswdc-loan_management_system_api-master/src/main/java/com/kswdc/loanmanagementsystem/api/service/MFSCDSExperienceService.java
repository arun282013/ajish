package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.MFSCDSExperience;
import com.kswdc.loanmanagementsystem.api.value.MFSCDSExperienceVO;


@Component
public interface MFSCDSExperienceService {

    Integer createMFSCDSExperience(MFSCDSExperience mfscdsexperience);

    Integer updateMFSCDSExperience(MFSCDSExperience mfscdsexperience);

    MFSCDSExperience getMFSCDSExperience(Integer id);

    Integer deleteMFSCDSExperience(Integer id);

}
