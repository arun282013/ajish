package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.Relation;
import com.kswdc.loanmanagementsystem.api.repository.RelationRepository;
import com.kswdc.loanmanagementsystem.api.value.RelationVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class RelationServiceImpl implements RelationService {
	private final Logger log = LoggerFactory.getLogger(RelationServiceImpl.class);
	
	@Autowired
	private RelationRepository relationRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createRelation(Relation Relation) {
		try {
			Relation savedRelation = relationRepository.save(Relation);
			return savedRelation.getRelationId() != null ? savedRelation.getRelationId() : -1;
		} catch (Exception e) {
			log.error("Exception in RelationServiceImpl::createRelation======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateRelation(Relation Relation) {
		try {
			Relation updateRelation = relationRepository.save(Relation);
			return updateRelation.getRelationId() != null ? updateRelation.getRelationId() : -1;
		} catch (Exception e) {
			log.error("Exception in RelationServiceImpl::updateRelation======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Relation getRelation(Integer id) {
		try {
			Relation relation = relationRepository.getRelationById(id);
			return relation;
		} catch (Exception e) {
			log.error("Exception in RelationServiceImpl::getRelation======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteRelation(Integer id) {
		try {
			Relation Relation = getRelation(id);
//			Relation.setActive(Boolean.FALSE);
			Relation.setDeletedOn(DateFunctions.getZonedServerDate());
			Relation.setIsDeleted(Constants.IS_DELETED);
			Relation updatedRelation = relationRepository.save(Relation);
			return updatedRelation.getRelationId() != null ? updatedRelation.getRelationId() : -1;
		} catch (Exception e) {
			log.error("Exception in RelationServiceImpl::deleteRelation======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<RelationVO> getRelationList() {
		try {
			List<RelationVO> relationList = relationRepository.getRelationList();
			return relationList;
		} catch (Exception e) {
			log.error("Exception in RelationServiceImpl::getRelationList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Relation getRelationByRelationName(String relationName) {
		try {
			Relation relation = relationRepository.findByRelationName(relationName);
			return relation;
		} catch (Exception e) {
			log.error("Exception in RelationServiceImpl::getRelationByRelationName======" + e.getMessage());
		}
		return null;
	}
}