package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistMFSCDS;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistMFSCDSVO;

@Repository
public interface DocumentChecklistMFSCDSRepository extends JpaRepository<DocumentChecklistMFSCDS, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.DocumentChecklistMFSCDSVO(d.documentchecklistmfscdsId,d.documentchecklistmfscdsName,"+
      "d.createdOn,u.fullName,d.modifiedOn,mu.fullName,d.isDeleted,d.deletedOn, d.isActive) " +
           " FROM DocumentChecklistMFSCDS d LEFT JOIN User u ON d.createdBy=u.userId LEFT JOIN User mu ON d.modifiedBy=mu.userId "+
            " WHERE d.isDeleted=0 ORDER BY d.documentchecklistmfscdsName ASC")
   List<DocumentChecklistMFSCDSVO> getDocumentChecklistMFSCDSList();//Filter only active loanTypes

   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.DocumentChecklistMFSCDSVO(d.documentchecklistmfscdsId,"+
      " d.documentchecklistmfscdsName,d.createdOn,u.fullName,d.modifiedOn,mu.fullName,d.isDeleted,d.deletedOn, d.isActive) " +
           " FROM DocumentChecklistMFSCDS d LEFT JOIN User u ON d.createdBy=u.userId"+
           " LEFT JOIN User mu ON d.modifiedBy=mu.userId WHERE d.isDeleted=0 "+
            " ORDER BY d.documentchecklistmfscdsName ASC")
   List<DocumentChecklistMFSCDSVO> getDocumentChecklistMFSCDSListByLoanType();
    
    @Query("SELECT a from DocumentChecklistMFSCDS a WHERE a.id=:documentchecklistmfscdsId")
    DocumentChecklistMFSCDS getDocumentChecklistMFSCDSById(@Param("documentchecklistmfscdsId") Integer documentchecklistmfscdsId);

    @Query("SELECT cl FROM DocumentChecklistMFSCDS cl WHERE cl.documentchecklistmfscdsName=:documentchecklistmfscdsName")
    DocumentChecklistMFSCDS findByDocumentChecklistMFSCDSName(@Param("documentchecklistmfscdsName") String documentchecklistmfscdsName);
}
