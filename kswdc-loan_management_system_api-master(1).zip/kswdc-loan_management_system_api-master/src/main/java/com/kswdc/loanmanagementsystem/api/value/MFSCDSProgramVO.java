package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MFSCDSProgramVO implements Serializable {
    private Integer programId;
    private String programName;
    private String programYear;
    private String programinstName;
    private Double programamountReceived;
    private String programBenefits;
    
    public MFSCDSProgramVO(Integer programId, 
    String programName, String programYear,
    String programinstName,Double programamountReceived,
    String programBenefits
    
    ) {
        this.programId = programId;
        this.programName = programName;
        this.programYear = programYear;
        this.programinstName = programinstName;
        this.programamountReceived = programamountReceived;
        this.programBenefits = programBenefits;
       
    }
    
}
