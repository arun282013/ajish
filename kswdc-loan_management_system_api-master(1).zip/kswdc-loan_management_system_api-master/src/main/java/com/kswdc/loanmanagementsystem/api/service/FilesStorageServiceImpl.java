package com.kswdc.loanmanagementsystem.api.service;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FilesStorageServiceImpl implements FilesStorageService {
    private final Path root = Paths.get("uploads");
    private final Path rootTL = Paths.get("uploads\\TL");
    private final Path rootTLPhoto = Paths.get("uploads\\TL\\photo");
    private final Path rootTLSign = Paths.get("uploads\\TL\\signature");
//---
    private final Path rootNGO = Paths.get("uploads\\NGO");
    private final Path rootNgostamp = Paths.get("uploads\\NGO\\stamp");
    private final Path rootngosign = Paths.get("uploads\\NGO\\sign");

    private final Path rootMFSCDS = Paths.get("uploads\\MFSCDS");

    @Override
    public void init() {
        try {
            Files.createDirectory(root);
            Files.createDirectory(rootTL);
            Files.createDirectory(rootTLPhoto);
            Files.createDirectory(rootTLSign);
            //--
            Files.createDirectory(rootNGO);
            Files.createDirectory(rootNgostamp);
            Files.createDirectory(rootngosign);

            Files.createDirectory(rootMFSCDS);
        } catch (IOException e) {
            throw new RuntimeException("Could not initialize folders for upload!");
        }
    }

    @Override
    public String save(MultipartFile file, Integer fileType, String filePrefix) {
        String fileName = "";
        try {
            System.out.println("file name: " + file.getOriginalFilename());
            fileName = file.getOriginalFilename();
            fileName = filePrefix + "_" + fileName;
            fileName = fileName.replaceAll(" ", "_");
            // Files.copy(file.getInputStream(),
            // this.root.resolve(file.getOriginalFilename()));
            // Files.copy(file.getInputStream(), this.root.resolve(fileName));
            if (fileType.equals(1)) {
                Files.copy(file.getInputStream(), this.rootTL.resolve(fileName));
            }
            //--
            if (fileType.equals(4)) {
                Files.copy(file.getInputStream(), this.rootNGO.resolve(fileName));
            }

            if (fileType.equals(2)) {
                Files.copy(file.getInputStream(), this.rootMFSCDS.resolve(fileName));
            }
            return fileName;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Could not store the file. Error: " + e.getMessage());
        }
    }

     


    @Override
    public Resource load(String filename, Integer fileType) {
        try {
            Path file = (fileType.equals(1) ? rootTL.resolve(filename) : root.resolve(filename));
            Resource resource = new UrlResource(file.toUri());
            if (resource.exists() || resource.isReadable()) {
                return resource;
            } else {
                throw new RuntimeException("Could not read the file!");
            }
        } catch (MalformedURLException e) {
            throw new RuntimeException("Error: " + e.getMessage());
        }
    }

    @Override
    public Resource loadngo(String filename, Integer fileType) {
        try {
            Path file = (fileType.equals(4) ? rootNGO.resolve(filename) : root.resolve(filename));
            Resource resource = new UrlResource(file.toUri());
            if (resource.exists() || resource.isReadable()) {
                return resource;
            } else {
                throw new RuntimeException("Could not read the file!");
            }
        } catch (MalformedURLException e) {
            throw new RuntimeException("Error: " + e.getMessage());
        }
    }

    @Override
    public Resource loadmfscds(String filename, Integer fileType) {
        try {
            Path file = (fileType.equals(2) ? rootMFSCDS.resolve(filename) : root.resolve(filename));
            Resource resource = new UrlResource(file.toUri());
            if (resource.exists() || resource.isReadable()) {
                return resource;
            } else {
                throw new RuntimeException("Could not read the file!");
            }
        } catch (MalformedURLException e) {
            throw new RuntimeException("Error: " + e.getMessage());
        }
    }

    @Override
    public void deleteAll() {
        FileSystemUtils.deleteRecursively(root.toFile());
    }

    @Override
    public Stream<Path> loadAll() {
        try {
            return Files.walk(this.root, 1).filter(path -> !path.equals(this.root)).map(this.root::relativize);
        } catch (IOException e) {
            throw new RuntimeException("Could not load the files!");
        }
    }

    //--save and load photo
    @Override
    public String savephoto(MultipartFile file, Integer fileType, String filePrefix) {
        String fileName = "";
        try {
            System.out.println("file name: " + file.getOriginalFilename());
            fileName = file.getOriginalFilename();
            fileName = filePrefix + "_" + fileName;
            fileName = fileName.replaceAll(" ", "_");

            if (fileType.equals(1)) {
                Files.copy(file.getInputStream(), this.rootTLPhoto.resolve(fileName));
            }
            return fileName;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Could not store the photo. Error: " + e.getMessage());
        }
    }

    @Override
    public Resource loadphoto(String filename, Integer fileType) {
        try {
            Path file = (fileType.equals(1) ? rootTLPhoto.resolve(filename) : root.resolve(filename));
            Resource resource = new UrlResource(file.toUri());
            if (resource.exists() || resource.isReadable()) {
                return resource;
            } else {
                throw new RuntimeException("Could not retrieve the photo!");
            }
        } catch (MalformedURLException e) {
            throw new RuntimeException("Error: " + e.getMessage());
        }
    } 
    //--save and load photo
    //--save and load sign
    @Override
    public String savesign(MultipartFile file, Integer fileType, String filePrefix) {
        String fileName = "";
        try {
            System.out.println("file name: " + file.getOriginalFilename());
            fileName = file.getOriginalFilename();
            fileName = filePrefix + "_" + fileName;
            fileName = fileName.replaceAll(" ", "_");

            if (fileType.equals(1)) {
                Files.copy(file.getInputStream(), this.rootTLSign.resolve(fileName));
            }
            return fileName;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Could not store the photo. Error: " + e.getMessage());
        }
    }

    @Override
    public Resource loadsign(String filename, Integer fileType) {
        try {
            Path file = (fileType.equals(1) ? rootTLSign.resolve(filename) : root.resolve(filename));
            Resource resource = new UrlResource(file.toUri());
            if (resource.exists() || resource.isReadable()) {
                return resource;
            } else {
                throw new RuntimeException("Could not retrieve the sign!");
            }
        } catch (MalformedURLException e) {
            throw new RuntimeException("Error: " + e.getMessage());
        }
    } 
    //--save and load sign


    //--save and load Stamp for NGO
    @Override
    public String savestampngo(MultipartFile file, Integer fileType, String filePrefix) {
        String fileName = "";
        try {
            System.out.println("file name: " + file.getOriginalFilename());
            fileName = file.getOriginalFilename();
            fileName = filePrefix + "_" + fileName;
            fileName = fileName.replaceAll(" ", "_");

            if (fileType.equals(1)) {
                Files.copy(file.getInputStream(), this.rootTLPhoto.resolve(fileName));
            }
            return fileName;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Could not store the photo. Error: " + e.getMessage());
        }
    }

    @Override
    public Resource loadstampngo(String filename, Integer fileType) {
        try {
            Path file = (fileType.equals(1) ? rootTLPhoto.resolve(filename) : root.resolve(filename));
            Resource resource = new UrlResource(file.toUri());
            if (resource.exists() || resource.isReadable()) {
                return resource;
            } else {
                throw new RuntimeException("Could not retrieve the photo!");
            }
        } catch (MalformedURLException e) {
            throw new RuntimeException("Error: " + e.getMessage());
        }
    } 
    //--save and load stamp //
    //--save and load sign for NGO
    @Override
    public String savesignngo(MultipartFile file, Integer fileType, String filePrefix) {
        String fileName = "";
        try {
            System.out.println("file name: " + file.getOriginalFilename());
            fileName = file.getOriginalFilename();
            fileName = filePrefix + "_" + fileName;
            fileName = fileName.replaceAll(" ", "_");

            if (fileType.equals(4)) {
                Files.copy(file.getInputStream(), this.rootngosign.resolve(fileName));
            }
            return fileName;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Could not store the photo. Error: " + e.getMessage());
        }
    }

    @Override
    public Resource loadsignngo(String filename, Integer fileType) {
        try {
            Path file = (fileType.equals(4) ? rootngosign.resolve(filename) : root.resolve(filename));
            Resource resource = new UrlResource(file.toUri());
            if (resource.exists() || resource.isReadable()) {
                return resource;
            } else {
                throw new RuntimeException("Could not retrieve the sign!");
            }
        } catch (MalformedURLException e) {
            throw new RuntimeException("Error: " + e.getMessage());
        }
    } 
    //--save and load sign ngo ///
}
