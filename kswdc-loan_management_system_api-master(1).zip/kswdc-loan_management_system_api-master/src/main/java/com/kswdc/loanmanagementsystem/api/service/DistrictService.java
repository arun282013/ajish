package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.District;
import com.kswdc.loanmanagementsystem.api.value.DistrictVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface DistrictService {

    Integer createDistrict(District district);

    Integer updateDistrict(District district);

    District getDistrict(Integer id);

    District getDistrictByDistrictName(String districtName);

    Integer deleteDistrict(Integer id);

    List<DistrictVO> getDistrictList();
}
