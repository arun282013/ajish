package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.Ward;
import com.kswdc.loanmanagementsystem.api.service.WardService;
import com.kswdc.loanmanagementsystem.api.value.WardVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class WardController {

	private final Logger log = LoggerFactory.getLogger(WardController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private WardService wardService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param Ward Ward
	 * @return Map
	 */
	@RequestMapping(value = "/ward", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createWard(@RequestBody Ward Ward) {
		log.info("In WardController::createWard=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(Ward)) {
//						Ward.setActive(Boolean.TRUE);
						Ward.setCreatedOn(DateFunctions.getZonedServerDate());
						// Ward.setCreatedBy();
						Ward.setIsDeleted(0);
						Integer WardId = wardService.createWard(Ward);
						if (!WardId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("WardId", WardId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in WardController::createWard======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param Ward Ward
	 * @return Map
	 */
	@RequestMapping(value = "/ward", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateWard(@RequestBody Ward ward) {
		log.info("In WardController::updateWard=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (ward != null && ward.getWardId() != null) { 
				if (checkValid(ward)) {
					Ward chkWard = wardService.getWard(ward.getWardId());
					if (chkWard!=null) {
//						if (chkWard.getActive()) {
//							Ward.setActive(Boolean.TRUE);
							chkWard.setWardName(ward.getWardName());							
							chkWard.setIsActive(ward.getIsActive());
							chkWard.setModifiedOn(DateFunctions.getZonedServerDate());							
							Integer WardId = wardService.updateWard(chkWard);
							if (!WardId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("WardId:", WardId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" Ward Id is deactivated:"+Ward.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in WardController::updateWard======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/ward/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteWard(@PathVariable Integer id) {
		log.info("In WardController::deleteWard=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Ward Ward = wardService.getWard(id);
				if (Ward != null) {
//					if (!Ward.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " WardId:" + id);
//					} else {
						Integer WardId = wardService.deleteWard(id);
						if (!WardId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("WardId", WardId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in WardController::deleteWard======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/ward/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneWard(@PathVariable Integer id) {
		log.info("In WardController::getOneWard=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Ward Ward = wardService.getWard(id);
				if (Ward != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("Ward", Ward);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in WardController::getOneWard======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- Ward ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/ward-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getWardList() {
		log.info("In WardController::getWardList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			WardListReturnVO WardListReturnVO = new WardListReturnVO(WardService.getWardList());
			List<WardVO> WardListReturnVO = wardService.getWardList();
			if (WardListReturnVO != null && WardListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("wards", WardListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in WardController::getWardList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param WardId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer WardId) {
		return (wardService.getWard(WardId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param Ward
	 * @return Boolean
	 */
	private Boolean checkValid(Ward Ward) {
		Boolean isValid = true;
		invalidMsg = "";
		if (Ward != null) {
//			if(Ward.getId()==null || Ward.getId()<=0) {
//				invalidMsg+="WardId is required and should be valid!";
//				isValid = false;
//			}
			if (Ward.getWardName() == null || Ward.getWardName().equalsIgnoreCase("")) {
				invalidMsg += "Ward Name is required and should not be empty!";
				isValid = false;
			}
//			if (Ward.getWardName() == null || Ward.getWardName().equalsIgnoreCase("")) {
//				invalidMsg += "Ward Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (Ward.getQuotaInMB() == null || Ward.getQuotaInMB().equals(0) || Ward.getQuotaInMB()<0) {
//				invalidMsg += "Ward Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (Ward.getChatHistoryDays() == null || Ward.getChatHistoryDays().equals(0) || Ward.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for Ward is required and should be valid!";
//				isValid = false;
//			}
//			if (Ward.getCdaTimeoutTime() == null || Ward.getCdaTimeoutTime().equals(0) || Ward.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for Ward!";
			isValid = false;
		}
		return isValid;
	}
	
}
