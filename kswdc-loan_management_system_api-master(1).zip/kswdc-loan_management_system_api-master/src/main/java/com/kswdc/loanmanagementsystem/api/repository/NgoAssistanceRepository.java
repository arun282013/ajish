package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.NgoAssistance;
import com.kswdc.loanmanagementsystem.api.value.NgoAssistanceVO;

@Repository
public interface NgoAssistanceRepository extends JpaRepository<NgoAssistance, Integer> {
   // @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TLFamilyMemberVO(f.tlfamilyMemberId,"+
   //    " f.tlfamilyMemberName,f.tlfamilyMemberAge,f.tlfamilyMemberEduqualification,f.tlfamilyMemberJob,"+
   //       "f.tlfamilyMemberAnnualIncome,t.fullName,r.relationName)"+ 
   //       "FROM TLFamilyMember f LEFT JOIN TermLoan t ON f.termLoanObj= t.termLoanId "+
   //       " LEFT JOIN Relation r ON f.relationObj = r.relationId "+
   //         " ORDER BY f.tlfamilyMemberName ASC")
   // @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TLFamilyMemberVO(f.tlfamilyMemberId,"+
   //    " f.tlfamilyMemberName,f.tlfamilyMemberAge,f.tlfamilyMemberEduqualification,f.tlfamilyMemberJob,"+
   //       "f.tlfamilyMemberAnnualIncome,t.fullName,r.relationName)"+ 
   //       "FROM TLFamilyMember f "+
   //       " LEFT JOIN Relation r ON f.relationObj = r.relationId "+
   //         " ORDER BY f.tlfamilyMemberName ASC")
//    List<TLFamilyMemberVO> getTLFamilyMemberList();//Filter only active familymember
    
    @Query("SELECT a FROM NgoAssistance a WHERE a.id=:assistanceId")
    NgoAssistance getNgoAssistanceById(@Param("assistanceId") Integer assistanceId);
 
    @Query("SELECT cl FROM NgoAssistance cl WHERE cl.category=category")
    NgoAssistance getNgoAssistanceByNgoAssistanceName(@Param("category") String category);

}
