package com.kswdc.loanmanagementsystem.api.controller;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.TermLoan;
import com.kswdc.loanmanagementsystem.api.model.User;
import com.kswdc.loanmanagementsystem.api.service.TermLoanService;
import com.kswdc.loanmanagementsystem.api.service.UserService;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistBeneficiaryVO;
import com.kswdc.loanmanagementsystem.api.value.ResponseMessageVO;
import com.kswdc.loanmanagementsystem.api.value.TLFamilyMemberVO;
import com.kswdc.loanmanagementsystem.api.value.TermLoanVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;
import com.kswdc.loanmanagementsystem.api.model.LoanCategory;
import com.kswdc.loanmanagementsystem.api.model.LocalbodyType;
import com.kswdc.loanmanagementsystem.api.service.LoanCategoryService;
import com.kswdc.loanmanagementsystem.api.model.LocalBody;
import com.kswdc.loanmanagementsystem.api.service.LocalBodyService;
import com.kswdc.loanmanagementsystem.api.service.LocalbodyTypeService;
import com.kswdc.loanmanagementsystem.api.model.MaritalStatus;
import com.kswdc.loanmanagementsystem.api.model.Postoffice;
import com.kswdc.loanmanagementsystem.api.service.MaritalStatusService;
import com.kswdc.loanmanagementsystem.api.service.PostofficeService;
import com.kswdc.loanmanagementsystem.api.model.Relation;
import com.kswdc.loanmanagementsystem.api.service.RelationService;
import com.kswdc.loanmanagementsystem.api.model.Religion;
import com.kswdc.loanmanagementsystem.api.model.TLFamilyMember;
//--17-03-2022
import com.kswdc.loanmanagementsystem.api.model.TLFamilyProperty;
//--17-03-2022
import com.kswdc.loanmanagementsystem.api.model.Taluk;
import com.kswdc.loanmanagementsystem.api.service.ReligionService;
import com.kswdc.loanmanagementsystem.api.service.TLFamilyMemberService;
import com.kswdc.loanmanagementsystem.api.service.TalukService;
import com.kswdc.loanmanagementsystem.api.model.Caste;
import com.kswdc.loanmanagementsystem.api.model.District;
import com.kswdc.loanmanagementsystem.api.model.DocumentChecklist;
import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistBeneficiary;
import com.kswdc.loanmanagementsystem.api.service.BankService;
import com.kswdc.loanmanagementsystem.api.service.CasteService;
import com.kswdc.loanmanagementsystem.api.service.DistrictService;
import com.kswdc.loanmanagementsystem.api.service.DocumentChecklistBeneficiaryService;
import com.kswdc.loanmanagementsystem.api.service.DocumentChecklistService;
import com.kswdc.loanmanagementsystem.api.model.Eduqualification;
import com.kswdc.loanmanagementsystem.api.model.FileInfo;
import com.kswdc.loanmanagementsystem.api.service.EduqualificationService;
import com.kswdc.loanmanagementsystem.api.service.FilesStorageService;
import com.kswdc.loanmanagementsystem.api.model.LoanType;
import com.kswdc.loanmanagementsystem.api.service.LoanTypeService;
import com.kswdc.loanmanagementsystem.api.model.Bank;
import com.kswdc.loanmanagementsystem.api.service.BankService;
import com.kswdc.loanmanagementsystem.api.model.Branch;
import com.kswdc.loanmanagementsystem.api.service.BranchService;
//--17-03-2022
import com.kswdc.loanmanagementsystem.api.model.Village;
import com.kswdc.loanmanagementsystem.api.service.VillageService;
//--17-03-2022
import com.kswdc.loanmanagementsystem.api.model.LocalbodyType;
import com.kswdc.loanmanagementsystem.api.service.LocalbodyTypeService;
//--
import com.kswdc.loanmanagementsystem.api.value.TLFamilyPropertyVO;
import com.kswdc.loanmanagementsystem.api.service.TLFamilyPropertyService;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class TermLoanController {

	private final Logger log = LoggerFactory.getLogger(TermLoanController.class);
	private String invalidMsg = "";

	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private TermLoanService termloanService;

	@Autowired
	private LoanCategoryService loanCategoryService;

	@Autowired
	private MaritalStatusService maritalstatusService;

	@Autowired
	private RelationService relationService;

	@Autowired
	private ReligionService religionService;

	@Autowired
	private CasteService casteService;

	@Autowired
	private EduqualificationService eduqualificationService;

	@Autowired
	private DistrictService districtService;

	@Autowired
	private TalukService talukService;

	@Autowired
	private LocalBodyService localbodyService;

	@Autowired
	private PostofficeService postofficeService;

	@Autowired
	private LoanTypeService loanTypeService;

	@Autowired
	private BankService bankService;

	@Autowired
	private BranchService branchService;

	@Autowired
	private UserService userService;

	// --17-03-2022
	@Autowired
	private VillageService villageService;
	// --17-03-2022
	// shiny 04-4-22
	@Autowired
	private LocalbodyTypeService localbodytypeService;

	@Autowired
	FilesStorageService storageService;

	@Autowired
	private DocumentChecklistService documentChecklistService;

	@Autowired
	private DocumentChecklistBeneficiaryService documentChecklistBeneficiaryService;

	@Autowired
	private TLFamilyMemberService tlFamilyMemberService;
	
	//--
	@Autowired
	private TLFamilyPropertyService tlFamilyPropertyService;

	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param TermLoan TermLoan
	 * @return Map
	 */
	@RequestMapping(value = "/termloan", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createTermLoan(@RequestBody TermLoanVO TermLoanVO) {
		log.info("In TermLoanController::createTermLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (checkValidVO(TermLoanVO)) {
				TermLoan termloanObj = new TermLoan();
				termloanObj.setFullName(TermLoanVO.getFullName());
				LoanCategory loanCategoryObj = loanCategoryService.getLoanCategory(TermLoanVO.getLoancategoryId());
				termloanObj.setLoanCategoryObj(loanCategoryObj);
				MaritalStatus maritalStatusObj = maritalstatusService.getMaritalStatus(TermLoanVO.getMaritalstatusId());
				termloanObj.setMaritalstatusObj(maritalStatusObj);
				Relation relationObj = relationService.getRelation(TermLoanVO.getRelationId());
				termloanObj.setRelationObj(relationObj);
				termloanObj.setTlguardianName(TermLoanVO.getTlguardianName());
				termloanObj.setTlDob(TermLoanVO.getTlDob());
				Religion religionObj = religionService.getReligion(TermLoanVO.getReligionId());
				termloanObj.setReligionObj(religionObj);
				Caste casteObj = casteService.getCaste(TermLoanVO.getCasteId());
				termloanObj.setCasteObj(casteObj);
				Eduqualification eduqualificationObj = eduqualificationService
						.getEduqualification(TermLoanVO.getEduqualificationId());
				termloanObj.setEduqualificationObj(eduqualificationObj);
				termloanObj.setTltechnicalQualification(TermLoanVO.getTltechnicalqualification());
				termloanObj.setTlExperience(TermLoanVO.getTlExperience());
				termloanObj.setTlpresenthouseName(TermLoanVO.getTlpresenthouseName());
				termloanObj.setTlpresenthouseNo(TermLoanVO.getTlpresenthouseNo());
				District presentdistrictObj = districtService.getDistrict(TermLoanVO.getPresentdistrictId());
				termloanObj.setPresentdistrictObj(presentdistrictObj);
				Taluk presenttalukObj = talukService.getTaluk(TermLoanVO.getPresenttalukId());
				termloanObj.setPresenttalukObj(presenttalukObj);
				termloanObj.setTlpresentlocationtypeId(TermLoanVO.getTlpresentlocationtypeId());
				LocalBody preslocalbodyObj = localbodyService.getLocalBody(TermLoanVO.getPreslocalbodyId());
				termloanObj.setPresentlocalbodyObj(preslocalbodyObj);
				termloanObj.setPresentLocation(TermLoanVO.getPresentLocation());
				Postoffice prespostofficeObj = postofficeService.getPostoffice(TermLoanVO.getPresentpostofficeId());
				termloanObj.setPresentpostofficeObj(prespostofficeObj);
				termloanObj.setPresentPincode(TermLoanVO.getPresentPincode());

				termloanObj.setTlpermanenthouseName(TermLoanVO.getTlpermanenthouseName());
				termloanObj.setTlpermanenthouseNo(TermLoanVO.getTlpermanenthouseNo());
				District permanentdistrictObj = districtService.getDistrict(TermLoanVO.getPermanentdistrictId());
				termloanObj.setPermanentdistrictObj(permanentdistrictObj);
				Taluk permanenttalukObj = talukService.getTaluk(TermLoanVO.getPermanenttalukId());
				termloanObj.setPermanenttalukObj(permanenttalukObj);
				termloanObj.setTlpermanentlocationtypeId(TermLoanVO.getTlpermanentlocationtypeId());
				LocalBody permlocalbodyObj = localbodyService.getLocalBody(TermLoanVO.getPermlocalbodyId());
				termloanObj.setPermanentlocalbodyObj(permlocalbodyObj);
				termloanObj.setPermanentLocation(TermLoanVO.getPermanentLocation());
				Postoffice permpostofficeObj = postofficeService.getPostoffice(TermLoanVO.getPermanentpostofficeId());
				termloanObj.setPermanentpostofficeObj(permpostofficeObj);
				termloanObj.setPermanentPincode(TermLoanVO.getPermanentPincode());
				termloanObj.setIsActive(1);
				LoanType loantypeObj = loanTypeService.getLoanType(1);
				termloanObj.setLoantypeObj(loantypeObj);
				termloanObj.setCreatedOn(DateFunctions.getZonedServerDate());
				User createdBy = userService.getUser(TermLoanVO.getCreatedById());
				termloanObj.setCreatedBy(createdBy);
				termloanObj.setUserObj(createdBy);
				termloanObj.setIsDeleted(0);
				termloanObj.setTlapplicationStatus(1);
				/// shiny 04-04-2022
				LocalbodyType permanentlbtypeObj = localbodytypeService
						.getLocalbodyType(TermLoanVO.getPermlocalbodytypeId());
				termloanObj.setPermanentlocalbodytypeObj(permanentlbtypeObj);
				LocalbodyType presentlbtypeObj = localbodytypeService
						.getLocalbodyType(TermLoanVO.getPreslocalbodytypeId());
				termloanObj.setPresentlocalbodytypeObj(presentlbtypeObj);
				////////////////////////////
				Integer TermLoanId = termloanService.createTermLoan(termloanObj);
				if (!TermLoanId.equals(-1)) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("TermLoanId", TermLoanId);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
					retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
			}

		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TermLoanController::createTermLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 *        //@param TermLoan TermLoan
	 * @return Map
	 */
	@RequestMapping(value = "/termloan", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateTermLoan(@RequestBody TermLoanVO termloanVO) {
		log.info("In TermLoanController::updateTermLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (termloanVO != null) { // && TermLoan.getId() != null
				if (checkValidVO(termloanVO)) {
					TermLoan chkTermLoan = termloanService.getTermLoan(termloanVO.getTermLoanId());
					if (chkTermLoan != null) {
						// if (chkTermLoan.getActive()) {
						// TermLoan.setActive(Boolean.TRUE);
						// chkTermLoan.setTermLoanName(termloan.getTermLoanName());
						// TermLoan termloanObj = new TermLoan();
						// chkTermLoan.setTermLoanId(termloanVO.getTermLoanId());
						// --for updation march 3
						// TermLoan termloanObj = new TermLoan();
						chkTermLoan.setFullName(termloanVO.getFullName());
						LoanCategory loanCategoryObj = loanCategoryService
								.getLoanCategory(termloanVO.getLoancategoryId());
						chkTermLoan.setLoanCategoryObj(loanCategoryObj);
						MaritalStatus maritalStatusObj = maritalstatusService
								.getMaritalStatus(termloanVO.getMaritalstatusId());
						chkTermLoan.setMaritalstatusObj(maritalStatusObj);
						Relation relationObj = relationService.getRelation(termloanVO.getRelationId());
						chkTermLoan.setRelationObj(relationObj);
						chkTermLoan.setTlguardianName(termloanVO.getTlguardianName());
						chkTermLoan.setTlDob(termloanVO.getTlDob());
						Religion religionObj = religionService.getReligion(termloanVO.getReligionId());
						chkTermLoan.setReligionObj(religionObj);
						Caste casteObj = casteService.getCaste(termloanVO.getCasteId());
						chkTermLoan.setCasteObj(casteObj);
						Eduqualification eduqualificationObj = eduqualificationService
								.getEduqualification(termloanVO.getEduqualificationId());
						chkTermLoan.setTltechnicalQualification(termloanVO.getTltechnicalqualification());
						chkTermLoan.setTlExperience(termloanVO.getTlExperience());
						chkTermLoan.setTlpresenthouseName(termloanVO.getTlpresenthouseName());
						chkTermLoan.setTlpresenthouseNo(termloanVO.getTlpresenthouseNo());
						District presentdistrictObj = districtService.getDistrict(termloanVO.getPresentdistrictId());
						chkTermLoan.setPresentdistrictObj(presentdistrictObj);
						Taluk presenttalukObj = talukService.getTaluk(termloanVO.getPresenttalukId());
						chkTermLoan.setPresenttalukObj(presenttalukObj);
						chkTermLoan.setTlpresentlocationtypeId(termloanVO.getTlpresentlocationtypeId());
						LocalBody preslocalbodyObj = localbodyService.getLocalBody(termloanVO.getPreslocalbodyId());
						chkTermLoan.setPresentlocalbodyObj(preslocalbodyObj);
						chkTermLoan.setPresentLocation(termloanVO.getPresentLocation());
						Postoffice prespostofficeObj = postofficeService
								.getPostoffice(termloanVO.getPresentpostofficeId());
						chkTermLoan.setPresentpostofficeObj(prespostofficeObj);
						chkTermLoan.setPresentPincode(termloanVO.getPresentPincode());

						chkTermLoan.setTlpermanenthouseName(termloanVO.getTlpermanenthouseName());
						chkTermLoan.setTlpermanenthouseNo(termloanVO.getTlpermanenthouseNo());
						District permanentdistrictObj = districtService
								.getDistrict(termloanVO.getPermanentdistrictId());
						chkTermLoan.setPermanentdistrictObj(permanentdistrictObj);
						Taluk permanenttalukObj = talukService.getTaluk(termloanVO.getPermanenttalukId());
						chkTermLoan.setPermanenttalukObj(permanenttalukObj);
						chkTermLoan.setTlpermanentlocationtypeId(termloanVO.getTlpermanentlocationtypeId());
						LocalBody permlocalbodyObj = localbodyService.getLocalBody(termloanVO.getPermlocalbodyId());
						chkTermLoan.setPermanentlocalbodyObj(permlocalbodyObj);
						chkTermLoan.setPermanentLocation(termloanVO.getPermanentLocation());
						Postoffice permpostofficeObj = postofficeService
								.getPostoffice(termloanVO.getPermanentpostofficeId());
						chkTermLoan.setPermanentpostofficeObj(permpostofficeObj);
						chkTermLoan.setPermanentPincode(termloanVO.getPermanentPincode());
						// termloanObj.setIsActive(1);
						LoanType loantypeObj = loanTypeService.getLoanType(1);
						chkTermLoan.setLoantypeObj(loantypeObj);
						// termloanObj.setCreatedOn(DateFunctions.getZonedServerDate());
						// termloanObj.setIsDeleted(0);
						// termloanObj.setTlapplicationStatus(1);
						// --for updation march 3

						User modifiedBy = userService.getUser(termloanVO.getModifiedById());
						chkTermLoan.setModifiedBy(modifiedBy);
						/// shiny 04-04-2022
						LocalbodyType permanentlbtypeObj = localbodytypeService
								.getLocalbodyType(termloanVO.getPermlocalbodytypeId());
						chkTermLoan.setPermanentlocalbodytypeObj(permanentlbtypeObj);
						LocalbodyType presentlbtypeObj = localbodytypeService
								.getLocalbodyType(termloanVO.getPreslocalbodytypeId());
						chkTermLoan.setPresentlocalbodytypeObj(presentlbtypeObj);
						////////////////////////////
						Integer TermLoanId = termloanService.updateTermLoan(chkTermLoan);
						if (!TermLoanId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("TermLoanId:", TermLoanId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
						// } else {
						// retMap = new HashMap<String, Object>();
						// retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						// retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						// retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
						// rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+"
						// TermLoan Id is deactivated:"+TermLoan.getId());
						// }

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TermLoanController::updateTermLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 *        //@param TermLoan TermLoan
	 * @return Map
	 */
	@RequestMapping(value = "/updateSecondTabTermLoan", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateSecondTabTermLoan(@RequestBody TermLoanVO termloanVO) {
		log.info("In TermLoanController::updateSecondTabTermLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (termloanVO != null) { // && TermLoan.getId() != null
				if (checkValidVO(termloanVO)) {
					TermLoan chkTermLoan = termloanService.getTermLoan(termloanVO.getTermLoanId());
					if (chkTermLoan != null) {
						// if (chkTermLoan.getActive()) {
						// TermLoan.setActive(Boolean.TRUE);
						// chkTermLoan.setTermLoanName(termloan.getTermLoanName());
						// TermLoan termloanObj = new TermLoan();
						// chkTermLoan.setTermLoanId(termloanVO.getTermLoanId());
						// --for updation march 3
						// TermLoan termloanObj = new TermLoan();
						Set<TLFamilyMember> familyMembers = new HashSet<TLFamilyMember>();
						String familyMembersStr = termloanVO.getFamilyMembers();
						if (familyMembersStr != null && familyMembersStr != "") {
							JSONArray jsonArray = new JSONArray(familyMembersStr);
							for (int i = 0; i < jsonArray.length(); i++) {
								JSONObject jsonObject = jsonArray.getJSONObject(i);
								String memberName = jsonObject.getString("fam_name");
								String memberOccupation = jsonObject.getString("fam_occupation");
								Double memberIncome = jsonObject.getDouble("fam_annualincome");
								Integer memberAge = jsonObject.getInt("fam_age");
								JSONObject relObj = jsonObject.getJSONObject("fam_relationId1");
								Relation relation = relationService.getRelation(relObj.getInt("relationId"));
								JSONObject qualObj = jsonObject.getJSONObject("fam_eduqualId1");
								Eduqualification eduqualification = eduqualificationService
										.getEduqualification(qualObj.getInt("eduqualificationId"));

								TLFamilyMember familyMember = new TLFamilyMember();
								familyMember.setMemberName(memberName);
								familyMember.setJob(memberOccupation);
								familyMember.setAge(memberAge);
								familyMember.setAnnualIncome(memberIncome);
								familyMember.setRelationObj(relation);
								// familyMember.setEduQualification(eduqualification.getEduqualificationName());// TO DO
																												// May
																												// have
																												// to
																												// change
																												// to
																												// Eduqualification
																												// Object

								familyMember.setEduqualificationObj(eduqualification);																		
								familyMembers.add(familyMember);
							}
							chkTermLoan.setFamilyMembers(familyMembers);
						}

						// --17-03-2022
						Set<TLFamilyProperty> familyPropertys = new HashSet<TLFamilyProperty>();
						String familyPropertysStr = termloanVO.getFamilyPropertys();
						if (familyPropertysStr != null && familyPropertysStr != "") {
							JSONArray jsonArray = new JSONArray(familyPropertysStr);
							for (int i = 0; i < jsonArray.length(); i++) {
								JSONObject jsonObject = jsonArray.getJSONObject(i);
								String propertyType = jsonObject.getString("famprop_type");
								String propertyArea = jsonObject.getString("famprop_area");
								String propertySurveyno = jsonObject.getString("famprop_surveyno");
								JSONObject distObj = jsonObject.getJSONObject("famprop_district");
								District district = districtService.getDistrict(distObj.getInt("districtId"));
								JSONObject tlkObj = jsonObject.getJSONObject("famprop_taluk");
								Taluk taluk = talukService.getTaluk(tlkObj.getInt("talukId"));
								JSONObject villageObj = jsonObject.getJSONObject("famprop_village");
								Village village = villageService.getVillage(villageObj.getInt("villageId"));

								TLFamilyProperty familyProperty = new TLFamilyProperty();
								familyProperty.setPropertyName(propertyType);
								familyProperty.setSize(propertyArea);
								familyProperty.setSurveyNo(propertySurveyno);
								familyProperty.setDistrictObj(district);
								familyProperty.setTalukObj(taluk);
								familyProperty.setVillageObj(village);

								familyPropertys.add(familyProperty);
							}
							chkTermLoan.setFamilyPropertys(familyPropertys);
						}
						// --17-03-2022
						chkTermLoan.setTlrationcardNo(termloanVO.getTlrationcardNo());
						chkTermLoan.setTlannualIncome(termloanVO.getTlannualIncome());
						chkTermLoan.setTlprojectName(termloanVO.getTlprojectName());
						chkTermLoan.setTlprojectCost(termloanVO.getTlprojectCost());
						chkTermLoan.setTlestimatedloanAmount(termloanVO.getTlestimatedloanAmount());
						chkTermLoan.setTlbankaccountNo(termloanVO.getTlbankaccountNo());
						
						Bank bankObj = bankService.getBank(termloanVO.getBankId());
						chkTermLoan.setBankObj(bankObj);
						Branch branchObj = branchService.getBranch(termloanVO.getBranchId());
						chkTermLoan.setBranchObj(branchObj);
						chkTermLoan.setIfsc(termloanVO.getIfsc());
						
						Integer TermLoanId = termloanService.updateTermLoan(chkTermLoan);
						if (!TermLoanId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("TermLoanId:", TermLoanId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
						// } else {
						// retMap = new HashMap<String, Object>();
						// retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						// retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						// retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
						// rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+"
						// TermLoan Id is deactivated:"+TermLoan.getId());
						// }

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TermLoanController::updateSecondTabTermLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/termloan/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteTermLoan(@PathVariable Integer id) {
		log.info("In TermLoanController::deleteTermLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				TermLoan TermLoan = termloanService.getTermLoan(id);
				if (TermLoan != null) {
					// if (!TermLoan.getActive()) {
					// retMap = new HashMap<String, Object>();
					// retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					// retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
					// retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
					// rabbitMqService.sendEvent(appName,
					// Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + "
					// TermLoanId:" + id);
					// } else {
					Integer TermLoanId = termloanService.deleteTermLoan(id);
					if (!TermLoanId.equals(-1)) {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
						retMap.put("TermLoanId", TermLoanId);
						return retMap;
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
						retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
					}
					// }
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TermLoanController::deleteTermLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/termloan/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneTermLoan(@PathVariable Integer id) {
		log.info("In TermLoanController::getOneTermLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				TermLoan TermLoan = termloanService.getTermLoan(id);
				if (TermLoan != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("TermLoan", TermLoan);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TermLoanController::getOneTermLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 14-Mar-2022
	 * @param Integer userId
	 * @return Map
	 */
	@RequestMapping(value = "/termloan-by-user/{userId}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneTermLoanByUser(@PathVariable Integer userId) {
		log.info("In TermLoanController::getOneTermLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (userId != null) {
				TermLoanVO TermLoanVo = termloanService.getTermLoanByUser(userId);
				if (TermLoanVo != null) {
					TermLoan termLoan = termloanService.getTermLoan(TermLoanVo.getTermLoanId());
					// List<TLFamilyMember> familyMemberVOs = tlFamilyMemberService
					// .getTLFamilyMemberListByTLId(TermLoanVo.getTermLoanId());
					Set<TLFamilyMember> familyMemberVOs = termLoan.getFamilyMembers();
					Set<TLFamilyProperty> familyPropertyVOs = termLoan.getFamilyPropertys();
					TermLoanVo.setFamilyMemberLst(familyMemberVOs);
					TermLoanVo.setFamilyPropertyLst(familyPropertyVOs);
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("TermLoan", TermLoanVo);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TermLoanController::getOneTermLoanByUser======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- TermLoan ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/termloan-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getTermLoanList() {
		log.info("In TermLoanController::getTermLoanList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			// TermLoanListReturnVO TermLoanListReturnVO = new
			// TermLoanListReturnVO(TermLoanService.getTermLoanList());
			List<TermLoanVO> TermLoanListReturnVO = termloanService.getTermLoanList();
			if (TermLoanListReturnVO != null && TermLoanListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("termloans", TermLoanListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TermLoanController::getTermLoanList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param TermLoanId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer TermLoanId) {
		return (termloanService.getTermLoan(TermLoanId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param TermLoan
	 * @return Boolean
	 */
	private Boolean checkValidVO(TermLoanVO TermLoanVO) {
		Boolean isValid = true;
		invalidMsg = "";
		if (TermLoanVO != null) {
			// if(TermLoan.getId()==null || TermLoan.getId()<=0) {
			// invalidMsg+="TermLoanId is required and should be valid!";
			// isValid = false;
			// }
			// if (TermLoan.getTermLoanName() == null ||
			// TermLoan.getTermLoanName().equalsIgnoreCase("")) {
			// invalidMsg += "TermLoan Name is required and should not be empty!";
			// isValid = false;
			// }
			// if (TermLoan.getTermLoanName() == null ||
			// TermLoan.getTermLoanName().equalsIgnoreCase("")) {
			// invalidMsg += "TermLoan Name is required and should not be empty!";
			// isValid = false;
			// }
			// if (TermLoan.getQuotaInMB() == null || TermLoan.getQuotaInMB().equals(0) ||
			// TermLoan.getQuotaInMB()<0) {
			// invalidMsg += "TermLoan Quota is required and should be valid!";
			// isValid = false;
			// }
			// if (TermLoan.getChatHistoryDays() == null ||
			// TermLoan.getChatHistoryDays().equals(0) || TermLoan.getChatHistoryDays()<0) {
			// invalidMsg += "Chat history days for TermLoan is required and should be
			// valid!";
			// isValid = false;
			// }
			// if (TermLoan.getCdaTimeoutTime() == null ||
			// TermLoan.getCdaTimeoutTime().equals(0) || TermLoan.getCdaTimeoutTime()<0) {
			// invalidMsg += "CDA Timeout time is required and should be valid!";
			// isValid = false;
			// }
		} else {
			invalidMsg = "Received data is not valid for TermLoan!";
			isValid = false;
		}
		return isValid;
	}

	// --modal view
	@RequestMapping(value = "/previewtermloan/{termLoanId}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOnePreviewTermLoan(@PathVariable Integer termLoanId) {
		log.info("In TermLoanController::getOnePreviewTermLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			TermLoanVO PreviewTermLoanReturnVO = termloanService.getPreviewTermLoan(termLoanId);
			if (PreviewTermLoanReturnVO != null) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("termloan", PreviewTermLoanReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TermLoanController::getOnePreviewTermLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}
	// --modal view

	@PostMapping("/upload")
	public ResponseEntity<ResponseMessageVO> uploadFile(@RequestParam("file") MultipartFile file,
			@RequestParam("docType") String docType, @RequestParam("docChecklistId") Integer docChecklistId,
			@RequestParam("loanTypeId") Integer loanTypeId, @RequestParam("termLoanId") Integer termLoanId) {
		String message = "";
		String fileName = "";
		try {
			if (docType.equals("TLCHK")) {
				String savedFileName = storageService.save(file, 1,
						loanTypeId + "_" + termLoanId + "_" + docChecklistId);
				if (savedFileName != null && !savedFileName.equals("")) {
					DocumentChecklistBeneficiary checklistBeneficiary = new DocumentChecklistBeneficiary();
					LoanType loanTypeObj = loanTypeService.getLoanType(loanTypeId);
					TermLoan termLoanObj = termloanService.getTermLoan(termLoanId);
					DocumentChecklist documentChecklist = documentChecklistService.getDocumentChecklist(docChecklistId);
					checklistBeneficiary.setLoanTypeObj(loanTypeObj);
					checklistBeneficiary.setTermLoanObj(termLoanObj);
					checklistBeneficiary.setDocumentChecklistObj(documentChecklist);
					checklistBeneficiary.setFilePath(savedFileName);
					documentChecklistBeneficiaryService.createDocumentChecklistBeneficiary(checklistBeneficiary);
				} else {
					return ResponseEntity.status(HttpStatus.NOT_MODIFIED)
							.body(new ResponseMessageVO("Could not upload document!", fileName));
				}
			} else {
				return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE)
						.body(new ResponseMessageVO("Loan type not got!", fileName));
			}
			message = "Uploaded the file successfully: " + file.getOriginalFilename();
			fileName = file.getOriginalFilename();
			return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessageVO(message, fileName));
		} catch (Exception e) {
			e.printStackTrace();
			message = "Could not upload the file: " + file.getOriginalFilename() + "! " + e.getMessage();
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessageVO(message, fileName));
		}
	}

	@GetMapping("/files")
	public ResponseEntity<List<FileInfo>> getListFiles() {
		List<FileInfo> fileInfos = storageService.loadAll().map(path -> {
			String filename = path.getFileName().toString();
			String url = MvcUriComponentsBuilder
					.fromMethodName(TermLoanController.class, "getFile", path.getFileName().toString()).build()
					.toString();
			return new FileInfo(0, filename, url);
		}).collect(Collectors.toList());
		return ResponseEntity.status(HttpStatus.OK).body(fileInfos);
	}

	@GetMapping("/files/{filename:.+}")
	@ResponseBody
	public ResponseEntity<Resource> getFile(@PathVariable String filename) {
		Resource file = storageService.load(filename, 0);
		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
				.body(file);
	}

	@GetMapping("/tlChkDocs/{termLoanId}")
	public ResponseEntity<List<FileInfo>> getTermLoanChecklistDocs(@PathVariable Integer termLoanId) {
		// Map<String,String> docInfo = new HashMap<String,String>();
		List<FileInfo> docs = new ArrayList<FileInfo>();
		List<DocumentChecklistBeneficiaryVO> checklistBeneficiaries = documentChecklistBeneficiaryService
				.getDocumentChecklistBeneficiaryByTermLoanId(termLoanId);
		if (checklistBeneficiaries != null && checklistBeneficiaries.size() > 0) {
			for (DocumentChecklistBeneficiaryVO documentChecklistBeneficiaryVo : checklistBeneficiaries) {
				Integer docChkBenId = documentChecklistBeneficiaryVo.getDocChecklistBeneficiaryId();
				String name = documentChecklistBeneficiaryVo.getDocumentChecklistName();
				String url = MvcUriComponentsBuilder
						.fromMethodName(TermLoanController.class, "getDoc",
								documentChecklistBeneficiaryVo.getDocChecklistBeneficiaryId())
						.build()
						.toString();
				FileInfo docInfo = new FileInfo(docChkBenId, name, url);
				docs.add(docInfo);
			}
		} else {
			return ResponseEntity.status(HttpStatus.OK).body(docs);
		}
		// List<FileInfo> fileInfos = storageService.loadAll().map(path -> {
		// String filename = path.getFileName().toString();
		// String url = MvcUriComponentsBuilder
		// .fromMethodName(TermLoanController.class, "getFile",
		// path.getFileName().toString()).build()
		// .toString();
		// return new FileInfo(filename, url);
		// }).collect(Collectors.toList());
		return ResponseEntity.status(HttpStatus.OK).body(docs);
	}

	@GetMapping("/getDoc/{docId}")
	@ResponseBody
	public ResponseEntity<Resource> getDoc(@PathVariable Integer docId) {
		DocumentChecklistBeneficiaryVO documentChecklistBeneficiary = documentChecklistBeneficiaryService
				.getDocumentChecklistBeneficiaryVO(docId);
		if (documentChecklistBeneficiary != null) {
			String fileName = documentChecklistBeneficiary.getFilePath();
			Resource file = storageService.load(fileName,
					documentChecklistBeneficiary.getLoanTypeId());
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
					.body(file);
		} else {
			return ResponseEntity.notFound().build();
		}
	}
	//--for photo

	@RequestMapping(value = "/updatePhotoTermLoan", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updatePhotoTermLoan(@RequestBody TermLoanVO termloanVO) {
		log.info("In TermLoanController::updatePhotoTermLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (termloanVO != null) {
				if (checkValidVO(termloanVO)) {
					TermLoan chkTermLoan = termloanService.getTermLoan(termloanVO.getTermLoanId());
					if (chkTermLoan != null) {
						chkTermLoan.setPhotoPath(termloanVO.getPhotoPath());
						Integer TermLoanId = termloanService.updateTermLoan(chkTermLoan);
						if (!TermLoanId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("TermLoanId:", TermLoanId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
						

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TermLoanController::updatePhotoTermLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	@PostMapping("/uploadphoto")
	public ResponseEntity<ResponseMessageVO> uploadPhoto(@RequestParam("file") MultipartFile file,
			@RequestParam("docType") String docType, 
			@RequestParam("loanTypeId") Integer loanTypeId, @RequestParam("termLoanId") Integer termLoanId) {
		String message = "";
		String fileName = "";
		try {
			if (docType.equals("TLPHT")) {
				String savedFileName = storageService.savephoto(file, 1,
						loanTypeId + "_" + termLoanId);
				if (savedFileName != null && !savedFileName.equals("")) {
					TermLoanVO termloanVO=new TermLoanVO();
					TermLoan chkTermLoan = termloanService.getTermLoan(termLoanId);
					if (chkTermLoan != null) {
					
					chkTermLoan.setPhotoPath(savedFileName);
					termloanService.updatePhotoTermLoan(chkTermLoan);
					}
				} else {
					return ResponseEntity.status(HttpStatus.NOT_MODIFIED)
							.body(new ResponseMessageVO("Could not upload photo!", fileName));
				}
			} else {
				return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE)
						.body(new ResponseMessageVO("Loan type not got!", fileName));
			}
			message = "Uploaded the photo successfully: " + file.getOriginalFilename();
			fileName = file.getOriginalFilename();
			return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessageVO(message, fileName));
		} catch (Exception e) {
			e.printStackTrace();
			message = "Could not upload the photo: " + file.getOriginalFilename() + "! " + e.getMessage();
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessageVO(message, fileName));
		}
	}

	@GetMapping("/getPht/{tlId}")
	@ResponseBody
	public ResponseEntity<Resource> getPht(@PathVariable Integer tlId) {
		TermLoanVO tlPhoto = termloanService.getTermLoanVOPhotoById(tlId);
		if (tlPhoto != null) {
			String fileName = tlPhoto.getPhotoPath();
			Resource file = storageService.loadphoto(fileName,tlPhoto.getLoantypeId());
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
					.body(file);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	//--for sign

	@RequestMapping(value = "/updateSignTermLoan", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateSignTermLoan(@RequestBody TermLoanVO termloanVO) {
		log.info("In TermLoanController::updateSignTermLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (termloanVO != null) {
				if (checkValidVO(termloanVO)) {
					TermLoan chkTermLoan = termloanService.getTermLoan(termloanVO.getTermLoanId());
					if (chkTermLoan != null) {
						chkTermLoan.setSignPath(termloanVO.getSignPath());
						Integer TermLoanId = termloanService.updateTermLoan(chkTermLoan);
						if (!TermLoanId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("TermLoanId:", TermLoanId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
						

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TermLoanController::updateSignTermLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	@PostMapping("/uploadsign")
	public ResponseEntity<ResponseMessageVO> uploadSign(@RequestParam("file") MultipartFile file,
			@RequestParam("docType") String docType, 
			@RequestParam("loanTypeId") Integer loanTypeId, @RequestParam("termLoanId") Integer termLoanId) {
		String message = "";
		String fileName = "";
		try {
			if (docType.equals("TLSGN")) {
				String savedFileName = storageService.savesign(file, 1,
						loanTypeId + "_" + termLoanId);
				if (savedFileName != null && !savedFileName.equals("")) {
					TermLoanVO termloanVO=new TermLoanVO();
					TermLoan chkTermLoan = termloanService.getTermLoan(termLoanId);
					if (chkTermLoan != null) {
					
					chkTermLoan.setSignPath(savedFileName);
					termloanService.updateSignTermLoan(chkTermLoan);
					}
				} else {
					return ResponseEntity.status(HttpStatus.NOT_MODIFIED)
							.body(new ResponseMessageVO("Could not upload sign!", fileName));
				}
			} else {
				return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE)
						.body(new ResponseMessageVO("Loan type not got!", fileName));
			}
			message = "Uploaded the sign successfully: " + file.getOriginalFilename();
			fileName = file.getOriginalFilename();
			return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessageVO(message, fileName));
		} catch (Exception e) {
			e.printStackTrace();
			message = "Could not upload the sign: " + file.getOriginalFilename() + "! " + e.getMessage();
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessageVO(message, fileName));
		}
	}

	@GetMapping("/getSign/{tlId}")
	@ResponseBody
	public ResponseEntity<Resource> getSign(@PathVariable Integer tlId) {
		TermLoanVO tlSign = termloanService.getTermLoanVOPhotoById(tlId);
		if (tlSign != null) {
			String fileName = tlSign.getSignPath();
			Resource file = storageService.loadsign(fileName,
			tlSign.getLoantypeId());
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
					.body(file);
		} else {
			return ResponseEntity.notFound().build();
		}
	}



}
