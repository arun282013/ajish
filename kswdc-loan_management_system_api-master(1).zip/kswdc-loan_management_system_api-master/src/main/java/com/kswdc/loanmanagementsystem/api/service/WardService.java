package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Ward;
import com.kswdc.loanmanagementsystem.api.value.WardVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface WardService {

    Integer createWard(Ward ward);

    Integer updateWard(Ward ward);

    Ward getWard(Integer id);

    Ward getWardByWardName(String wardName);

    Integer deleteWard(Integer id);

    List<WardVO> getWardList();
}
