package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TLFamilyMemberVO implements Serializable {
    private Integer memberId;
    private String memberName;
    private Integer age;
    private String eduQualification;
    private String job;
    private Double annualIncome;
    private String relationName;

    public TLFamilyMemberVO(Integer memberId,
            String memberName, Integer age,
            String eduQualification, String job,
            Double annualIncome,
            String relationName) {
        this.memberId = memberId;
        this.memberName = memberName;
        this.age = age;
        this.eduQualification = eduQualification;
        this.job = job;
        this.annualIncome = annualIncome;
        this.relationName = relationName;
    }

}
