package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.District;
import com.kswdc.loanmanagementsystem.api.repository.DistrictRepository;
import com.kswdc.loanmanagementsystem.api.value.DistrictVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class DistrictServiceImpl implements DistrictService {
	private final Logger log = LoggerFactory.getLogger(DistrictServiceImpl.class);
	
	@Autowired
	private DistrictRepository DistrictRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createDistrict(District district) {
		try {
			District savedDistrict = DistrictRepository.save(district);
			return savedDistrict.getDistrictId() != null ? savedDistrict.getDistrictId() : -1;
		} catch (Exception e) {
			log.error("Exception in DistrictServiceImpl::createDistrict======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateDistrict(District District) {
		try {
			District updateDistrict = DistrictRepository.save(District);
			return updateDistrict.getDistrictId() != null ? updateDistrict.getDistrictId() : -1;
		} catch (Exception e) {
			log.error("Exception in DistrictServiceImpl::updateDistrict======" + e.getMessage());
		}
		return null;
	}

	@Override
	public District getDistrict(Integer id) {
		try {
			District District = DistrictRepository.getDistrictById(id);
			return District;
		} catch (Exception e) {
			log.error("Exception in DistrictServiceImpl::getDistrict======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteDistrict(Integer id) {
		try {
			District District = getDistrict(id);
//			District.setActive(Boolean.FALSE);
			District.setDeletedOn(DateFunctions.getZonedServerDate());
			District.setIsDeleted(Constants.IS_DELETED);
			District updatedDistrict = DistrictRepository.save(District);
			return updatedDistrict.getDistrictId() != null ? updatedDistrict.getDistrictId() : -1;
		} catch (Exception e) {
			log.error("Exception in DistrictServiceImpl::deleteDistrict======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<DistrictVO> getDistrictList() {
		try {
			List<DistrictVO> DistrictList = DistrictRepository.getDistrictList();
			return DistrictList;
		} catch (Exception e) {
			log.error("Exception in DistrictServiceImpl::getDistrictList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public District getDistrictByDistrictName(String DistrictName) {
		try {
			District District = DistrictRepository.findByDistrictName(DistrictName);
			return District;
		} catch (Exception e) {
			log.error("Exception in DistrictServiceImpl::getDistrictByDistrictName======" + e.getMessage());
		}
		return null;
	}
}