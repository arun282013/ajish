package com.kswdc.loanmanagementsystem.api.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.kswdc.loanmanagementsystem.api.repository.UserRepository;

@Service
public class JwtUserDetailsService implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		if (!username.equalsIgnoreCase("")) {
			com.kswdc.loanmanagementsystem.api.model.User userModel = userRepository.findByUserName(username);
			if (userModel != null) {
				return new User(userModel.getEmailId(), userModel.getUserPassword(), new ArrayList<>());
			} else {
				throw new UsernameNotFoundException("User not found with username: " + username);
			}
		} else {
			throw new NullPointerException("User name is required!");
		}
		// if ("javainuse".equals(username)) {
		// return new User("javainuse",
		// "$2a$10$VfUYldwzIc3QYAkjAilyauJhJc8xFSOVH/v.1A66lvVjOxqD7JdXK",
		// new ArrayList<>());
		// } else {
		// throw new UsernameNotFoundException("User not found with username: " +
		// username);
		// }
	}
}