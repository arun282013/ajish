package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.LoanType;
import com.kswdc.loanmanagementsystem.api.value.LoanTypeVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface LoanTypeService {

    Integer createLoanType(LoanType loanType);

    Integer updateLoanType(LoanType loanType);

    LoanType getLoanType(Integer id);

    LoanType getLoanTypeByLoanTypeName(String loantypeName);

    Integer deleteLoanType(Integer id);

    List<LoanTypeVO> getLoanTypeList();
}
