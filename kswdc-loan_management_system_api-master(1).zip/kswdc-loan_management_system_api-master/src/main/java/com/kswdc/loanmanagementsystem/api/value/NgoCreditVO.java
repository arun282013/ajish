package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class NgoCreditVO implements Serializable {
    private Integer creditId;
    private String year;
    private String activities;
    private Integer noofShgs;
    private Integer noofBorrowers;
    private Double loanAmount;
    private Double loanamountDue;
    private Double loanamountRecovered;
    private Double percentageofRecovery;
    private String sourceFund;

    public NgoCreditVO(Integer creditId, 
    String year,String activities,
    Integer noofShgs,Integer noofBorrowers,
    Double loanAmount,Double loanamountDue,
    Double loanamountRecovered,Double percentageofRecovery,
    String sourceFund
    ) {
        this.creditId = creditId;
        this.year = year;
        this.activities = activities;
        this.noofShgs = noofShgs;
        this.noofBorrowers = noofBorrowers;
        this.loanAmount = loanAmount;
        this.loanamountDue = loanamountDue;
        this.loanamountRecovered = loanamountRecovered;
        this.percentageofRecovery = percentageofRecovery;
        this.sourceFund = sourceFund;
        }
    
}
