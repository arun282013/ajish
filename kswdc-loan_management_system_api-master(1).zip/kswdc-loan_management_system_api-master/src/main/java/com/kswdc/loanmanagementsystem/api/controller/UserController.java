package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.LoanCategory;
import com.kswdc.loanmanagementsystem.api.model.User;
import com.kswdc.loanmanagementsystem.api.model.UserType;
import com.kswdc.loanmanagementsystem.api.service.LoanCategoryService;
import com.kswdc.loanmanagementsystem.api.service.UserService;
import com.kswdc.loanmanagementsystem.api.service.UserTypeService;
import com.kswdc.loanmanagementsystem.api.value.UserVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class UserController {

	private final Logger log = LoggerFactory.getLogger(UserController.class);
	private String invalidMsg = "";

	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private UserService userService;

	@Autowired
	private LoanCategoryService loanCategoryService;

	@Autowired
	private UserTypeService userTypeService;

	@Autowired
	private PasswordEncoder passwordEncoder;

	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param User User
	 * @return Map
	 */
	@RequestMapping(value = "/user", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createUser(@RequestBody UserVO userVo) {
		log.info("In UserController::createUser=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (checkValidVO(userVo)) {
				// User.setActive(Boolean.TRUE);
				User userObj = new User();
				userObj.setFullName(userVo.getFullName());
				userObj.setAadharNo(userVo.getAadharNo());
				userObj.setMobileNo(userVo.getMobileNo());
				userObj.setEmailId(userVo.getEmailId());
				userObj.setUserName(userVo.getUserName());
				userObj.setUserPassword(passwordEncoder.encode(userVo.getUserPassword()));
				userObj.setAccountType(userVo.getAccountType());
				userObj.setUserStatus(1);
				UserType usertypeObj = userTypeService.getUserType(userVo.getUserTypeId());
				userObj.setUsertypeObj(usertypeObj);

				LoanCategory loanCategoryObj = loanCategoryService.getLoanCategory(userVo.getLoancategoryId());
				userObj.setLoanCategoryObj(loanCategoryObj);
				userObj.setCreatedOn(DateFunctions.getZonedServerDate());
				// User.setCreatedBy();
				userObj.setIsDeleted(0);
				userObj.setAadharValidated(0);
				Integer UserId = userService.createUser(userObj);
				if (!UserId.equals(-1)) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("UserId", UserId);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
					retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
			}

		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in UserController::createUser======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 *        //@param User User
	 * @return Map
	 */
	@RequestMapping(value = "/user", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateUser(@RequestBody User user) {
		log.info("In UserController::updateUser=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (user != null) { // && User.getId() != null
				if (checkValid(user)) {
					User chkUser = userService.getUser(user.getUserId());
					if (chkUser != null) {
						// if (chkUser.getActive()) {
						// User.setActive(Boolean.TRUE);
						chkUser.setAadharNo(user.getAadharNo());
						chkUser.setFullName(user.getFullName());
						chkUser.setMobileNo(user.getMobileNo());
						chkUser.setEmailId(user.getEmailId());
						chkUser.setAccountType(user.getAccountType());
						// chkUser.setUsertypeId(user.getUsertypeId());
						Integer UserId = userService.updateUser(chkUser);
						if (!UserId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("UserId:", UserId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
						// } else {
						// retMap = new HashMap<String, Object>();
						// retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						// retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						// retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
						// rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+"
						// User Id is deactivated:"+User.getId());
						// }

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in UserController::updateUser======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/user/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteUser(@PathVariable Integer id) {
		log.info("In UserController::deleteUser=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				User User = userService.getUser(id);
				if (User != null) {
					// if (!User.getActive()) {
					// retMap = new HashMap<String, Object>();
					// retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					// retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
					// retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
					// rabbitMqService.sendEvent(appName,
					// Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + "
					// UserId:" + id);
					// } else {
					Integer UserId = userService.deleteUser(id);
					if (!UserId.equals(-1)) {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
						retMap.put("UserId", UserId);
						return retMap;
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
						retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
					}
					// }
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in UserController::deleteUser======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/user/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneUser(@PathVariable Integer id) {
		log.info("In UserController::getOneUser=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				User User = userService.getUser(id);
				if (User != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("User", User);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in UserController::getOneUser======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- User ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/user-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getUserList() {
		log.info("In UserController::getUserList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			// UserListReturnVO UserListReturnVO = new
			// UserListReturnVO(UserService.getUserList());
			List<UserVO> UserListReturnVO = userService.getUserList();
			if (UserListReturnVO != null && UserListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("users", UserListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in UserController::getUserList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param UserId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer UserId) {
		return (userService.getUser(UserId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param User
	 * @return Boolean
	 */
	private Boolean checkValid(User User) {
		Boolean isValid = true;
		invalidMsg = "";
		if (User != null) {
			// if(User.getId()==null || User.getId()<=0) {
			// invalidMsg+="UserId is required and should be valid!";
			// isValid = false;
			// }
			if (User.getUserName() == null || User.getUserName().equalsIgnoreCase("")) {
				invalidMsg += "User Name is required and should not be empty!";
				isValid = false;
			}
			// if (User.getUserName() == null || User.getUserName().equalsIgnoreCase("")) {
			// invalidMsg += "User Name is required and should not be empty!";
			// isValid = false;
			// }
			// if (User.getQuotaInMB() == null || User.getQuotaInMB().equals(0) ||
			// User.getQuotaInMB()<0) {
			// invalidMsg += "User Quota is required and should be valid!";
			// isValid = false;
			// }
			// if (User.getChatHistoryDays() == null || User.getChatHistoryDays().equals(0)
			// || User.getChatHistoryDays()<0) {
			// invalidMsg += "Chat history days for User is required and should be valid!";
			// isValid = false;
			// }
			// if (User.getCdaTimeoutTime() == null || User.getCdaTimeoutTime().equals(0) ||
			// User.getCdaTimeoutTime()<0) {
			// invalidMsg += "CDA Timeout time is required and should be valid!";
			// isValid = false;
			// }
		} else {
			invalidMsg = "Received data is not valid for User!";
			isValid = false;
		}
		return isValid;
	}

	private Boolean checkValidVO(UserVO userVo) {
		Boolean isValid = true;
		invalidMsg = "";
		if (userVo != null) {
			// if(User.getId()==null || User.getId()<=0) {
			// invalidMsg+="UserId is required and should be valid!";
			// isValid = false;
			// }
			if (userVo.getUserName() == null || userVo.getUserName().equalsIgnoreCase("")) {
				invalidMsg += "User Name is required and should not be empty!";
				isValid = false;
			}
			// if (User.getUserName() == null || User.getUserName().equalsIgnoreCase("")) {
			// invalidMsg += "User Name is required and should not be empty!";
			// isValid = false;
			// }
			// if (User.getQuotaInMB() == null || User.getQuotaInMB().equals(0) ||
			// User.getQuotaInMB()<0) {
			// invalidMsg += "User Quota is required and should be valid!";
			// isValid = false;
			// }
			// if (User.getChatHistoryDays() == null || User.getChatHistoryDays().equals(0)
			// || User.getChatHistoryDays()<0) {
			// invalidMsg += "Chat history days for User is required and should be valid!";
			// isValid = false;
			// }
			// if (User.getCdaTimeoutTime() == null || User.getCdaTimeoutTime().equals(0) ||
			// User.getCdaTimeoutTime()<0) {
			// invalidMsg += "CDA Timeout time is required and should be valid!";
			// isValid = false;
			// }
		} else {
			invalidMsg = "Received data is not valid for User!";
			isValid = false;
		}
		return isValid;
	}

}
