package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ActivityfinancedVO implements Serializable {

    private Integer activityfinancedId;
    private String activityfinancedName;
    private String sectorName;
    private ZonedDateTime createdOn;
    private String createdBy;
    private ZonedDateTime modifiedOn;
    private String modifiedBy;
    private Integer isDeleted;
    private String deletedStr;
    private ZonedDateTime deletedOn;
    private Integer isActive;
    private String activeStr;


    public ActivityfinancedVO(Integer activityfinancedId, String activityfinancedName, String sectorName,
     ZonedDateTime createdOn, String createdBy, ZonedDateTime modifiedOn, String modifiedBy, Integer isDeleted, 
      ZonedDateTime deletedOn, Integer isActive) {
        this.activityfinancedId = activityfinancedId;
        this.activityfinancedName = activityfinancedName;
        this.sectorName = sectorName;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.modifiedOn = modifiedOn;
        this.modifiedBy = modifiedBy;
        this.isDeleted = isDeleted;
        this.deletedStr = isDeleted.equals(1)?Constants.IS_DELETED_STR:Constants.IS_NOT_DELETED_STR;
        this.deletedOn = deletedOn;
        this.isActive = isActive;
        this.activeStr = isActive.equals(1)?Constants.IS_ACTIVE_STR:Constants.IS_NOT_ACTIVE_STR;
    }
    
}
