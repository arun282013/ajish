package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklist;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistVO;

@Repository
public interface DocumentChecklistRepository extends JpaRepository<DocumentChecklist, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.DocumentChecklistVO(d.documentchecklistId,d.documentchecklistName,"+
      "d.createdOn,u.fullName,d.modifiedOn,mu.fullName,d.isDeleted,d.deletedOn, d.isActive) " +
           " FROM DocumentChecklist d LEFT JOIN User u ON d.createdBy=u.userId LEFT JOIN User mu ON d.modifiedBy=mu.userId "+
            " WHERE d.isDeleted=0 ORDER BY d.documentchecklistName ASC")
   List<DocumentChecklistVO> getDocumentChecklistList();//Filter only active loanTypes

   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.DocumentChecklistVO(d.documentchecklistId,"+
      " d.documentchecklistName,d.createdOn,u.fullName,d.modifiedOn,mu.fullName,d.isDeleted,d.deletedOn, d.isActive) " +
           " FROM DocumentChecklist d LEFT JOIN User u ON d.createdBy=u.userId"+
           " LEFT JOIN User mu ON d.modifiedBy=mu.userId WHERE d.isDeleted=0 "+
            " ORDER BY d.documentchecklistName ASC")
   List<DocumentChecklistVO> getDocumentChecklistListByLoanType(@Param("loantypeId") Integer loantypeId);
    
    @Query("SELECT a from DocumentChecklist a WHERE a.id=:documentchecklistId")
    DocumentChecklist getDocumentChecklistById(@Param("documentchecklistId") Integer documentchecklistId);

    @Query("SELECT cl FROM DocumentChecklist cl WHERE cl.documentchecklistName=:documentchecklistName")
    DocumentChecklist findByDocumentChecklistName(@Param("documentchecklistName") String documentchecklistName);
}
