package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_user")
@EqualsAndHashCode()
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "USER_ID")
    private Integer userId;

    @Column(name = "FULL_NAME", columnDefinition = "varchar(100) not null")
    private String fullName;

    @Column(name = "AADHAR_NO", columnDefinition = "varchar(12) not null")
    private String aadharNo;

    @Column(name = "AADHAR_VALIDATED", columnDefinition = "tinyint(1) not null default 0")
    private Integer aadharValidated;

    @Column(name = "VALIDATION_TIME", nullable = true)
    private ZonedDateTime validationTime;

    @Column(name = "MOBILE_NO", columnDefinition = "varchar(15) not null")
    private String mobileNo;

    @Column(name = "EMAIL_ID", columnDefinition = "varchar(150)", nullable = true)
    private String emailId;

    @Column(name = "USER_NAME", columnDefinition = "varchar(50) not null")
    private String userName;

    @Column(name = "USER_PASSWORD", columnDefinition = "varchar(100) not null")
    private String userPassword;

    @Column(name = "USER_STATUS", columnDefinition = "tinyint(1) not null default 0")
    private Integer userStatus;

    @Column(name = "CREATED_ON")
    private ZonedDateTime createdOn;

    @ManyToOne()
    @JoinColumn(name = "CREATED_BY", nullable = true)
    private User createdBy;

    @Column(name = "MODIFIED_ON", nullable = true)
    private ZonedDateTime modifiedOn;

    @ManyToOne()
    @JoinColumn(name = "MODIFIED_BY", nullable = true)
    private User modifiedBy;

    @Column(name = "IS_DELETED", columnDefinition = "tinyint(1) default 0")
    private Integer isDeleted;

    @Column(name = "DELETED_ON", nullable = true)
    private ZonedDateTime deletedOn;

    @ManyToOne()
    @JoinColumn(name = "DELETED_BY", nullable = true)
    private User deletedBy;

    @Column(name = "USER_OTP", nullable = true)
    private Integer userOtp;

    @ManyToOne()
    @JoinColumn(name = "USERTYPE_ID")
    private UserType usertypeObj;

    @Column(name = "ACCOUNT_TYPE", columnDefinition = "tinyint(1) not null")
    private Integer accountType;

    @ManyToOne()
    @JoinColumn(name = "LOAN_CATEGORY", nullable = true)
    private LoanCategory loanCategoryObj;

}
