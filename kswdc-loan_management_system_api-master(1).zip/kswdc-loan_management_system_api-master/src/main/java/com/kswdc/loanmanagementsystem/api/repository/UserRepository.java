package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.User;
import com.kswdc.loanmanagementsystem.api.value.UserVO;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
    @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.UserVO(o.userId,"+
    " o.userName,o.aadharNo,o.mobileNo,o.emailId,o.userName,o.userPassword,o.createdOn,u.fullName,"+
    "o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.userStatus) " +
         " FROM User o LEFT JOIN User u ON o.createdBy=u.userId "+
         "LEFT JOIN User mu ON o.modifiedBy=mu.userId WHERE o.isDeleted=0 ORDER BY o.userName ASC")
 List<UserVO> getUserList();//Filter only active users
  
  @Query("SELECT a from User a WHERE a.id=:userId")
  User getUserById(@Param("userId") Integer userId);

  @Query("SELECT cl FROM User cl WHERE cl.userName=:userName")
  User findByUserName(@Param("userName") String userName);
}
