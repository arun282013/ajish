package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Taluk;
import com.kswdc.loanmanagementsystem.api.value.TalukVO;

@Repository
public interface TalukRepository extends JpaRepository<Taluk, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TalukVO(o.talukId,"+
      " o.talukName,d.districtName,o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM Taluk o LEFT JOIN District d ON o.districtObj = d.districtId LEFT JOIN User u ON o.createdBy=u.userId"+
           " LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 ORDER BY o.talukName ASC")

   List<TalukVO> getTalukList();//Filter only active taluks

   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TalukVO(o.talukId,"+
      " o.talukName,d.districtName,o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM Taluk o LEFT JOIN District d ON o.districtObj = d.districtId LEFT JOIN User u ON o.createdBy=u.userId"+
           " LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 and d.districtId=:districtId ORDER BY o.talukName ASC")

    List<TalukVO> getTalukListByDistrict(@Param("districtId") Integer districtId);
    
    @Query("SELECT a from Taluk a WHERE a.id=:talukId")
    Taluk getTalukById(@Param("talukId") Integer talukId);

    @Query("SELECT cl FROM Taluk cl WHERE cl.talukName=:talukName")
    Taluk findByTalukName(@Param("talukName") String talukName);
}
