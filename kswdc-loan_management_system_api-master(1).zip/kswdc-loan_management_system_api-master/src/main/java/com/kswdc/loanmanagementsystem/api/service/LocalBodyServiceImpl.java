package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.LocalBody;
import com.kswdc.loanmanagementsystem.api.repository.LocalBodyRepository;
import com.kswdc.loanmanagementsystem.api.value.LocalBodyVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class LocalBodyServiceImpl implements LocalBodyService {
	private final Logger log = LoggerFactory.getLogger(LocalBodyServiceImpl.class);
	
	@Autowired
	private LocalBodyRepository localBodyRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createLocalBody(LocalBody LocalBody) {
		try {
			LocalBody savedLocalBody = localBodyRepository.save(LocalBody);
			return savedLocalBody.getLocalbodyId() != null ? savedLocalBody.getLocalbodyId() : -1;
		} catch (Exception e) {
			log.error("Exception in LocalBodyServiceImpl::createLocalBody======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateLocalBody(LocalBody LocalBody) {
		try {
			LocalBody updateLocalBody = localBodyRepository.save(LocalBody);
			return updateLocalBody.getLocalbodyId() != null ? updateLocalBody.getLocalbodyId() : -1;
		} catch (Exception e) {
			log.error("Exception in LocalBodyServiceImpl::updateLocalBody======" + e.getMessage());
		}
		return null;
	}

	@Override
	public LocalBody getLocalBody(Integer id) {
		try {
			LocalBody localBody = localBodyRepository.getLocalBodyById(id);
			return localBody;
		} catch (Exception e) {
			log.error("Exception in LocalBodyServiceImpl::getLocalBody======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteLocalBody(Integer id) {
		try {
			LocalBody LocalBody = getLocalBody(id);
			LocalBody.setDeletedOn(DateFunctions.getZonedServerDate());
			LocalBody.setIsDeleted(Constants.IS_DELETED);
			LocalBody updatedLocalBody = localBodyRepository.save(LocalBody);
			return updatedLocalBody.getLocalbodyId() != null ? updatedLocalBody.getLocalbodyId() : -1;
		} catch (Exception e) {
			log.error("Exception in LocalBodyServiceImpl::deleteLocalBody======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<LocalBodyVO> getLocalBodyList() {
		try {
			List<LocalBodyVO> localBodyList = localBodyRepository.getLocalBodyList();
			return localBodyList;
		} catch (Exception e) {
			log.error("Exception in LocalBodyServiceImpl::getLocalBodyList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public LocalBody getLocalBodyByLocalBodyName(String localBodyName) {
		try {
			LocalBody localBody = localBodyRepository.findByLocalBodyName(localBodyName);
			return localBody;
		} catch (Exception e) {
			log.error("Exception in LocalBodyServiceImpl::getLocalBodyByLocalBodyName======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<LocalBodyVO> getLocalBodyListByDistrict(Integer districtId,Integer localbodyTypeId) {
		try {
			List<LocalBodyVO> localBodyList = localBodyRepository.getLocalBodyListByDistrict(districtId,localbodyTypeId);
			return localBodyList;
		} catch (Exception e) {
			log.error("Exception in LocalBodyServiceImpl::getLocalBodyListByDistrict======" + e.getMessage());
		}
		return null;
	}

}