package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.SuretyType;
import com.kswdc.loanmanagementsystem.api.value.SuretyTypeVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface SuretyTypeService {

    Integer createSuretyType(SuretyType suretytype);

    Integer updateSuretyType(SuretyType suretytype);

    SuretyType getSuretyType(Integer id);

    SuretyType getSuretyTypeBySuretyTypeName(String suretytypeName);

    Integer deleteSuretyType(Integer id);

    List<SuretyTypeVO> getSuretyTypeList();

    List<SuretyTypeVO> getSuretyTypeListByLoanType(Integer loantypeId);
}
