package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistNgo;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistNgoVO;


@Component
public interface DocumentChecklistngoService {

    Integer createDocumentChecklistngo(DocumentChecklistNgo documentChecklistngo);

    Integer updateDocumentChecklistngo(DocumentChecklistNgo documentChecklistngo);

    DocumentChecklistNgo getDocumentChecklistngo(Integer id);

    DocumentChecklistNgo getDocumentChecklistngoByDocumentChecklistngoName(String documentchecklistngoName);

    Integer deleteDocumentChecklistngo(Integer id);

    List<DocumentChecklistNgoVO> getDocumentChecklistListngo();

    List<DocumentChecklistNgoVO> getDocumentChecklistListngoByLoanType(Integer loantypeId);
}
