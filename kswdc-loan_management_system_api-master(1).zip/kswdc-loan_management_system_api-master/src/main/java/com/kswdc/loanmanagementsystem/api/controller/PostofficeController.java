package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.Postoffice;
import com.kswdc.loanmanagementsystem.api.service.PostofficeService;
import com.kswdc.loanmanagementsystem.api.value.PostofficeVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class PostofficeController {

	private final Logger log = LoggerFactory.getLogger(PostofficeController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private PostofficeService postofficeService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param Postoffice Postoffice
	 * @return Map
	 */
	@RequestMapping(value = "/postoffice", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createPostoffice(@RequestBody Postoffice Postoffice) {
		log.info("In PostofficeController::createPostoffice=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(Postoffice)) {
//						Postoffice.setActive(Boolean.TRUE);
						Postoffice.setCreatedOn(DateFunctions.getZonedServerDate());
						// Postoffice.setCreatedBy();
						Postoffice.setIsDeleted(0);
						Integer PostofficeId = postofficeService.createPostoffice(Postoffice);
						if (!PostofficeId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("PostofficeId", PostofficeId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in PostofficeController::createPostoffice======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param Postoffice Postoffice
	 * @return Map
	 */
	@RequestMapping(value = "/postoffice", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updatePostoffice(@RequestBody Postoffice postoffice) {
		log.info("In PostofficeController::updatePostoffice=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (postoffice != null) { // && Postoffice.getId() != null
				if (checkValid(postoffice)) {
					Postoffice chkPostoffice = postofficeService.getPostoffice(postoffice.getPostofficeId());
					if (chkPostoffice!=null) {
//						if (chkPostoffice.getActive()) {
//							Postoffice.setActive(Boolean.TRUE);
							chkPostoffice.setPostofficeName(postoffice.getPostofficeName());
							chkPostoffice.setPostofficeId(postoffice.getPostofficeId());							
							
							Integer PostofficeId = postofficeService.updatePostoffice(chkPostoffice);
							if (!PostofficeId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("PostofficeId:", PostofficeId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" Postoffice Id is deactivated:"+Postoffice.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in PostofficeController::updatePostoffice======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/postoffice/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deletePostoffice(@PathVariable Integer id) {
		log.info("In PostofficeController::deletePostoffice=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Postoffice Postoffice = postofficeService.getPostoffice(id);
				if (Postoffice != null) {
//					if (!Postoffice.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " PostofficeId:" + id);
//					} else {
						Integer PostofficeId = postofficeService.deletePostoffice(id);
						if (!PostofficeId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("PostofficeId", PostofficeId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in PostofficeController::deletePostoffice======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/postoffice/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOnePostoffice(@PathVariable Integer id) {
		log.info("In PostofficeController::getOnePostoffice=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Postoffice Postoffice = postofficeService.getPostoffice(id);
				if (Postoffice != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("Postoffice", Postoffice);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in PostofficeController::getOnePostoffice======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- Postoffice ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/postoffice-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getPostofficeList() {
		log.info("In PostofficeController::getPostofficeList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			PostofficeListReturnVO PostofficeListReturnVO = new PostofficeListReturnVO(PostofficeService.getPostofficeList());
			List<PostofficeVO> PostofficeListReturnVO = postofficeService.getPostofficeList();
			if (PostofficeListReturnVO != null && PostofficeListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("postoffices", PostofficeListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in PostofficeController::getPostofficeList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	@RequestMapping(value = "/postoffice-list-by-district/{districtId}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getPostofficeListByDistrict(@PathVariable Integer districtId) {
		log.info("In PostofficeController::getPostofficeListByDistrict=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			List<PostofficeVO> PostofficeListReturnVO = postofficeService.getPostofficeListByDistrict(districtId);
			if (PostofficeListReturnVO != null && PostofficeListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("postoffices", PostofficeListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in PostofficeController::getPostofficeListByDistrict======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param PostofficeId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer PostofficeId) {
		return (postofficeService.getPostoffice(PostofficeId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param Postoffice
	 * @return Boolean
	 */
	private Boolean checkValid(Postoffice Postoffice) {
		Boolean isValid = true;
		invalidMsg = "";
		if (Postoffice != null) {
//			if(Postoffice.getId()==null || Postoffice.getId()<=0) {
//				invalidMsg+="PostofficeId is required and should be valid!";
//				isValid = false;
//			}
			if (Postoffice.getPostofficeName() == null || Postoffice.getPostofficeName().equalsIgnoreCase("")) {
				invalidMsg += "Postoffice Name is required and should not be empty!";
				isValid = false;
			}
//			if (Postoffice.getPostofficeName() == null || Postoffice.getPostofficeName().equalsIgnoreCase("")) {
//				invalidMsg += "Postoffice Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (Postoffice.getQuotaInMB() == null || Postoffice.getQuotaInMB().equals(0) || Postoffice.getQuotaInMB()<0) {
//				invalidMsg += "Postoffice Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (Postoffice.getChatHistoryDays() == null || Postoffice.getChatHistoryDays().equals(0) || Postoffice.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for Postoffice is required and should be valid!";
//				isValid = false;
//			}
//			if (Postoffice.getCdaTimeoutTime() == null || Postoffice.getCdaTimeoutTime().equals(0) || Postoffice.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for Postoffice!";
			isValid = false;
		}
		return isValid;
	}
	
}
