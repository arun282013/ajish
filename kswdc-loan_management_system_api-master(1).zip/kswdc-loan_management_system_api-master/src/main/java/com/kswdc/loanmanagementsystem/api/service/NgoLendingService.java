package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.NgoLending;
import com.kswdc.loanmanagementsystem.api.value.NgoLendingVO;


@Component
public interface NgoLendingService {

    Integer createNgoLending(NgoLending ngoLending);

    Integer updateNgoLending(NgoLending ngoLending);
    NgoLending getNgoLending(Integer id);

    // TLFamilyMember getTLFamilyMemberByTLFamilyMemberName(String tlfamilymemberName);

    Integer deleteNgoLending(Integer id);

    // List<TLFamilyMemberVO> getTLFamilyMemberList();
}
