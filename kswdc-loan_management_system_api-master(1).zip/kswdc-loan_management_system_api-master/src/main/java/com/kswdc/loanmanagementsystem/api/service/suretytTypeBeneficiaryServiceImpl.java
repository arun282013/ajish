package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.SuretyTypeBeneficiary;
import com.kswdc.loanmanagementsystem.api.repository.SuretyTypeBeneficiaryRepository;
import com.kswdc.loanmanagementsystem.api.value.SuretyTypeBeneficiaryVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;


@Service
public class suretytTypeBeneficiaryServiceImpl implements SuretyTypeBeneficiaryService {
	private final Logger log = LoggerFactory.getLogger(suretytTypeBeneficiaryServiceImpl.class);
	
	@Autowired
	private SuretyTypeBeneficiaryRepository suretyTypeBeneficiaryRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createSuretyTypeBeneficiary(SuretyTypeBeneficiary SuretyTypeBeneficiary) {
		try {
			SuretyTypeBeneficiary savedSuretyTypeBeneficiary = suretyTypeBeneficiaryRepository.save(SuretyTypeBeneficiary);
			return savedSuretyTypeBeneficiary.getSuretytypeBeneficiaryId() != null ? savedSuretyTypeBeneficiary.getSuretytypeBeneficiaryId() : -1;
		} catch (Exception e) {
			log.error("Exception in SuretyTypeBeneficiaryServiceImpl::createSuretyTypeBeneficiary======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateSuretyTypeBeneficiary(SuretyTypeBeneficiary SuretyTypeBeneficiary) {
		try {
			SuretyTypeBeneficiary updateSuretyTypeBeneficiary = suretyTypeBeneficiaryRepository.save(SuretyTypeBeneficiary);
			return updateSuretyTypeBeneficiary.getSuretytypeBeneficiaryId() != null ? updateSuretyTypeBeneficiary.getSuretytypeBeneficiaryId() : -1;
		} catch (Exception e) {
			log.error("Exception in SuretyTypeBeneficiaryServiceImpl::updateSuretyTypeBeneficiary======" + e.getMessage());
		}
		return null;
	}

	@Override
	public SuretyTypeBeneficiary getSuretyTypeBeneficiary(Integer id) {
		try {
			SuretyTypeBeneficiary suretyTypeBeneficiary = suretyTypeBeneficiaryRepository.getSuretyTypeBeneficiaryById(id);
			return suretyTypeBeneficiary;
		} catch (Exception e) {
			log.error("Exception in SuretyTypeBeneficiaryServiceImpl::getSuretyTypeBeneficiary======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteSuretyTypeBeneficiary(Integer id) {
		try {
			SuretyTypeBeneficiary SuretyTypeBeneficiary = getSuretyTypeBeneficiary(id);
//			LoanType.setActive(Boolean.FALSE);
			// LoanSuretyType.setDeletedOn(DateFunctions.getZonedServerDate());
			//LoanSuretyType.setIsDeleted(Constants.IS_DELETED);
			SuretyTypeBeneficiary updatedSuretyTypeBeneficiary = suretyTypeBeneficiaryRepository.save(SuretyTypeBeneficiary);
			return updatedSuretyTypeBeneficiary.getSuretytypeBeneficiaryId() != null ? updatedSuretyTypeBeneficiary.getSuretytypeBeneficiaryId() : -1;
		} catch (Exception e) {
			log.error("Exception in SuretyTypeBeneficiaryServiceImpl::deleteSuretyTypeBeneficiary======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<SuretyTypeBeneficiaryVO> getSuretyTypeBeneficiaryList() {
		try {
			List<SuretyTypeBeneficiaryVO> suretyTypeBeneficiaryList = suretyTypeBeneficiaryRepository.getSuretyTypeBeneficiaryList();
			return suretyTypeBeneficiaryList;
		} catch (Exception e) {
			log.error("Exception in SuretyTypeBeneficiaryServiceImpl::getSuretyTypeBeneficiaryList======" + e.getMessage());
		}
		return null;
	}

	// @Override
	// public LoanSuretyType getLoanSuretyTypeByLoanSuretyTypeName(String loanSuretyTypeName) {
	// 	try {
	// 		LoanSuretyType loanSuretyType = loanSuretyTypeRepository.findByLoanSuretyTypeName(loanSuretyTypeName);
	// 		return loanSuretyType;
	// 	} catch (Exception e) {
	// 		log.error("Exception in LoanSuretyTypeServiceImpl::getLoanSuretyTypeByLoanSuretyTypeName======" + e.getMessage());
	// 	}
	// 	return null;
	// }
}