package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.LoanCategory;
import com.kswdc.loanmanagementsystem.api.value.LoanCategoryVO;

@Repository
public interface LoanCategoryRepository extends JpaRepository<LoanCategory, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.LoanCategoryVO(o.loanCategoryId,o.loanCategoryCode,"+
      " o.loanCategoryName,o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM LoanCategory o LEFT JOIN User u ON o.createdBy=u.userId LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 ORDER BY o.loanCategoryName ASC")
   List<LoanCategoryVO> getLoanCategoryList();//Filter only active loanCategorys
    
    @Query("SELECT a from LoanCategory a WHERE a.id=:loanCategoryId")
    LoanCategory getLoanCategoryById(@Param("loanCategoryId") Integer loanCategoryId);

    @Query("SELECT cl FROM LoanCategory cl WHERE cl.loanCategoryName=:loanCategoryName")
    LoanCategory findByLoanCategoryName(@Param("loanCategoryName") String loanCategoryName);
}
