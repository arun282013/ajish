package com.kswdc.loanmanagementsystem.api.model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

@Data
@Entity
@Table(name = "tbl_term_loan")
@EqualsAndHashCode()
public class TermLoan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TERM_LOAN_ID")
    private Integer termLoanId;

    @ManyToOne()
    @JoinColumn(name = "USER_ID", nullable = true)
    private User userObj;

    @ManyToOne()
    @JoinColumn(name = "LOANCATEGORY_ID", nullable = true)
    private LoanCategory loanCategoryObj;

    @ManyToOne()
    @JoinColumn(name = "LOANTYPE_ID", nullable = true)
    private LoanType loantypeObj;

    @Column(name = "FULL_NAME", columnDefinition = "varchar(100) not null")
    private String fullName;

    @ManyToOne()
    @JoinColumn(name = "MARITALSTATUS_ID", nullable = true)
    private MaritalStatus maritalstatusObj;

    @ManyToOne()
    @JoinColumn(name = "RELATION_ID", nullable = true)
    private Relation relationObj;

    @Column(name = "TL_GUARDIAN_NAME", columnDefinition = "varchar(100) not null")
    private String tlguardianName;

    @Column(name = "TL_PRESENT_HOUSENAME", columnDefinition = "varchar(100) not null")
    private String tlpresenthouseName;

    @Column(name = "TL_PRESENT_HOUSENO", columnDefinition = "varchar(50) not null")
    private String tlpresenthouseNo;

    @Column(name = "TL_PRESENT_LOCATIONTYPEID", nullable = true)
    private Integer tlpresentlocationtypeId;

    @ManyToOne()
    @JoinColumn(name = "PRESENT_POSTOFFICE_ID", nullable = true)
    private Postoffice presentpostofficeObj;

    @ManyToOne()
    @JoinColumn(name = "PRESENT_DISTRICT_ID", nullable = true)
    private District presentdistrictObj;

    @ManyToOne()
    @JoinColumn(name = "PRESENT_TALUK_ID", nullable = true)
    private Taluk presenttalukObj;

    @ManyToOne()
    @JoinColumn(name = "PRESENT_LOCALBODY_ID", nullable = true)
    private LocalBody presentlocalbodyObj;

    @Column(name = "PRESENT_LOCATION", columnDefinition = "varchar(100) ", nullable = true)
    private String presentLocation;

    @Column(name = "PRESENT_PINCODE", columnDefinition = "int(11) not null")
    private Integer presentPincode;

    @Column(name = "TL_PERMANENT_HOUSENAME", columnDefinition = "varchar(100) not null")
    private String tlpermanenthouseName;

    @Column(name = "TL_PERMANENT_HOUSENO", columnDefinition = "varchar(50) not null")
    private String tlpermanenthouseNo;

    @Column(name = "TL_PERMANENT_LOCATIONTYPEID", nullable = true)
    private Integer tlpermanentlocationtypeId;

    @ManyToOne()
    @JoinColumn(name = "PERMANENT_POSTOFFICE_ID", nullable = true)
    private Postoffice permanentpostofficeObj;

    @ManyToOne()
    @JoinColumn(name = "PERMANENT_DISTRICT_ID", nullable = true)
    private District permanentdistrictObj;

    @ManyToOne()
    @JoinColumn(name = "PERMANENT_TALUK_ID", nullable = true)
    private Taluk permanenttalukObj;

    @ManyToOne()
    @JoinColumn(name = "PERMANENT_LOCALBODY_ID", nullable = true)
    private LocalBody permanentlocalbodyObj;

    @Column(name = "PERMANENT_LOCATION", columnDefinition = "varchar(100) ", nullable = true)
    private String permanentLocation;

    @Column(name = "PERMANENT_PINCODE", columnDefinition = "int(11) not null")
    private Integer permanentPincode;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(name = "TL_DOB", nullable = true, unique = false)
    private Date tlDob;

    @Column(name = "TL_AGE")
    private Integer tlAge;

    @ManyToOne()
    @JoinColumn(name = "CASTE_ID", nullable = true)
    private Caste casteObj;

    @ManyToOne()
    @JoinColumn(name = "RELIGION_ID", nullable = true)
    private Religion religionObj;

    @ManyToOne()
    @JoinColumn(name = "EDUQUALIFICATION_ID", nullable = true)
    private Eduqualification eduqualificationObj;

    @Column(name = "TL_TECHNICAL_QUALIFICATION", columnDefinition = "varchar(300) ", nullable = true)
    private String tltechnicalQualification;

    @Column(name = "TL_EXPERIENCE", columnDefinition = "varchar(300)", nullable = true)
    private String tlExperience;

    @Column(name = "TL_ANNUAL_INCOME", columnDefinition = "double", nullable = true)
    private Double tlannualIncome;

    @Column(name = "TL_RATIONCARD_NO", columnDefinition = "varchar(20)", nullable = true)
    private String tlrationcardNo;

    @Column(name = "TL_PROJECT_NAME", columnDefinition = "varchar(200) ", nullable = true)
    private String tlprojectName;

    @Column(name = "TL_PROJECT_COST", columnDefinition = "double ", nullable = true)
    private Double tlprojectCost;

    @Column(name = "TL_ESTIMATED_LOAN_AMOUNT", columnDefinition = "double ", nullable = true)
    private Double tlestimatedloanAmount;

    @Column(name = "TL_BANK_ACCOUNT_NO", columnDefinition = "varchar(30) ", nullable = true)
    private String tlbankaccountNo;

    @ManyToOne()
    @JoinColumn(name = "BANK_ID", nullable = true)
    private Bank bankObj;

    @ManyToOne()
    @JoinColumn(name = "BRANCH_ID", nullable = true)
    private Branch branchObj;

    @Column(name = "TL_APPLICATION_STATUS", columnDefinition = "tinyint(1) not null default 0")
    private Integer tlapplicationStatus;

    @Column(name = "ENTERED_ON", nullable = true)
    private ZonedDateTime enteredOn;

    @OneToMany(cascade = { CascadeType.ALL })
    @JoinColumn(name = "TERM_LOAN_ID")
    private Set<TLFamilyMember> familyMembers = new HashSet<>(0);

    @OneToMany(cascade = { CascadeType.ALL })
    @JoinColumn(name = "TERM_LOAN_ID")
    private Set<TLFamilyProperty> familyPropertys = new HashSet<>(0);

    @Column(name = "CREATED_ON")
    private ZonedDateTime createdOn;

    @ManyToOne()
    @JoinColumn(name = "CREATED_BY")
    private User createdBy;

    @Column(name = "MODIFIED_ON", nullable = true)
    private ZonedDateTime modifiedOn;

    @ManyToOne()
    @JoinColumn(name = "MODIFIED_BY", nullable = true)
    private User modifiedBy;

    @Column(name = "IS_DELETED", columnDefinition = "tinyint(1) not null default 0")
    private Integer isDeleted;

    @Column(name = "DELETED_ON", nullable = true)
    private ZonedDateTime deletedOn;

    @Column(name = "IS_ACTIVE", columnDefinition = "tinyint(1) not null default 0")
    private Integer isActive;

    @Column(name = "IFSC", columnDefinition = "varchar(100) nullable = true")
    private String ifsc;

    @ManyToOne()
    @JoinColumn(name = "PERMANENT_LOCALBODYTYPE_ID", nullable = true)
    private LocalbodyType permanentlocalbodytypeObj;

    @ManyToOne()
    @JoinColumn(name = "PRESENT_LOCALBODYTYPE_ID", nullable = true)
    private LocalbodyType presentlocalbodytypeObj;

    @Column(name = "PHOTO_PATH", columnDefinition = "varchar(300) nullable = true")
    private String photoPath;

    @Column(name = "SIGN_PATH", columnDefinition = "varchar(300) nullable = true")
    private String signPath;

   
}
