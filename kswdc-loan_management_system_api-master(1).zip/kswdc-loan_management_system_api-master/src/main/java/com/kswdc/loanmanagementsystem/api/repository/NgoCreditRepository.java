package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.NgoCredit;
import com.kswdc.loanmanagementsystem.api.value.NgoCreditVO;

@Repository
public interface NgoCreditRepository extends JpaRepository<NgoCredit, Integer> {
   // @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TLFamilyMemberVO(f.tlfamilyMemberId,"+
   //    " f.tlfamilyMemberName,f.tlfamilyMemberAge,f.tlfamilyMemberEduqualification,f.tlfamilyMemberJob,"+
   //       "f.tlfamilyMemberAnnualIncome,t.fullName,r.relationName)"+ 
   //       "FROM TLFamilyMember f LEFT JOIN TermLoan t ON f.termLoanObj= t.termLoanId "+
   //       " LEFT JOIN Relation r ON f.relationObj = r.relationId "+
   //         " ORDER BY f.tlfamilyMemberName ASC")
   // @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TLFamilyMemberVO(f.tlfamilyMemberId,"+
   //    " f.tlfamilyMemberName,f.tlfamilyMemberAge,f.tlfamilyMemberEduqualification,f.tlfamilyMemberJob,"+
   //       "f.tlfamilyMemberAnnualIncome,t.fullName,r.relationName)"+ 
   //       "FROM TLFamilyMember f "+
   //       " LEFT JOIN Relation r ON f.relationObj = r.relationId "+
   //         " ORDER BY f.tlfamilyMemberName ASC")
//    List<TLFamilyMemberVO> getTLFamilyMemberList();//Filter only active familymember
    
    @Query("SELECT a FROM NgoCredit a WHERE a.id=:creditId")
    NgoCredit getNgoCreditById(@Param("creditId") Integer creditId);
 
    @Query("SELECT cl FROM NgoCredit cl WHERE cl.activities=activities")
    NgoCredit getNgoCreditByNgoCreditName(@Param("programName") String activities);

}
