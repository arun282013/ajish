package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_ngo_sources")
@EqualsAndHashCode()
public class NgoSources{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SOURCES_ID")
    private Integer sourcesId;

    @Column(name = "SOURCES_NAME", columnDefinition = "varchar(200)",nullable = true)
    private String sourcesname;

    @Column(name = "BALANCE", columnDefinition = "decimal(15,2) not null default 0.00")
    private Double balance;

    @Column(name = "AMT_EXPECTED", columnDefinition = "decimal(15,2) not null default 0.00")
    private Double amtexpected;

    @Column(name = "TOTAL_AMT", columnDefinition = "decimal(15,2) not null default 0.00")
    private Double totalamt;

       
}
