package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Branch;
import com.kswdc.loanmanagementsystem.api.value.BranchVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface BranchService {

    Integer createBranch(Branch branch);

    Integer updateBranch(Branch branch);

    Branch getBranch(Integer id);

    Branch getBranchByBranchName(String branchName);

    Integer deleteBranch(Integer id);

    List<BranchVO> getBranchList();

    List<BranchVO> getBranchListByBank(Integer bankId);
}
