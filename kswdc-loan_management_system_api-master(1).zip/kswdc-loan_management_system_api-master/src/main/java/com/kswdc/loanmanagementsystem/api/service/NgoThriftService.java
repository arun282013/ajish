package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.NgoThrift;
import com.kswdc.loanmanagementsystem.api.value.NgoThriftVO;


@Component
public interface NgoThriftService {

    Integer createNgoThrift(NgoThrift NgoThrift);

    Integer updateNgoThrift(NgoThrift NgoThrift);
    NgoThrift getNgoThrift(Integer id);

    // TLFamilyMember getTLFamilyMemberByTLFamilyMemberName(String tlfamilymemberName);

    Integer deleteNgoThrift(Integer id);

    // List<TLFamilyMemberVO> getTLFamilyMemberList();
}
