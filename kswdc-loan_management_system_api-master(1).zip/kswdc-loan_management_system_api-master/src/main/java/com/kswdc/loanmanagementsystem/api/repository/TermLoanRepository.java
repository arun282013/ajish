package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.TermLoan;
import com.kswdc.loanmanagementsystem.api.value.TermLoanVO;

@Repository
public interface TermLoanRepository extends JpaRepository<TermLoan, Integer> {
  @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TermLoanVO(t.termLoanId, ur.fullName, lc.loanCategoryName, lt.loantypeName, "
      +
      " t.fullName, ms.maritalstatusName, r.relationName, t.tlguardianName , t.tlpresenthouseName ,t.tlpresenthouseNo, t.tlpresentlocationtypeId, p.postofficeName, d.districtName, "
      +
      " tk.talukName, lb.localbodyName, t.presentLocation, t.presentPincode, t.tlpermanenthouseName, t.tlpermanenthouseNo, "
      +
      " t.tlpermanentlocationtypeId, po.postofficeName, pd.districtName, ptl.talukName, plb.localbodyName, " +
      " t.permanentLocation, t.permanentPincode, t.tlDob, t.tlAge ,c.casteName,rl.religionName, ed.eduqualificationName, t.tltechnicalQualification,"
      +
      " t.tlExperience, t.tlannualIncome, t.tlrationcardNo,t.tlprojectName, t.tlprojectCost, t.tlestimatedloanAmount, "
      +
      " t.tlbankaccountNo, b.bankName, br.branchName, t.tlapplicationStatus, t.enteredOn, t.createdOn,u.fullName,t.modifiedOn,mu.fullName, t.isDeleted, t.deletedOn, t.isActive, t.ifsc, pres_lbt.localbodyTypeName, perm_lbt.localbodyTypeName) "
      +
      "FROM TermLoan t LEFT JOIN User ur ON t.userObj = ur.userId LEFT JOIN LoanCategory lc ON t.loanCategoryObj=lc.loanCategoryId "
      +
      "LEFT JOIN LoanType lt ON t.loantypeObj= lt.loantypeId LEFT JOIN MaritalStatus ms ON t.maritalstatusObj = ms.maritalstatusId "
      +
      "LEFT JOIN Relation r ON t.relationObj= r.relationId LEFT JOIN Postoffice p ON t.presentpostofficeObj= p.postofficeId "
      +
      "LEFT JOIN District d ON t.presentdistrictObj= d.districtId LEFT JOIN Taluk tk ON t.presenttalukObj= tk.talukId "
      +
      "LEFT JOIN LocalBody lb ON t.presentlocalbodyObj= lb.localbodyId LEFT JOIN Postoffice po ON t.permanentpostofficeObj= po.postofficeId "
      +
      "LEFT JOIN District pd ON t.permanentdistrictObj= pd.districtId LEFT JOIN Taluk ptl ON t.permanenttalukObj= ptl.talukId "
      +
      "LEFT JOIN LocalBody plb ON t.permanentlocalbodyObj= plb.localbodyId LEFT JOIN Caste c ON t.casteObj= c.casteId "
      +
      "LEFT JOIN Religion rl ON t.religionObj= rl.religionId LEFT JOIN Eduqualification ed ON t.eduqualificationObj= ed.eduqualificationId "
      +
      "LEFT JOIN LocalbodyType perm_lbt ON t.permanentlocalbodytypeObj= perm_lbt.localbodyTypeId  "
       +
      "LEFT JOIN LocalbodyType pres_lbt ON t.presentlocalbodytypeObj= pres_lbt.localbodyTypeId  "
       +
      "LEFT JOIN Bank b ON t.bankObj=b.bankId LEFT JOIN Branch br ON t.branchObj= br.branchId " +
      "LEFT JOIN User u ON t.createdBy=u.userId LEFT JOIN User mu ON t.modifiedBy=mu.userId " +
      "WHERE t.isDeleted=0 and t.isActive=1 ORDER BY t.termLoanId ASC")
  List<TermLoanVO> getTermLoanList();// Filter only active termloans

  @Query("SELECT t from TermLoan t WHERE t.id=:termLoanId")
  TermLoan getTermLoanById(@Param("termLoanId") Integer termLoanId);

  @Query("SELECT cl FROM TermLoan cl WHERE cl.fullName=:fullName")
  TermLoan findByTermLoanName(@Param("fullName") String fullName);

  // --modal view
  @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TermLoanVO(t.termLoanId, ur.fullName,lc.loanCategoryId, lc.loanCategoryName, lt.loantypeName, "
      +
      " t.fullName, ms.maritalstatusId, ms.maritalstatusName, r.relationId, r.relationName, t.tlguardianName , t.tlpresenthouseName ,t.tlpresenthouseNo, t.tlpresentlocationtypeId, p.postofficeId, p.postofficeName, d.districtId, d.districtName, "
      +
      " tk.talukId, tk.talukName, lb.localbodyId, lb.localbodyName, t.presentLocation, t.presentPincode, t.tlpermanenthouseName, t.tlpermanenthouseNo, "
      +
      " t.tlpermanentlocationtypeId, po.postofficeId, po.postofficeName, pd.districtId, pd.districtName, ptl.talukId, ptl.talukName, plb.localbodyId, plb.localbodyName, "
      +
      " t.permanentLocation, t.permanentPincode, t.tlDob, t.tlAge ,c.casteId, c.casteName, rl.religionId, rl.religionName, ed.eduqualificationId, ed.eduqualificationName, t.tltechnicalQualification,"
      +
      " t.tlExperience, t.tlannualIncome, t.tlrationcardNo,t.tlprojectName, t.tlprojectCost, t.tlestimatedloanAmount, "
      +
      " t.tlbankaccountNo, b.bankId, b.bankName, br.branchId, br.branchName, t.tlapplicationStatus, t.enteredOn, t.createdOn,u.fullName,t.modifiedOn,mu.fullName, t.isDeleted, t.deletedOn, t.isActive, t.ifsc, pres_lbt.localbodyTypeId, pres_lbt.localbodyTypeName, perm_lbt.localbodyTypeId, perm_lbt.localbodyTypeName) "
      +
      "FROM TermLoan t LEFT JOIN User ur ON t.userObj = ur.userId LEFT JOIN LoanCategory lc ON t.loanCategoryObj=lc.loanCategoryId "
      +
      "LEFT JOIN LoanType lt ON t.loantypeObj= lt.loantypeId LEFT JOIN MaritalStatus ms ON t.maritalstatusObj = ms.maritalstatusId "
      +
      "LEFT JOIN Relation r ON t.relationObj= r.relationId LEFT JOIN Postoffice p ON t.presentpostofficeObj= p.postofficeId "
      +
      "LEFT JOIN District d ON t.presentdistrictObj= d.districtId LEFT JOIN Taluk tk ON t.presenttalukObj= tk.talukId "
      +
      "LEFT JOIN LocalBody lb ON t.presentlocalbodyObj= lb.localbodyId LEFT JOIN Postoffice po ON t.permanentpostofficeObj= po.postofficeId "
      +
      "LEFT JOIN District pd ON t.permanentdistrictObj= pd.districtId LEFT JOIN Taluk ptl ON t.permanenttalukObj= ptl.talukId "
      +
      "LEFT JOIN LocalBody plb ON t.permanentlocalbodyObj= plb.localbodyId LEFT JOIN Caste c ON t.casteObj= c.casteId "
      +
      "LEFT JOIN Religion rl ON t.religionObj= rl.religionId LEFT JOIN Eduqualification ed ON t.eduqualificationObj= ed.eduqualificationId "
      +
      "LEFT JOIN LocalbodyType perm_lbt ON t.permanentlocalbodytypeObj= perm_lbt.localbodyTypeId  "
       +
      "LEFT JOIN LocalbodyType pres_lbt ON t.presentlocalbodytypeObj= pres_lbt.localbodyTypeId  "
       +
      "LEFT JOIN Bank b ON t.bankObj=b.bankId LEFT JOIN Branch br ON t.branchObj= br.branchId " +
      "LEFT JOIN User u ON t.createdBy=u.userId LEFT JOIN User mu ON t.modifiedBy=mu.userId " +
      "WHERE t.isDeleted=0 and t.isActive=1 and t.termLoanId=:termLoanId")
  TermLoanVO getPreviewTermLoanById(@Param("termLoanId") Integer termLoanId);

  @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TermLoanVO(t.termLoanId, ur.fullName,lc.loanCategoryId, lc.loanCategoryName, lt.loantypeName, "
      +
      " t.fullName, ms.maritalstatusId, ms.maritalstatusName, r.relationId, r.relationName, t.tlguardianName , t.tlpresenthouseName ,t.tlpresenthouseNo, t.tlpresentlocationtypeId, p.postofficeId, p.postofficeName, d.districtId, d.districtName, "
      +
      " tk.talukId, tk.talukName, lb.localbodyId, lb.localbodyName, t.presentLocation, t.presentPincode, t.tlpermanenthouseName, t.tlpermanenthouseNo, "
      +
      " t.tlpermanentlocationtypeId, po.postofficeId, po.postofficeName, pd.districtId, pd.districtName, ptl.talukId, ptl.talukName, plb.localbodyId, plb.localbodyName, "
      +
      " t.permanentLocation, t.permanentPincode, t.tlDob, t.tlAge ,c.casteId, c.casteName, rl.religionId, rl.religionName, ed.eduqualificationId, ed.eduqualificationName, t.tltechnicalQualification,"
      +
      " t.tlExperience, t.tlannualIncome, t.tlrationcardNo,t.tlprojectName, t.tlprojectCost, t.tlestimatedloanAmount, "
      +
      " t.tlbankaccountNo, b.bankId, b.bankName, br.branchId, br.branchName, t.tlapplicationStatus, t.enteredOn, t.createdOn,u.fullName,t.modifiedOn,mu.fullName, t.isDeleted, t.deletedOn, t.isActive, t.ifsc, pres_lbt.localbodyTypeId, pres_lbt.localbodyTypeName, perm_lbt.localbodyTypeId, perm_lbt.localbodyTypeName) "
      +
      "FROM TermLoan t LEFT JOIN User ur ON t.userObj = ur.userId LEFT JOIN LoanCategory lc ON t.loanCategoryObj=lc.loanCategoryId "
      +
      "LEFT JOIN LoanType lt ON t.loantypeObj= lt.loantypeId LEFT JOIN MaritalStatus ms ON t.maritalstatusObj = ms.maritalstatusId "
      +
      "LEFT JOIN Relation r ON t.relationObj= r.relationId LEFT JOIN Postoffice p ON t.presentpostofficeObj= p.postofficeId "
      +
      "LEFT JOIN District d ON t.presentdistrictObj= d.districtId LEFT JOIN Taluk tk ON t.presenttalukObj= tk.talukId "
      +
      "LEFT JOIN LocalBody lb ON t.presentlocalbodyObj= lb.localbodyId LEFT JOIN Postoffice po ON t.permanentpostofficeObj= po.postofficeId "
      +
      "LEFT JOIN District pd ON t.permanentdistrictObj= pd.districtId LEFT JOIN Taluk ptl ON t.permanenttalukObj= ptl.talukId "
      +
      "LEFT JOIN LocalBody plb ON t.permanentlocalbodyObj= plb.localbodyId LEFT JOIN Caste c ON t.casteObj= c.casteId "
      +
      "LEFT JOIN Religion rl ON t.religionObj= rl.religionId LEFT JOIN Eduqualification ed ON t.eduqualificationObj= ed.eduqualificationId "
      +
      "LEFT JOIN LocalbodyType perm_lbt ON t.permanentlocalbodytypeObj= perm_lbt.localbodyTypeId  "
       +
      "LEFT JOIN LocalbodyType pres_lbt ON t.presentlocalbodytypeObj= pres_lbt.localbodyTypeId  "
       +
      "LEFT JOIN Bank b ON t.bankObj=b.bankId LEFT JOIN Branch br ON t.branchObj= br.branchId " +
      "LEFT JOIN User u ON t.createdBy=u.userId LEFT JOIN User mu ON t.modifiedBy=mu.userId " +
      "WHERE t.isDeleted=0 and t.isActive=1 and u.userId=:userId")
  TermLoanVO getTermLoanByUserId(@Param("userId") Integer userId);
  // --modal view
  //--for photo
  @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TermLoanVO(cb.termLoanId,"
                        +
                        "cb.fullName,l.loantypeId,l.loantypeName,cb.photoPath,cb.signPath) " +
                        "FROM TermLoan cb "
                        +
                        " LEFT JOIN LoanType l ON cb.loantypeObj=l.loantypeId "
                        +
                        " WHERE cb.id=:termLoanId")
                        TermLoanVO getTermLoanVOPhotoById(
                        @Param("termLoanId") Integer termLoanId);


        // @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TermLoanVO(cb.docChecklistBeneficiaryId,dc.documentchecklistName,"
        //                 +
        //                 "tl.fullName,l.loantypeId,l.loantypeName,cb.filePath) " +
        //                 "FROM DocumentChecklistBeneficiary cb LEFT JOIN DocumentChecklist dc on cb.documentChecklistObj=dc.documentchecklistId "
        //                 +
        //                 "LEFT JOIN TermLoan tl ON cb.termLoanObj=tl.termLoanId LEFT JOIN LoanType l ON cb.loanTypeObj=l.loantypeId "
        //                 +
        //                 "WHERE tl.termLoanId=:termLoanId ORDER BY cb.docChecklistBeneficiaryId ASC")
        // List<DocumentChecklistBeneficiaryVO> getDocumentChecklistBeneficiaryByTermLoanId(
        //                 @Param("termLoanId") Integer termLoanId);
}
