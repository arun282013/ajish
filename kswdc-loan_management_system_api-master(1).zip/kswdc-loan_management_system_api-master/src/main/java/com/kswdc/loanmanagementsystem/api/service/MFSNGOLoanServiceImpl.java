package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.MFSNGOLoan;
import com.kswdc.loanmanagementsystem.api.value.MFSNGOLoanVO;
import com.kswdc.loanmanagementsystem.api.repository.MFSNGOLoanRepository;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class MFSNGOLoanServiceImpl implements MFSNGOLoanService {
	private final Logger log = LoggerFactory.getLogger(MFSNGOLoanServiceImpl.class);

	@Autowired
	private MFSNGOLoanRepository mfsngoloanRepository;

	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createMFSNGOLoan(MFSNGOLoan MFSNGOLoan) {
		try {
			MFSNGOLoan savedMFSNGOLoan = mfsngoloanRepository.save(MFSNGOLoan);
			return savedMFSNGOLoan.getMfsngoLoanId() != null ? savedMFSNGOLoan.getMfsngoLoanId() : -1;
		} catch (Exception e) {
			log.error("Exception in MFSNGOLoanServiceImpl::createMFSNGOLoan======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateMFSNGOLoan(MFSNGOLoan MFSNGOLoan) {
		try {
			MFSNGOLoan updateMFSNGOLoan = mfsngoloanRepository.save(MFSNGOLoan);
			return updateMFSNGOLoan.getMfsngoLoanId() != null ? updateMFSNGOLoan.getMfsngoLoanId() : -1;
		} catch (Exception e) {
			log.error("Exception in MFSNGOLoanServiceImpl::updateMFSNGOLoan======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateSecondTabMFSNGOLoan(MFSNGOLoan MFSNGOLoan) {
		try {
			MFSNGOLoan updateSecondTabMFSNGOLoan = mfsngoloanRepository.save(MFSNGOLoan);
			return updateSecondTabMFSNGOLoan.getMfsngoLoanId() != null ? updateSecondTabMFSNGOLoan.getMfsngoLoanId() : -1;
		} catch (Exception e) {
			log.error("Exception in MFSNGOLoanServiceImpl::updateSecondTabMFSNGOLoan======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateThirdTabMFSNGOLoan(MFSNGOLoan MFSNGOLoan) {
		try {
			MFSNGOLoan updateThirdTabMFSNGOLoan = mfsngoloanRepository.save(MFSNGOLoan);
			return updateThirdTabMFSNGOLoan.getMfsngoLoanId() != null ? updateThirdTabMFSNGOLoan.getMfsngoLoanId() : -1;
		} catch (Exception e) {
			log.error("Exception in MFSNGOLoanServiceImpl::updateThirdTabMFSNGOLoan======" + e.getMessage());
		}
		return null;
	}

	@Override
	public MFSNGOLoan getMFSNGOLoan(Integer id) {
		try {
			MFSNGOLoan mfsngoloan = mfsngoloanRepository.getMFSNGOLoanById(id);
			return mfsngoloan;
		} catch (Exception e) {
			log.error("Exception in MFSNGOLoanServiceImpl::getMFSNGOLoan======" + e.getMessage());
		}
		return null;
	}

	@Override
	public MFSNGOLoanVO getMFSNGOLoanByUser(Integer userId) {
		try {
			MFSNGOLoanVO mfsngoloan = mfsngoloanRepository.getMFSNGOLoanByUserId(userId);
			return mfsngoloan;
		} catch (Exception e) {
			log.error("Exception in MFSNGOLoanServiceImpl::getMFSNGOLoanByUser======" + e.getMessage());
		}
		return null;
	}

	// @Override
	// public Integer deleteTermLoan(Integer id) {
	// 	try {
	// 		TermLoan TermLoan = getTermLoan(id);
	// 		// TermLoan.setActive(Boolean.FALSE);
	// 		TermLoan.setDeletedOn(DateFunctions.getZonedServerDate());
	// 		TermLoan.setIsDeleted(Constants.IS_DELETED);
	// 		TermLoan updatedTermLoan = termloanRepository.save(TermLoan);
	// 		return updatedTermLoan.getTermLoanId() != null ? updatedTermLoan.getTermLoanId() : -1;
	// 	} catch (Exception e) {
	// 		log.error("Exception in TermLoanServiceImpl::deleteTermLoan======" + e.getMessage());
	// 	}
	// 	return null;
	// }

	// @Override
	// public List<TermLoanVO> getTermLoanList() {
	// 	try {
	// 		List<TermLoanVO> termloanList = termloanRepository.getTermLoanList();
	// 		return termloanList;
	// 	} catch (Exception e) {
	// 		log.error("Exception in TermLoanServiceImpl::getTermLoanList======" + e.getMessage());
	// 	}
	// 	return null;
	// }

	// // @Override
	// // public TermLoan getTermLoanByTermLoanName(String termloanName) {
	// // try {
	// // TermLoan termloan = termloanRepository.findByTermLoanName(termloanName);
	// // return termloan;
	// // } catch (Exception e) {
	// // log.error("Exception in TermLoanServiceImpl::getTermLoanByTermLoanName======"
	// // + e.getMessage());
	// // }
	// // return null;
	// // }
	// // -modal view
	@Override
	public MFSNGOLoanVO getPreviewMFSNGOLoan(Integer mfsngoLoanId) {
		try {
			MFSNGOLoanVO mfsngoloan = mfsngoloanRepository.getPreviewMFSNGOLoanById(mfsngoLoanId);
			return mfsngoloan;
		} catch (Exception e) {
			log.error("Exception in MFSNGOLoanServiceImpl::getPreviewMFSNGOLoan======" + e.getMessage());
		}
		return null;
	}
	// -modal view

	//--for photo
	@Override
	public Integer updateStampNgoLoan(MFSNGOLoan MFSNGOLoan) {
		try {
			MFSNGOLoan updateStampNgoLoan = mfsngoloanRepository.save(MFSNGOLoan);
			return updateStampNgoLoan.getMfsngoLoanId() != null ? updateStampNgoLoan.getMfsngoLoanId() : -1;
		} catch (Exception e) {
			log.error("Exception in TermLoanServiceImpl::updatePhotoTermLoan======" + e.getMessage());
		}
		return null;
	}
	
	@Override
	public MFSNGOLoanVO getNgoLoanVOsignById(Integer id) {
		try {
			MFSNGOLoanVO mfsngoloan = mfsngoloanRepository.getNgoLoanVOsignById(id);
			return mfsngoloan;
		} catch (Exception e) {
			log.error("Exception in TermLoanServiceImpl::getTermLoanVO======"
					+ e.getMessage());
		}
		return null;
	}
	//--for sign
	@Override
	public Integer updateSignNgoLoan(MFSNGOLoan MFSNGOLoan) {
		try {
			MFSNGOLoan updateSignNgoLoan = mfsngoloanRepository.save(MFSNGOLoan);
			return updateSignNgoLoan.getMfsngoLoanId() != null ? updateSignNgoLoan.getMfsngoLoanId() : -1;
		} catch (Exception e) {
			log.error("Exception in TermLoanServiceImpl::updateSignTermLoan======" + e.getMessage());
		}
		return null;
	}
	
}