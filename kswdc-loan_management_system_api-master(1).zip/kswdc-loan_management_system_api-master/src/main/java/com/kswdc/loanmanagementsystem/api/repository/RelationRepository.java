package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Relation;
import com.kswdc.loanmanagementsystem.api.value.RelationVO;

@Repository
public interface RelationRepository extends JpaRepository<Relation, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.RelationVO(o.relationId,"+
      " o.relationName,o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM Relation o LEFT JOIN User u ON o.createdBy=u.userId LEFT JOIN User mu ON o.createdBy=mu.userId "+
            " WHERE o.isDeleted=0 ORDER BY o.relationName ASC")
   List<RelationVO> getRelationList();//Filter only active relations
    
    @Query("SELECT a from Relation a WHERE a.id=:relationId")
    Relation getRelationById(@Param("relationId") Integer relationId);

    @Query("SELECT cl FROM Relation cl WHERE cl.relationName=:relationName")
    Relation findByRelationName(@Param("relationName") String relationName);
}
