package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.Branch;
import com.kswdc.loanmanagementsystem.api.repository.BranchRepository;
import com.kswdc.loanmanagementsystem.api.value.BranchVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class BranchServiceImpl implements BranchService {
	private final Logger log = LoggerFactory.getLogger(BranchServiceImpl.class);
	
	@Autowired
	private BranchRepository branchRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createBranch(Branch Branch) {
		try {
			Branch savedBranch = branchRepository.save(Branch);
			return savedBranch.getBranchId() != null ? savedBranch.getBranchId() : -1;
		} catch (Exception e) {
			log.error("Exception in BranchServiceImpl::createBranch======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateBranch(Branch Branch) {
		try {
			Branch updateBranch = branchRepository.save(Branch);
			return updateBranch.getBranchId() != null ? updateBranch.getBranchId() : -1;
		} catch (Exception e) {
			log.error("Exception in BranchServiceImpl::updateBranch======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Branch getBranch(Integer id) {
		try {
			Branch branch = branchRepository.getBranchById(id);
			return branch;
		} catch (Exception e) {
			log.error("Exception in BranchServiceImpl::getBranch======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteBranch(Integer id) {
		try {
			Branch Branch = getBranch(id);
//			Branch.setActive(Boolean.FALSE);
			Branch.setDeletedOn(DateFunctions.getZonedServerDate());
			Branch.setIsDeleted(Constants.IS_DELETED);
			Branch updatedBranch = branchRepository.save(Branch);
			return updatedBranch.getBranchId() != null ? updatedBranch.getBranchId() : -1;
		} catch (Exception e) {
			log.error("Exception in BranchServiceImpl::deleteBranch======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<BranchVO> getBranchList() {
		try {
			List<BranchVO> branchList = branchRepository.getBranchList();
			return branchList;
		} catch (Exception e) {
			log.error("Exception in BranchServiceImpl::getBranchList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<BranchVO> getBranchListByBank(Integer bankId) {
		try {
			List<BranchVO> branchList = branchRepository.getBranchListByBank(bankId);
			return branchList;
		} catch (Exception e) {
			log.error("Exception in BranchServiceImpl::getBranchListByBank======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Branch getBranchByBranchName(String branchName) {
		try {
			Branch branch = branchRepository.findByBranchName(branchName);
			return branch;
		} catch (Exception e) {
			log.error("Exception in BranchServiceImpl::getBranchByBranchName======" + e.getMessage());
		}
		return null;
	}
}