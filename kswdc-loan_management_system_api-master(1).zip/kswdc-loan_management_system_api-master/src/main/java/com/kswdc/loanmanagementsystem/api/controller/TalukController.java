package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.Taluk;
import com.kswdc.loanmanagementsystem.api.service.TalukService;
import com.kswdc.loanmanagementsystem.api.value.TalukVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class TalukController {

	private final Logger log = LoggerFactory.getLogger(TalukController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private TalukService talukService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param Taluk Taluk
	 * @return Map
	 */
	@RequestMapping(value = "/taluk", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createTaluk(@RequestBody Taluk Taluk) {
		log.info("In TalukController::createTaluk=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(Taluk)) {
//						Taluk.setActive(Boolean.TRUE);
						Taluk.setCreatedOn(DateFunctions.getZonedServerDate());
						// Taluk.setCreatedBy();
						Taluk.setIsDeleted(0);
						Integer TalukId = talukService.createTaluk(Taluk);
						if (!TalukId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("TalukId", TalukId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TalukController::createTaluk======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param Taluk Taluk
	 * @return Map
	 */
	@RequestMapping(value = "/taluk", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateTaluk(@RequestBody Taluk taluk) {
		log.info("In TalukController::updateTaluk=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (taluk != null) { // && Taluk.getId() != null
				if (checkValid(taluk)) {
					Taluk chkTaluk = talukService.getTaluk(taluk.getTalukId());
					if (chkTaluk!=null) {
//						if (chkTaluk.getActive()) {
//							Taluk.setActive(Boolean.TRUE);
							chkTaluk.setTalukName(taluk.getTalukName());							
							chkTaluk.setIsActive(taluk.getIsActive());							
							Integer TalukId = talukService.updateTaluk(chkTaluk);
							if (!TalukId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("TalukId:", TalukId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" Taluk Id is deactivated:"+Taluk.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TalukController::updateTaluk======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/taluk/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteTaluk(@PathVariable Integer id) {
		log.info("In TalukController::deleteTaluk=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Taluk Taluk = talukService.getTaluk(id);
				if (Taluk != null) {
//					if (!Taluk.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " TalukId:" + id);
//					} else {
						Integer TalukId = talukService.deleteTaluk(id);
						if (!TalukId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("TalukId", TalukId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TalukController::deleteTaluk======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/taluk/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneTaluk(@PathVariable Integer id) {
		log.info("In TalukController::getOneTaluk=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Taluk Taluk = talukService.getTaluk(id);
				if (Taluk != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("Taluk", Taluk);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TalukController::getOneTaluk======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- Taluk ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/taluk-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getTalukList() {
		log.info("In TalukController::getTalukList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			TalukListReturnVO TalukListReturnVO = new TalukListReturnVO(TalukService.getTalukList());
			List<TalukVO> TalukListReturnVO = talukService.getTalukList();
			if (TalukListReturnVO != null && TalukListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("taluks", TalukListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TalukController::getTalukList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Sreelekshmi
	 * @since 21-Feb-2022
	 * @return Map
	 */
	@RequestMapping(value = "/taluk-list-by-district/{districtId}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getTalukListByDistrict(@PathVariable Integer districtId) {
		log.info("In TalukController::getTalukListByDistrict=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			List<TalukVO> TalukListReturnVO = talukService.getTalukListByDistrict(districtId);
			if (TalukListReturnVO != null && TalukListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("taluks", TalukListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TalukController::getTalukListByDistrict======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param TalukId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer TalukId) {
		return (talukService.getTaluk(TalukId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param Taluk
	 * @return Boolean
	 */
	private Boolean checkValid(Taluk Taluk) {
		Boolean isValid = true;
		invalidMsg = "";
		if (Taluk != null) {
//			if(Taluk.getId()==null || Taluk.getId()<=0) {
//				invalidMsg+="TalukId is required and should be valid!";
//				isValid = false;
//			}
			if (Taluk.getTalukName() == null || Taluk.getTalukName().equalsIgnoreCase("")) {
				invalidMsg += "Taluk Name is required and should not be empty!";
				isValid = false;
			}
//			if (Taluk.getTalukName() == null || Taluk.getTalukName().equalsIgnoreCase("")) {
//				invalidMsg += "Taluk Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (Taluk.getQuotaInMB() == null || Taluk.getQuotaInMB().equals(0) || Taluk.getQuotaInMB()<0) {
//				invalidMsg += "Taluk Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (Taluk.getChatHistoryDays() == null || Taluk.getChatHistoryDays().equals(0) || Taluk.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for Taluk is required and should be valid!";
//				isValid = false;
//			}
//			if (Taluk.getCdaTimeoutTime() == null || Taluk.getCdaTimeoutTime().equals(0) || Taluk.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for Taluk!";
			isValid = false;
		}
		return isValid;
	}
	
}
