package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.NgoCredit;
import com.kswdc.loanmanagementsystem.api.value.NgoCreditVO;


@Component
public interface NgoCreditService {

    Integer createNgoCredit(NgoCredit NgoCredit);

    Integer updateNgoCredit(NgoCredit NgoCredit);
    NgoCredit getNgoCredit(Integer id);

    // TLFamilyMember getTLFamilyMemberByTLFamilyMemberName(String tlfamilymemberName);

    Integer deleteNgoCredit(Integer id);

    // List<TLFamilyMemberVO> getTLFamilyMemberList();
}
