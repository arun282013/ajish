package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Sector;
import com.kswdc.loanmanagementsystem.api.value.SectorVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface SectorService {

    Integer createSector(Sector sector);

    Integer updateSector(Sector sector);

    Sector getSector(Integer id);

    Sector getSectorBySectorName(String sectorName);

    Integer deleteSector(Integer id);

    List<SectorVO> getSectorList();
}
