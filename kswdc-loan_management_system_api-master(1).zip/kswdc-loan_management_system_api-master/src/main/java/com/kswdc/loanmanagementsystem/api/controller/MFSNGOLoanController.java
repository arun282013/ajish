package com.kswdc.loanmanagementsystem.api.controller;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.Date;
import java.text.SimpleDateFormat;

import com.kswdc.loanmanagementsystem.api.model.User;
import com.kswdc.loanmanagementsystem.api.service.MFSNGOLoanService;
import com.kswdc.loanmanagementsystem.api.service.UserService;
import com.kswdc.loanmanagementsystem.api.value.MFSNGOLoanVO;

import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;
// import com.kswdc.loanmanagementsystem.api.model.LoanCategory;
import com.kswdc.loanmanagementsystem.api.model.LocalbodyType;
import com.kswdc.loanmanagementsystem.api.model.MFSNGOLoan;
import com.kswdc.loanmanagementsystem.api.model.NgoCredit;
import com.kswdc.loanmanagementsystem.api.model.NgoThrift;
import com.kswdc.loanmanagementsystem.api.model.Ngofinance;
import com.kswdc.loanmanagementsystem.api.model.NgoLending;
import com.kswdc.loanmanagementsystem.api.model.NgoSources;
import com.kswdc.loanmanagementsystem.api.model.NgoAssistance;
import com.kswdc.loanmanagementsystem.api.service.LoanCategoryService;
import com.kswdc.loanmanagementsystem.api.model.LocalBody;
import com.kswdc.loanmanagementsystem.api.service.LocalBodyService;
import com.kswdc.loanmanagementsystem.api.service.LocalbodyTypeService;
import com.kswdc.loanmanagementsystem.api.model.Postoffice;
import com.kswdc.loanmanagementsystem.api.service.PostofficeService;
import com.kswdc.loanmanagementsystem.api.model.Taluk;
import com.kswdc.loanmanagementsystem.api.service.TalukService;
import com.kswdc.loanmanagementsystem.api.model.District;
import com.kswdc.loanmanagementsystem.api.service.DistrictService;
import com.kswdc.loanmanagementsystem.api.model.LoanType;
import com.kswdc.loanmanagementsystem.api.service.LoanTypeService;
import com.kswdc.loanmanagementsystem.api.model.Bank;
import com.kswdc.loanmanagementsystem.api.service.BankService;
import com.kswdc.loanmanagementsystem.api.model.Branch;
import com.kswdc.loanmanagementsystem.api.service.BranchService;

//--third tab
import com.kswdc.loanmanagementsystem.api.model.NgoStaff;
import com.kswdc.loanmanagementsystem.api.service.NgoStaffService;
import com.kswdc.loanmanagementsystem.api.value.NgoStaffVO;

//File upload
import com.kswdc.loanmanagementsystem.api.model.FileInfoNgo;

import com.kswdc.loanmanagementsystem.api.service.FilesStorageService;
import com.kswdc.loanmanagementsystem.api.value.ResponseMessageVO;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;
import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistNgoBeneficiary;
import com.kswdc.loanmanagementsystem.api.service.DocumentChecklistngoService;
import com.kswdc.loanmanagementsystem.api.service.DocumentChecklistNgoBeneficiaryService;
import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistNgo;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistNgoVO;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistNgoBeneficiaryVO;
/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class MFSNGOLoanController {

	private final Logger log = LoggerFactory.getLogger(MFSNGOLoanController.class);
	private String invalidMsg = "";

	@Value("${spring.application.name}")
	private String appName;

	// @Autowired
	// private LoanCategoryService loanCategoryService;

	@Autowired
	private DistrictService districtService;

	@Autowired
	private TalukService talukService;

	@Autowired
	private LocalBodyService localbodyService;

	@Autowired
	private PostofficeService postofficeService;

	@Autowired
	private LoanTypeService loanTypeService;

	
	@Autowired
	private UserService userService;

	@Autowired
	private MFSNGOLoanService mfsngoloanService;

	@Autowired
	private LocalbodyTypeService localbodytypeService;

	@Autowired
	private BankService bankService;

	@Autowired
	private BranchService branchService;

	//--third tab
	@Autowired
	private NgoStaffService staffService;

	@Autowired
	FilesStorageService storageService;

	@Autowired
	private DocumentChecklistngoService documentChecklistngoService;

	@Autowired
	private DocumentChecklistNgoBeneficiaryService documentChecklistngoBeneficiaryService;
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param TermLoan TermLoan
	 * @return Map
	 */
	@RequestMapping(value = "/mfsngoloan", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createMFSNGOLoan(@RequestBody MFSNGOLoanVO MFSNGOLoanVO) {
		log.info("In MFSNGOLoanController::createMFSNGOLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (checkValidVO(MFSNGOLoanVO)) {
				MFSNGOLoan mfsngoloanObj = new MFSNGOLoan();
				mfsngoloanObj.setMfsngoname(MFSNGOLoanVO.getMfsngoname());
				// LoanCategory loanCategoryObj = loanCategoryService.getLoanCategory(MFSNGOLoanVO.getLoancategoryId());
				// mfsngoloanObj.setLoanCategoryObj(loanCategoryObj);
				LoanType loantypeObj = loanTypeService.getLoanType(4);
				mfsngoloanObj.setLoantypeObj(loantypeObj);
				mfsngoloanObj.setMfsngobuildingnumber(MFSNGOLoanVO.getMfsngobuildingnumber());
				District mfsngodistrictObj = districtService.getDistrict(MFSNGOLoanVO.getMfsngodistrictId());
				mfsngoloanObj.setMfsngodistrictObj(mfsngodistrictObj);
				Taluk mfsngotalukObj = talukService.getTaluk(MFSNGOLoanVO.getMfsngotalukId());
				mfsngoloanObj.setMfsngotalukObj(mfsngotalukObj);
				mfsngoloanObj.setMfsngolocation(MFSNGOLoanVO.getMfsngolocation());
				LocalBody mfsngolocalbodyObj = localbodyService.getLocalBody(MFSNGOLoanVO.getMfsngolocalbodyId());
				mfsngoloanObj.setMfsngolocalbodyObj(mfsngolocalbodyObj);
				LocalbodyType mfsngolocalbodytypeObj = localbodytypeService.getLocalbodyType(MFSNGOLoanVO.getMfsngolocalbodytypeId());
				mfsngoloanObj.setMfsngolocalbodytypeObj(mfsngolocalbodytypeObj);
				mfsngoloanObj.setMfsngoplace(MFSNGOLoanVO.getMfsngoplace());
				Postoffice mfsngopostofficeObj = postofficeService.getPostoffice(MFSNGOLoanVO.getMfsngopostofficeId());
				mfsngoloanObj.setMfsngopostofficeObj(mfsngopostofficeObj);
				mfsngoloanObj.setMfsngoPincode(MFSNGOLoanVO.getMfsngoPincode());
				mfsngoloanObj.setMfsngophonenumber(MFSNGOLoanVO.getMfsngophonenumber());
				mfsngoloanObj.setMfsngofaxnumber(MFSNGOLoanVO.getMfsngofaxnumber());
				mfsngoloanObj.setMfsngoregistrationnumber(MFSNGOLoanVO.getMfsngoregistrationnumber());
				mfsngoloanObj.setMfsngodor(MFSNGOLoanVO.getMfsngodor());
				mfsngoloanObj.setMfsngodorenewal(MFSNGOLoanVO.getMfsngodorenewal());
				mfsngoloanObj.setMfsngoareaofoperation(MFSNGOLoanVO.getMfsngoareaofoperation());
				

				Bank bankobj = bankService.getBank(MFSNGOLoanVO.getBankId());
				mfsngoloanObj.setBankObj(bankobj);

				Branch branchobj = branchService.getBranch(MFSNGOLoanVO.getBranchId());
				mfsngoloanObj.setBranchObj(branchobj);

				mfsngoloanObj.setIfsc(MFSNGOLoanVO.getIfsc());

				mfsngoloanObj.setMfsngoaccountnumber(MFSNGOLoanVO.getMfsngoaccountnumber());
				mfsngoloanObj.setMfsngochieffunctionary(MFSNGOLoanVO.getMfsngochieffunctionary());
				mfsngoloanObj.setMfsngodesigchieffunctionary(MFSNGOLoanVO.getMfsngodesigchieffunctionary());
				mfsngoloanObj.setCreatedOn(DateFunctions.getZonedServerDate());
				User createdBy = userService.getUser(MFSNGOLoanVO.getCreatedById());
				mfsngoloanObj.setCreatedBy(createdBy);
				mfsngoloanObj.setCreatedBy(createdBy);
				mfsngoloanObj.setUserObj(createdBy);
				mfsngoloanObj.setIsDeleted(0);
				mfsngoloanObj.setIsActive(1);

				Integer MFSNGOLoanId = mfsngoloanService.createMFSNGOLoan(mfsngoloanObj);
				if (!MFSNGOLoanId.equals(-1)) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("MFSNGOLoanId", MFSNGOLoanId);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
					retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
			}

		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSNGOLoanController::createMFSNGOLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 *        //@param TermLoan TermLoan
	 * @return Map
	 */
	@RequestMapping(value = "/mfsngoloan", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateMFSNGOLoan(@RequestBody MFSNGOLoanVO mfsngoloanVO) {
		log.info("In MFSNGOLoanController::updateMFSNGOLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (mfsngoloanVO != null) { // && TermLoan.getId() != null
				if (checkValidVO(mfsngoloanVO)) {
					MFSNGOLoan chkMFSNGOLoan = mfsngoloanService.getMFSNGOLoan(mfsngoloanVO.getMfsngoLoanId());
					if (chkMFSNGOLoan != null) {
						// if (chkTermLoan.getActive()) {
						// TermLoan.setActive(Boolean.TRUE);
						// chkTermLoan.setTermLoanName(termloan.getTermLoanName());
						// TermLoan termloanObj = new TermLoan();
						// chkTermLoan.setTermLoanId(termloanVO.getTermLoanId());
						// --for updation march 3
						// TermLoan termloanObj = new TermLoan();
						chkMFSNGOLoan.setMfsngoname(mfsngoloanVO.getMfsngoname());
						LoanType loantypeObj = loanTypeService.getLoanType(4);
						chkMFSNGOLoan.setLoantypeObj(loantypeObj);
						chkMFSNGOLoan.setMfsngobuildingnumber(mfsngoloanVO.getMfsngobuildingnumber());
						District mfsngodistrictObj = districtService.getDistrict(mfsngoloanVO.getMfsngodistrictId());
						chkMFSNGOLoan.setMfsngodistrictObj(mfsngodistrictObj);
						Taluk mfsngotalukObj = talukService.getTaluk(mfsngoloanVO.getMfsngotalukId());
						chkMFSNGOLoan.setMfsngotalukObj(mfsngotalukObj);
						chkMFSNGOLoan.setMfsngolocation(mfsngoloanVO.getMfsngolocation());
						LocalBody mfsngolocalbodyObj = localbodyService.getLocalBody(mfsngoloanVO.getMfsngolocalbodyId());
						chkMFSNGOLoan.setMfsngolocalbodyObj(mfsngolocalbodyObj);
						LocalbodyType mfsngolocalbodytypeObj = localbodytypeService.getLocalbodyType(mfsngoloanVO.getMfsngolocalbodytypeId());
						chkMFSNGOLoan.setMfsngolocalbodytypeObj(mfsngolocalbodytypeObj);
						chkMFSNGOLoan.setMfsngoplace(mfsngoloanVO.getMfsngoplace());
						Postoffice mfsngopostofficeObj = postofficeService.getPostoffice(mfsngoloanVO.getMfsngopostofficeId());
						chkMFSNGOLoan.setMfsngopostofficeObj(mfsngopostofficeObj);
						chkMFSNGOLoan.setMfsngoPincode(mfsngoloanVO.getMfsngoPincode());
						chkMFSNGOLoan.setMfsngophonenumber(mfsngoloanVO.getMfsngophonenumber());
						chkMFSNGOLoan.setMfsngofaxnumber(mfsngoloanVO.getMfsngofaxnumber());
						chkMFSNGOLoan.setMfsngoregistrationnumber(mfsngoloanVO.getMfsngoregistrationnumber());
						chkMFSNGOLoan.setMfsngodor(mfsngoloanVO.getMfsngodor());
						chkMFSNGOLoan.setMfsngodorenewal(mfsngoloanVO.getMfsngodorenewal());
						chkMFSNGOLoan.setMfsngoareaofoperation(mfsngoloanVO.getMfsngoareaofoperation());
						Bank bankobj = bankService.getBank(mfsngoloanVO.getBankId());
						chkMFSNGOLoan.setBankObj(bankobj);
		
						Branch branchobj = branchService.getBranch(mfsngoloanVO.getBranchId());
						chkMFSNGOLoan.setBranchObj(branchobj);
		
						chkMFSNGOLoan.setIfsc(mfsngoloanVO.getIfsc());
		
						chkMFSNGOLoan.setMfsngoaccountnumber(mfsngoloanVO.getMfsngoaccountnumber());
						chkMFSNGOLoan.setMfsngochieffunctionary(mfsngoloanVO.getMfsngochieffunctionary());
						chkMFSNGOLoan.setMfsngodesigchieffunctionary(mfsngoloanVO.getMfsngodesigchieffunctionary());



						
						User modifiedBy = userService.getUser(mfsngoloanVO.getModifiedById());
						chkMFSNGOLoan.setModifiedBy(modifiedBy);
						
						Integer MFSNGOLoanId = mfsngoloanService.updateMFSNGOLoan(chkMFSNGOLoan);
						if (!MFSNGOLoanId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("MFSNGOLoanId:", MFSNGOLoanId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
						// } else {
						// retMap = new HashMap<String, Object>();
						// retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						// retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						// retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
						// rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+"
						// TermLoan Id is deactivated:"+TermLoan.getId());
						// }

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSNGOLoanController::updateMFSNGOLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// /**
	//  * @author Arun
	//  * @since 22-Apr-2021
	//  *        //@param TermLoan TermLoan
	//  * @return Map
	//  */
	@RequestMapping(value = "/updateSecondTabMFSNGOLoan", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateSecondTabMFSNGOLoan(@RequestBody MFSNGOLoanVO mfsngoloanVO) {
		log.info("In MFSNGOLoanController::updateSecondTabMFSNGOLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (mfsngoloanVO != null) { // && TermLoan.getId() != null
				if (checkValidVO(mfsngoloanVO)) {
					//MFSNGOLoan chkMFSNGOLoan = mfsngoloanService.getMFSNGOLoan(4);

					 MFSNGOLoan chkMFSNGOLoan = mfsngoloanService.getMFSNGOLoan(mfsngoloanVO.getMfsngoLoanId());
					if (chkMFSNGOLoan != null) {
						
						Set<Ngofinance> ngoFinances = new HashSet<Ngofinance>();
						String ngoFinancesStr = mfsngoloanVO.getNgoFinances();
						if (ngoFinancesStr != null && ngoFinancesStr != "") {
							JSONArray jsonArray = new JSONArray(ngoFinancesStr);
							for (int i = 0; i < jsonArray.length(); i++) {
								JSONObject jsonObject = jsonArray.getJSONObject(i);
								String financeYear = jsonObject.getString("financeYear");
								String programName = jsonObject.getString("programName");
								String fundedBy = jsonObject.getString("fundedBy");
								Double amountReceived = jsonObject.getDouble("amountReceived");
								String achievements = jsonObject.getString("achievements");
							
								Ngofinance ngofinance = new Ngofinance();
								ngofinance.setFinanceYear(financeYear);
								ngofinance.setProgramName(programName);
								ngofinance.setFundedBy(fundedBy);
								ngofinance.setAmountReceived(amountReceived);
								ngofinance.setAchievements(achievements);
							
								ngoFinances.add(ngofinance);
								
							}
							chkMFSNGOLoan.setNgoFinances(ngoFinances);
						}

						//---Ngo Credit

						Set<NgoCredit> ngoCredits = new HashSet<NgoCredit>();
						String ngoCreditsStr = mfsngoloanVO.getNgoCredits();
						if (ngoCreditsStr != null && ngoCreditsStr != "") {
							JSONArray jsonArray = new JSONArray(ngoCreditsStr);
							for (int i = 0; i < jsonArray.length(); i++) {
								JSONObject jsonObject = jsonArray.getJSONObject(i);
								String year = jsonObject.getString("year");
								String activities = jsonObject.getString("activities");
								Integer noofShgs = jsonObject.getInt("noofShgs");
								Integer noofBorrowers = jsonObject.getInt("noofBorrowers");
								Double loanAmount = jsonObject.getDouble("loanAmount");
								Double loanamountDue = jsonObject.getDouble("loanamountDue");
								Double loanamountRecovered = jsonObject.getDouble("loanamountRecovered");
								Double percentageofRecovery = jsonObject.getDouble("percentageofRecovery");
								String sourceFund = jsonObject.getString("sourceFund");
							
								NgoCredit ngocredit = new NgoCredit();

								ngocredit.setYear(year);
								ngocredit.setActivities(activities);
								ngocredit.setNoofShgs(noofShgs);
								ngocredit.setNoofBorrowers(noofBorrowers);
								ngocredit.setLoanAmount(loanAmount);
								ngocredit.setLoanamountDue(loanamountDue);
								ngocredit.setLoanamountRecovered(loanamountRecovered);
								ngocredit.setPercentageofRecovery(percentageofRecovery);
								ngocredit.setSourceFund(sourceFund);

								ngoCredits.add(ngocredit);
								
							}
							chkMFSNGOLoan.setNgoCredits(ngoCredits);
							
						}

						//--ngo Credit End

						//--ngo Thrift-----
						Set<NgoThrift> NgoThrift = new HashSet<NgoThrift>();
						String NgoThriftStr = mfsngoloanVO.getNgoThrift();
						if (NgoThriftStr != null && NgoThriftStr != "") {
							JSONArray jsonArray = new JSONArray(NgoThriftStr);
							for (int i = 0; i < jsonArray.length(); i++) {
								JSONObject jsonObject = jsonArray.getJSONObject(i);
								String nameandaddress = jsonObject.getString("nameandaddress");
								//----------
								// Date dteformation = jsonObject.("dteformation");
								String dateStr = jsonObject.getString("dteformation");
								SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
								Date dateFormation = sdf.parse(dateStr);
								//-------------
								Integer members = jsonObject.getInt("members");
								String savings = jsonObject.getString("savings");
								String outofsavings = jsonObject.getString("outofsavings");
								Integer amtrecovered = jsonObject.getInt("amtrecovered");
								Integer amtoutstanding = jsonObject.getInt("amtoutstanding");

							
								NgoThrift ngothrift = new NgoThrift();
								ngothrift.setNameandaddress(nameandaddress);
								ngothrift.setDteformation(dateFormation);
								ngothrift.setMembers(members);
								ngothrift.setSavings(savings);
								ngothrift.setOutofsavings(outofsavings);
								ngothrift.setAmtrecovered(amtrecovered);
								ngothrift.setAmtoutstanding(amtoutstanding);

															
								NgoThrift.add(ngothrift);
								
							}
							chkMFSNGOLoan.setNgoThrift(NgoThrift);
						}

						//ngo end

						//--ngo Lending-----
						Set<NgoLending> NgoLending = new HashSet<NgoLending>();
						String NgoLendingStr = mfsngoloanVO.getNgoLending();
						if (NgoLendingStr != null && NgoLendingStr != "") {
							JSONArray jsonArray = new JSONArray(NgoLendingStr);
							for (int i = 0; i < jsonArray.length(); i++) {
								JSONObject jsonObject = jsonArray.getJSONObject(i);
								String category = jsonObject.getString("category");
								String activities = jsonObject.getString("activities");
								Integer noofshgs = jsonObject.getInt("noofshgs");
								Integer noofborrowers = jsonObject.getInt("noofborrowers");
								Double avgloanamt = jsonObject.getDouble("avgloanamt");
								Double totamt = jsonObject.getDouble("totamt");
							
							
								NgoLending ngoLending = new NgoLending();
								ngoLending.setCategory(category);
								ngoLending.setActivities(activities);
								ngoLending.setNoofshgs(noofshgs);
								ngoLending.setNoofborrowers(noofborrowers);
								ngoLending.setAvgloanamt(avgloanamt);
								ngoLending.setTotamt(totamt);
															
								NgoLending.add(ngoLending);
								
							}
							chkMFSNGOLoan.setNgoLending(NgoLending);
						}

						//ngo end

						//--ngo sources-----
						Set<NgoSources> NgoSources = new HashSet<NgoSources>();
						String NgoSourcesStr = mfsngoloanVO.getNgoSources();
						if (NgoSourcesStr != null && NgoSourcesStr != "") {
							JSONArray jsonArray = new JSONArray(NgoSourcesStr);
							for (int i = 0; i < jsonArray.length(); i++) {
								JSONObject jsonObject = jsonArray.getJSONObject(i);
								String sourcesname = jsonObject.getString("sourcesname");
								Double balance = jsonObject.getDouble("balance");
								Double amtexpected = jsonObject.getDouble("amtexpected");
								Double totalamt = jsonObject.getDouble("totalamt");
								
							
								NgoSources ngoSources = new NgoSources();
								ngoSources.setSourcesname(sourcesname);
								ngoSources.setBalance(balance);
								ngoSources.setAmtexpected(amtexpected);
								ngoSources.setTotalamt(totalamt);
								
								NgoSources.add(ngoSources);
								
							}
							chkMFSNGOLoan.setNgoSources(NgoSources);
						}

						//ngo end
	//--ngo assistance-----
	Set<NgoAssistance> NgoAssistance = new HashSet<NgoAssistance>();
	String NgoAssistanceStr = mfsngoloanVO.getNgoAssistance();
	if (NgoAssistanceStr != null && NgoAssistanceStr != "") {
		JSONArray jsonArray = new JSONArray(NgoAssistanceStr);
		for (int i = 0; i < jsonArray.length(); i++) {
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			String category = jsonObject.getString("category");
			String activities = jsonObject.getString("activities");
			int noofshgs = jsonObject.getInt("noofshgs");
			int noofborrowers = jsonObject.getInt("noofborrowers");
			Double avgamt = jsonObject.getDouble("avgamt");
			Double amtrequired = jsonObject.getDouble("amtrequired");
		
			NgoAssistance ngoAssistance = new NgoAssistance();
			ngoAssistance.setCategory(category);
			ngoAssistance.setActivities(activities);
			ngoAssistance.setNoofshgs(noofshgs);
			ngoAssistance.setNoofborrowers(noofborrowers);
			ngoAssistance.setAvgamt(avgamt);
			ngoAssistance.setAmtrequired(amtrequired);

			NgoAssistance.add(ngoAssistance);
			
		}
		chkMFSNGOLoan.setNgoAssistance(NgoAssistance);
	}

	//ngo end
						
						//--17-03-2022
						chkMFSNGOLoan.setMfsngodofinancialbalance(mfsngoloanVO.getMfsngodofinancialbalance());
						chkMFSNGOLoan.setMfsngofixedasset(mfsngoloanVO.getMfsngofixedasset());
						chkMFSNGOLoan.setMfsngocurrentasset(mfsngoloanVO.getMfsngocurrentasset());
						chkMFSNGOLoan.setMfsngoborrowings(mfsngoloanVO.getMfsngoborrowings());
						chkMFSNGOLoan.setMfsngootherliability(mfsngoloanVO.getMfsngootherliability());
						

						Integer MFSNGOLoanId = mfsngoloanService.updateMFSNGOLoan(chkMFSNGOLoan);
						if (!MFSNGOLoanId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("MFSNGOLoanId:", MFSNGOLoanId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
						// } else {
						// retMap = new HashMap<String, Object>();
						// retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						// retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						// retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
						// rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+"
						// TermLoan Id is deactivated:"+TermLoan.getId());
						// }

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSNGOLoanController::updateSecondTabMFSNGOLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

//third tab
/**
	//  * @author Arun
	//  * @since 22-Apr-2021
	//  *        //@param TermLoan TermLoan
	//  * @return Map
	//  */
	@RequestMapping(value = "/updateThirdTabMFSNGOLoan", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateThirdTabMFSNGOLoan(@RequestBody MFSNGOLoanVO mfsngoloanVO) {
		log.info("In MFSNGOLoanController::updateThirdTabMFSNGOLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (mfsngoloanVO != null) { // && TermLoan.getId() != null
				if (checkValidVO(mfsngoloanVO)) {
					//MFSNGOLoan chkMFSNGOLoan = mfsngoloanService.getMFSNGOLoan(4);

					 MFSNGOLoan chkMFSNGOLoan = mfsngoloanService.getMFSNGOLoan(mfsngoloanVO.getMfsngoLoanId());
					if (chkMFSNGOLoan != null) {
					 	
						
						Set<NgoStaff> NgoStaff = new HashSet<NgoStaff>();
						
						
                    	String NgoStaffStr = mfsngoloanVO.getNgoStaff();
					if (NgoStaffStr != null && NgoStaffStr != "") {
						JSONArray jsonArray = new JSONArray(NgoStaffStr);
						for (int i = 0; i < jsonArray.length(); i++) {
							JSONObject jsonObject = jsonArray.getJSONObject(i);
							int officetrained = jsonObject.getInt("officetrained");
							int officeuntrained = jsonObject.getInt("officeuntrained");
							int fieldtrained = jsonObject.getInt("fieldtrained");
							int fielduntrained = jsonObject.getInt("fielduntrained");
							int officestafftotal = jsonObject.getInt("officestafftotal");
							int fieldstafftotal = jsonObject.getInt("fieldstafftotal");

		
								NgoStaff ngoStff = new NgoStaff();
								ngoStff.setOfficetrained(officetrained);
								ngoStff.setOfficeuntrained(officeuntrained);
								ngoStff.setOfficestafftotal(officestafftotal);
								ngoStff.setFieldtrained(fieldtrained);
								ngoStff.setFielduntrained(fielduntrained);
								ngoStff.setFieldstafftotal(fieldstafftotal);


								NgoStaff.add(ngoStff);
			
					}
					chkMFSNGOLoan.setNgoStaff(NgoStaff);
				}


						Integer MFSNGOLoanId = mfsngoloanService.updateMFSNGOLoan(chkMFSNGOLoan);
						if (!MFSNGOLoanId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("MFSNGOLoanId:", MFSNGOLoanId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
						// } else {
						// retMap = new HashMap<String, Object>();
						// retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						// retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						// retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
						// rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+"
						// TermLoan Id is deactivated:"+TermLoan.getId());
						// }

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSNGOLoanController::updateThirdTabMFSNGOLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}
	

	// /**
	//  * @author Arun
	//  * @since 22-Apr-2021
	//  * @param Integer id
	//  * @return Map
	//  */
	// @RequestMapping(value = "/termloan/{id}", method = RequestMethod.DELETE)
	// @Produces("application/json")
	// public Map deleteTermLoan(@PathVariable Integer id) {
	// 	log.info("In TermLoanController::deleteTermLoan=============");
	// 	Map<String, Object> retMap = new HashMap<String, Object>();
	// 	try {
	// 		if (id != null) {
	// 			TermLoan TermLoan = termloanService.getTermLoan(id);
	// 			if (TermLoan != null) {
	// 				// if (!TermLoan.getActive()) {
	// 				// retMap = new HashMap<String, Object>();
	// 				// retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
	// 				// retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
	// 				// retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
	// 				// rabbitMqService.sendEvent(appName,
	// 				// Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + "
	// 				// TermLoanId:" + id);
	// 				// } else {
	// 				Integer TermLoanId = termloanService.deleteTermLoan(id);
	// 				if (!TermLoanId.equals(-1)) {
	// 					retMap = new HashMap<String, Object>();
	// 					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
	// 					retMap.put("TermLoanId", TermLoanId);
	// 					return retMap;
	// 				} else {
	// 					retMap = new HashMap<String, Object>();
	// 					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
	// 					retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
	// 					retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
	// 				}
	// 				// }
	// 			} else {
	// 				retMap = new HashMap<String, Object>();
	// 				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
	// 				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
	// 				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
	// 			}
	// 		} else {
	// 			retMap = new HashMap<String, Object>();
	// 			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
	// 			retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
	// 			retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
	// 		}
	// 	} catch (Exception e) {
	// 		retMap = new HashMap<String, Object>();
	// 		retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
	// 		retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
	// 		retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
	// 		log.error("Exception in TermLoanController::deleteTermLoan======" + e.getMessage());
	// 		e.printStackTrace();
	// 	}
	// 	return retMap;
	// }

	// /**
	//  * @author Arun
	//  * @since 22-Apr-2021
	//  * @param Integer id
	//  * @return Map
	//  */
	// @RequestMapping(value = "/termloan/{id}", method = RequestMethod.GET)
	// @Produces("application/json")
	// public Map getOneTermLoan(@PathVariable Integer id) {
	// 	log.info("In TermLoanController::getOneTermLoan=============");
	// 	Map<String, Object> retMap = new HashMap<String, Object>();
	// 	try {
	// 		if (id != null) {
	// 			TermLoan TermLoan = termloanService.getTermLoan(id);
	// 			if (TermLoan != null) {
	// 				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
	// 				retMap.put("TermLoan", TermLoan);
	// 			} else {
	// 				retMap = new HashMap<String, Object>();
	// 				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
	// 				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
	// 				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
	// 			}
	// 		} else {
	// 			retMap = new HashMap<String, Object>();
	// 			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
	// 			retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
	// 			retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
	// 		}
	// 	} catch (Exception e) {
	// 		retMap = new HashMap<String, Object>();
	// 		retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
	// 		retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
	// 		retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
	// 		log.error("Exception in TermLoanController::getOneTermLoan======" + e.getMessage());
	// 		e.printStackTrace();
	// 	}
	// 	return retMap;
	// }

	/**
	 * @author Arun
	 * @since 14-Mar-2022
	 * @param Integer userId
	 * @return Map
	 */
	@RequestMapping(value = "/mfsngoloan-by-user/{userId}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneMFSNGOByUser(@PathVariable Integer userId) {
		log.info("In MFSNGOLoanController::getOneMFSNGOLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (userId != null) {
				MFSNGOLoanVO MFSNGOLoanVo = mfsngoloanService.getMFSNGOLoanByUser(userId);
				if (MFSNGOLoanVo != null) {

					MFSNGOLoan mfsngoloan = mfsngoloanService.getMFSNGOLoan(MFSNGOLoanVo.getMfsngoLoanId());
					Set<Ngofinance> NgofinanceVOs = mfsngoloan.getNgoFinances();
					MFSNGOLoanVo.setNgofinanceLst(NgofinanceVOs);

					Set<NgoCredit> NgocreditVOs = mfsngoloan.getNgoCredits();
					MFSNGOLoanVo.setNgocreditLst(NgocreditVOs);

					Set<NgoThrift> NgothriftVOs = mfsngoloan.getNgoThrift();
					MFSNGOLoanVo.setNgothriftLst(NgothriftVOs);

					Set<NgoLending> NgolendingVOs = mfsngoloan.getNgoLending();
					MFSNGOLoanVo.setNgolendingLst(NgolendingVOs);

					Set<NgoSources> NgosourcesVOs = mfsngoloan.getNgoSources();
					MFSNGOLoanVo.setNgosourcesLst(NgosourcesVOs);

					Set<NgoAssistance> NgoassistancesVOs = mfsngoloan.getNgoAssistance();
					MFSNGOLoanVo.setNgoassistanceLst(NgoassistancesVOs);

					Set<NgoStaff> NgostaffsVOs = mfsngoloan.getNgoStaff();
					MFSNGOLoanVo.setNgostaffLst(NgostaffsVOs);

					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("MFSNGOLoan", MFSNGOLoanVo);

					

				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSNGOLoanController::getOneMFSNGOLoanByUser======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// // End: ---------- TermLoan ------------------------------

	// /**
	//  * @author Arun
	//  * @since 22-Apr-2021
	//  * @return Map
	//  */
	// @RequestMapping(value = "/termloan-list", method = RequestMethod.GET)
	// @Produces("application/json")
	// public Map getTermLoanList() {
	// 	log.info("In TermLoanController::getTermLoanList=============");
	// 	Map<String, Object> retMap = new HashMap<String, Object>();
	// 	try {
	// 		// TermLoanListReturnVO TermLoanListReturnVO = new
	// 		// TermLoanListReturnVO(TermLoanService.getTermLoanList());
	// 		List<TermLoanVO> TermLoanListReturnVO = termloanService.getTermLoanList();
	// 		if (TermLoanListReturnVO != null && TermLoanListReturnVO.size() > 0) {
	// 			retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
	// 			retMap.put("termloans", TermLoanListReturnVO);
	// 		} else {
	// 			retMap = new HashMap<String, Object>();
	// 			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
	// 			retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
	// 			retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
	// 		}
	// 	} catch (Exception e) {
	// 		retMap = new HashMap<String, Object>();
	// 		retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
	// 		retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
	// 		retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
	// 		log.error("Exception in TermLoanController::getTermLoanList======" + e.getMessage());
	// 		e.printStackTrace();
	// 	}
	// 	return retMap;
	// }

	// /**
	//  * @author Arun
	//  * @since 22-Apr-2021
	//  * @param TermLoanId
	//  * @return Boolean
	//  */

	// private Boolean checkIfExists(Integer TermLoanId) {
	// 	return (termloanService.getTermLoan(TermLoanId) != null) ? Boolean.TRUE : Boolean.FALSE;
	// }

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param MFSNGOLoan
	 * @return Boolean
	 */
	private Boolean checkValidVO(MFSNGOLoanVO MFSNGOLoanVO) {
		Boolean isValid = true;
		invalidMsg = "";
		if (MFSNGOLoanVO != null) {
 	} else {
			invalidMsg = "Received data is not valid for MFSNGOLoan!";
			isValid = false;
		}
		return isValid;
	}

	// // --modal view
	@RequestMapping(value = "/previewmfsngoloan/{mfsngoLoanId}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOnePreviewMFSNGOLoan(@PathVariable Integer mfsngoLoanId) {
		log.info("In MFSNGOLoanController::getOnePreviewMFSNGOLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			MFSNGOLoanVO PreviewMFSNGOLoanReturnVO = mfsngoloanService.getPreviewMFSNGOLoan(mfsngoLoanId);
			if (PreviewMFSNGOLoanReturnVO != null) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("mfsngoloan", PreviewMFSNGOLoanReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSNGOLoanController::getOnePreviewMFSNGOLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}
	// --------//

	//----Upload----//
@PostMapping("/ngoUpload")
	public ResponseEntity<ResponseMessageVO> uploadNgoFile(@RequestParam("file") MultipartFile file,
			@RequestParam("docType") String docType, @RequestParam("docChecklistId") Integer docChecklistngoId,
			@RequestParam("loanTypeId") Integer loanTypeId, @RequestParam("mfsngoLoanId") Integer mfsngoLoanId) {
		String message = "";
		String fileName = "";
		try {
			if (docType.equals("NGOCHK")) {
				String savedFileName = storageService.save(file, 4,
						loanTypeId + "_" + mfsngoLoanId + "_" + docChecklistngoId);
				if (savedFileName != null && !savedFileName.equals("")) {
					DocumentChecklistNgoBeneficiary checklistngoBeneficiary = new DocumentChecklistNgoBeneficiary();
					LoanType loanTypeObj = loanTypeService.getLoanType(loanTypeId);
					MFSNGOLoan mfsngoLoanObj = mfsngoloanService.getMFSNGOLoan(mfsngoLoanId);
					DocumentChecklistNgo documentChecklistngo = documentChecklistngoService.getDocumentChecklistngo(docChecklistngoId);
					checklistngoBeneficiary.setLoanTypeObj(loanTypeObj);
					checklistngoBeneficiary.setMfsngoLoanObj(mfsngoLoanObj);
					checklistngoBeneficiary.setDocumentChecklistngoObj(documentChecklistngo);
					checklistngoBeneficiary.setFilePath(savedFileName);
					documentChecklistngoBeneficiaryService.createDocumentChecklistngoBeneficiary(checklistngoBeneficiary);
				} else {
					return ResponseEntity.status(HttpStatus.NOT_MODIFIED)
							.body(new ResponseMessageVO("Could not upload document!", fileName));
				}
			} else {
				return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE)
						.body(new ResponseMessageVO("Loan type not got!", fileName));
			}
			message = "Uploaded the file successfully: " + file.getOriginalFilename();
			fileName = file.getOriginalFilename();
			return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessageVO(message, fileName));
		} catch (Exception e) {
			e.printStackTrace();
			message = "Could not upload the file: " + file.getOriginalFilename() + "! " + e.getMessage();
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessageVO(message, fileName));
		}
	}

	@GetMapping("/ngoChkDocs/{mfsngoLoanId}")
	public ResponseEntity<List<FileInfoNgo>> getMFSNGOLoanChecklistDocs(@PathVariable Integer mfsngoLoanId) {
		// Map<String,String> docInfo = new HashMap<String,String>();
		List<FileInfoNgo> docs = new ArrayList<FileInfoNgo>();
		List<DocumentChecklistNgoBeneficiaryVO> checklistngoBeneficiaries = documentChecklistngoBeneficiaryService
				.getDocumentChecklistngoBeneficiaryByMFSNGOLoanId(mfsngoLoanId);
		if (checklistngoBeneficiaries != null && checklistngoBeneficiaries.size() > 0) {
			for (DocumentChecklistNgoBeneficiaryVO documentChecklistngoBeneficiaryVo : checklistngoBeneficiaries) {
				Integer docChkBenId = documentChecklistngoBeneficiaryVo.getDocChecklistngoBeneficiaryId();
				String name = documentChecklistngoBeneficiaryVo.getDocumentChecklistngoName();
				String url = MvcUriComponentsBuilder
						.fromMethodName(MFSNGOLoanController.class, "getDoc",
								documentChecklistngoBeneficiaryVo.getDocChecklistngoBeneficiaryId())
						.build()
						.toString();
				FileInfoNgo docInfo = new FileInfoNgo(docChkBenId, name, url);
				docs.add(docInfo);
			}
		} else {
			return ResponseEntity.status(HttpStatus.OK).body(docs);
		}
		// List<FileInfo> fileInfos = storageService.loadAll().map(path -> {
		// String filename = path.getFileName().toString();
		// String url = MvcUriComponentsBuilder
		// .fromMethodName(TermLoanController.class, "getFile",
		// path.getFileName().toString()).build()
		// .toString();
		// return new FileInfo(filename, url);
		// }).collect(Collectors.toList());
		return ResponseEntity.status(HttpStatus.OK).body(docs);
	}

	@GetMapping("/getNgoDoc/{docId}")
	@ResponseBody
	public ResponseEntity<Resource> getDoc(@PathVariable Integer docId) {
		DocumentChecklistNgoBeneficiaryVO documentChecklistngoBeneficiary = documentChecklistngoBeneficiaryService
				.getDocumentChecklistngoBeneficiaryVO(docId);
		if (documentChecklistngoBeneficiary != null) {
			String fileName = documentChecklistngoBeneficiary.getFilePath();
			Resource file = storageService.loadngo(fileName,
					documentChecklistngoBeneficiary.getLoanTypeId());
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
					.body(file);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

//--for Stamp

@RequestMapping(value = "/updateStampNgoLoan", method = RequestMethod.PUT)
@Produces("application/json")
public Map updateStampNgoLoan(@RequestBody MFSNGOLoanVO mfsngoloanVO) {
	log.info("In TermLoanController::updatePhotoTermLoan=============");
	Map<String, Object> retMap = new HashMap<String, Object>();
	try {
		if (mfsngoloanVO != null) {
			if (checkValidVO(mfsngoloanVO)) {
				MFSNGOLoan chkmfsngoLoan = mfsngoloanService.getMFSNGOLoan(mfsngoloanVO.getMfsngoLoanId());
				if (chkmfsngoLoan != null) {
					chkmfsngoLoan.setStampPath(mfsngoloanVO.getStampPath());
					Integer MFSNGOLoanId = mfsngoloanService.updateMFSNGOLoan(chkmfsngoLoan);
					if (!MFSNGOLoanId.equals(-1)) {
						retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
						retMap.put("MFSNGOLoanId:", MFSNGOLoanId);
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
						retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
					}
					

				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
			}
		} else {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
			retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
		}
	} catch (Exception e) {
		retMap = new HashMap<String, Object>();
		retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
		retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
		retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
		log.error("Exception in TermLoanController::updatePhotoTermLoan======" + e.getMessage());
		e.printStackTrace();
	}
	return retMap;
}

@PostMapping("/uploadstamp")
public ResponseEntity<ResponseMessageVO> uploadstamp(@RequestParam("file") MultipartFile file,
		@RequestParam("docType") String docType, 
		@RequestParam("loanTypeId") Integer loanTypeId, @RequestParam("mfsngoLoanId") Integer mfsngoLoanId) {
	String message = "";
	String fileName = "";
	try {
		if (docType.equals("NGOSTP")) {
			String savedFileName = storageService.savestampngo(file, 1,
					loanTypeId + "_" + mfsngoLoanId);
			if (savedFileName != null && !savedFileName.equals("")) {
				MFSNGOLoanVO mfsngoloanVO=new MFSNGOLoanVO();
				MFSNGOLoan chkmfsngoLoan = mfsngoloanService.getMFSNGOLoan(mfsngoLoanId);
				if (chkmfsngoLoan != null) {
				
					chkmfsngoLoan.setStampPath(savedFileName);
				mfsngoloanService.updateStampNgoLoan(chkmfsngoLoan);
				}
			} else {
				return ResponseEntity.status(HttpStatus.NOT_MODIFIED)
						.body(new ResponseMessageVO("Could not upload photo!", fileName));
			}
		} else {
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE)
					.body(new ResponseMessageVO("Loan type not got!", fileName));
		}
		message = "Uploaded the photo successfully: " + file.getOriginalFilename();
		fileName = file.getOriginalFilename();
		return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessageVO(message, fileName));
	} catch (Exception e) {
		e.printStackTrace();
		message = "Could not upload the photo: " + file.getOriginalFilename() + "! " + e.getMessage();
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessageVO(message, fileName));
	}
}

@GetMapping("/getstmp/{ngoId}")
@ResponseBody
public ResponseEntity<Resource> getStamp(@PathVariable Integer ngoId) {
	MFSNGOLoanVO ngostamp = mfsngoloanService.getNgoLoanVOsignById(ngoId);
	if (ngostamp != null) {
		String fileName = ngostamp.getStampPath();
		Resource file = storageService.loadstampngo(fileName,ngostamp.getLoantypeId());
		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
				.body(file);
	} else {
		return ResponseEntity.notFound().build();
	}
}

//--for sign

@RequestMapping(value = "/updateSignNgoLoan", method = RequestMethod.PUT)
@Produces("application/json")
public Map updateSignNgoLoan(@RequestBody MFSNGOLoanVO mfsngoloanVO) {
	log.info("In MFSNGOLoanController::updateSignNgoLoan=============");
	Map<String, Object> retMap = new HashMap<String, Object>();
	try {
		if (mfsngoloanVO != null) {
			if (checkValidVO(mfsngoloanVO)) {
				MFSNGOLoan chkmfsngoLoan = mfsngoloanService.getMFSNGOLoan(mfsngoloanVO.getMfsngoLoanId());
				if (chkmfsngoLoan != null) {
					chkmfsngoLoan.setSignPath(mfsngoloanVO.getSignPath());
					Integer MFSNGOLoanId = mfsngoloanService.updateMFSNGOLoan(chkmfsngoLoan);
					if (!MFSNGOLoanId.equals(-1)) {
						retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
						retMap.put("MFSNGOLoanId:", MFSNGOLoanId);
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
						retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
					}
					

				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
			}
		} else {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
			retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
		}
	} catch (Exception e) {
		retMap = new HashMap<String, Object>();
		retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
		retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
		retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
		log.error("Exception in MFSNGOLoanController::updateSignNgoLoan======" + e.getMessage());
		e.printStackTrace();
	}
	return retMap;
}

@PostMapping("/uploadngosign")
public ResponseEntity<ResponseMessageVO> uploadngosign(@RequestParam("file") MultipartFile file,
		@RequestParam("docType") String docType, 
		@RequestParam("loanTypeId") Integer loanTypeId, @RequestParam("mfsngoLoanId") Integer mfsngoLoanId) {
	String message = "";
	String fileName = "";
	try {
		if (docType.equals("NGOSGN")) {
			String savedFileName = storageService.savesignngo(file, 1,
					loanTypeId + "_" + mfsngoLoanId);
			if (savedFileName != null && !savedFileName.equals("")) {
				MFSNGOLoanVO mfsngoloanVO=new MFSNGOLoanVO();
				MFSNGOLoan chkmfsngoLoan = mfsngoloanService.getMFSNGOLoan(mfsngoLoanId);
				if (chkmfsngoLoan != null) {
				
				chkmfsngoLoan.setSignPath(savedFileName);
				mfsngoloanService.updateSignNgoLoan(chkmfsngoLoan);
				}
			} else {
				return ResponseEntity.status(HttpStatus.NOT_MODIFIED)
						.body(new ResponseMessageVO("Could not upload sign!", fileName));
			}
		} else {
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE)
					.body(new ResponseMessageVO("Loan type not got!", fileName));
		}
		message = "Uploaded the sign successfully: " + file.getOriginalFilename();
		fileName = file.getOriginalFilename();
		return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessageVO(message, fileName));
	} catch (Exception e) {
		e.printStackTrace();
		message = "Could not upload the sign: " + file.getOriginalFilename() + "! " + e.getMessage();
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessageVO(message, fileName));
	}
}

@GetMapping("/getngoSign/{ngoId}")
@ResponseBody
public ResponseEntity<Resource> getSign(@PathVariable Integer ngoId) {
	MFSNGOLoanVO ngoSign = mfsngoloanService.getNgoLoanVOsignById(ngoId);
	if (ngoSign != null) {
		String fileName = ngoSign.getSignPath();
		Resource file = storageService.loadsignngo(fileName,ngoSign.getLoantypeId());
		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
				.body(file);
	} else {
		return ResponseEntity.notFound().build();
	}
}

	

}

	


