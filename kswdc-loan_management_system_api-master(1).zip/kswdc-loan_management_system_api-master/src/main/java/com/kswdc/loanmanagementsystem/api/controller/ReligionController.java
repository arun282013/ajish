package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.Religion;
import com.kswdc.loanmanagementsystem.api.service.ReligionService;
import com.kswdc.loanmanagementsystem.api.value.ReligionVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class ReligionController {

	private final Logger log = LoggerFactory.getLogger(ReligionController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private ReligionService ReligionService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param Religion Religion
	 * @return Map
	 */
	@RequestMapping(value = "/religion", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createReligion(@RequestBody Religion Religion) {
		log.info("In ReligionController::createReligion=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(Religion)) {
//						Religion.setActive(Boolean.TRUE);
						Religion.setCreatedOn(DateFunctions.getZonedServerDate());
						// Religion.setCreatedBy();
						Religion.setIsDeleted(0);
						Integer ReligionId = ReligionService.createReligion(Religion);
						if (!ReligionId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("ReligionId", ReligionId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in ReligionController::createReligion======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param Religion Religion
	 * @return Map
	 */
	@RequestMapping(value = "/Religion", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateReligion(@RequestBody Religion Religion) {
		log.info("In ReligionController::updateReligion=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (Religion != null) { // && Religion.getId() != null
				if (checkValid(Religion)) {
					Religion chkReligion = ReligionService.getReligion(Religion.getReligionId());
					if (chkReligion!=null) {
//						if (chkReligion.getActive()) {
//							Religion.setActive(Boolean.TRUE);
							chkReligion.setReligionName(Religion.getReligionName());							
							chkReligion.setIsActive(Religion.getIsActive());							
							Integer ReligionId = ReligionService.updateReligion(chkReligion);
							if (!ReligionId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("ReligionId:", ReligionId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" Religion Id is deactivated:"+Religion.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in ReligionController::updateReligion======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/Religion/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteReligion(@PathVariable Integer id) {
		log.info("In ReligionController::deleteReligion=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Religion Religion = ReligionService.getReligion(id);
				if (Religion != null) {
//					if (!Religion.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " ReligionId:" + id);
//					} else {
						Integer ReligionId = ReligionService.deleteReligion(id);
						if (!ReligionId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("ReligionId", ReligionId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in ReligionController::deleteReligion======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/Religion/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneReligion(@PathVariable Integer id) {
		log.info("In ReligionController::getOneReligion=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Religion Religion = ReligionService.getReligion(id);
				if (Religion != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("Religion", Religion);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in ReligionController::getOneReligion======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- Religion ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/religion-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getReligionList() {
		log.info("In ReligionController::getReligionList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			ReligionListReturnVO ReligionListReturnVO = new ReligionListReturnVO(ReligionService.getReligionList());
			List<ReligionVO> ReligionListReturnVO = ReligionService.getReligionList();
			if (ReligionListReturnVO != null && ReligionListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("Religions", ReligionListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in ReligionController::getReligionList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param ReligionId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer ReligionId) {
		return (ReligionService.getReligion(ReligionId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param Religion
	 * @return Boolean
	 */
	private Boolean checkValid(Religion Religion) {
		Boolean isValid = true;
		invalidMsg = "";
		if (Religion != null) {
//			if(Religion.getId()==null || Religion.getId()<=0) {
//				invalidMsg+="ReligionId is required and should be valid!";
//				isValid = false;
//			}
			if (Religion.getReligionName() == null || Religion.getReligionName().equalsIgnoreCase("")) {
				invalidMsg += "Religion Name is required and should not be empty!";
				isValid = false;
			}
//			if (Religion.getReligionName() == null || Religion.getReligionName().equalsIgnoreCase("")) {
//				invalidMsg += "Religion Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (Religion.getQuotaInMB() == null || Religion.getQuotaInMB().equals(0) || Religion.getQuotaInMB()<0) {
//				invalidMsg += "Religion Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (Religion.getChatHistoryDays() == null || Religion.getChatHistoryDays().equals(0) || Religion.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for Religion is required and should be valid!";
//				isValid = false;
//			}
//			if (Religion.getCdaTimeoutTime() == null || Religion.getCdaTimeoutTime().equals(0) || Religion.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for Religion!";
			isValid = false;
		}
		return isValid;
	}
	
}
