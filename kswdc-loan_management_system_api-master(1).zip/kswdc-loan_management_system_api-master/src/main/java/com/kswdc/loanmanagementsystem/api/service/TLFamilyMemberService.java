package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.TLFamilyMember;
import com.kswdc.loanmanagementsystem.api.value.TLFamilyMemberVO;

@Component
public interface TLFamilyMemberService {

    Integer createTLFamilyMember(TLFamilyMember tlfamilymember);

    Integer updateTLFamilyMember(TLFamilyMember tlfamilymember);

    TLFamilyMember getTLFamilyMember(Integer id);

    // TLFamilyMember getTLFamilyMemberByTLFamilyMemberName(String
    // tlfamilymemberName);

    Integer deleteTLFamilyMember(Integer id);

    // List<TLFamilyMemberVO> getTLFamilyMemberList();
    List<TLFamilyMember> getTLFamilyMemberListByTLId(Integer termLoanId);
}
