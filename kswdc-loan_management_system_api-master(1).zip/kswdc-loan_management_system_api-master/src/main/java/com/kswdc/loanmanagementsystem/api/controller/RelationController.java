package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.Relation;
import com.kswdc.loanmanagementsystem.api.service.RelationService;
import com.kswdc.loanmanagementsystem.api.value.RelationVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class RelationController {

	private final Logger log = LoggerFactory.getLogger(RelationController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private RelationService relationService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param Relation Relation
	 * @return Map
	 */
	@RequestMapping(value = "/relation", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createRelation(@RequestBody Relation Relation) {
		log.info("In RelationController::createRelation=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(Relation)) {
//						Relation.setActive(Boolean.TRUE);
						Relation.setCreatedOn(DateFunctions.getZonedServerDate());
						// Relation.setCreatedBy();
						Relation.setIsDeleted(0);
						Integer RelationId = relationService.createRelation(Relation);
						if (!RelationId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("RelationId", RelationId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in RelationController::createRelation======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param Relation Relation
	 * @return Map
	 */
	@RequestMapping(value = "/relation", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateRelation(@RequestBody Relation relation) {
		log.info("In RelationController::updateRelation=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (relation != null) { // && Relation.getId() != null
				if (checkValid(relation)) {
					Relation chkRelation = relationService.getRelation(relation.getRelationId());
					if (chkRelation!=null) {
//						if (chkRelation.getActive()) {
//							Relation.setActive(Boolean.TRUE);
							chkRelation.setRelationName(relation.getRelationName());							
							chkRelation.setIsActive(relation.getIsActive());							
							Integer RelationId = relationService.updateRelation(chkRelation);
							if (!RelationId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("RelationId:", RelationId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" Relation Id is deactivated:"+Relation.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in RelationController::updateRelation======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/relation/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteRelation(@PathVariable Integer id) {
		log.info("In RelationController::deleteRelation=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Relation Relation = relationService.getRelation(id);
				if (Relation != null) {
//					if (!Relation.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " RelationId:" + id);
//					} else {
						Integer RelationId = relationService.deleteRelation(id);
						if (!RelationId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("RelationId", RelationId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in RelationController::deleteRelation======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/relation/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneRelation(@PathVariable Integer id) {
		log.info("In RelationController::getOneRelation=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Relation Relation = relationService.getRelation(id);
				if (Relation != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("Relation", Relation);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in RelationController::getOneRelation======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- Relation ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/relation-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getRelationList() {
		log.info("In RelationController::getRelationList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			RelationListReturnVO RelationListReturnVO = new RelationListReturnVO(RelationService.getRelationList());
			List<RelationVO> RelationListReturnVO = relationService.getRelationList();
			if (RelationListReturnVO != null && RelationListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("relations", RelationListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in RelationController::getRelationList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param RelationId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer RelationId) {
		return (relationService.getRelation(RelationId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param Relation
	 * @return Boolean
	 */
	private Boolean checkValid(Relation Relation) {
		Boolean isValid = true;
		invalidMsg = "";
		if (Relation != null) {
//			if(Relation.getId()==null || Relation.getId()<=0) {
//				invalidMsg+="RelationId is required and should be valid!";
//				isValid = false;
//			}
			if (Relation.getRelationName() == null || Relation.getRelationName().equalsIgnoreCase("")) {
				invalidMsg += "Relation Name is required and should not be empty!";
				isValid = false;
			}
//			if (Relation.getRelationName() == null || Relation.getRelationName().equalsIgnoreCase("")) {
//				invalidMsg += "Relation Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (Relation.getQuotaInMB() == null || Relation.getQuotaInMB().equals(0) || Relation.getQuotaInMB()<0) {
//				invalidMsg += "Relation Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (Relation.getChatHistoryDays() == null || Relation.getChatHistoryDays().equals(0) || Relation.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for Relation is required and should be valid!";
//				isValid = false;
//			}
//			if (Relation.getCdaTimeoutTime() == null || Relation.getCdaTimeoutTime().equals(0) || Relation.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for Relation!";
			isValid = false;
		}
		return isValid;
	}
	
}
