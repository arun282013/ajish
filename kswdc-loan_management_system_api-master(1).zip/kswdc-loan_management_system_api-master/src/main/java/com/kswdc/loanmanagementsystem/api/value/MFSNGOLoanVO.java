package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.time.ZonedDateTime;
import java.util.Set;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MFSNGOLoanVO implements Serializable {

    private Integer mfsngoLoanId;
    private String userName;
    // private String loanCategoryName;
    // private Integer loancategoryId;
    private String loantypeName;
    private Integer loantypeId;
    private String mfsngoname;
    private String mfsngobuildingnumber;
    private String mfsngodistrictName;
    private Integer mfsngodistrictId;
    private String mfsngotalukName;
    private Integer mfsngotalukId;
    private String mfsngolocation;
    private String mfsngolocalbodyName;
    private Integer mfsngolocalbodyId;
    private Integer mfsngolocalbodytypeId;
  //  private Integer mfsngolbtypeId;
    private String mfsngolocalbodytypename;
    private String mfsngoplace;
    private String mfsngopostofficeName;
    private Integer mfsngopostofficeId;
    private Integer mfsngoPincode;
    private String mfsngofaxnumber;
    private String mfsngoregistrationnumber;
    private Date mfsngodor;
    private Date mfsngodorenewal;
    private String mfsngoareaofoperation;
    private String mfsngoaccountnumber;
    private String mfsngochieffunctionary;
    private String mfsngodesigchieffunctionary;
    private ZonedDateTime createdOn;
    private String createdBy;
    private Integer createdById;
    private ZonedDateTime modifiedOn;
    private String modifiedBy;
    private Integer modifiedById;
    private Integer isDeleted;
    private ZonedDateTime deletedOn;
    private String deletedStr;
    private Integer isActive;
    private String activeStr;
    private Integer bankId;
    private Integer branchId;
    private String ifsc;
    private String bankName;
    private String branchName;
    private String mfsngophonenumber;

    private Date mfsngodofinancialbalance;
    private String mfsngofixedasset;
    private String mfsngocurrentasset;
    private String mfsngoborrowings;
    private String mfsngootherliability; 
    private String ngoFinances; 
    private String ngoCredits;
    private String ngoThrift;
    private String ngoLending;
    private String ngoSources;
    private String ngoAssistance;
    //--
    private String ngoStaff;

    private Set ngofinanceLst;
    private Set ngocreditLst;
    private Set ngothriftLst;
    private Set NgolendingLst;
    private Set ngosourcesLst;
  private Set NgoassistanceLst;
  private Set ngostaffLst;

   //--forstamp
   private String stampPath;
   //--for sign
   private String signPath;
  
    public MFSNGOLoanVO(){
    }  
  
    public MFSNGOLoanVO(Integer mfsngoLoanId, String userName, String loantypeName,
    String mfsngoname, String mfsngobuildingnumber, String mfsngodistrictName, String mfsngotalukName,
    String mfsngolocation,
    String mfsngolocalbodyName, String mfsngolocalbodytypename, String mfsngoplace,
    String mfsngopostofficeName,
    Integer mfsngoPincode,String mfsngophonenumber, String mfsngofaxnumber, String mfsngoregistrationnumber, Date mfsngodor,
    Date mfsngodorenewal, String mfsngoareaofoperation,String mfsngoaccountnumber, String mfsngochieffunctionary, String mfsngodesigchieffunctionary,ZonedDateTime createdOn,String createdBy,
    ZonedDateTime modifiedOn,String modifiedBy,Integer isDeleted,ZonedDateTime deletedOn,Integer isActive,String bankName,String branchName,String ifsc,Date mfsngodofinancialbalance,
    String mfsngofixedasset,String mfsngocurrentasset,String mfsngoborrowings, String mfsngootherliability) {
        this.mfsngoLoanId = mfsngoLoanId;
        this.userName = userName;
      //  this.loanCategoryName = loanCategoryName;
        this.loantypeName = loantypeName;
        this.mfsngoname = mfsngoname;
        this.mfsngobuildingnumber = mfsngobuildingnumber;
        this.mfsngodistrictName = mfsngodistrictName;
        this.mfsngotalukName = mfsngotalukName;
        this.mfsngolocation = mfsngolocation;
        this.mfsngolocalbodyName = mfsngolocalbodyName;
        this.mfsngolocalbodytypename = mfsngolocalbodytypename;
        this.mfsngoplace = mfsngoplace;
        this.mfsngopostofficeName = mfsngopostofficeName;
        this.mfsngoPincode = mfsngoPincode;
        this.mfsngophonenumber =mfsngophonenumber;
        this.mfsngofaxnumber = mfsngofaxnumber;
        this.mfsngoregistrationnumber = mfsngoregistrationnumber;
        this.mfsngodor = mfsngodor;
        this.mfsngodorenewal = mfsngodorenewal;
        this.mfsngoareaofoperation = mfsngoareaofoperation;
        this.mfsngoaccountnumber = mfsngoaccountnumber;
        this.mfsngochieffunctionary = mfsngochieffunctionary;
        this.mfsngodesigchieffunctionary = mfsngodesigchieffunctionary;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.modifiedOn = modifiedOn;
        this.modifiedBy = modifiedBy;
        this.isDeleted = isDeleted;
        this.deletedOn = deletedOn;
        this.deletedStr = isDeleted != null && isDeleted.equals(1) ? Constants.IS_DELETED_STR : Constants.IS_NOT_DELETED_STR;
        this.isActive = isActive;
        this.activeStr = isActive != null && isActive.equals(1) ? Constants.IS_ACTIVE_STR : Constants.IS_NOT_ACTIVE_STR;

        this.bankName=bankName;
        this.branchName=branchName;
        this.ifsc=ifsc;
        this.mfsngodofinancialbalance=mfsngodofinancialbalance;
        this.mfsngofixedasset=mfsngofixedasset;
        this.mfsngocurrentasset=mfsngocurrentasset;
        this.mfsngoborrowings=mfsngoborrowings;
        this.mfsngootherliability=mfsngootherliability;
        //--
       
    
    
    }
  
    public MFSNGOLoanVO(Integer mfsngoLoanId, String userName,Integer loantypeId, String loantypeName,
    String mfsngoname, String mfsngobuildingnumber,Integer mfsngodistrictId, String mfsngodistrictName,Integer mfsngotalukId, String mfsngotalukName,
    String mfsngolocation,
    Integer mfsngolocalbodyId, String mfsngolocalbodyName,Integer mfsngolocalbodytypeId, String mfsngolocalbodytypename, String mfsngoplace,
    Integer mfsngopostofficeId,  String mfsngopostofficeName,
    Integer mfsngoPincode,String mfsngophonenumber, String mfsngofaxnumber, String mfsngoregistrationnumber, Date mfsngodor,
    Date mfsngodorenewal, String mfsngoareaofoperation,String mfsngoaccountnumber, String mfsngochieffunctionary, String mfsngodesigchieffunctionary,ZonedDateTime createdOn,String createdBy,
    ZonedDateTime modifiedOn,String modifiedBy,Integer isDeleted,ZonedDateTime deletedOn,Integer isActive,Integer bankId, String bankName, Integer branchId, String branchName,String ifsc,Date mfsngodofinancialbalance,
    String mfsngofixedasset,String mfsngocurrentasset,String mfsngoborrowings, String mfsngootherliability) {
        this.mfsngoLoanId = mfsngoLoanId;
        this.userName = userName;
      //  this.loanCategoryName = loanCategoryName;
        this.loantypeId = loantypeId;
        this.loantypeName = loantypeName;
        this.mfsngoname = mfsngoname;
        this.mfsngobuildingnumber = mfsngobuildingnumber;
        this.mfsngodistrictId = mfsngodistrictId;
        this.mfsngodistrictName = mfsngodistrictName;
        this.mfsngotalukId = mfsngotalukId;
        this.mfsngotalukName = mfsngotalukName;
        this.mfsngolocation = mfsngolocation;
        this.mfsngolocalbodyId = mfsngolocalbodyId;
        this.mfsngolocalbodyName = mfsngolocalbodyName;
        this.mfsngolocalbodytypeId = mfsngolocalbodytypeId;
        this.mfsngolocalbodytypename = mfsngolocalbodytypename;
      //  this.mfsngolbtypeId = mfsngolbtypeId;
      //  this.mfsngolbtypename = mfsngolbtypename;
        this.mfsngoplace = mfsngoplace;
        this.mfsngopostofficeId = mfsngopostofficeId;
        this.mfsngopostofficeName = mfsngopostofficeName;
        this.mfsngoPincode = mfsngoPincode;
        this.mfsngophonenumber =mfsngophonenumber;
        this.mfsngofaxnumber = mfsngofaxnumber;
        this.mfsngoregistrationnumber = mfsngoregistrationnumber;
        this.mfsngodor = mfsngodor;
        this.mfsngodorenewal = mfsngodorenewal;
        this.mfsngoareaofoperation = mfsngoareaofoperation;
        this.mfsngoaccountnumber = mfsngoaccountnumber;
        this.mfsngochieffunctionary = mfsngochieffunctionary;
        this.mfsngodesigchieffunctionary = mfsngodesigchieffunctionary;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.modifiedOn = modifiedOn;
        this.modifiedBy = modifiedBy;
        this.isDeleted = isDeleted;
        this.deletedOn = deletedOn;
        this.deletedStr = isDeleted != null && isDeleted.equals(1) ? Constants.IS_DELETED_STR : Constants.IS_NOT_DELETED_STR;
        this.isActive = isActive;
        this.activeStr = isActive != null && isActive.equals(1) ? Constants.IS_ACTIVE_STR : Constants.IS_NOT_ACTIVE_STR;
        this.bankId=bankId;
        this.bankName=bankName;
        this.branchId=branchId;
        this.branchName=branchName;
        this.ifsc=ifsc;
        this.mfsngodofinancialbalance=mfsngodofinancialbalance;
        this.mfsngofixedasset=mfsngofixedasset;
        this.mfsngocurrentasset=mfsngocurrentasset;
        this.mfsngoborrowings=mfsngoborrowings;
        this.mfsngootherliability=mfsngootherliability;
       
    
    }

    public MFSNGOLoanVO(Integer mfsngoLoanId,String mfsngoname,Integer loantypeId,String loantypeName,String stampPath,String signPath){
      this.mfsngoLoanId = mfsngoLoanId;
      this.mfsngoname = mfsngoname;
      this.loantypeId = loantypeId;
      this.loantypeName = loantypeName;
      this.stampPath = stampPath;
      this.signPath = signPath;
  }
  
}
