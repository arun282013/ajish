package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Village;
import com.kswdc.loanmanagementsystem.api.value.VillageVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface VillageService {

    Integer createVillage(Village village);

    Integer updateVillage(Village village);

    Village getVillage(Integer id);

    Village getVillageByVillageName(String villageName);

    Integer deleteVillage(Integer id);

    List<VillageVO> getVillageList();

    List<VillageVO> getVillageListByTaluk(Integer talukId);
}
