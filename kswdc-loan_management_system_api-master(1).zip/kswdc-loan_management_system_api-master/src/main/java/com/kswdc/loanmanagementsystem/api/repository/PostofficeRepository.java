package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Postoffice;
import com.kswdc.loanmanagementsystem.api.value.PostofficeVO;

@Repository
public interface PostofficeRepository extends JpaRepository<Postoffice, Integer> {
    @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.PostofficeVO(p.postofficeId," + 
    "  p.postofficeName, d.districtName, p.pincode, p.createdOn,u.fullName,p.modifiedOn,mu.fullName, p.isDeleted, p.deletedOn, p.isActive ) " +
         " FROM Postoffice p LEFT JOIN District d ON p.districtObj=d.districtId LEFT JOIN User u ON p.createdBy = u.userId LEFT JOIN User mu ON p.modifiedBy=mu.userId "+
          " WHERE p.isDeleted=0 ORDER BY p.postofficeName ASC")
 List<PostofficeVO> getPostofficeList();//Filter only active postoffices

 @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.PostofficeVO(p.postofficeId,"+
 " p.postofficeName, d.districtName, p.pincode, p.createdOn, u.fullName, p.modifiedOn, mu.fullName, p.isDeleted, p.deletedOn, p.isActive) " +
      " FROM Postoffice p LEFT JOIN District d ON p.districtObj= d.districtId LEFT JOIN User u ON p.createdBy=u.userId"+
      " LEFT JOIN User mu ON p.modifiedBy=mu.userId "+
       " WHERE p.isDeleted=0 and d.districtId=:districtId ORDER BY p.postofficeName ASC")
List<PostofficeVO> getPostofficeListByDistrict(@Param("districtId") Integer districtId);
  
  @Query("SELECT a from Postoffice a WHERE a.id=:postofficeId")
  Postoffice getPostofficeById(@Param("postofficeId") Integer postofficeId);

  @Query("SELECT cl FROM Postoffice cl WHERE cl.postofficeName=:postofficeName")
  Postoffice findByPostofficeName(@Param("postofficeName") String postofficeName);
}
