package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.District;
import com.kswdc.loanmanagementsystem.api.value.DistrictVO;

@Repository
public interface DistrictRepository extends JpaRepository<District, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.DistrictVO(o.districtId,"+
      " o.districtName,o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM District o LEFT JOIN User u ON o.createdBy=u.userId LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 ORDER BY o.districtName ASC")
   List<DistrictVO> getDistrictList();//Filter only active Districts
    
    @Query("SELECT a from District a WHERE a.id=:districtId")
    District getDistrictById(@Param("districtId") Integer districtId);

    @Query("SELECT cl FROM District cl WHERE cl.districtName=:districtName")
    District findByDistrictName(@Param("districtName") String districtName);
}
