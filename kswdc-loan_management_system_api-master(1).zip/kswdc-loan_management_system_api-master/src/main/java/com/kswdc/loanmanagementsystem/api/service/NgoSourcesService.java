package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.NgoSources;
import com.kswdc.loanmanagementsystem.api.value.NgoSourcesVO;


@Component
public interface NgoSourcesService {

    Integer createNgoSources(NgoSources ngoSources);

    Integer updateNgoSources(NgoSources ngoSources);
    NgoSources getNgoSources(Integer id);

    // TLFamilyMember getTLFamilyMemberByTLFamilyMemberName(String tlfamilymemberName);

    Integer deleteNgoSources(Integer id);

    // List<TLFamilyMemberVO> getTLFamilyMemberList();
}
