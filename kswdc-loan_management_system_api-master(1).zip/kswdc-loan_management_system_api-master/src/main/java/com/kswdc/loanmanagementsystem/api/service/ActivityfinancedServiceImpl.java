package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.Activityfinanced;
import com.kswdc.loanmanagementsystem.api.repository.ActivityfinancedRepository;
import com.kswdc.loanmanagementsystem.api.value.ActivityfinancedVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class ActivityfinancedServiceImpl implements ActivityfinancedService {
	private final Logger log = LoggerFactory.getLogger(ActivityfinancedServiceImpl.class);
	
	@Autowired
	private ActivityfinancedRepository activityfinancedRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createActivityfinanced(Activityfinanced Activityfinanced) {
		try {
			Activityfinanced savedActivityfinanced = activityfinancedRepository.save(Activityfinanced);
			return savedActivityfinanced.getActivityfinancedId() != null ? savedActivityfinanced.getActivityfinancedId() : -1;
		} catch (Exception e) {
			log.error("Exception in ActivityfinancedServiceImpl::createActivityfinanced======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateActivityfinanced(Activityfinanced Activityfinanced) {
		try {
			Activityfinanced updateActivityfinanced = activityfinancedRepository.save(Activityfinanced);
			return updateActivityfinanced.getActivityfinancedId() != null ? updateActivityfinanced.getActivityfinancedId() : -1;
		} catch (Exception e) {
			log.error("Exception in ActivityfinancedServiceImpl::updateActivityfinanced======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Activityfinanced getActivityfinanced(Integer id) {
		try {
			Activityfinanced activityfinanced = activityfinancedRepository.getActivityfinancedById(id);
			return activityfinanced;
		} catch (Exception e) {
			log.error("Exception in ActivityfinancedServiceImpl::getActivityfinanced======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteActivityfinanced(Integer id) {
		try {
			Activityfinanced Activityfinanced = getActivityfinanced(id);
//			Activityfinanced.setActive(Boolean.FALSE);
			Activityfinanced.setDeletedOn(DateFunctions.getZonedServerDate());
			Activityfinanced.setIsDeleted(Constants.IS_DELETED);
			Activityfinanced updatedActivityfinanced = activityfinancedRepository.save(Activityfinanced);
			return updatedActivityfinanced.getActivityfinancedId() != null ? updatedActivityfinanced.getActivityfinancedId() : -1;
		} catch (Exception e) {
			log.error("Exception in ActivityfinancedServiceImpl::deleteActivityfinanced======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<ActivityfinancedVO> getActivityfinancedList() {
		try {
			List<ActivityfinancedVO> activityfinancedList = activityfinancedRepository.getActivityfinancedList();
			return activityfinancedList;
		} catch (Exception e) {
			log.error("Exception in ActivityfinancedServiceImpl::getActivityfinancedList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Activityfinanced getActivityfinancedByActivityfinancedName(String activityfinancedName) {
		try {
			Activityfinanced activityfinanced = activityfinancedRepository.findByActivityfinancedName(activityfinancedName);
			return activityfinanced;
		} catch (Exception e) {
			log.error("Exception in ActivityfinancedServiceImpl::getActivityfinancedByActivityfinancedName======" + e.getMessage());
		}
		return null;
	}
}