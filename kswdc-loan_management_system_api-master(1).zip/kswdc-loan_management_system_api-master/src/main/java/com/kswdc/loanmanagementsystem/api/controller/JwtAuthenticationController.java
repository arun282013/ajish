package com.kswdc.loanmanagementsystem.api.controller;

import java.util.HashMap;
import java.util.Map;
// import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.kswdc.loanmanagementsystem.api.config.JwtTokenUtil;
import com.kswdc.loanmanagementsystem.api.model.User;
import com.kswdc.loanmanagementsystem.api.service.JwtUserDetailsService;
import com.kswdc.loanmanagementsystem.api.service.UserService;
import com.kswdc.loanmanagementsystem.api.value.JwtRequest;
import com.kswdc.loanmanagementsystem.api.value.JwtResponse;

@RestController
@CrossOrigin
public class JwtAuthenticationController {

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private JwtUserDetailsService userDetailsService;

	@Autowired
	private UserService userService;

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest authenticationRequest) throws Exception {

		authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());

		// final UserDetails userDetails = userDetailsService
		// .loadUserByUsername(authenticationRequest.getUsername());

		// User user = userService.getUserByUser(authenticationRequest.getUsername());
		// Map<String, Object> userAddiDetails = new HashMap<String,Object>();
		// userAddiDetails.put("name", user.getFullName());
		// userAddiDetails.put("id", user.getId());
		// userAddiDetails.put("role",user.getRole().getRoleName());
		// final String token = jwtTokenUtil.generateToken(userDetails,userAddiDetails);

		// final String token = authenticateAndGenerateToken(authenticationRequest);

		final String token = getNewAuthToken(authenticationRequest);

		return ResponseEntity.ok(new JwtResponse(token));
	}

	private void authenticate(String username, String password) throws Exception {
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (DisabledException e) {
			throw new Exception("USER_DISABLED", e);
		} catch (BadCredentialsException e) {
			throw new Exception("INVALID_CREDENTIALS", e);
		}
	}

	public String authenticateAndGenerateToken(JwtRequest authenticationRequest) throws Exception {
		authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());

		final UserDetails userDetails = userDetailsService
				.loadUserByUsername(authenticationRequest.getUsername());

		User user = userService.getUserByUserName(authenticationRequest.getUsername());
		Map<String, Object> userAddiDetails = new HashMap<String, Object>();
		userAddiDetails.put("name", user.getFullName());
		userAddiDetails.put("id", user.getUserId());
		// userAddiDetails.put("role", user.getRole().getRoleName());
		final String token = jwtTokenUtil.generateToken(userDetails, userAddiDetails);

		return token;
	}

	public String getNewAuthToken(JwtRequest authenticationRequest) {
		final UserDetails userDetails = userDetailsService
				.loadUserByUsername(authenticationRequest.getUsername());

		User user = userService.getUserByUserName(authenticationRequest.getUsername());
		Map<String, Object> userAddiDetails = new HashMap<String, Object>();
		userAddiDetails.put("name", user.getFullName());
		userAddiDetails.put("id", user.getUserId());
		userAddiDetails.put("aadhar", user.getAadharNo());
		userAddiDetails.put("mobileNo", user.getMobileNo());
		userAddiDetails.put("emailId", user.getEmailId());
		userAddiDetails.put("accountType", user.getAccountType());
		
		
		// userAddiDetails.put("role", user.getRole().getRoleName());
		final String token = jwtTokenUtil.generateToken(userDetails, userAddiDetails);

		return token;
	}

	@RequestMapping(value = "/auth/sign-out", method = RequestMethod.POST)
	public ResponseEntity<?> logout() {
		return ResponseEntity.ok("success");
	}
}