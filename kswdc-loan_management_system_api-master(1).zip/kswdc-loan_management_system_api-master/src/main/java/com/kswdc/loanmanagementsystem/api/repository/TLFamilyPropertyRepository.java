package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.TLFamilyProperty;
import com.kswdc.loanmanagementsystem.api.value.TLFamilyPropertyVO;

@Repository
public interface TLFamilyPropertyRepository extends JpaRepository<TLFamilyProperty, Integer> {
   // @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TLFamilyPropertyVO(f.tlfamilyPropertyId,"+
   //    " f.tlfamilyPropertyName,f.tlfamilyPropertyAge,f.tlfamilyPropertyEduqualification,f.tlfamilyPropertyJob,"+
   //       "f.tlfamilyPropertyAnnualIncome,t.fullName,r.relationName)"+ 
   //       "FROM TLFamilyProperty f LEFT JOIN TermLoan t ON f.termLoanObj= t.termLoanId "+
   //       " LEFT JOIN Relation r ON f.relationObj = r.relationId "+
   //         " ORDER BY f.tlfamilyPropertyName ASC")
   // @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TLFamilyPropertyVO(f.tlfamilyPropertyId,"+
   //    " f.tlfamilyPropertyName,f.tlfamilyPropertyAge,f.tlfamilyPropertyEduqualification,f.tlfamilyPropertyJob,"+
   //       "f.tlfamilyPropertyAnnualIncome,t.fullName,r.relationName)"+ 
   //       "FROM TLFamilyProperty f "+
   //       " LEFT JOIN Relation r ON f.relationObj = r.relationId "+
   //         " ORDER BY f.tlfamilyPropertyName ASC")
//    List<TLFamilyPropertyVO> getTLFamilyPropertyList();//Filter only active familyproperty
//--
@Query("SELECT t FROM TermLoan t " +
            " WHERE t.termLoanId=:termLoanId")
    List<TLFamilyProperty> getTLFamilyPropertyListByTLId(@Param("termLoanId") Integer termLoanId);
//--
    
    @Query("SELECT a FROM TLFamilyProperty a WHERE a.id=:propertyId")
    TLFamilyProperty getTLFamilyPropertyById(@Param("propertyId") Integer propertyId);
 
    @Query("SELECT cl FROM TLFamilyProperty cl WHERE cl.propertyName=propertyName")
    TLFamilyProperty getTLFamilyPropertyByTLFamilyPropertyName(@Param("propertyName") String propertyName);

}
