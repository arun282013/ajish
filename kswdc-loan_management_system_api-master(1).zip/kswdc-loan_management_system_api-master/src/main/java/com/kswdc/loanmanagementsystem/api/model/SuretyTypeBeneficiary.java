package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_SuretyType_beneficiary")
@EqualsAndHashCode()
public class SuretyTypeBeneficiary{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SURETYTYPE_BENEFICIARY_ID")
    private Integer suretytypeBeneficiaryId;

    // @ManyToOne()
    // @JoinColumn(name= "LOAN_SURETYTYPE_ID")
    // private LoanSuretyType loanSuretyTypeObj;
    @ManyToOne()
    @JoinColumn(name= "SURETYTYPE_ID")
    private SuretyType suretyTypeObj;

    @ManyToOne()
    @JoinColumn(name= "TERM_LOAN_ID")
    private TermLoan termLoanObj;

    @ManyToOne()
    @JoinColumn(name= "LOANTYPE_ID")
    private LoanType loanTypeObj;

   
}
