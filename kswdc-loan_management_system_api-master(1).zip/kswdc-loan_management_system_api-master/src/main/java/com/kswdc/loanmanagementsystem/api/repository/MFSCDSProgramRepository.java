package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.MFSCDSProgram;
import com.kswdc.loanmanagementsystem.api.value.MFSCDSProgramVO;

@Repository
public interface MFSCDSProgramRepository extends JpaRepository<MFSCDSProgram, Integer> {
    @Query("SELECT a FROM MFSCDSProgram a WHERE a.id=:programId")
    MFSCDSProgram getMFSCDSProgramById(@Param("programId") Integer programId);
 
    @Query("SELECT cl FROM MFSCDSProgram cl WHERE cl.programName=programName")
    MFSCDSProgram getMFSCDSProgramByMFSCDSProgramName(@Param("programName") String programName);

}
