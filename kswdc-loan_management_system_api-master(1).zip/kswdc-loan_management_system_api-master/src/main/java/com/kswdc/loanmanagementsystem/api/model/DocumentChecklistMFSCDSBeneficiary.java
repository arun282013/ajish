package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_document_checklistmfscds_beneficiary")
@EqualsAndHashCode()
public class DocumentChecklistMFSCDSBeneficiary{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DOC_CHECKLISTMFSCDS_BENEFICIARY_ID")
    private Integer docChecklistMFSCDSBeneficiaryId;

    @ManyToOne()
    @JoinColumn(name= "DOCUMENT_CHECKLIST_MFSCDS_ID")
    private DocumentChecklistMFSCDS documentchecklistmfscdsObj;

    @ManyToOne()
    @JoinColumn(name= "MFSCDS_LOAN_ID")
    private MFSCDSLoan mfscdsLoanObj;

    
    @ManyToOne()
    @JoinColumn(name= "LOANTYPE_ID")
    private LoanType loanTypeObj;

    @Column(name = "FILE_PATH", columnDefinition = "varchar(300) not null")
    private String filePath;
}
