package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class RelationVO implements Serializable {

    private Integer relationId;
    private String relationName;
    private Integer relationStatus;
    private String relationStatusStr;
    private ZonedDateTime createdOn;
    private String createdBy;
    private ZonedDateTime modifiedOn;
    private String modifiedBy;
    private Integer isDeleted;
    private String deletedStr;
    private ZonedDateTime deletedOn;
    private Integer isActive;
    private String activeStr;


    public RelationVO(Integer relationId,String relationName, 
     ZonedDateTime createdOn, String createdBy, ZonedDateTime modifiedOn, String modifiedBy, Integer isDeleted, 
      ZonedDateTime deletedOn, Integer isActive) {
        this.relationId = relationId;
        this.relationName = relationName;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.modifiedOn = modifiedOn;
        this.modifiedBy = modifiedBy;
        this.isDeleted = isDeleted;
        this.deletedStr = isDeleted.equals(1)?Constants.IS_DELETED_STR:Constants.IS_NOT_DELETED_STR;
        this.deletedOn = deletedOn;
        this.isActive = isActive;
        this.activeStr = isActive.equals(1)?Constants.IS_ACTIVE_STR:Constants.IS_NOT_ACTIVE_STR;
    }
    
}
