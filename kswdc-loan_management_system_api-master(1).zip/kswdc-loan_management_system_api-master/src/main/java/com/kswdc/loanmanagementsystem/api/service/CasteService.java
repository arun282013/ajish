package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Caste;
import com.kswdc.loanmanagementsystem.api.value.CasteVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface CasteService {

    Integer createCaste(Caste caste);

    Integer updateCaste(Caste caste);

    Caste getCaste(Integer id);

    Caste getCasteByCasteName(String casteName);

    Integer deleteCaste(Integer id);

    List<CasteVO> getCasteList();

    List<CasteVO> getCasteListByReligion(Integer religionId);
}
