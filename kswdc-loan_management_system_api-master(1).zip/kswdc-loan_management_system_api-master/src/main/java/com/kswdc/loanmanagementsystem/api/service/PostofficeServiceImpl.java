package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.Postoffice;
import com.kswdc.loanmanagementsystem.api.repository.PostofficeRepository;
import com.kswdc.loanmanagementsystem.api.value.PostofficeVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class PostofficeServiceImpl implements PostofficeService {
	private final Logger log = LoggerFactory.getLogger(PostofficeServiceImpl.class);
	
	@Autowired
	private PostofficeRepository postofficeRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createPostoffice(Postoffice Postoffice) {
		try {
			Postoffice savedPostoffice = postofficeRepository.save(Postoffice);
			return savedPostoffice.getPostofficeId() != null ? savedPostoffice.getPostofficeId() : -1;
		} catch (Exception e) {
			log.error("Exception in PostofficeServiceImpl::createPostoffice======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updatePostoffice(Postoffice Postoffice) {
		try {
			Postoffice updatePostoffice = postofficeRepository.save(Postoffice);
			return updatePostoffice.getPostofficeId() != null ? updatePostoffice.getPostofficeId() : -1;
		} catch (Exception e) {
			log.error("Exception in PostofficeServiceImpl::updatePostoffice======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Postoffice getPostoffice(Integer id) {
		try {
			Postoffice postoffice = postofficeRepository.getPostofficeById(id);
			return postoffice;
		} catch (Exception e) {
			log.error("Exception in PostofficeServiceImpl::getPostoffice======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deletePostoffice(Integer id) {
		try {
			Postoffice Postoffice = getPostoffice(id);
//			Postoffice.setActive(Boolean.FALSE);
			Postoffice.setDeletedOn(DateFunctions.getZonedServerDate());
			Postoffice.setIsDeleted(Constants.IS_DELETED);
			Postoffice updatedPostoffice = postofficeRepository.save(Postoffice);
			return updatedPostoffice.getPostofficeId() != null ? updatedPostoffice.getPostofficeId() : -1;
		} catch (Exception e) {
			log.error("Exception in PostofficeServiceImpl::deletePostoffice======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<PostofficeVO> getPostofficeList() {
		try {
			List<PostofficeVO> postofficeList = postofficeRepository.getPostofficeList();
			return postofficeList;
		} catch (Exception e) {
			log.error("Exception in PostofficeServiceImpl::getPostofficeList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<PostofficeVO> getPostofficeListByDistrict(Integer districtId) {
		try {
			List<PostofficeVO> postofficeList = postofficeRepository.getPostofficeListByDistrict(districtId);
			return postofficeList;
		} catch (Exception e) {
			log.error("Exception in PostofficeServiceImpl::getPostofficeListByDistrict======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Postoffice getPostofficeByPostofficeName(String postofficeName) {
		try {
			Postoffice postoffice = postofficeRepository.findByPostofficeName(postofficeName);
			return postoffice;
		} catch (Exception e) {
			log.error("Exception in PostofficeServiceImpl::getPostofficeByPostofficeName======" + e.getMessage());
		}
		return null;
	}
}