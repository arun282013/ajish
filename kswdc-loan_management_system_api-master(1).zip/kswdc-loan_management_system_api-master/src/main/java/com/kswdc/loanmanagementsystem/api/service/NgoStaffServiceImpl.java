package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.NgoStaff;
import com.kswdc.loanmanagementsystem.api.repository.NgoStaffRepository;
import com.kswdc.loanmanagementsystem.api.value.NgoStaffVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class NgoStaffServiceImpl implements NgoStaffService {
	private final Logger log = LoggerFactory.getLogger(NgoStaffServiceImpl.class);
	
	@Autowired
	private NgoStaffRepository NgoStaffRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createNgoStaff(NgoStaff NgoStaff) {
		try {
			NgoStaff savedNgoStaff =NgoStaffRepository.save(NgoStaff);
			return savedNgoStaff.getStaffId() != null ? savedNgoStaff.getStaffId(): -1;
		} catch (Exception e) {
			log.error("Exception in NgoStaffServiceImpl::createNgoStaff======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateNgoStaff(NgoStaff NgoStaff) {
		try {
			NgoStaff updateNgoStaff = NgoStaffRepository.save(NgoStaff);
			return updateNgoStaff.getStaffId() != null ? updateNgoStaff.getStaffId() : -1;
		} catch (Exception e) {
			log.error("Exception in NgoStaffServiceImpl::updateNgoStaff======" + e.getMessage());
		}
		return null;
	}

	@Override
	public NgoStaff getNgoStaff(Integer id) {
		try {
			NgoStaff NgoStaff = NgoStaffRepository.getNgoStaffById(id);
			return NgoStaff;
		} catch (Exception e) {
			log.error("Exception in NgoStaffServiceImpl::getNgoStaff======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteNgoStaff(Integer id) {
		try {
			NgoStaff NgoStaff = getNgoStaff(id);
//			TLFamilyMember.setActive(Boolean.FALSE);
			// TLFamilyMember.setDeletedOn(DateFunctions.getZonedServerDate());
			// TLFamilyMember.setIsDeleted(Constants.IS_DELETED);
			NgoStaff updatedNgoStaff = NgoStaffRepository.save(NgoStaff);
			return updatedNgoStaff.getStaffId() != null ? updatedNgoStaff.getStaffId() : -1;
		} catch (Exception e) {
			log.error("Exception in NgoStaffServiceImpl::deleteNgoStaff======" + e.getMessage());
		}
		return null;
	}

	// @Override
	// public List<TLFamilyMemberVO> getTLFamilyMemberList() {
	// 	try {
	// 		List<TLFamilyMemberVO> tlfamilymemberList = tlfamilymemberRepository.getTLFamilyMemberList();
	// 		return tlfamilymemberList;
	// 	} catch (Exception e) {
	// 		log.error("Exception in TLFamilyMemberServiceImpl::getTLFamilyMemberList======" + e.getMessage());
	// 	}
	// 	return null;
	// }

	// @Override
	// public TLFamilyMember getTLFamilyMemberByTLFamilyMemberName(String TLFamilyMemberName) {
	// 	try {
	// 		TLFamilyMember TLFamilyMember = TLFamilyMemberRepository.getTLFamilyMemberByTLFamilyMemberName(TLFamilyMemberName);
	// 		return TLFamilyMember;
	// 	} catch (Exception e) {
	// 		log.error("Exception in TLFamilyMemberServiceImpl::getTLFamilyMemberByTLFamilyMemberName======" + e.getMessage());
	// 	}
	// 	return null;
	// }
}