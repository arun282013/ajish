package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.NgoThrift;
import com.kswdc.loanmanagementsystem.api.repository.NgoThriftRepository;
import com.kswdc.loanmanagementsystem.api.value.NgoThriftVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class NgoThriftServiceImpl implements NgoThriftService {
	private final Logger log = LoggerFactory.getLogger(NgoThriftServiceImpl.class);
	
	@Autowired
	private NgoThriftRepository NgoThriftRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createNgoThrift(NgoThrift NgoThrift) {
		try {
			NgoThrift savedNgoThrift =NgoThriftRepository.save(NgoThrift);
			return savedNgoThrift.getThriftId() != null ? savedNgoThrift.getThriftId(): -1;
		} catch (Exception e) {
			log.error("Exception in NgoThrifServiceImpl::createNgoThrif======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateNgoThrift(NgoThrift NgoThrift) {
		try {
			NgoThrift updateNgoThrift = NgoThriftRepository.save(NgoThrift);
			return updateNgoThrift.getThriftId() != null ? updateNgoThrift.getThriftId() : -1;
		} catch (Exception e) {
			log.error("Exception in NgoThriftServiceImpl::updateNgoThrift======" + e.getMessage());
		}
		return null;
	}

	@Override
	public NgoThrift getNgoThrift(Integer id) {
		try {
			NgoThrift NgoThrift = NgoThriftRepository.getNgoThriftById(id);
			return NgoThrift;
		} catch (Exception e) {
			log.error("Exception in NgoThriftServiceImpl::getNgoThrift======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteNgoThrift(Integer id) {
		try {
			NgoThrift NgoThrift = getNgoThrift(id);
//			TLFamilyMember.setActive(Boolean.FALSE);
			// TLFamilyMember.setDeletedOn(DateFunctions.getZonedServerDate());
			// TLFamilyMember.setIsDeleted(Constants.IS_DELETED);
			NgoThrift updatedNgoThrift = NgoThriftRepository.save(NgoThrift);
			return updatedNgoThrift.getThriftId() != null ? updatedNgoThrift.getThriftId() : -1;
		} catch (Exception e) {
			log.error("Exception in NgoThriftServiceImpl::deleteNgoThrift======" + e.getMessage());
		}
		return null;
	}

	// @Override
	// public List<TLFamilyMemberVO> getTLFamilyMemberList() {
	// 	try {
	// 		List<TLFamilyMemberVO> tlfamilymemberList = tlfamilymemberRepository.getTLFamilyMemberList();
	// 		return tlfamilymemberList;
	// 	} catch (Exception e) {
	// 		log.error("Exception in TLFamilyMemberServiceImpl::getTLFamilyMemberList======" + e.getMessage());
	// 	}
	// 	return null;
	// }

	// @Override
	// public TLFamilyMember getTLFamilyMemberByTLFamilyMemberName(String TLFamilyMemberName) {
	// 	try {
	// 		TLFamilyMember TLFamilyMember = TLFamilyMemberRepository.getTLFamilyMemberByTLFamilyMemberName(TLFamilyMemberName);
	// 		return TLFamilyMember;
	// 	} catch (Exception e) {
	// 		log.error("Exception in TLFamilyMemberServiceImpl::getTLFamilyMemberByTLFamilyMemberName======" + e.getMessage());
	// 	}
	// 	return null;
	// }
}