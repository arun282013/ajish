package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class NgoStaffVO implements Serializable {
    private Integer staffId;
    private Integer officetrained;
    private Integer officeuntrained;
    private Integer fieldtrained;
    private Integer fielduntrained;
    private Integer officestafftotal;
    private Integer fieldstafftotal;


    public NgoStaffVO(Integer staffId, 
    Integer officetrained,Integer officeuntrained,
    Integer fieldtrained, Integer fielduntrained,Integer officestafftotal,Integer fieldstafftotal
    ) {
        this.staffId = staffId;
        this.officetrained = officetrained;
        this.officeuntrained = officeuntrained;
        this.fieldtrained = fieldtrained;
        this.fielduntrained = fielduntrained;
        this.officestafftotal=officestafftotal;
        this.fieldstafftotal=fieldstafftotal;

    }
    
}
