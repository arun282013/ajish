package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.LoanDocumentChecklist;
import com.kswdc.loanmanagementsystem.api.repository.LoanDocumentChecklistRepository;
import com.kswdc.loanmanagementsystem.api.value.LoanDocumentChecklistVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;


@Service
public class LoanDocumentChecklistServiceImpl implements LoanDocumentChecklistService {
	private final Logger log = LoggerFactory.getLogger(LoanDocumentChecklistServiceImpl.class);
	
	@Autowired
	private LoanDocumentChecklistRepository loanDocumentChecklistRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createLoanDocumentChecklist(LoanDocumentChecklist LoanDocumentChecklist) {
		try {
			LoanDocumentChecklist savedLoanDocumentChecklist = loanDocumentChecklistRepository.save(LoanDocumentChecklist);
			return savedLoanDocumentChecklist.getLoanDocChecklistId() != null ? savedLoanDocumentChecklist.getLoanDocChecklistId() : -1;
		} catch (Exception e) {
			log.error("Exception in LoanDocumentChecklistServiceImpl::createLoanDocumentChecklist======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateLoanDocumentChecklist(LoanDocumentChecklist LoanDocumentChecklist) {
		try {
			LoanDocumentChecklist updateLoanDocumentChecklist = loanDocumentChecklistRepository.save(LoanDocumentChecklist);
			return updateLoanDocumentChecklist.getLoanDocChecklistId() != null ? updateLoanDocumentChecklist.getLoanDocChecklistId() : -1;
		} catch (Exception e) {
			log.error("Exception in LoanDocumentChecklistServiceImpl::updateLoanDocumentChecklist======" + e.getMessage());
		}
		return null;
	}

	@Override
	public LoanDocumentChecklist getLoanDocumentChecklist(Integer id) {
		try {
			LoanDocumentChecklist loanDocumentChecklist = loanDocumentChecklistRepository.getLoanDocumentChecklistById(id);
			return loanDocumentChecklist;
		} catch (Exception e) {
			log.error("Exception in LoanDocumentChecklistServiceImpl::getLoanDocumentChecklist======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteLoanDocumentChecklist(Integer id) {
		try {
			LoanDocumentChecklist LoanDocumentChecklist = getLoanDocumentChecklist(id);
//			LoanType.setActive(Boolean.FALSE);
			// LoanDocumentChecklist.setDeletedOn(DateFunctions.getZonedServerDate());
			//LoanDocumentChecklist.setIsDeleted(Constants.IS_DELETED);
			LoanDocumentChecklist updatedLoanDocumentChecklist = loanDocumentChecklistRepository.save(LoanDocumentChecklist);
			return updatedLoanDocumentChecklist.getLoanDocChecklistId() != null ? updatedLoanDocumentChecklist.getLoanDocChecklistId() : -1;
		} catch (Exception e) {
			log.error("Exception in LoanDocumentChecklistServiceImpl::deleteLoanDocumentChecklist======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<LoanDocumentChecklistVO> getLoanDocumentChecklistList() {
		try {
			List<LoanDocumentChecklistVO> loanDocumentChecklistList = loanDocumentChecklistRepository.getLoanDocumentChecklistList();
			return loanDocumentChecklistList;
		} catch (Exception e) {
			log.error("Exception in LoanDocumentChecklistServiceImpl::getLoanDocumentChecklistList======" + e.getMessage());
		}
		return null;
	}

	// @Override
	// public LoanDocumentChecklist getLoanDocumentChecklistByLoanDocumentChecklistName(String loanDocumentChecklistName) {
	// 	try {
	// 		LoanDocumentChecklist loanDocumentChecklist = loanDocumentChecklistRepository.findByLoanDocumentChecklistName(loanDocumentChecklistName);
	// 		return loanDocumentChecklist;
	// 	} catch (Exception e) {
	// 		log.error("Exception in LoanDocumentChecklistServiceImpl::getLoanDocumentChecklistByLoanDocumentChecklistName======" + e.getMessage());
	// 	}
	// 	return null;
	// }
}