package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TermLoanVO implements Serializable {

    private Integer termLoanId;
    private String userName;
    private String loanCategoryName;
    private Integer loancategoryId;
    private String loantypeName;
    // private Integer loanTypeId;
    private Integer loantypeId;
    private String fullName;
    private String maritalstatusName;
    private Integer maritalstatusId;
    private String relationName;
    private Integer relationId;
    private String tlguardianName;
    private String tlpresenthouseName;
    private String tlpresenthouseNo;
    private Integer tlpresentlocationtypeId;
    private String presentpostofficeName;
    private Integer presentpostofficeId;
    private String presentdistrictName;
    private Integer presentdistrictId;
    private String presenttalukName;
    private Integer presenttalukId;
    private Integer preslocalbodytypeId;
    private String preslbtypename;
    private String presentlocalbodyName;
    private Integer preslocalbodyId;
    private String presentLocation;
    private Integer presentPincode;
    private String tlpermanenthouseName;
    private String tlpermanenthouseNo;
    private Integer tlpermanentlocationtypeId;
    private String permanentpostofficeName;
    private String permanentdistrictName;
    private Integer permanentdistrictId;
    private String permanenttalukName;
    private Integer permanenttalukId;
    private Integer permlocalbodytypeId;
    private String permlbtypename;
    private String permanentlocalbodyName;
    private Integer permlocalbodyId;
    private String permanentLocation;
    private Integer permanentpostofficeId;
    private Integer permanentPincode;
    private Date tlDob;
    private Integer tlAge;
    private String casteName;
    private Integer casteId;
    private String religionName;
    private Integer religionId;
    private String eduqualificationName;
    private Integer eduqualificationId;
    private String tltechnicalqualification;
    private String tlExperience;
    private Double tlannualIncome;
    private String tlrationcardNo;
    private String tlprojectName;
    private Double tlprojectCost;
    private Double tlestimatedloanAmount;
    private String tlbankaccountNo;
    private String tlbankName;
    private String tlbranchName;
    private Integer tlapplicationStatus;
    private ZonedDateTime enteredOn;
    private ZonedDateTime createdOn;
    private String createdBy;
    private Integer createdById;
    private ZonedDateTime modifiedOn;
    private String modifiedBy;
    private Integer modifiedById;
    private Integer isDeleted;
    private ZonedDateTime deletedOn;
    private String deletedStr;
    private Integer isActive;
    private String activeStr;
    private Integer userStatus;
    private String ifsc;
    private Integer bankId;
    private Integer branchId;
    private String familyMembers;
    // --
    private String familyPropertys;
    // --

    private Set familyMemberLst;
    // --
    private Set familyPropertyLst;
    //--for photo
    private String photoPath;
    //--for sign
    private String signPath;

    public TermLoanVO() {
    }

    public TermLoanVO(Integer termLoanId, String userName, String loanCategoryName, String loantypeName,
            String fullName, String maritalstatusName, String relationName, String tlguardianName,
            String tlpresenthouseName,
            String tlpresenthouseNo, Integer tlpresentlocationtypeId, String presentpostofficeName,
            String presentdistrictName,
            String presenttalukName, String presentlocalbodyName, String presentLocation, Integer presentPincode,
            String tlpermanenthouseName, String tlpermanenthouseNo, Integer tlpermanentlocationtypeId,
            String permanentpostofficeName, String permanentdistrictName, String permanenttalukName,
            String permanentlocalbodyName, String permanentLocation, Integer permanentPincode, Date tlDob,
            Integer tlAge, String casteName, String religionName, String eduqualificationName,
            String tltechnicalqualification,
            String tlExperience, Double tlannualIncome, String tlrationcardNo, String tlprojectName,
            Double tlprojectCost,
            Double tlestimatedloanAmount, String tlbankaccountNo, String tlbankName, String tlbranchName,
            Integer tlapplicationStatus,
            ZonedDateTime enteredOn, ZonedDateTime createdOn, String createdBy, ZonedDateTime modifiedOn,
            String modifiedBy,
            Integer isDeleted, ZonedDateTime deletedOn, Integer isActive, String ifsc, String preslbtypename,
            String permlbtypename) {
        this.termLoanId = termLoanId;
        this.userName = userName;
        this.loanCategoryName = loanCategoryName;
        this.loantypeName = loantypeName;
        this.fullName = fullName;
        this.maritalstatusName = maritalstatusName;
        this.relationName = relationName;
        this.tlguardianName = tlguardianName;
        this.tlpresenthouseName = tlpresenthouseName;
        this.tlpresenthouseNo = tlpresenthouseNo;
        this.tlpresentlocationtypeId = tlpresentlocationtypeId;
        this.presentpostofficeName = presentpostofficeName;
        this.presentdistrictName = presentdistrictName;
        this.presenttalukName = presenttalukName;
        this.presentlocalbodyName = presentlocalbodyName;
        this.presentLocation = presentLocation;
        this.presentPincode = presentPincode;
        this.tlpermanenthouseName = tlpermanenthouseName;
        this.tlpermanenthouseNo = tlpermanenthouseNo;
        this.tlpermanentlocationtypeId = tlpermanentlocationtypeId;
        this.permanentpostofficeName = permanentpostofficeName;
        this.permanentdistrictName = permanentdistrictName;
        this.permanenttalukName = permanenttalukName;
        this.permanentlocalbodyName = permanentlocalbodyName;
        this.permanentLocation = permanentLocation;
        this.permanentPincode = permanentPincode;
        this.tlDob = tlDob;
        this.tlAge = tlAge;
        this.casteName = casteName;
        this.religionName = religionName;
        this.eduqualificationName = eduqualificationName;
        this.tltechnicalqualification = tltechnicalqualification;
        this.tlExperience = tlExperience;
        this.tlannualIncome = tlannualIncome;
        this.tlrationcardNo = tlrationcardNo;
        this.tlprojectName = tlprojectName;
        this.tlprojectCost = tlprojectCost;
        this.tlestimatedloanAmount = tlestimatedloanAmount;
        this.tlbankaccountNo = tlbankaccountNo;
        this.tlbankName = tlbankName;
        this.tlbranchName = tlbranchName;
        this.tlapplicationStatus = tlapplicationStatus;
        this.enteredOn = enteredOn;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.modifiedOn = modifiedOn;
        this.modifiedBy = modifiedBy;
        this.isDeleted = isDeleted;
        this.deletedOn = deletedOn;
        this.deletedStr = isDeleted != null && isDeleted.equals(1) ? Constants.IS_DELETED_STR
                : Constants.IS_NOT_DELETED_STR;
        this.isActive = isActive;
        this.activeStr = isActive != null && isActive.equals(1) ? Constants.IS_ACTIVE_STR : Constants.IS_NOT_ACTIVE_STR;
        this.ifsc = ifsc;
        this.preslbtypename = preslbtypename;
        this.permlbtypename = permlbtypename;

        // this.photoPath = photoPath;
    }

    public TermLoanVO(Integer termLoanId, String userName, Integer loanCategoryId, String loanCategoryName,
            String loantypeName,
            String fullName, Integer maritalstatusId, String maritalstatusName, Integer relationId, String relationName,
            String tlguardianName,
            String tlpresenthouseName,
            String tlpresenthouseNo, Integer tlpresentlocationtypeId, Integer presentpostofficeId,
            String presentpostofficeName,
            Integer presentdistrictId, String presentdistrictName,
            Integer presenttalukId, String presenttalukName, Integer presentlocalbodyId, String presentlocalbodyName,
            String presentLocation, Integer presentPincode,
            String tlpermanenthouseName, String tlpermanenthouseNo, Integer tlpermanentlocationtypeId,
            Integer permanentpostofficeId,
            String permanentpostofficeName,
            Integer permanentdistrictId,
            String permanentdistrictName,
            Integer permanenttalukId,
            String permanenttalukName,
            Integer permanentlocalbodyId,
            String permanentlocalbodyName, String permanentLocation, Integer permanentPincode, Date tlDob,
            Integer tlAge,
            Integer casteId,
            String casteName,
            Integer religionId,
            String religionName,
            Integer eduqualificationId,
            String eduqualificationName,
            String tltechnicalqualification,
            String tlExperience, Double tlannualIncome, String tlrationcardNo, String tlprojectName,
            Double tlprojectCost,
            Double tlestimatedloanAmount, String tlbankaccountNo,
            Integer tlbankId,
            String tlbankName,
            Integer tlbranchId,
            String tlbranchName,
            Integer tlapplicationStatus,
            ZonedDateTime enteredOn, ZonedDateTime createdOn, String createdBy, ZonedDateTime modifiedOn,
            String modifiedBy,
            Integer isDeleted, ZonedDateTime deletedOn, Integer isActive, String ifsc, Integer preslocalbodytypeId,
            String preslbtypename, Integer permlocalbodytypeId, String permlbtypename) {
        this.termLoanId = termLoanId;
        this.userName = userName;
        this.loancategoryId = loanCategoryId;
        this.loanCategoryName = loanCategoryName;
        this.loantypeName = loantypeName;
        this.fullName = fullName;
        this.maritalstatusId = maritalstatusId;
        this.maritalstatusName = maritalstatusName;
        this.relationId = relationId;
        this.relationName = relationName;
        this.tlguardianName = tlguardianName;
        this.tlpresenthouseName = tlpresenthouseName;
        this.tlpresenthouseNo = tlpresenthouseNo;
        this.tlpresentlocationtypeId = tlpresentlocationtypeId;
        this.presentpostofficeId = presentpostofficeId;
        this.presentpostofficeName = presentpostofficeName;
        this.presentdistrictId = presentdistrictId;
        this.presentdistrictName = presentdistrictName;
        this.presenttalukId = presenttalukId;
        this.presenttalukName = presenttalukName;
        this.preslocalbodyId = presentlocalbodyId;
        this.presentlocalbodyName = presentlocalbodyName;
        this.presentLocation = presentLocation;
        this.presentPincode = presentPincode;
        this.tlpermanenthouseName = tlpermanenthouseName;
        this.tlpermanenthouseNo = tlpermanenthouseNo;
        this.tlpermanentlocationtypeId = tlpermanentlocationtypeId;
        this.permanentpostofficeId = permanentpostofficeId;
        this.permanentpostofficeName = permanentpostofficeName;
        this.permanentdistrictId = permanentdistrictId;
        this.permanentdistrictName = permanentdistrictName;
        this.permanenttalukId = permanenttalukId;
        this.permanenttalukName = permanenttalukName;
        this.permlocalbodyId = permanentlocalbodyId;

        this.permanentlocalbodyName = permanentlocalbodyName;
        this.permanentLocation = permanentLocation;
        this.permanentPincode = permanentPincode;
        this.tlDob = tlDob;
        this.tlAge = tlAge;
        this.casteId = casteId;
        this.casteName = casteName;
        this.religionId = religionId;
        this.religionName = religionName;
        this.eduqualificationId = eduqualificationId;
        this.eduqualificationName = eduqualificationName;
        this.tltechnicalqualification = tltechnicalqualification;
        this.tlExperience = tlExperience;
        this.tlannualIncome = tlannualIncome;
        this.tlrationcardNo = tlrationcardNo;
        this.tlprojectName = tlprojectName;
        this.tlprojectCost = tlprojectCost;
        this.tlestimatedloanAmount = tlestimatedloanAmount;
        this.tlbankaccountNo = tlbankaccountNo;
        this.bankId = tlbankId;
        this.tlbankName = tlbankName;
        this.branchId = tlbranchId;
        this.tlbranchName = tlbranchName;
        this.tlapplicationStatus = tlapplicationStatus;
        this.enteredOn = enteredOn;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.modifiedOn = modifiedOn;
        this.modifiedBy = modifiedBy;
        this.isDeleted = isDeleted;
        this.deletedOn = deletedOn;
        this.deletedStr = isDeleted != null && isDeleted.equals(1) ? Constants.IS_DELETED_STR
                : Constants.IS_NOT_DELETED_STR;
        this.isActive = isActive;
        this.activeStr = isActive != null && isActive.equals(1) ? Constants.IS_ACTIVE_STR : Constants.IS_NOT_ACTIVE_STR;
        this.ifsc = ifsc;
        this.preslocalbodytypeId = preslocalbodytypeId;
        this.preslbtypename = preslbtypename;
        this.permlocalbodytypeId = permlocalbodytypeId;
        this.permlbtypename = permlbtypename;

        // this.photoPath = photoPath;
    }

    public TermLoanVO(Integer termLoanId,String fullName,Integer loantypeId,String loantypeName,String photoPath,String signPath){
        this.termLoanId = termLoanId;
        this.fullName = fullName;
        this.loantypeId = loantypeId;
        this.loantypeName = loantypeName;
        this.photoPath = photoPath;
        this.signPath = signPath;
    }

}
