package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.SuretyType;
import com.kswdc.loanmanagementsystem.api.repository.SuretyTypeRepository;
import com.kswdc.loanmanagementsystem.api.value.SuretyTypeVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class SuretyTypeServiceImpl implements SuretyTypeService {
	private final Logger log = LoggerFactory.getLogger(SuretyTypeServiceImpl.class);
	
	@Autowired
	private SuretyTypeRepository SuretyTypeRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createSuretyType(SuretyType suretytype) {
		try {
			SuretyType savedSuretyType = SuretyTypeRepository.save(suretytype);
			return savedSuretyType.getSuretytypeId() != null ? savedSuretyType.getSuretytypeId() : -1;
		} catch (Exception e) {
			log.error("Exception in SuretyTypeServiceImpl::createSuretyType======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateSuretyType(SuretyType SuretyType) {
		try {
			SuretyType updateSuretyType = SuretyTypeRepository.save(SuretyType);
			return updateSuretyType.getSuretytypeId() != null ? updateSuretyType.getSuretytypeId() : -1;
		} catch (Exception e) {
			log.error("Exception in SuretyTypeServiceImpl::updateSuretyType======" + e.getMessage());
		}
		return null;
	}

	@Override
	public SuretyType getSuretyType(Integer id) {
		try {
			SuretyType SuretyType = SuretyTypeRepository.getSuretyTypeById(id);
			return SuretyType;
		} catch (Exception e) {
			log.error("Exception in SuretyTypeServiceImpl::getSuretyType======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteSuretyType(Integer id) {
		try {
			SuretyType SuretyType = getSuretyType(id);
//			SuretyType.setActive(Boolean.FALSE);
			SuretyType.setDeletedOn(DateFunctions.getZonedServerDate());
			SuretyType.setIsDeleted(Constants.IS_DELETED);
			SuretyType updatedSuretyType = SuretyTypeRepository.save(SuretyType);
			return updatedSuretyType.getSuretytypeId() != null ? updatedSuretyType.getSuretytypeId() : -1;
		} catch (Exception e) {
			log.error("Exception in SuretyTypeServiceImpl::deleteSuretyType======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<SuretyTypeVO> getSuretyTypeList() {
		try {
			List<SuretyTypeVO> SuretyTypeList = SuretyTypeRepository.getSuretyTypeList();
			return SuretyTypeList;
		} catch (Exception e) {
			log.error("Exception in SuretyTypeServiceImpl::getSuretyTypeList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<SuretyTypeVO> getSuretyTypeListByLoanType(Integer loantypeId) {
		try {
			List<SuretyTypeVO> suretyTypeList = SuretyTypeRepository.getSuretyTypeListByLoanType(loantypeId);
			return suretyTypeList;
		} catch (Exception e) {
			log.error("Exception in SuretyTypeServiceImpl::getSuretyTypeListByLoanType======" + e.getMessage());
		}
		return null;
	}

	@Override
	public SuretyType getSuretyTypeBySuretyTypeName(String SuretyTypeName) {
		try {
			SuretyType SuretyType = SuretyTypeRepository.findBySuretyTypeName(SuretyTypeName);
			return SuretyType;
		} catch (Exception e) {
			log.error("Exception in SuretyTypeServiceImpl::getSuretyTypeBySuretyTypeName======" + e.getMessage());
		}
		return null;
	}
}