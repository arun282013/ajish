package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentChecklistNgoBeneficiaryVO implements Serializable {
    private Integer docChecklistngoBeneficiaryId;
    private String documentChecklistngoName;
    private String mfsngoLoanFullname;
    private String loanTypeName;
    private String filePath;
    private Integer loanTypeId;

    public DocumentChecklistNgoBeneficiaryVO(Integer docChecklistngoBeneficiaryId, String documentChecklistngoName,
            String mfsngoLoanFullname, Integer loanTypeId, String loanTypeName, String filePath) {
        this.docChecklistngoBeneficiaryId = docChecklistngoBeneficiaryId;
        this.documentChecklistngoName = documentChecklistngoName;
        this.mfsngoLoanFullname = mfsngoLoanFullname;
        this.loanTypeId = loanTypeId;
        this.loanTypeName = loanTypeName;
        this.filePath = filePath;
    }

}
