package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_ngo_lending")
@EqualsAndHashCode()
public class NgoLending{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LENDING_ID")
    private Integer lendingId;

    @Column(name = "CATEGORY", columnDefinition = "varchar(100) not null")
    private String category;
    
    @Column(name = "ACTIVITIES", columnDefinition = "varchar(100) not null")
    private String activities;

    @Column(name = "NO_OF_SHGS", columnDefinition ="int not null")
     private Integer noofshgs;
    
     @Column(name = "NO_OF_BORROWERS", columnDefinition ="int not null")
     private Integer noofborrowers;

     @Column(name = "AVG_LOAN_AMT", columnDefinition = "decimal(15,2) not null default 0.00")
     private Double avgloanamt;

     @Column(name = "TOT_AMT", columnDefinition = "decimal(15,2) not null default 0.00")
     private Double totamt;

    
       
}
