package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.TermLoan;
import com.kswdc.loanmanagementsystem.api.value.TermLoanVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface TermLoanService {

    Integer createTermLoan(TermLoan termloan);

    Integer updateTermLoan(TermLoan termloan);

    Integer updateSecondTabTermLoan(TermLoan termloan);

    TermLoan getTermLoan(Integer id);

    TermLoanVO getTermLoanByUser(Integer userId);

    // TermLoan getTermLoanByTermLoanName(String termLoanName);

    Integer deleteTermLoan(Integer id);

    List<TermLoanVO> getTermLoanList();

    // --modal view
    TermLoanVO getPreviewTermLoan(Integer termLoanId);
    // TermLoan getPreviewTermLoan(Integer id);
    // --modal view

    //--for photo
    Integer updatePhotoTermLoan(TermLoan termloan);

    TermLoanVO getTermLoanVOPhotoById(Integer termLoanId);
    //--for sign
    Integer updateSignTermLoan(TermLoan termloan);

    // TermLoanVO getTermLoanVOSignById(Integer termLoanId);


}
