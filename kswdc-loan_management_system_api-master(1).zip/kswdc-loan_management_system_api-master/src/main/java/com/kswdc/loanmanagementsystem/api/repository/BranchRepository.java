package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Branch;
import com.kswdc.loanmanagementsystem.api.value.BranchVO;

@Repository
public interface BranchRepository extends JpaRepository<Branch, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.BranchVO(o.branchId,"+
      " o.branchName,o.branchIFSC,b.bankName,d.districtName,o.createdOn,u.fullName,o.modifiedOn,"+
      "mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM Branch o LEFT JOIN Bank b ON o.bankObj= b.bankId LEFT JOIN District d ON o.districtObj = d.districtId "+
           "LEFT JOIN User u ON o.createdBy=u.userId LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 ORDER BY o.branchName ASC")
   List<BranchVO> getBranchList();//Filter only active branchs

   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.BranchVO(o.branchId,"+
      " o.branchName, o.branchIFSC, b.bankName, d.districtName, o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM Branch o LEFT JOIN Bank b ON o.bankObj= b.bankId LEFT JOIN District d ON o.districtObj = d.districtId"+
           " LEFT JOIN User u ON o.createdBy=u.userId LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 and b.bankId=:bankId ORDER BY o.branchName ASC")
   List<BranchVO> getBranchListByBank(@Param("bankId") Integer bankId);
    
    @Query("SELECT a from Branch a WHERE a.id=:branchId")
    Branch getBranchById(@Param("branchId") Integer branchId);

    @Query("SELECT cl FROM Branch cl WHERE cl.branchName=:branchName")
    Branch findByBranchName(@Param("branchName") String branchName);

}
