package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_mfscds_experience")
@EqualsAndHashCode()
public class MFSCDSExperience{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EXPERIENCE_ID")
    private Integer experienceId;

    @Column(name = "EXPERIENCE_YEAR", columnDefinition = "varchar(100) not null")
     private String experienceYear;

    @Column(name = "EXPERIENCE_NOOFGROUPS", columnDefinition = "int(11) not null")
    private Integer experienceNoofgroups;
       
    @Column(name = "EXPERIENCE_AMOUNTRECEIVED", columnDefinition = "decimal(15,2) not null default 0.00")
     private Double experienceamountReceived;

    @Column(name = "EXPERIENCE_PROJECTDONE", columnDefinition = "varchar(200) not null")
     private String experienceProjectdone;

     @Column(name = "EXPERIENCE_PENDINGAMOUNT", columnDefinition = "decimal(15,2) not null default 0.00")
     private Double experiencePendingamount;

     
      
}
