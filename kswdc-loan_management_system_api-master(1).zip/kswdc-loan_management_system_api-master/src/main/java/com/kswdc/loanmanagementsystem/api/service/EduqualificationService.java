package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Eduqualification;
import com.kswdc.loanmanagementsystem.api.value.EduqualificationVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface EduqualificationService {

    Integer createEduqualification(Eduqualification eduqualification);

    Integer updateEduqualification(Eduqualification eduqualification);

    Eduqualification getEduqualification(Integer id);

    Eduqualification getEduqualificationByEduqualificationName(String eduqualificationName);

    Integer deleteEduqualification(Integer id);

    List<EduqualificationVO> getEduqualificationList();
}
