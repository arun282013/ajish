package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_ngo_assistance")
@EqualsAndHashCode()
public class NgoAssistance{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ASSISTANCE_ID")
    private Integer assistanceId;

    @Column(name = "CATEGORY", columnDefinition = "varchar(100) not null")
    private String category;
    
    @Column(name = "ACTIVITIES", columnDefinition = "varchar(100) not null")
    private String activities;

    @Column(name = "NO_OF_SHGS", columnDefinition ="int not null")
     private Integer noofshgs;
    
     @Column(name = "NO_OF_BORROWERS", columnDefinition ="int not null")
     private Integer noofborrowers;
    
     @Column(name = "AVG_AMT", columnDefinition = "decimal(15,2) not null default 0.00")
     private Double avgamt;

     @Column(name = "AMT_REQUIRED", columnDefinition = "decimal(15,2) not null default 0.00")
     private Double amtrequired;

       
}
