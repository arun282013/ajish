package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentChecklistMFSCDSBeneficiaryVO implements Serializable {
    private Integer docChecklistMFSCDSBeneficiaryId;
    private String documentChecklistMFSCDSName;
    private String mfscdsLoanFullname;
    private String loanTypeName;
    private String filePath;
    private Integer loanTypeId;

    public DocumentChecklistMFSCDSBeneficiaryVO(Integer docChecklistMFSCDSBeneficiaryId, String documentChecklistMFSCDSName,
            String mfscdsLoanFullname, Integer loanTypeId, String loanTypeName, String filePath) {
        this.docChecklistMFSCDSBeneficiaryId = docChecklistMFSCDSBeneficiaryId;
        this.documentChecklistMFSCDSName = documentChecklistMFSCDSName;
        this.mfscdsLoanFullname = mfscdsLoanFullname;
        this.loanTypeId = loanTypeId;
        this.loanTypeName = loanTypeName;
        this.filePath = filePath;
    }

}
