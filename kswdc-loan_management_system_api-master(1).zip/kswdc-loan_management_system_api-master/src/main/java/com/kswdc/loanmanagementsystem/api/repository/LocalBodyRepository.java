package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.LocalBody;
import com.kswdc.loanmanagementsystem.api.value.LocalBodyVO;

@Repository
public interface LocalBodyRepository extends JpaRepository<LocalBody, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.LocalBodyVO(o.localbodyId,"+
      " o.localbodyName,l.localbodyTypeName,d.districtName,o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM LocalBody o LEFT JOIN LocalbodyType l ON o.localbodyTypeObj = l.localbodyTypeId"+
           "  LEFT JOIN District d ON o.districtObj = d.districtId LEFT JOIN User u ON o.createdBy=u.userId LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 ORDER BY o.localbodyName ASC")
   List<LocalBodyVO> getLocalBodyList();//Filter only active localBodys

   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.LocalBodyVO(o.localbodyId,"+
      " o.localbodyName,l.localbodyTypeName,d.districtName,o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM LocalBody o LEFT JOIN LocalbodyType l ON o.localbodyTypeObj = l.localbodyTypeId"+
           "  LEFT JOIN District d ON o.districtObj = d.districtId  LEFT JOIN User u ON o.createdBy=u.userId LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 and d.districtId=:districtId  and l.localbodyTypeId=:localbodyTypeId ORDER BY o.localbodyName ASC")
   List<LocalBodyVO> getLocalBodyListByDistrict(@Param("districtId") Integer districtId, @Param("localbodyTypeId") Integer localbodyTypeId);//Filter only active localBodys
    
    @Query("SELECT a from LocalBody a WHERE a.localbodyId=:localbodyId")
    LocalBody getLocalBodyById(@Param("localbodyId") Integer localbodyId);

    @Query("SELECT cl FROM LocalBody cl WHERE cl.localbodyName=:localbodyName")
    LocalBody findByLocalBodyName(@Param("localbodyName") String localbodyName);
}
