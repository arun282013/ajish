package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.LocalbodyType;
import com.kswdc.loanmanagementsystem.api.repository.LocalbodyTypeRepository;
import com.kswdc.loanmanagementsystem.api.value.LocalbodyTypeVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class LocalbodyTypeServiceImpl implements LocalbodyTypeService {
	private final Logger log = LoggerFactory.getLogger(LocalbodyTypeServiceImpl.class);
	
	@Autowired
	private LocalbodyTypeRepository localbodyTypeRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createLocalbodyType(LocalbodyType LocalbodyType) {
		try {
			LocalbodyType savedLocalbodyType = localbodyTypeRepository.save(LocalbodyType);
			return savedLocalbodyType.getLocalbodyTypeId() != null ? savedLocalbodyType.getLocalbodyTypeId() : -1;
		} catch (Exception e) {
			log.error("Exception in LocalbodyTypeServiceImpl::createLocalbodyType======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateLocalbodyType(LocalbodyType LocalbodyType) {
		try {
			LocalbodyType updateLocalbodyType = localbodyTypeRepository.save(LocalbodyType);
			return updateLocalbodyType.getLocalbodyTypeId() != null ? updateLocalbodyType.getLocalbodyTypeId() : -1;
		} catch (Exception e) {
			log.error("Exception in LocalbodyTypeServiceImpl::updateLocalbodyType======" + e.getMessage());
		}
		return null;
	}

	@Override
	public LocalbodyType getLocalbodyType(Integer id) {
		try {
			LocalbodyType localbodyType = localbodyTypeRepository.getLocalbodyTypeById(id);
			return localbodyType;
		} catch (Exception e) {
			log.error("Exception in LocalbodyTypeServiceImpl::getLocalbodyType======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteLocalbodyType(Integer id) {
		try {
			LocalbodyType LocalbodyType = getLocalbodyType(id);
//			LocalbodyType.setActive(Boolean.FALSE);
			LocalbodyType.setDeletedOn(DateFunctions.getZonedServerDate());
			LocalbodyType.setIsDeleted(Constants.IS_DELETED);
			LocalbodyType updatedLocalbodyType = localbodyTypeRepository.save(LocalbodyType);
			return updatedLocalbodyType.getLocalbodyTypeId() != null ? updatedLocalbodyType.getLocalbodyTypeId() : -1;
		} catch (Exception e) {
			log.error("Exception in LocalbodyTypeServiceImpl::deleteLocalbodyType======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<LocalbodyTypeVO> getLocalbodyTypeList() {
		try {
			List<LocalbodyTypeVO> localbodyTypeList = localbodyTypeRepository.getLocalbodyTypeList();
			return localbodyTypeList;
		} catch (Exception e) {
			log.error("Exception in LocalbodyTypeServiceImpl::getLocalbodyTypeList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public LocalbodyType getLocalbodyTypeByLocalbodyTypeName(String localbodyTypeName) {
		try {
			LocalbodyType localbodyType = localbodyTypeRepository.findByLocalbodyTypeName(localbodyTypeName);
			return localbodyType;
		} catch (Exception e) {
			log.error("Exception in LocalbodyTypeServiceImpl::getLocalbodyTypeByLocalbodyTypeName======" + e.getMessage());
		}
		return null;
	}
}