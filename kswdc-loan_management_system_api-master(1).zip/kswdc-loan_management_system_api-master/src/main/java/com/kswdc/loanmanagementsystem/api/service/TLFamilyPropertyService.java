package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.TLFamilyProperty;
import com.kswdc.loanmanagementsystem.api.value.TLFamilyPropertyVO;


@Component
public interface TLFamilyPropertyService {

    Integer createTLFamilyProperty(TLFamilyProperty tlfamilyproperty);

    Integer updateTLFamilyProperty(TLFamilyProperty tlfamilyproperty);
     TLFamilyProperty getTLFamilyProperty(Integer id);

    // TLFamilyProperty getTLFamilyPropertyByTLFamilyPropertyName(String tlfamilypropertyName);

    Integer deleteTLFamilyProperty(Integer id);
    //--
    // List<TLFamilyPropertyVO> getTLFamilyPropertyList();
    List<TLFamilyProperty> getTLFamilyPropertyListByTLId(Integer termLoanId);
    //--
}
