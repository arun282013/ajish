package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserVO implements Serializable {

    private Integer userId;
    private String fullName;
    private String aadharNo;
    private String mobileNo;
    private String emailId;
    private Integer userTypeId;
    private String userName;
    private String userPassword;
    private Integer accountType;
    private Integer loancategoryId;
    private Integer userStatus;
    private String userStatusStr;
    private ZonedDateTime createdOn;
    private String createdBy;
    private ZonedDateTime modifiedOn;
    private String modifiedBy;
    private Integer isDeleted;
    private String deletedStr;
    private ZonedDateTime deletedOn;
    private String activeStr;

    public UserVO(Integer userId, String fullName, String aadharNo,
            String mobileNo, String emailId, String userName,
            String userPassword, ZonedDateTime createdOn, String createdBy, ZonedDateTime modifiedOn,
            String modifiedBy, Integer isDeleted, ZonedDateTime deletedOn, Integer userStatus) {
        this.userId = userId;
        this.fullName = fullName;
        this.aadharNo = aadharNo;
        this.mobileNo = mobileNo;
        this.emailId = emailId;
        this.userName = userName;
        this.userPassword = userPassword;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.modifiedOn = modifiedOn;
        this.modifiedBy = modifiedBy;
        this.isDeleted = isDeleted;
        this.deletedStr = isDeleted != null && isDeleted.equals(1) ? Constants.IS_DELETED_STR
                : Constants.IS_NOT_DELETED_STR;
        this.deletedOn = deletedOn;
        this.userStatus = userStatus;
        this.activeStr = userStatus != null && userStatus.equals(1) ? Constants.IS_ACTIVE_STR
                : Constants.IS_NOT_ACTIVE_STR;
    }

}
