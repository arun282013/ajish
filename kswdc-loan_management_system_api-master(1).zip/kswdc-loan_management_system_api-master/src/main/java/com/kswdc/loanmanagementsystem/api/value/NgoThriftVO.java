package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class NgoThriftVO implements Serializable {
    private Integer thriftId;
    private String nameandaddress;
    private Date dteformation;
    private Integer members;
    private String savings;
    private String outofsavings;
    private Integer amtrecovered;
    private Integer amtoutstanding;


    public NgoThriftVO(Integer thriftId, 
    String nameandaddress,Date dteformation,
    Integer members, String savings,
    String outofsavings,
    Integer amtrecovered,Integer amtoutstanding
    ) {
        this.thriftId = thriftId;
        this.nameandaddress = nameandaddress;
        this.dteformation = dteformation;
        this.members = members;
        this.savings = savings;
        this.outofsavings = outofsavings;
        this.amtrecovered = amtrecovered;
        this.amtoutstanding = amtoutstanding;
    }
    
}
