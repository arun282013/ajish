package com.kswdc.loanmanagementsystem.common;

import org.springframework.http.HttpStatus;

public class Constants {
	/**********KEY STRINGS START********************/
	public static String EMPTY_STRING = "";
	public static String STATUS ="status";
	public static String STATUS_SUCCESS ="success";
	public static String STATUS_ERROR ="error";
	public static String ERROR_CODE ="errorCode";
	public static String DATA ="data";
	public static String MESSAGE ="msg";
	/**********KEY STRINGS END********************/
	
	/**********MESSAGE TYPES START********************/
	public static Integer ERROR_EVENTS=300;
	/**********MESSAGE TYPES END********************/
	
	/**********MESSAGES START********************/
	public static String MSG_DATA_NOT_FOUND ="No matching data found.";
	public static String MSG_ERROR ="Error in method:: ";
	public static String MSG_DATA_ALREADY_EXISTS ="Data already exists.";
	public static String MSG_DATA_ALREADY_DELETED ="Data already deleted.";
	public static String MSG_DATA_RECV_NOT_VALID ="Received data is not valid.";
	public static String MSG_ERROR_DATA_SAVE ="Could not save data. Please try again.";
	public static String MSG_ERROR_DATA_UPDATE ="Could not update data. Please try again.";
	public static String MSG_ERROR_DATA_PARTIAL_UPDATE ="Could not update all data. Please try again.";
	/**********MESSAGES END********************/
	
	/**********DATA RESPONSE START********************/
	public static Integer DATA_ALREADY_EXISTS=409;
	public static Integer DATA_ALREADY_DELETED=410;
	public static Integer INTERNAL_SERVER_ERROR =500;
	public static Integer NOT_FOUND = 404;
	public static Integer NO_CONTENT = 204;
	public static Integer NOT_ACCEPTABLE = 406;
	public static Integer DB_FETCH_ERROR = 512;
	public static Integer DB_PARTIAL_UPDATE = 513;
	/**********DATA RESPONSE END********************/
	
	/**********STATUS START********************/
	public static Integer IS_ACTIVE=1;
	public static Integer IS_NOT_ACTIVE=0;
	public static Integer IS_DELETED=1;
	public static Integer IS_NOT_DELETED=0;
	public static String IS_ACTIVE_STR="ACTIVE";
	public static String IS_NOT_ACTIVE_STR="IN ACTIVE";
	public static String IS_DELETED_STR="DELETED";
	public static String IS_NOT_DELETED_STR="";
	/**********STATUS END********************/

}
