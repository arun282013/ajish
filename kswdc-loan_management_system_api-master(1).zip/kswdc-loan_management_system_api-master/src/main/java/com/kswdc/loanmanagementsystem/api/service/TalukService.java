package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Taluk;
import com.kswdc.loanmanagementsystem.api.value.TalukVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface TalukService {

    Integer createTaluk(Taluk taluk);

    Integer updateTaluk(Taluk taluk);

    Taluk getTaluk(Integer id);

    Taluk getTalukByTalukName(String talukName);

    Integer deleteTaluk(Integer id);

    List<TalukVO> getTalukList();

    List<TalukVO> getTalukListByDistrict(Integer districtId);
}
