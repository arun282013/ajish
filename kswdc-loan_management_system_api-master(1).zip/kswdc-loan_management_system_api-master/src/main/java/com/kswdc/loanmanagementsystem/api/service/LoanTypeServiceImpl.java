package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.LoanType;
import com.kswdc.loanmanagementsystem.api.repository.LoanTypeRepository;
import com.kswdc.loanmanagementsystem.api.value.LoanTypeVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class LoanTypeServiceImpl implements LoanTypeService {
	private final Logger log = LoggerFactory.getLogger(LoanTypeServiceImpl.class);
	
	@Autowired
	private LoanTypeRepository loanTypeRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createLoanType(LoanType LoanType) {
		try {
			LoanType savedLoanType = loanTypeRepository.save(LoanType);
			return savedLoanType.getLoantypeId() != null ? savedLoanType.getLoantypeId() : -1;
		} catch (Exception e) {
			log.error("Exception in LoanTypeServiceImpl::createLoanType======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateLoanType(LoanType LoanType) {
		try {
			LoanType updateLoanType = loanTypeRepository.save(LoanType);
			return updateLoanType.getLoantypeId() != null ? updateLoanType.getLoantypeId() : -1;
		} catch (Exception e) {
			log.error("Exception in LoanTypeServiceImpl::updateLoanType======" + e.getMessage());
		}
		return null;
	}

	@Override
	public LoanType getLoanType(Integer id) {
		try {
			LoanType loanType = loanTypeRepository.getLoanTypeById(id);
			return loanType;
		} catch (Exception e) {
			log.error("Exception in LoanTypeServiceImpl::getLoanType======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteLoanType(Integer id) {
		try {
			LoanType LoanType = getLoanType(id);
//			LoanType.setActive(Boolean.FALSE);
			LoanType.setDeletedOn(DateFunctions.getZonedServerDate());
			LoanType.setIsDeleted(Constants.IS_DELETED);
			LoanType updatedLoanType = loanTypeRepository.save(LoanType);
			return updatedLoanType.getLoantypeId() != null ? updatedLoanType.getLoantypeId() : -1;
		} catch (Exception e) {
			log.error("Exception in LoanTypeServiceImpl::deleteLoanType======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<LoanTypeVO> getLoanTypeList() {
		try {
			List<LoanTypeVO> loanTypeList = loanTypeRepository.getLoanTypeList();
			return loanTypeList;
		} catch (Exception e) {
			log.error("Exception in LoanTypeServiceImpl::getLoanTypeList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public LoanType getLoanTypeByLoanTypeName(String loanTypeName) {
		try {
			LoanType loanType = loanTypeRepository.findByLoanTypeName(loanTypeName);
			return loanType;
		} catch (Exception e) {
			log.error("Exception in LoanTypeServiceImpl::getLoanTypeByLoanTypeName======" + e.getMessage());
		}
		return null;
	}
}