package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Postoffice;
import com.kswdc.loanmanagementsystem.api.value.PostofficeVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface PostofficeService {

    Integer createPostoffice(Postoffice postoffice);

    Integer updatePostoffice(Postoffice postoffice);

    Postoffice getPostoffice(Integer id);

    Postoffice getPostofficeByPostofficeName(String postofficeName);

    Integer deletePostoffice(Integer id);

    List<PostofficeVO> getPostofficeList();

    List<PostofficeVO> getPostofficeListByDistrict(Integer districtId);
}
