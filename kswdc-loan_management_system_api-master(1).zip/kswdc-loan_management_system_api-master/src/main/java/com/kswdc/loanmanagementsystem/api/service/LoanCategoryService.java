package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.LoanCategory;
import com.kswdc.loanmanagementsystem.api.value.LoanCategoryVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface LoanCategoryService {

    Integer createLoanCategory(LoanCategory loanCategory);

    Integer updateLoanCategory(LoanCategory loanCategory);

    LoanCategory getLoanCategory(Integer id);

    LoanCategory getLoanCategoryByLoanCategoryName(String loancategoryName);

    Integer deleteLoanCategory(Integer id);

    List<LoanCategoryVO> getLoanCategoryList();
}
