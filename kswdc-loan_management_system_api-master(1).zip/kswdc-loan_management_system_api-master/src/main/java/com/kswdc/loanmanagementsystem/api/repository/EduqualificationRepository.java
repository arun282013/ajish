package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Eduqualification;
import com.kswdc.loanmanagementsystem.api.value.EduqualificationVO;

@Repository
public interface EduqualificationRepository extends JpaRepository<Eduqualification, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.EduqualificationVO(o.eduqualificationId,"+
      " o.eduqualificationName,o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM Eduqualification o LEFT JOIN User u ON o.createdBy=u.userId LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 ORDER BY o.eduqualificationName ASC")
   List<EduqualificationVO> getEduqualificationList();//Filter only active eduqualifications
    
    @Query("SELECT a from Eduqualification a WHERE a.id=:eduqualificationId")
    Eduqualification getEduqualificationById(@Param("eduqualificationId") Integer eduqualificationId);

    @Query("SELECT cl FROM Eduqualification cl WHERE cl.eduqualificationName=:eduqualificationName")
    Eduqualification findByEduqualificationName(@Param("eduqualificationName") String eduqualificationName);
}
