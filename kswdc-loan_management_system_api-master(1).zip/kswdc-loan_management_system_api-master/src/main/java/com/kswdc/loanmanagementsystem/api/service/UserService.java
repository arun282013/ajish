package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.User;
import com.kswdc.loanmanagementsystem.api.value.UserVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface UserService {

    Integer createUser(User user);

    Integer updateUser(User user);

    User getUser(Integer id);

    User getUserByUserName(String userName);

    Integer deleteUser(Integer id);

    List<UserVO> getUserList();
}
