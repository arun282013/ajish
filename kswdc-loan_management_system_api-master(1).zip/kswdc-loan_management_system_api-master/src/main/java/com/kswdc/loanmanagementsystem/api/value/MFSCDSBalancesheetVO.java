package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MFSCDSBalancesheetVO implements Serializable {
    private Integer balancesheetId;
    private String balancesheetYear;
    private Double balancesheetAmount;
    
    public MFSCDSBalancesheetVO(Integer balancesheetId, 
    String balancesheetYear, Double balancesheetAmount) {
        this.balancesheetId = balancesheetId;
        this.balancesheetYear = balancesheetYear;
        this.balancesheetAmount = balancesheetAmount;    
    }
    
}
