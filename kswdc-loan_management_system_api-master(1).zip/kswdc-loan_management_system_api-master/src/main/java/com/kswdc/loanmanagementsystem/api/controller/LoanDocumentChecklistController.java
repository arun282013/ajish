package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.LoanDocumentChecklist;
import com.kswdc.loanmanagementsystem.api.service.LoanDocumentChecklistService;
import com.kswdc.loanmanagementsystem.api.value.LoanDocumentChecklistVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class LoanDocumentChecklistController {

	private final Logger log = LoggerFactory.getLogger(LoanDocumentChecklistController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private LoanDocumentChecklistService loanDocumentChecklistService;
	

	@RequestMapping(value = "/loanDocumentChecklist", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createLoanDocumentChecklist(@RequestBody LoanDocumentChecklist LoanDocumentChecklist) {
		log.info("In LoanDocumentChecklistController::createLoanDocumentChecklist=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(LoanDocumentChecklist)) {
					//						LoanType.setActive(Boolean.TRUE);
						//LoanDocumentChecklist.setCreatedOn(DateFunctions.getZonedServerDate());
						// LoanType.setCreatedBy();
						//LoanDocumentChecklist.setIsDeleted(0);
						Integer LoanDocumentChecklistId = loanDocumentChecklistService.createLoanDocumentChecklist(LoanDocumentChecklist);
						if (!LoanDocumentChecklistId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("LoanDocumentChecklistId", LoanDocumentChecklistId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanDocumentChecklistController::createLoanDocumentChecklist======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	@RequestMapping(value = "/loanDocumentChecklist", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateLoanDocumentChecklist(@RequestBody LoanDocumentChecklist loanDocumentChecklist) {
		log.info("In LoanDocumentChecklistController::updateLoanDocumentChecklist=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (loanDocumentChecklist != null) { // && LoanType.getId() != null
				if (checkValid(loanDocumentChecklist)) {
					LoanDocumentChecklist chkLoanDocumentChecklist = loanDocumentChecklistService.getLoanDocumentChecklist(loanDocumentChecklist.getLoanDocChecklistId());
					if (chkLoanDocumentChecklist!=null) {
//						if (chkLoanType.getActive()) {
//							LoanType.setActive(Boolean.TRUE);
							//chkLoanDocumentChecklist.setLoandocumentChecklistCode(loanDocumentChecklist.);
							//chkLoanDocumentChecklist.setLoandocumentChecklistName(loanDocumentChecklist.getLoantypeName());							
							//chkLoanDocumentChecklist.setIsActive(loanDocumentChecklist.getIsActive());							
							Integer LoanDocumentChecklistId = loanDocumentChecklistService.updateLoanDocumentChecklist(chkLoanDocumentChecklist);
							if (!LoanDocumentChecklistId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("LoanDocumentChecklistId:", LoanDocumentChecklistId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" LoanType Id is deactivated:"+LoanType.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanDocumentChecklistController::updateLoanDocumentChecklist======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	@RequestMapping(value = "/loanDocumentChecklist/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteLoanDocumentChecklist(@PathVariable Integer id) {
		log.info("In LoanDocumentChecklistController::deleteLoanDocumentChecklist=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				LoanDocumentChecklist LoanDocumentChecklist = loanDocumentChecklistService.getLoanDocumentChecklist(id);
				if (LoanDocumentChecklist != null) {
//					if (!LoanType.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " LoanTypeId:" + id);
//					} else {
						Integer LoanDocumentChecklistId = loanDocumentChecklistService.deleteLoanDocumentChecklist(id);
						if (!LoanDocumentChecklistId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("LoanDocumentChecklistId", LoanDocumentChecklistId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanDocumentChecklistController::deleteLoanDocumentChecklist======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	@RequestMapping(value = "/loanDocumentChecklist/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneLoanDocumentChecklist(@PathVariable Integer id) {
		log.info("In LoanDocumentChecklistController::getOneLoanDocumentChecklist=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				LoanDocumentChecklist LoanDocumentChecklist = loanDocumentChecklistService.getLoanDocumentChecklist(id);
				if (LoanDocumentChecklist != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("LoanDocumentChecklist", LoanDocumentChecklist);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanDocumentChecklistController::getOneLoanDocumentChecklist======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	@RequestMapping(value = "/loanDocumentChecklist-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getLoanDocumentChecklistList() {
		log.info("In LoanDocumentChecklistController::getLoanDocumentChecklistList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			LoanTypeListReturnVO LoanTypeListReturnVO = new LoanTypeListReturnVO(LoanTypeService.getLoanTypeList());
			List<LoanDocumentChecklistVO> LoanDocumentChecklistListReturnVO = loanDocumentChecklistService.getLoanDocumentChecklistList();
			if (LoanDocumentChecklistListReturnVO != null && LoanDocumentChecklistListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("loanDocumentChecklists", LoanDocumentChecklistListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanDocumentChecklistController::getLoanDocumentChecklistList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	

	private Boolean checkIfExists(Integer LoanDocumentChecklistId) {
		return (loanDocumentChecklistService.getLoanDocumentChecklist(LoanDocumentChecklistId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	
	private Boolean checkValid(LoanDocumentChecklist loanDocumentChecklist) {
		Boolean isValid = true;
		invalidMsg = "";
		if (loanDocumentChecklist != null) {
//			if(LoanType.getId()==null || LoanType.getId()<=0) {
//				invalidMsg+="LoanTypeId is required and should be valid!";
//				isValid = false;
//			}
			// if (LoanDocumentChecklist.getLoandocumentChecklistName() == null || LoanDocumentChecklist.getLoandocumentChecklistName().equalsIgnoreCase("")) {
			// 	invalidMsg += "LoanDocumentChecklist Name is required and should not be empty!";
			// 	isValid = false;
			// }
//			if (LoanType.getLoanTypeName() == null || LoanType.getLoanTypeName().equalsIgnoreCase("")) {
//				invalidMsg += "LoanType Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (LoanType.getQuotaInMB() == null || LoanType.getQuotaInMB().equals(0) || LoanType.getQuotaInMB()<0) {
//				invalidMsg += "LoanType Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanType.getChatHistoryDays() == null || LoanType.getChatHistoryDays().equals(0) || LoanType.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for LoanType is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanType.getCdaTimeoutTime() == null || LoanType.getCdaTimeoutTime().equals(0) || LoanType.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for loanDocumentChecklist!";
			isValid = false;
		}
		return isValid;
	}
	
}
