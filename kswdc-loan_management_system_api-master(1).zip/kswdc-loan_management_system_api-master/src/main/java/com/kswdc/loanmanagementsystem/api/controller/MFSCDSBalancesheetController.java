package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.MFSCDSBalancesheet;
import com.kswdc.loanmanagementsystem.api.service.MFSCDSBalancesheetService;
import com.kswdc.loanmanagementsystem.api.value.MFSCDSBalancesheetVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;


@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class MFSCDSBalancesheetController {

	private final Logger log = LoggerFactory.getLogger(MFSCDSBalancesheetController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private MFSCDSBalancesheetService mfscdsbalancesheetService;
	
	/**
	 * @param MFSCDSBalancesheet MFSCDSBalancesheet
	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsbalancesheet", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createMFSCDSBalancesheet(@RequestBody MFSCDSBalancesheet MFSCDSBalancesheet) {
		log.info("In MFSCDSBalancesheetController::createMFSCDSBalancesheet=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(MFSCDSBalancesheet)) {
						Integer BalancesheetId = mfscdsbalancesheetService.createMFSCDSBalancesheet(MFSCDSBalancesheet);
						if (!BalancesheetId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("BalancesheetId", BalancesheetId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSBalancesheetController::createMFSCDSBalancesheet======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * //@param MFSCDSBalancesheet MFSCDSBalancesheet
	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsbalancesheet", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateMFSCDSBalancesheet(@RequestBody MFSCDSBalancesheet mfscdsbalancesheet) {
		log.info("In MFSCDSBalancesheetController::updateMFSCDSBalancesheet=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (mfscdsbalancesheet != null) { // && MFSCDSExperience.getId() != null
				if (checkValid(mfscdsbalancesheet)) {
					MFSCDSBalancesheet chkMFSCDSBalancesheet = mfscdsbalancesheetService.getMFSCDSBalancesheet(mfscdsbalancesheet.getBalancesheetId());
					if (chkMFSCDSBalancesheet!=null) {						
							chkMFSCDSBalancesheet.setBalancesheetId(mfscdsbalancesheet.getBalancesheetId());
							
							Integer balancesheetId = mfscdsbalancesheetService.updateMFSCDSBalancesheet(chkMFSCDSBalancesheet);
							if (!balancesheetId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("BalancesheetId:", balancesheetId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSBalancesheetController::updateMFSCDSBalancesheet======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsbalancesheet/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteMFSCDSBalancesheet(@PathVariable Integer id) {
		log.info("In MFSCDSBalancesheetController::deleteMFSCDSBalancesheet=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				MFSCDSBalancesheet MFSCDSBalancesheet = mfscdsbalancesheetService.getMFSCDSBalancesheet(id);
				if (MFSCDSBalancesheet != null) {
						Integer balancesheetId = mfscdsbalancesheetService.deleteMFSCDSBalancesheet(id);
						if (!balancesheetId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("MFSCDSBalancesheetId", balancesheetId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSBalancesheetController::deleteMFSCDSBalancesheet======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsbalancesheet/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneMFSCDSBalancesheet(@PathVariable Integer id) {
		log.info("In MFSCDSBalancesheetController::getOneMFSCDSBalancesheet=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				MFSCDSBalancesheet MFSCDSBalancesheet = mfscdsbalancesheetService.getMFSCDSBalancesheet(id);
				if (MFSCDSBalancesheet != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("MFSCDSBalancesheet", MFSCDSBalancesheet);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSBalancesheetController::getOneMFSCDSBalancesheet======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End:



	/**
	 * @param MFSCDSBalancesheetId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer balancesheetId) {
		return (mfscdsbalancesheetService.getMFSCDSBalancesheet(balancesheetId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @purpose For checking if mandatory data is passed
	 * @param MFSCDSBalancesheet
	 * @return Boolean
	 */
	private Boolean checkValid(MFSCDSBalancesheet MFSCDSBalancesheet) {
		Boolean isValid = true;
		invalidMsg = "";
		if (MFSCDSBalancesheet != null) {
			if (MFSCDSBalancesheet.getBalancesheetYear() == null || MFSCDSBalancesheet.getBalancesheetYear().equalsIgnoreCase("")) {
				invalidMsg += "MFSCDSBalancesheet Year is required and should not be empty!";
				isValid = false;
			}

		} else {
			invalidMsg = "Received data is not valid for MFSCDSBalancesheet!";
			isValid = false;
		}
		return isValid;
	}
	
}
