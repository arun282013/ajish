package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.UserType;
import com.kswdc.loanmanagementsystem.api.value.UserTypeVO;

@Repository
public interface UserTypeRepository extends JpaRepository<UserType, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.UserTypeVO(o.usertypeId,"+
      " o.usertypeName,o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM UserType o LEFT JOIN User u ON o.createdBy=u.userId LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 ORDER BY o.usertypeName ASC")
   List<UserTypeVO> getUserTypeList();//Filter only active userTypes
    
    @Query("SELECT a from UserType a WHERE a.id=:userTypeId")
    UserType getUserTypeById(@Param("userTypeId") Integer userTypeId);

    @Query("SELECT cl FROM UserType cl WHERE cl.usertypeName=:userTypeName")
    UserType findByUserTypeName(@Param("userTypeName") String userTypeName);
}
