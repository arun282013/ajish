package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.LoanCategory;
import com.kswdc.loanmanagementsystem.api.repository.LoanCategoryRepository;
import com.kswdc.loanmanagementsystem.api.value.LoanCategoryVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class LoanCategoryServiceImpl implements LoanCategoryService {
	private final Logger log = LoggerFactory.getLogger(LoanCategoryServiceImpl.class);
	
	@Autowired
	private LoanCategoryRepository loanCategoryRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createLoanCategory(LoanCategory LoanCategory) {
		try {
			LoanCategory savedLoanCategory = loanCategoryRepository.save(LoanCategory);
			return savedLoanCategory.getLoanCategoryId() != null ? savedLoanCategory.getLoanCategoryId() : -1;
		} catch (Exception e) {
			log.error("Exception in LoanCategoryServiceImpl::createLoanCategory======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateLoanCategory(LoanCategory LoanCategory) {
		try {
			LoanCategory updateLoanCategory = loanCategoryRepository.save(LoanCategory);
			return updateLoanCategory.getLoanCategoryId() != null ? updateLoanCategory.getLoanCategoryId() : -1;
		} catch (Exception e) {
			log.error("Exception in LoanCategoryServiceImpl::updateLoanCategory======" + e.getMessage());
		}
		return null;
	}

	@Override
	public LoanCategory getLoanCategory(Integer id) {
		try {
			LoanCategory loanCategory = loanCategoryRepository.getLoanCategoryById(id);
			return loanCategory;
		} catch (Exception e) {
			log.error("Exception in LoanCategoryServiceImpl::getLoanCategory======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteLoanCategory(Integer id) {
		try {
			LoanCategory LoanCategory = getLoanCategory(id);
//			LoanCategory.setActive(Boolean.FALSE);
			LoanCategory.setDeletedOn(DateFunctions.getZonedServerDate());
			LoanCategory.setIsDeleted(Constants.IS_DELETED);
			LoanCategory updatedLoanCategory = loanCategoryRepository.save(LoanCategory);
			return updatedLoanCategory.getLoanCategoryId() != null ? updatedLoanCategory.getLoanCategoryId() : -1;
		} catch (Exception e) {
			log.error("Exception in LoanCategoryServiceImpl::deleteLoanCategory======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<LoanCategoryVO> getLoanCategoryList() {
		try {
			List<LoanCategoryVO> loanCategoryList = loanCategoryRepository.getLoanCategoryList();
			return loanCategoryList;
		} catch (Exception e) {
			log.error("Exception in LoanCategoryServiceImpl::getLoanCategoryList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public LoanCategory getLoanCategoryByLoanCategoryName(String loanCategoryName) {
		try {
			LoanCategory loanCategory = loanCategoryRepository.findByLoanCategoryName(loanCategoryName);
			return loanCategory;
		} catch (Exception e) {
			log.error("Exception in LoanCategoryServiceImpl::getLoanCategoryByLoanCategoryName======" + e.getMessage());
		}
		return null;
	}
}