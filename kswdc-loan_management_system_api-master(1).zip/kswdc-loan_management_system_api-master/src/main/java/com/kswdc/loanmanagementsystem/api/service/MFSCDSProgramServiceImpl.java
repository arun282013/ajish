package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.MFSCDSProgram;
import com.kswdc.loanmanagementsystem.api.repository.MFSCDSProgramRepository;
import com.kswdc.loanmanagementsystem.api.value.MFSCDSProgramVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 */

@Service
public class MFSCDSProgramServiceImpl implements MFSCDSProgramService {
	private final Logger log = LoggerFactory.getLogger(MFSCDSProgramServiceImpl.class);
	
	@Autowired
	private MFSCDSProgramRepository mfscdsprogramRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createMFSCDSProgram(MFSCDSProgram MFSCDSProgram) {
		try {
			MFSCDSProgram savedMFSCDSProgram = mfscdsprogramRepository.save(MFSCDSProgram);
			return savedMFSCDSProgram.getProgramId() != null ? savedMFSCDSProgram.getProgramId() : -1;
		} catch (Exception e) {
			log.error("Exception in MFSCDSProgramServiceImpl::createMFSCDSProgram======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateMFSCDSProgram(MFSCDSProgram MFSCDSProgram) {
		try {
			MFSCDSProgram updateMFSCDSProgram = mfscdsprogramRepository.save(MFSCDSProgram);
			return updateMFSCDSProgram.getProgramId() != null ? updateMFSCDSProgram.getProgramId() : -1;
		} catch (Exception e) {
			log.error("Exception in MFSCDSProgramServiceImpl::updateMFSCDSProgram======" + e.getMessage());
		}
		return null;
	}

	@Override
	public MFSCDSProgram getMFSCDSProgram(Integer id) {
		try {
			MFSCDSProgram mfscdsprogram = mfscdsprogramRepository.getMFSCDSProgramById(id);
			return mfscdsprogram;
		} catch (Exception e) {
			log.error("Exception in MFSCDSProgramServiceImpl::getMFSCDSProgram======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteMFSCDSProgram(Integer id) {
		try {
			MFSCDSProgram MFSCDSProgram = getMFSCDSProgram(id);
			MFSCDSProgram updatedMFSCDSProgram = mfscdsprogramRepository.save(MFSCDSProgram);
			return updatedMFSCDSProgram.getProgramId() != null ? updatedMFSCDSProgram.getProgramId() : -1;
		} catch (Exception e) {
			log.error("Exception in MFSCDSProgramServiceImpl::deleteMFSCDSProgram======" + e.getMessage());
		}
		return null;
	}

	
}