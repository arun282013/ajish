package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_tl_family_property")
@EqualsAndHashCode()
public class TLFamilyProperty{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PROPERTY_ID")
    private Integer propertyId;

    @Column(name = "PROPERTY_NAME", columnDefinition = "varchar(100) not null")
    private String propertyName;
    
    @Column(name = "SIZE", columnDefinition = "varchar(50) not null")
     private String size;
    
     @Column(name = "SURVEY_NUMBER", columnDefinition = "varchar(40) not null" )
     private String surveyNo;
         
    @ManyToOne()
    @JoinColumn(name= "VILLAGE_ID",nullable = true)
    private Village villageObj;

    @ManyToOne()
    @JoinColumn(name= "TALUK_ID",nullable = true)
    private Taluk talukObj;

    @ManyToOne()
    @JoinColumn(name= "DISTRICT_ID",nullable = true)
    private District districtObj;

       
}
