package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.LoanDocumentChecklist;
import com.kswdc.loanmanagementsystem.api.value.LoanDocumentChecklistVO;

@Repository
public interface LoanDocumentChecklistRepository extends JpaRepository<LoanDocumentChecklist, Integer> {
    @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.LoanDocumentChecklistVO(lc.loanDocChecklistId,"+
    " l.loantypeName,dc.documentchecklistName) " +
         " FROM LoanDocumentChecklist lc LEFT JOIN LoanType l ON lc.loanTypeObj=l.loantypeId LEFT JOIN DocumentChecklist dc ON lc.documentChecklistObj=dc.documentchecklistId "+
          " ORDER BY lc.loanDocChecklistId ASC") 
 List<LoanDocumentChecklistVO> getLoanDocumentChecklistList();//Filter only active data
  
  @Query("SELECT a from LoanDocumentChecklist a WHERE a.id=:loanDocChecklistId")
  LoanDocumentChecklist getLoanDocumentChecklistById(@Param("loanDocChecklistId") Integer loanDocChecklistId);

  // @Query("SELECT cl FROM LoanDocumentChecklist cl WHERE cl.userName=:userName")
  // LoanDocumentChecklist findByLoanDocumentChecklistName(@Param("userName") String userName);
}
