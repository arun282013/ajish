package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TLFamilyPropertyVO implements Serializable {
    private Integer propertyId;
    private String propertyName;
    private String size;
    private String surveyNo;
    private String villageName;
    private String talukName;
    private String districtName;

    public TLFamilyPropertyVO(Integer propertyId, String propertyName,String size,
    String surveyNo,String villageName,String talukName,String districtName ) {
        this.propertyId = propertyId;
        this.propertyName = propertyName;
        this.size = size;
        this.surveyNo = surveyNo;
        this.villageName = villageName;
        this.talukName = talukName;
        this.districtName = districtName;
    }
    
}
