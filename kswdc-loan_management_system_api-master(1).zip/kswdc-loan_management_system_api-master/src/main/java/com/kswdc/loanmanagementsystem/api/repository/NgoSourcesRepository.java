package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.NgoSources;
import com.kswdc.loanmanagementsystem.api.value.NgoSourcesVO;

@Repository
public interface NgoSourcesRepository extends JpaRepository<NgoSources, Integer> {
   // @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TLFamilyMemberVO(f.tlfamilyMemberId,"+
   //    " f.tlfamilyMemberName,f.tlfamilyMemberAge,f.tlfamilyMemberEduqualification,f.tlfamilyMemberJob,"+
   //       "f.tlfamilyMemberAnnualIncome,t.fullName,r.relationName)"+ 
   //       "FROM TLFamilyMember f LEFT JOIN TermLoan t ON f.termLoanObj= t.termLoanId "+
   //       " LEFT JOIN Relation r ON f.relationObj = r.relationId "+
   //         " ORDER BY f.tlfamilyMemberName ASC")
   // @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TLFamilyMemberVO(f.tlfamilyMemberId,"+
   //    " f.tlfamilyMemberName,f.tlfamilyMemberAge,f.tlfamilyMemberEduqualification,f.tlfamilyMemberJob,"+
   //       "f.tlfamilyMemberAnnualIncome,t.fullName,r.relationName)"+ 
   //       "FROM TLFamilyMember f "+
   //       " LEFT JOIN Relation r ON f.relationObj = r.relationId "+
   //         " ORDER BY f.tlfamilyMemberName ASC")
//    List<TLFamilyMemberVO> getTLFamilyMemberList();//Filter only active familymember
    
    @Query("SELECT a FROM NgoSources a WHERE a.id=:sourcesId")
    NgoSources getNgoSourcesById(@Param("sourcesId") Integer sourcesId);
 
    @Query("SELECT cl FROM NgoSources cl WHERE cl.sourcesname=sourcesname")
    NgoSources getNgoSourcesByNgoSourcesname(@Param("sourcesname") String sourcesname);

}
