package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_tl_family_member")
@EqualsAndHashCode()
public class TLFamilyMember{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MEMBER_ID")
    private Integer memberId;

    @Column(name = "MEMBER_NAME", columnDefinition = "varchar(100) not null")
    private String memberName;
    
    @Column(name = "AGE", columnDefinition ="int not null")
     private Integer age;
    
    //  @Column(name = "EDUQUALIFICATION", columnDefinition = "varchar(200)",nullable = true)
    //  private String eduQualification;
    @ManyToOne()
    @JoinColumn(name= "EDUQUALIFICATION_ID",nullable = true)
    private Eduqualification eduqualificationObj;

     @Column(name = "JOB", columnDefinition = "varchar(200)",nullable = true)
     private String job;

     @Column(name = "ANNUAL_INCOME", columnDefinition = "decimal(15,2) not null default 0.00")
     private Double annualIncome;

     @ManyToOne()
    @JoinColumn(name= "RELATION_ID",nullable = true)
    private Relation relationObj;

       
}
