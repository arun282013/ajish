package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.UserType;
import com.kswdc.loanmanagementsystem.api.value.UserTypeVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface UserTypeService {

    Integer createUserType(UserType userType);

    Integer updateUserType(UserType userType);

    UserType getUserType(Integer id);

    UserType getUserTypeByUserTypeName(String usertypeName);

    Integer deleteUserType(Integer id);

    List<UserTypeVO> getUserTypeList();
}
