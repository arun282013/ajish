package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.LoanType;
import com.kswdc.loanmanagementsystem.api.service.LoanTypeService;
import com.kswdc.loanmanagementsystem.api.value.LoanTypeVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class LoanTypeController {

	private final Logger log = LoggerFactory.getLogger(LoanTypeController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private LoanTypeService loanTypeService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param LoanType LoanType
	 * @return Map
	 */
	@RequestMapping(value = "/loanType", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createLoanType(@RequestBody LoanType LoanType) {
		log.info("In LoanTypeController::createLoanType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(LoanType)) {
//						LoanType.setActive(Boolean.TRUE);
						LoanType.setCreatedOn(DateFunctions.getZonedServerDate());
						// LoanType.setCreatedBy();
						LoanType.setIsDeleted(0);
						Integer LoanTypeId = loanTypeService.createLoanType(LoanType);
						if (!LoanTypeId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("LoanTypeId", LoanTypeId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanTypeController::createLoanType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param LoanType LoanType
	 * @return Map
	 */
	@RequestMapping(value = "/loanType", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateLoanType(@RequestBody LoanType loanType) {
		log.info("In LoanTypeController::updateLoanType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (loanType != null) { // && LoanType.getId() != null
				if (checkValid(loanType)) {
					LoanType chkLoanType = loanTypeService.getLoanType(loanType.getLoantypeId());
					if (chkLoanType!=null) {
//						if (chkLoanType.getActive()) {
//							LoanType.setActive(Boolean.TRUE);
							chkLoanType.setLoantypeCode(loanType.getLoantypeCode());
							chkLoanType.setLoantypeName(loanType.getLoantypeName());							
							chkLoanType.setIsActive(loanType.getIsActive());							
							Integer LoanTypeId = loanTypeService.updateLoanType(chkLoanType);
							if (!LoanTypeId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("LoanTypeId:", LoanTypeId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" LoanType Id is deactivated:"+LoanType.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanTypeController::updateLoanType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/loanType/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteLoanType(@PathVariable Integer id) {
		log.info("In LoanTypeController::deleteLoanType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				LoanType LoanType = loanTypeService.getLoanType(id);
				if (LoanType != null) {
//					if (!LoanType.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " LoanTypeId:" + id);
//					} else {
						Integer LoanTypeId = loanTypeService.deleteLoanType(id);
						if (!LoanTypeId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("LoanTypeId", LoanTypeId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanTypeController::deleteLoanType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/loanType/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneLoanType(@PathVariable Integer id) {
		log.info("In LoanTypeController::getOneLoanType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				LoanType LoanType = loanTypeService.getLoanType(id);
				if (LoanType != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("LoanType", LoanType);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanTypeController::getOneLoanType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- LoanType ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/loanType-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getLoanTypeList() {
		log.info("In LoanTypeController::getLoanTypeList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			LoanTypeListReturnVO LoanTypeListReturnVO = new LoanTypeListReturnVO(LoanTypeService.getLoanTypeList());
			List<LoanTypeVO> LoanTypeListReturnVO = loanTypeService.getLoanTypeList();
			if (LoanTypeListReturnVO != null && LoanTypeListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("loanTypes", LoanTypeListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanTypeController::getLoanTypeList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param LoanTypeId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer LoanTypeId) {
		return (loanTypeService.getLoanType(LoanTypeId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param LoanType
	 * @return Boolean
	 */
	private Boolean checkValid(LoanType LoanType) {
		Boolean isValid = true;
		invalidMsg = "";
		if (LoanType != null) {
//			if(LoanType.getId()==null || LoanType.getId()<=0) {
//				invalidMsg+="LoanTypeId is required and should be valid!";
//				isValid = false;
//			}
			if (LoanType.getLoantypeName() == null || LoanType.getLoantypeName().equalsIgnoreCase("")) {
				invalidMsg += "LoanType Name is required and should not be empty!";
				isValid = false;
			}
//			if (LoanType.getLoanTypeName() == null || LoanType.getLoanTypeName().equalsIgnoreCase("")) {
//				invalidMsg += "LoanType Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (LoanType.getQuotaInMB() == null || LoanType.getQuotaInMB().equals(0) || LoanType.getQuotaInMB()<0) {
//				invalidMsg += "LoanType Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanType.getChatHistoryDays() == null || LoanType.getChatHistoryDays().equals(0) || LoanType.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for LoanType is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanType.getCdaTimeoutTime() == null || LoanType.getCdaTimeoutTime().equals(0) || LoanType.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for LoanType!";
			isValid = false;
		}
		return isValid;
	}
	
}
