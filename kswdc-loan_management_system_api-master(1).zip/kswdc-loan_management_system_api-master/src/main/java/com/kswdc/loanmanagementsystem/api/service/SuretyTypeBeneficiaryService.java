package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.SuretyTypeBeneficiary;
import com.kswdc.loanmanagementsystem.api.value.SuretyTypeBeneficiaryVO;


@Component
public interface SuretyTypeBeneficiaryService {

    Integer createSuretyTypeBeneficiary(SuretyTypeBeneficiary suretyTypeBeneficiary);

    Integer updateSuretyTypeBeneficiary(SuretyTypeBeneficiary suretyTypeBeneficiary);

    SuretyTypeBeneficiary getSuretyTypeBeneficiary(Integer id);

    //LoanSuretyType geLoanSuretyTypeByLoanSuretyTypeName(String loanSuretyTypeName);

    Integer deleteSuretyTypeBeneficiary(Integer id);

    List<SuretyTypeBeneficiaryVO> getSuretyTypeBeneficiaryList();
}
