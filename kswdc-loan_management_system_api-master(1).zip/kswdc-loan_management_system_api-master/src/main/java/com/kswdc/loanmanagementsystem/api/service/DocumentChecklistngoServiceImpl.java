package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistNgo;
import com.kswdc.loanmanagementsystem.api.repository.DocumentChecklistngoRepository;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistNgoVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;


@Service
public class DocumentChecklistngoServiceImpl implements DocumentChecklistngoService {
	private final Logger log = LoggerFactory.getLogger(DocumentChecklistngoServiceImpl.class);
	
	@Autowired
	private DocumentChecklistngoRepository documentChecklistngoRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createDocumentChecklistngo(DocumentChecklistNgo DocumentChecklistngo) {
		try {
			DocumentChecklistNgo savedDocumentChecklistngo = documentChecklistngoRepository.save(DocumentChecklistngo);
			return savedDocumentChecklistngo.getDocumentchecklistngoId() != null ? savedDocumentChecklistngo.getDocumentchecklistngoId() : -1;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistServiceImpl::createDocumentChecklist======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateDocumentChecklistngo(DocumentChecklistNgo DocumentChecklistngo) {
		try {
			DocumentChecklistNgo updateDocumentChecklistngo = documentChecklistngoRepository.save(DocumentChecklistngo);
			return updateDocumentChecklistngo.getDocumentchecklistngoId() != null ? updateDocumentChecklistngo.getDocumentchecklistngoId() : -1;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistServiceImpl::updateDocumentChecklist======" + e.getMessage());
		}
		return null;
	}

	@Override
	public DocumentChecklistNgo getDocumentChecklistngo(Integer id) {
		try {
			DocumentChecklistNgo documentChecklistngo = documentChecklistngoRepository.getDocumentChecklistngoById(id);
			return documentChecklistngo;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistServiceImpl::getDocumentChecklist======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteDocumentChecklistngo(Integer id) {
		try {
			DocumentChecklistNgo DocumentChecklistngo = getDocumentChecklistngo(id);
//			LoanCategory.setActive(Boolean.FALSE);
			DocumentChecklistngo.setDeletedOn(DateFunctions.getZonedServerDate());
			DocumentChecklistngo.setIsDeleted(Constants.IS_DELETED);
			DocumentChecklistNgo updatedDocumentChecklistngo = documentChecklistngoRepository.save(DocumentChecklistngo);
			return updatedDocumentChecklistngo.getDocumentchecklistngoId() != null ? updatedDocumentChecklistngo.getDocumentchecklistngoId() : -1;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistServiceImpl::deleteDocumentChecklist======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<DocumentChecklistNgoVO> getDocumentChecklistListngo() {
		try {
			List<DocumentChecklistNgoVO> documentChecklistListngo = documentChecklistngoRepository.getDocumentChecklistListngo();
			return documentChecklistListngo;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistServiceImpl::getDocumentChecklistList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<DocumentChecklistNgoVO> getDocumentChecklistListngoByLoanType(Integer loantypeId) {
		try {
			List<DocumentChecklistNgoVO> documentchecklistListngo = documentChecklistngoRepository.getDocumentChecklistListngoByLoanType(loantypeId);
			return documentchecklistListngo;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistServiceImpl::getDocumentChecklistListByLoanType======" + e.getMessage());
		}
		return null;
	}


	@Override
	public DocumentChecklistNgo getDocumentChecklistngoByDocumentChecklistngoName(String documentchecklistngoName) {
		try {
			DocumentChecklistNgo documentChecklistngo = documentChecklistngoRepository.findByDocumentChecklistngoName(documentchecklistngoName);
			return documentChecklistngo;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistServiceImpl::getDocumentChecklistByDocumentChecklistName======" + e.getMessage());
		}
		return null;
	}
}