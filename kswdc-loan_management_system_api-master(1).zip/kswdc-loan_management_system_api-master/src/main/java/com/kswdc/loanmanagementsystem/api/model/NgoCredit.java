package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_ngocredit")
@EqualsAndHashCode()
public class NgoCredit{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CREDIT_ID")
    private Integer creditId;

    @Column(name = "YEAR", columnDefinition = "varchar(20) not null")
    private String year;
    
    @Column(name = "ACTIVITIES", columnDefinition = "varchar(200) not null")
    private String activities;
    
     @Column(name = "NO_SHGS", columnDefinition ="int not null")
     private Integer noofShgs;

     @Column(name = "NO_BORROWERS", columnDefinition ="int not null")
     private Integer noofBorrowers;

     @Column(name = "LOAN_AMOUNT", columnDefinition = "decimal(15,2) not null default 0.00")
     private Double loanAmount;

     @Column(name = "LOAN_AMOUNT_DUE", columnDefinition = "decimal(15,2) not null default 0.00")
     private Double loanamountDue;

     @Column(name = "LOAN_AMOUNT_RECOVERED", columnDefinition = "decimal(15,2) not null default 0.00")
     private Double loanamountRecovered;

     @Column(name = "PERCENTAGE_RECOVERY", columnDefinition = "decimal(15,2) not null default 0.00")
     private Double percentageofRecovery;

     @Column(name = "SOURCE_FUND", columnDefinition = "varchar(200) not null")
     private String sourceFund;


     
}
