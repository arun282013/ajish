package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_document_checklist_beneficiary")
@EqualsAndHashCode()
public class DocumentChecklistBeneficiary{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DOC_CHECKLIST_BENEFICIARY_ID")
    private Integer docChecklistBeneficiaryId;

    @ManyToOne()
    @JoinColumn(name= "DOCUMENT_CHECKLIST_ID")
    private DocumentChecklist documentChecklistObj;

    @ManyToOne()
    @JoinColumn(name= "TERM_LOAN_ID")
    private TermLoan termLoanObj;

    @ManyToOne()
    @JoinColumn(name= "LOANTYPE_ID")
    private LoanType loanTypeObj;

    @Column(name = "FILE_PATH", columnDefinition = "varchar(300) not null")
    private String filePath;
}
