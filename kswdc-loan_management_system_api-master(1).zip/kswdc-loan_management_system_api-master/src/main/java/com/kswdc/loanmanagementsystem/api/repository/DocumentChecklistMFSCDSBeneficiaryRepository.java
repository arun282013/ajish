package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistMFSCDSBeneficiary;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistMFSCDSBeneficiaryVO;

@Repository
public interface DocumentChecklistMFSCDSBeneficiaryRepository extends JpaRepository<DocumentChecklistMFSCDSBeneficiary, Integer> {
        @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.DocumentChecklistMFSCDSBeneficiaryVO(cb.docChecklistMFSCDSBeneficiaryId,dc.documentchecklistmfscdsName,"
                        +
                        "tl.cdsName,l.loantypeId,l.loantypeName,cb.filePath) " +
                        "FROM DocumentChecklistMFSCDSBeneficiary cb LEFT JOIN DocumentChecklistMFSCDS dc on cb.documentchecklistmfscdsObj=dc.documentchecklistmfscdsId "
                        +
                        "LEFT JOIN MFSCDSLoan tl ON cb.mfscdsLoanObj=tl.mfscdsLoanId LEFT JOIN LoanType l ON cb.loanTypeObj=l.loantypeId "
                        +
                        "ORDER BY cb.docChecklistMFSCDSBeneficiaryId ASC")
        List<DocumentChecklistMFSCDSBeneficiaryVO> getDocumentChecklistMFSCDSBeneficiaryList();// Filter only active data

        @Query("SELECT a from DocumentChecklistMFSCDSBeneficiary a WHERE a.id=:docChecklistMFSCDSBeneficiaryId")
        DocumentChecklistMFSCDSBeneficiary getDocumentChecklistMFSCDSBeneficiaryById(
                        @Param("docChecklistMFSCDSBeneficiaryId") Integer docChecklistMFSCDSBeneficiaryId);

        @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.DocumentChecklistMFSCDSBeneficiaryVO(cb.docChecklistMFSCDSBeneficiaryId,dc.documentchecklistmfscdsName,"
                        +
                        "tl.cdsName,l.loantypeId, l.loantypeName,cb.filePath) " +
                        "FROM DocumentChecklistMFSCDSBeneficiary cb LEFT JOIN DocumentChecklistMFSCDS dc on cb.documentchecklistmfscdsObj=dc.documentchecklistmfscdsId "
                        +
                        "LEFT JOIN MFSCDSLoan tl ON cb.mfscdsLoanObj=tl.mfscdsLoanId LEFT JOIN LoanType l ON cb.loanTypeObj=l.loantypeId "
                        +
                        " WHERE cb.id=:docChecklistMFSCDSBeneficiaryId")
        DocumentChecklistMFSCDSBeneficiaryVO getDocumentChecklistMFSCDSBeneficiaryVOById(
                        @Param("docChecklistMFSCDSBeneficiaryId") Integer docChecklistMFSCDSBeneficiaryId);

        // @Query("SELECT a from DocumentChecklistBeneficiary a LEFT JOIN TermLoan t ON
        // a.termLoanObj=t.termLoanId WHERE t.termLoanId=:termLoanId")
        // List<DocumentChecklistBeneficiary>
        // getDocumentChecklistBeneficiaryByTermLoanId(
        // @Param("termLoanId") Integer termLoanId);

        @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.DocumentChecklistMFSCDSBeneficiaryVO(cb.docChecklistMFSCDSBeneficiaryId,dc.documentchecklistmfscdsName,"
                        +
                        "tl.cdsName,l.loantypeId,l.loantypeName,cb.filePath) " +
                        "FROM DocumentChecklistMFSCDSBeneficiary cb LEFT JOIN DocumentChecklistMFSCDS dc on cb.documentchecklistmfscdsObj=dc.documentchecklistmfscdsId "
                        +
                        "LEFT JOIN MFSCDSLoan tl ON cb.mfscdsLoanObj=tl.mfscdsLoanId LEFT JOIN LoanType l ON cb.loanTypeObj=l.loantypeId "
                        +
                        "WHERE tl.mfscdsLoanId=:mfscdsLoanId ORDER BY cb.docChecklistMFSCDSBeneficiaryId ASC")
        List<DocumentChecklistMFSCDSBeneficiaryVO> getDocumentChecklistMFSCDSBeneficiaryByMFSCDSLoanId(
                        @Param("mfscdsLoanId") Integer mfscdsLoanId);

        // @Query("SELECT cl FROM LoanDocumentChecklist cl WHERE cl.userName=:userName")
        // LoanDocumentChecklist findByLoanDocumentChecklistName(@Param("userName")
        // String userName);
}
