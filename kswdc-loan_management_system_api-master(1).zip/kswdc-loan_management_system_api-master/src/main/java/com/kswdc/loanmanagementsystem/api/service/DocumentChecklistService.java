package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklist;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistVO;


@Component
public interface DocumentChecklistService {

    Integer createDocumentChecklist(DocumentChecklist documentChecklist);

    Integer updateDocumentChecklist(DocumentChecklist documentChecklist);

    DocumentChecklist getDocumentChecklist(Integer id);

    DocumentChecklist getDocumentChecklistByDocumentChecklistName(String documentchecklistName);

    Integer deleteDocumentChecklist(Integer id);

    List<DocumentChecklistVO> getDocumentChecklistList();

    List<DocumentChecklistVO> getDocumentChecklistListByLoanType(Integer loantypeId);
}
