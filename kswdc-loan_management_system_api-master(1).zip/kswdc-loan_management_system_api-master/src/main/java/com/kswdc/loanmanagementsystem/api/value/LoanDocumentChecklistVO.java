package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class LoanDocumentChecklistVO implements Serializable {

    private Integer loanDocChecklistId;
    private String loanTypeName;
    private String documentChecklistName;

    public LoanDocumentChecklistVO(Integer loanDocChecklistId,  String loanTypeName, 
    String documentChecklistName) {
        this.loanDocChecklistId = loanDocChecklistId;
        this.loanTypeName = loanTypeName;
        this.documentChecklistName = documentChecklistName;
    }
    
}
