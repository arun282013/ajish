package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.MFSCDSBalancesheet;
import com.kswdc.loanmanagementsystem.api.repository.MFSCDSBalancesheetRepository;
import com.kswdc.loanmanagementsystem.api.value.MFSCDSBalancesheetVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 */

@Service
public class MFSCDSBalancesheetServiceImpl implements MFSCDSBalancesheetService {
	private final Logger log = LoggerFactory.getLogger(MFSCDSBalancesheetServiceImpl.class);
	
	@Autowired
	private MFSCDSBalancesheetRepository mfscdsbalancesheetRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createMFSCDSBalancesheet(MFSCDSBalancesheet MFSCDSBalancesheet) {
		try {
			MFSCDSBalancesheet savedMFSCDSBalancesheet = mfscdsbalancesheetRepository.save(MFSCDSBalancesheet);
			return savedMFSCDSBalancesheet.getBalancesheetId() != null ? savedMFSCDSBalancesheet.getBalancesheetId() : -1;
		} catch (Exception e) {
			log.error("Exception in MFSCDSBalancesheetServiceImpl::createMFSCDSBalancesheet======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateMFSCDSBalancesheet(MFSCDSBalancesheet MFSCDSBalancesheet) {
		try {
			MFSCDSBalancesheet updateMFSCDSBalancesheet = mfscdsbalancesheetRepository.save(MFSCDSBalancesheet);
			return updateMFSCDSBalancesheet.getBalancesheetId() != null ? updateMFSCDSBalancesheet.getBalancesheetId() : -1;
		} catch (Exception e) {
			log.error("Exception in MFSCDSBalancesheetServiceImpl::updateMFSCDSBalancesheet======" + e.getMessage());
		}
		return null;
	}

	@Override
	public MFSCDSBalancesheet getMFSCDSBalancesheet(Integer id) {
		try {
			MFSCDSBalancesheet mfscdsexperience = mfscdsbalancesheetRepository.getMFSCDSBalancesheetById(id);
			return mfscdsexperience;
		} catch (Exception e) {
			log.error("Exception in MFSCDSBalancesheetServiceImpl::getMFSCDSBalancesheet======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteMFSCDSBalancesheet(Integer id) {
		try {
			MFSCDSBalancesheet MFSCDSBalancesheet = getMFSCDSBalancesheet(id);
			MFSCDSBalancesheet updatedMFSCDSBalancesheet = mfscdsbalancesheetRepository.save(MFSCDSBalancesheet);
			return updatedMFSCDSBalancesheet.getBalancesheetId() != null ? updatedMFSCDSBalancesheet.getBalancesheetId() : -1;
		} catch (Exception e) {
			log.error("Exception in MFSCDSExperienceServiceImpl::deleteMFSCDSExperience======" + e.getMessage());
		}
		return null;
	}

	
}