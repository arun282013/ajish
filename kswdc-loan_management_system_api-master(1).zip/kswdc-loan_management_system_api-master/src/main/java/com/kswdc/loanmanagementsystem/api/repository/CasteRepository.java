package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Caste;
import com.kswdc.loanmanagementsystem.api.value.CasteVO;

@Repository
public interface CasteRepository extends JpaRepository<Caste, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.CasteVO(o.casteId,"+
      " o.casteName, r.religionName, o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM Caste o LEFT JOIN Religion r ON o.religionObj= r.religionId LEFT JOIN User u ON o.createdBy=u.userId"+
           " LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 ORDER BY o.casteName ASC")
   List<CasteVO> getCasteList();//Filter only active castes

   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.CasteVO(o.casteId,"+
      " o.casteName, r.religionName, o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM Caste o LEFT JOIN Religion r ON o.religionObj= r.religionId LEFT JOIN User u ON o.createdBy=u.userId"+
           " LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 and r.religionId=:religionId ORDER BY o.casteName ASC")
   List<CasteVO> getCasteListByReligion(@Param("religionId") Integer religionId);
    
    @Query("SELECT a from Caste a WHERE a.id=:casteId")
    Caste getCasteById(@Param("casteId") Integer casteId);

    @Query("SELECT cl FROM Caste cl WHERE cl.casteName=:casteName")
    Caste findByCasteName(@Param("casteName") String casteName);
}
