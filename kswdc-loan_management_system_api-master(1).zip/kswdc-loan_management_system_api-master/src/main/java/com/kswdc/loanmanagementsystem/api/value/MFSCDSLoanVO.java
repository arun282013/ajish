package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MFSCDSLoanVO implements Serializable {

    private Integer mfscdsLoanId;
    private String userName;
    private String loanCategoryName;
    private Integer loancategoryId;
    private String loantypeName;
    private Integer loanTypeId;
    private String cdsName;
    private String cdshouseName;
    private String cdshouseNo;
    private Integer cdsdistrictId;
    private String cdsdistrictName;
    private Integer cdstalukId;
    private String cdstalukName;
    private Integer cdslocationtypeId;
    private Integer cdslocalbodytypeId;
    private String cdslocalbodytypeName;
    private Integer cdslocalbodyId;
    private String cdslocalbodyName;
    private String cdsLocation;
    private Integer cdspostofficeId;
    private String cdspostofficeName;
    private Integer cdsPincode;
    private String cdsemailId;
    private String cdspanNo;
    private String cdsregNo;
    private Integer cdsregYear;
    private String cdscpName;
    private String cdscpPhoneNo;
    private String cdssecName;
    private String cdssecPhoneNo;
    private String cdscpAadharNo;
    private String cdssecAadharNo;
    private String cdscphouseName;
    private String cdscphouseNo;
    private Integer cdscpdistrictId;
    private String cdscpdistrictName;
    private Integer cdscptalukId;
    private String cdscptalukName;
    private Integer cdscplocationtypeId;
    private Integer cdscplocalbodytypeId;
    private String cdscplocalbodytypeName;
    private Integer cdscplocalbodyId;
    private String cdscplocalbodyName;
    private String cdscpLocation;
    private Integer cdscppostofficeId;
    private String cdscppostofficeName;
    private Integer cdscpPincode;
    private String cdssechouseName;
    private String cdssechouseNo;
    private Integer cdssecdistrictId;
    private String cdssecdistrictName;
    private Integer cdssectalukId;
    private String cdssectalukName;
    private Integer cdsseclocationtypeId;
    private Integer cdsseclocalbodytypeId;
    private String cdsseclocalbodytypeName;
    private Integer cdsseclocalbodyId;
    private String cdsseclocalbodyName;
    private String cdssecLocation;
    private Integer cdssecpostofficeId;
    private String cdssecpostofficeName;
    private Integer cdssecPincode;
    private Integer meunitsoneyearCount;
    private Integer meunitsoneyearaboveCount;
    private Integer meunitstotalCount;
    private String cdsprojectName;
    private Double cdsloanAmount;

    private Integer cdsapplicationStatus;
    private ZonedDateTime enteredOn;
    private ZonedDateTime createdOn;
    private String createdBy;
    private Integer createdById;
    private ZonedDateTime modifiedOn;
    private String modifiedBy;
    private Integer modifiedById;
    private Integer isDeleted;
    private ZonedDateTime deletedOn;
    private String deletedStr;
    private Integer isActive;
    private String activeStr;
    private Integer userStatus;
    //-for program popup
    private String programs;
    //-for program popup

    //-for experience popup
    private String experiences;
    //-for experience popup

    //-for balancesheet popup
    private String balancesheets;
    //-for balancesheet popup

    private Set programLst;
    // --
    private Set experienceLst;

    private Set balancesheetLst;

    
    public MFSCDSLoanVO() {
    }

    public MFSCDSLoanVO(Integer mfscdsLoanId, String userName, String loanCategoryName, String loantypeName,
            String cdsName, String cdshouseName, String cdshouseNo,  String cdsdistrictName, String cdstalukName, 
            Integer cdslocationtypeId, String cdslocalbodytypeName, String cdslocalbodyName, String cdsLocation, String cdspostofficeName, 
            Integer cdsPincode, String cdsemailId, String cdspanNo, String cdsregNo, 
            Integer cdsregYear, String cdscpName, String cdscpPhoneNo, String cdssecName, String cdssecPhoneNo,
            String cdscpAadharNo, String cdssecAadharNo, String cdscphouseName, String cdscphouseNo, String cdscpdistrictName, 
            String cdscptalukName, Integer cdscplocationtypeId, String cdscplocalbodytypeName, String cdscplocalbodyName, 
            String cdscpLocation, String cdscppostofficeName, Integer cdscpPincode, String cdssechouseName, 
            String cdssechouseNo, String cdssecdistrictName, String cdssectalukName, Integer cdsseclocationtypeId, 
            String cdsseclocalbodytypeName, String cdsseclocalbodyName, String cdssecLocation, 
            String cdssecpostofficeName, Integer cdssecPincode, Integer meunitsoneyearCount, Integer meunitsoneyearaboveCount, 
            Integer meunitstotalCount, String cdsprojectName, Double cdsloanAmount,  
            Integer cdsapplicationStatus,
            ZonedDateTime enteredOn, ZonedDateTime createdOn, String createdBy, ZonedDateTime modifiedOn,
            String modifiedBy,
            Integer isDeleted, ZonedDateTime deletedOn, Integer isActive) {
        this.mfscdsLoanId = mfscdsLoanId;
        this.userName = userName;
        this.loanCategoryName = loanCategoryName;
        this.loantypeName = loantypeName;
        this.cdsName = cdsName;
        this.cdshouseName = cdshouseName;
        this.cdshouseNo = cdshouseNo;
        this.cdsdistrictName = cdsdistrictName;
        this.cdstalukName = cdstalukName;
        this.cdslocationtypeId = cdslocationtypeId;
        this.cdslocalbodytypeName = cdslocalbodytypeName;
        this.cdslocalbodyName = cdslocalbodyName;
        this.cdsLocation = cdsLocation;
        this.cdspostofficeName = cdspostofficeName;
        this.cdsPincode = cdsPincode;
        this.cdsemailId = cdsemailId;
        this.cdspanNo = cdspanNo;
        this.cdsregNo = cdsregNo;
        this.cdsregYear = cdsregYear;
        this.cdscpName = cdscpName;
        this.cdscpPhoneNo = cdscpPhoneNo;
        this.cdssecName = cdssecName;
        this.cdssecPhoneNo = cdssecPhoneNo;
        this.cdscpAadharNo = cdscpAadharNo;
        this.cdssecAadharNo = cdssecAadharNo;
        this.cdscphouseName = cdscphouseName;
        this.cdscphouseNo = cdscphouseNo;
        this.cdscpdistrictName = cdscpdistrictName;
        this.cdscptalukName = cdscptalukName;
        this.cdscplocationtypeId = cdscplocationtypeId;
        this.cdscplocalbodytypeName = cdscplocalbodytypeName;
        this.cdscplocalbodyName = cdscplocalbodyName;
        this.cdscpLocation = cdscpLocation;
        this.cdscppostofficeName = cdscppostofficeName;
        this.cdscpPincode = cdscpPincode;
        this.cdssechouseName = cdssechouseName;
        this.cdssechouseNo = cdssechouseNo;
        this.cdssecdistrictName = cdssecdistrictName;
        this.cdssectalukName = cdssectalukName;
        this.cdsseclocationtypeId = cdsseclocationtypeId;
        this.cdsseclocalbodytypeName = cdsseclocalbodytypeName;
        this.cdsseclocalbodyName = cdsseclocalbodyName;
        this.cdssecLocation = cdssecLocation;
        this.cdssecpostofficeName = cdssecpostofficeName;
        this.cdssecPincode = cdssecPincode;
        this.meunitsoneyearCount = meunitsoneyearCount;
        this.meunitsoneyearaboveCount = meunitsoneyearaboveCount;
        this.meunitstotalCount = meunitstotalCount;
        this.cdsprojectName = cdsprojectName;
        this.cdsloanAmount = cdsloanAmount;
        
        this.cdsapplicationStatus = cdsapplicationStatus;
        this.enteredOn = enteredOn;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.modifiedOn = modifiedOn;
        this.modifiedBy = modifiedBy;
        this.isDeleted = isDeleted;
        this.deletedOn = deletedOn;
        this.deletedStr = isDeleted != null && isDeleted.equals(1) ? Constants.IS_DELETED_STR
                : Constants.IS_NOT_DELETED_STR;
        this.isActive = isActive;
        this.activeStr = isActive != null && isActive.equals(1) ? Constants.IS_ACTIVE_STR : Constants.IS_NOT_ACTIVE_STR;
        
            }

    public MFSCDSLoanVO(Integer mfscdsLoanId, String userName, Integer loancategoryId, String loanCategoryName, String loantypeName,
            String cdsName, String cdshouseName, String cdshouseNo,  Integer cdsdistrictId, String cdsdistrictName, Integer cdstalukId, String cdstalukName, 
            Integer cdslocationtypeId, Integer cdslocalbodytypeId, String cdslocalbodytypeName, Integer cdslocalbodyId, String cdslocalbodyName, String cdsLocation, Integer cdspostofficeId, String cdspostofficeName, 
            Integer cdsPincode, String cdsemailId, String cdspanNo, String cdsregNo, 
            Integer cdsregYear, String cdscpName, String cdscpPhoneNo, String cdssecName, String cdssecPhoneNo,
            String cdscpAadharNo, String cdssecAadharNo, String cdscphouseName, String cdscphouseNo, Integer cdscpdistrictId, String cdscpdistrictName, 
            Integer cdscptalukId, String cdscptalukName, Integer cdscplocationtypeId, Integer cdscplocalbodytypeId, String cdscplocalbodytypeName, Integer cdscplocalbodyId, String cdscplocalbodyName, 
            String cdscpLocation, Integer cdscppostofficeId, String cdscppostofficeName, Integer cdscpPincode, String cdssechouseName, 
            String cdssechouseNo, Integer cdssecdistrictId, String cdssecdistrictName, Integer cdssectalukId, String cdssectalukName, Integer cdsseclocationtypeId, 
            Integer cdsseclocalbodytypeId, String cdsseclocalbodytypeName, Integer cdsseclocalbodyId, String cdsseclocalbodyName, String cdssecLocation, 
            Integer cdssecpostofficeId, String cdssecpostofficeName, Integer cdssecPincode, Integer meunitsoneyearCount, Integer meunitsoneyearaboveCount, 
            Integer meunitstotalCount, String cdsprojectName, Double cdsloanAmount,  
            Integer cdsapplicationStatus,
            ZonedDateTime enteredOn, ZonedDateTime createdOn, String createdBy, ZonedDateTime modifiedOn,
            String modifiedBy,
            Integer isDeleted, ZonedDateTime deletedOn, Integer isActive) {
        this.mfscdsLoanId = mfscdsLoanId;
        this.userName = userName;
        this.loancategoryId = loancategoryId;
        this.loanCategoryName = loanCategoryName;
        this.loantypeName = loantypeName;
        this.cdsName = cdsName;
        this.cdshouseName = cdshouseName;
        this.cdshouseNo = cdshouseNo;
        this.cdsdistrictId = cdsdistrictId;
        this.cdsdistrictName = cdsdistrictName;
        this.cdstalukId = cdstalukId;
        this.cdstalukName = cdstalukName;
        this.cdslocationtypeId = cdslocationtypeId;
        this.cdslocalbodytypeId = cdslocalbodytypeId;
        this.cdslocalbodytypeName = cdslocalbodytypeName;
        this.cdslocalbodyId = cdslocalbodyId;
        this.cdslocalbodyName = cdslocalbodyName;
        this.cdsLocation = cdsLocation;
        this.cdspostofficeId = cdspostofficeId;
        this.cdspostofficeName = cdspostofficeName;
        this.cdsPincode = cdsPincode;
        this.cdsemailId = cdsemailId;
        this.cdspanNo = cdspanNo;
        this.cdsregNo = cdsregNo;
        this.cdsregYear = cdsregYear;
        this.cdscpName = cdscpName;
        this.cdscpPhoneNo = cdscpPhoneNo;
        this.cdssecName = cdssecName;
        this.cdssecPhoneNo = cdssecPhoneNo;
        this.cdscpAadharNo = cdscpAadharNo;
        this.cdssecAadharNo = cdssecAadharNo;
        this.cdscphouseName = cdscphouseName;
        this.cdscphouseNo = cdscphouseNo;
        this.cdscpdistrictId = cdscpdistrictId;
        this.cdscpdistrictName = cdscpdistrictName;
        this.cdscptalukId = cdscptalukId;
        this.cdscptalukName = cdscptalukName;
        this.cdscplocationtypeId = cdscplocationtypeId;
        this.cdscplocalbodytypeId = cdscplocalbodytypeId;
        this.cdscplocalbodytypeName = cdscplocalbodytypeName;
        this.cdscplocalbodyId = cdscplocalbodyId;
        this.cdscplocalbodyName = cdscplocalbodyName;
        this.cdscpLocation = cdscpLocation;
        this.cdscppostofficeId = cdscppostofficeId;
        this.cdscppostofficeName = cdscppostofficeName;
        this.cdscpPincode = cdscpPincode;
        this.cdssechouseName = cdssechouseName;
        this.cdssechouseNo = cdssechouseNo;
        this.cdssecdistrictId = cdssecdistrictId;
        this.cdssecdistrictName = cdssecdistrictName;
        this.cdssectalukId = cdssectalukId;
        this.cdssectalukName = cdssectalukName;
        this.cdsseclocationtypeId = cdsseclocationtypeId;
        this.cdsseclocalbodytypeId = cdsseclocalbodytypeId;
        this.cdsseclocalbodytypeName = cdsseclocalbodytypeName;
        this.cdsseclocalbodyId = cdsseclocalbodyId;
        this.cdsseclocalbodyName = cdsseclocalbodyName;
        this.cdssecLocation = cdssecLocation;
        this.cdssecpostofficeId = cdssecpostofficeId;
        this.cdssecpostofficeName = cdssecpostofficeName;
        this.cdssecPincode = cdssecPincode;
        this.meunitsoneyearCount = meunitsoneyearCount;
        this.meunitsoneyearaboveCount = meunitsoneyearaboveCount;
        this.meunitstotalCount = meunitstotalCount;
        this.cdsprojectName = cdsprojectName;
        this.cdsloanAmount = cdsloanAmount;
        
        this.cdsapplicationStatus = cdsapplicationStatus;
        this.enteredOn = enteredOn;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.modifiedOn = modifiedOn;
        this.modifiedBy = modifiedBy;
        this.isDeleted = isDeleted;
        this.deletedOn = deletedOn;
        this.deletedStr = isDeleted != null && isDeleted.equals(1) ? Constants.IS_DELETED_STR
                : Constants.IS_NOT_DELETED_STR;
        this.isActive = isActive;
        this.activeStr = isActive != null && isActive.equals(1) ? Constants.IS_ACTIVE_STR : Constants.IS_NOT_ACTIVE_STR;
        
            }

}
