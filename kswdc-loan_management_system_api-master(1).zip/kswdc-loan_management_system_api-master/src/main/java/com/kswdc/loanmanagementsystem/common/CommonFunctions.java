package com.kswdc.loanmanagementsystem.common;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Random;
import java.util.UUID;

public class CommonFunctions {

	public static String basicEncoder(final String input) {
	    String simpleBase64 = Base64.getEncoder().encodeToString(input.getBytes(StandardCharsets.UTF_8));
	    return simpleBase64;
	}
	
	public static String basicDecoder(final String encodedData) {
	    byte[] decodeData = Base64.getDecoder().decode(encodedData);
	    return new String(decodeData, StandardCharsets.UTF_8);
	}
	
	//String input= "search?_base64";
	public static String urlEncoding(final String input) {
	    return Base64.getUrlEncoder().encodeToString(input.getBytes(StandardCharsets.UTF_8));
	}
	
	public static String urlDecoding(final String encodedData) {
	    byte[] decodeData = Base64.getUrlDecoder().decode(encodedData);
	    return new String(decodeData, StandardCharsets.UTF_8);
	}
	
	public static String mimeEncoder(){
	    StringBuilder stringBuffer = new StringBuilder();
	    for (int t = 0; t < 10; ++t) {
	        stringBuffer.append(UUID.randomUUID().toString());
	    }

	    String mimeEncoding = Base64.getMimeEncoder().
	                          encodeToString(stringBuffer.toString().getBytes(StandardCharsets.UTF_8));

	    System.out.println("MIME Encoding is " +mimeEncoding);
	    return mimeEncoding;
	}
	
	public static String mimeDecoder(String encodedData) {
		byte[] decodeData = Base64.getMimeDecoder().decode(encodedData);
		System.out.println(new String(decodeData, StandardCharsets.UTF_8));
		return decodeData.toString();
	}
	
	public static String generateColour() {    	
    	// create object of Random class
    	Random obj = new Random();
    	int rand_num = obj.nextInt(0xffffff + 1);
    	// format it as hexadecimal string and print
    	return String.format("#%06x", rand_num);
    }
}
