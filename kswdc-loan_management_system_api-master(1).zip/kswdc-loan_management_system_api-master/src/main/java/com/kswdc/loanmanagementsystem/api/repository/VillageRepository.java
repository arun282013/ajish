package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Village;
import com.kswdc.loanmanagementsystem.api.value.VillageVO;

@Repository
public interface VillageRepository extends JpaRepository<Village, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.VillageVO(o.villageId,"+
      " o.villageName, t.talukName, o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM Village o LEFT JOIN Taluk t ON o.talukObj = t.talukId " +
           " LEFT JOIN User u ON o.createdBy=u.userId LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 ORDER BY o.villageName ASC")
   List<VillageVO> getVillageList();//Filter only active villages

   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.VillageVO(o.villageId,"+
      " o.villageName, t.talukName, o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM Village o LEFT JOIN Taluk t ON o.talukObj= t.talukId LEFT JOIN User u ON o.createdBy=u.userId"+
           " LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 and t.talukId=:talukId ORDER BY o.villageName ASC")
   List<VillageVO> getVillageListByTaluk(@Param("talukId") Integer talukId);
    
    @Query("SELECT a from Village a WHERE a.id=:villageId")
    Village getVillageById(@Param("villageId") Integer villageId);

    @Query("SELECT cl FROM Village cl WHERE cl.villageName=:villageName")
    Village findByVillageName(@Param("villageName") String villageName);
}
