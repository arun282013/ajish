package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.NgoStaff;
import com.kswdc.loanmanagementsystem.api.value.NgoStaffVO;

@Repository
public interface NgoStaffRepository extends JpaRepository<NgoStaff, Integer> {
   // @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TLFamilyMemberVO(f.tlfamilyMemberId,"+
   //    " f.tlfamilyMemberName,f.tlfamilyMemberAge,f.tlfamilyMemberEduqualification,f.tlfamilyMemberJob,"+
   //       "f.tlfamilyMemberAnnualIncome,t.fullName,r.relationName)"+ 
   //       "FROM TLFamilyMember f LEFT JOIN TermLoan t ON f.termLoanObj= t.termLoanId "+
   //       " LEFT JOIN Relation r ON f.relationObj = r.relationId "+
   //         " ORDER BY f.tlfamilyMemberName ASC")
   // @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TLFamilyMemberVO(f.tlfamilyMemberId,"+
   //    " f.tlfamilyMemberName,f.tlfamilyMemberAge,f.tlfamilyMemberEduqualification,f.tlfamilyMemberJob,"+
   //       "f.tlfamilyMemberAnnualIncome,t.fullName,r.relationName)"+ 
   //       "FROM TLFamilyMember f "+
   //       " LEFT JOIN Relation r ON f.relationObj = r.relationId "+
   //         " ORDER BY f.tlfamilyMemberName ASC")
//    List<TLFamilyMemberVO> getTLFamilyMemberList();//Filter only active familymember
    
    @Query("SELECT a FROM NgoStaff a   WHERE a.id=:staffId")
    NgoStaff getNgoStaffById(@Param("staffId") Integer staffId);
 
    @Query("SELECT cl FROM NgoStaff cl WHERE cl.officetrained=officetrained")
    NgoStaff getNgoStafftByNgoStaffOffice(@Param("officetrained") Integer officetrained);

}
