package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.LocalBody;
import com.kswdc.loanmanagementsystem.api.model.LocalbodyType;
import com.kswdc.loanmanagementsystem.api.model.Ward;
import com.kswdc.loanmanagementsystem.api.value.WardVO;

@Repository
public interface WardRepository extends JpaRepository<Ward, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.WardVO(w.wardId,"+
      " w.wardName,w.wardNumber,l.localbodyId,l.localbodyName,w.createdOn,u.fullName,w.modifiedOn,mu.fullName,w.isDeleted,w.deletedOn, w.isActive) " +
       " FROM Ward w LEFT JOIN LocalBody l ON w.localbodyObj=l.localbodyId "+
           " LEFT JOIN User u ON w.createdBy=u.userId LEFT JOIN User mu ON w.modifiedBy=mu.userId "+
            " WHERE w.isDeleted=0 ORDER BY w.wardName ASC")
   List<WardVO> getWardList();//Filter only active wards
   
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.WardVO(w.wardId,"+
      " w.wardName,w.wardNumber,l.localbodyId,l.localbodyName,w.createdOn,u.fullName,w.modifiedOn,mu.fullName,w.isDeleted,w.deletedOn, w.isActive) " +
       " FROM Ward w LEFT JOIN LocalBody l ON w.localbodyObj=l.localbodyId "+
           " LEFT JOIN User u ON w.createdBy=u.userId LEFT JOIN User mu ON w.modifiedBy=mu.userId "+
            " WHERE w.isDeleted=0 and w.isActive=1 ORDER BY w.wardName ASC")
   List<WardVO> getActiveWardList();//Filter only active wards
    
    @Query("SELECT w from Ward w WHERE w.wardId=:wardId")
    Ward getWardById(@Param("wardId") Integer wardId);

    @Query("SELECT w FROM Ward w WHERE w.wardName=:wardName")
    Ward findByWardName(@Param("wardName") String wardName);

    @Query("SELECT w FROM Ward w WHERE w.wardNumber=:wardNumber")
    Ward findByWardNumber(@Param("wardNumber") Integer wardNumber);



}
