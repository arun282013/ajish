package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class NgoSourcesVO implements Serializable {
    private Integer sourcesId;
    private String sourcesname;
    private Double balance;
    private Double amtexpected;
    private Double totalamt;
   
    public NgoSourcesVO(Integer sourcesId, 
    String sourcesname,Double balance,
    Double amtexpected,Double totalamt 
    ) {
        this.sourcesId = sourcesId;
        this.sourcesname = sourcesname;
        this.balance = balance;
        this.amtexpected = amtexpected;
        this.totalamt = totalamt;
        
    }
    
}
