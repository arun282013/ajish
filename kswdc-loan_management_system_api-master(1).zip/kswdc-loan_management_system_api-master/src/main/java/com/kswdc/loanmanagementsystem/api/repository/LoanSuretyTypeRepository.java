package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.LoanSuretyType;
import com.kswdc.loanmanagementsystem.api.value.LoanSuretyTypeVO;

@Repository
public interface LoanSuretyTypeRepository extends JpaRepository<LoanSuretyType, Integer> {
    @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.LoanSuretyTypeVO(ls.loan_suretytypeId,"+
    " l.loantypeName,s.suretytypeName) " +
         " FROM LoanSuretyType ls LEFT JOIN LoanType l ON ls.loanTypeObj=l.loantypeId LEFT JOIN SuretyType s ON ls.suretytypeObj=s.suretytypeId "+
          " ORDER BY ls.loan_suretytypeId ASC") 
 List<LoanSuretyTypeVO> getLoanSuretyTypeList();//Filter only active data
  
  @Query("SELECT a from LoanSuretyType a WHERE a.id=:loan_suretytypeId")
  LoanSuretyType getLoanSuretyTypeById(@Param("loan_suretytypeId") Integer loan_suretytypeId);

  // @Query("SELECT cl FROM LoanSuretyType cl WHERE cl.userName=:userName")
  // LoanSuretyType findByLoanSuretyTypeName(@Param("userName") String userName);
}
