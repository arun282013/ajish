package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistNgoBeneficiary;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistNgoBeneficiaryVO;

@Component
public interface DocumentChecklistNgoBeneficiaryService {

    Integer createDocumentChecklistngoBeneficiary(DocumentChecklistNgoBeneficiary documentChecklistngoBeneficiary);

    Integer updateDocumentChecklistngoBeneficiary(DocumentChecklistNgoBeneficiary documentChecklistngoBeneficiary);

    DocumentChecklistNgoBeneficiary getDocumentChecklistngoBeneficiary(Integer id);

    DocumentChecklistNgoBeneficiaryVO getDocumentChecklistngoBeneficiaryVO(Integer id);

    List<DocumentChecklistNgoBeneficiaryVO> getDocumentChecklistngoBeneficiaryByMFSNGOLoanId(Integer mfsngoLoanId);

    // LoanDocumentChecklist
    // geLoanDocumentChecklistByLoanDocumentChecklistName(String
    // loanDocumentChecklistName);

    Integer deleteDocumentChecklistngoBeneficiary(Integer id);

    List<DocumentChecklistNgoBeneficiaryVO> getDocumentChecklistngoBeneficiaryList();

}
