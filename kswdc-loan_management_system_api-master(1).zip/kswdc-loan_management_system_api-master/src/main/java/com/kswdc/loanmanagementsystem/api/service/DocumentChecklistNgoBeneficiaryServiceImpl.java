package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistNgoBeneficiary;
import com.kswdc.loanmanagementsystem.api.repository.DocumentChecklistNgoBeneficiaryRepository;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistNgoBeneficiaryVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

@Service
public class DocumentChecklistNgoBeneficiaryServiceImpl implements DocumentChecklistNgoBeneficiaryService {
	private final Logger log = LoggerFactory.getLogger(DocumentChecklistNgoBeneficiaryServiceImpl.class);

	@Autowired
	private DocumentChecklistNgoBeneficiaryRepository documentChecklistngoBeneficiaryRepository;

	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createDocumentChecklistngoBeneficiary(DocumentChecklistNgoBeneficiary DocumentChecklistngoBeneficiary) {
		try {
			DocumentChecklistNgoBeneficiary savedDocumentChecklistngoBeneficiary = documentChecklistngoBeneficiaryRepository
					.save(DocumentChecklistngoBeneficiary);
			return savedDocumentChecklistngoBeneficiary.getDocChecklistngoBeneficiaryId() != null
					? savedDocumentChecklistngoBeneficiary.getDocChecklistngoBeneficiaryId()
					: -1;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistBeneficiaryServiceImpl::createDocumentChecklistBeneficiary======"
					+ e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateDocumentChecklistngoBeneficiary(DocumentChecklistNgoBeneficiary DocumentChecklistngoBeneficiary) {
		try {
			DocumentChecklistNgoBeneficiary updateDocumentChecklistngoBeneficiary = documentChecklistngoBeneficiaryRepository
					.save(DocumentChecklistngoBeneficiary);
			return updateDocumentChecklistngoBeneficiary.getDocChecklistngoBeneficiaryId() != null
					? updateDocumentChecklistngoBeneficiary.getDocChecklistngoBeneficiaryId()
					: -1;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistBeneficiaryServiceImpl::updateDocumentChecklistBeneficiary======"
					+ e.getMessage());
		}
		return null;
	}

	@Override
	public DocumentChecklistNgoBeneficiary getDocumentChecklistngoBeneficiary(Integer id) {
		try {
			DocumentChecklistNgoBeneficiary documentChecklistngoBeneficiary = documentChecklistngoBeneficiaryRepository
					.getDocumentChecklistngoBeneficiaryById(id);
			return documentChecklistngoBeneficiary;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistBeneficiaryServiceImpl::getDocumentChecklistBeneficiary======"
					+ e.getMessage());
		}
		return null;
	}

	@Override
	public DocumentChecklistNgoBeneficiaryVO getDocumentChecklistngoBeneficiaryVO(Integer id) {
		try {
			DocumentChecklistNgoBeneficiaryVO documentChecklistngoBeneficiary = documentChecklistngoBeneficiaryRepository
					.getDocumentChecklistngoBeneficiaryVOById(id);
			return documentChecklistngoBeneficiary;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistBeneficiaryServiceImpl::getDocumentChecklistBeneficiaryVO======"
					+ e.getMessage());
		}
		return null;
	}

	@Override
	public List<DocumentChecklistNgoBeneficiaryVO> getDocumentChecklistngoBeneficiaryByMFSNGOLoanId(Integer mfsngoLoanId) {
		try {
			List<DocumentChecklistNgoBeneficiaryVO> documentChecklistngoBeneficiaries = documentChecklistngoBeneficiaryRepository
					.getDocumentChecklistngoBeneficiaryByMFSNGOLoanId(mfsngoLoanId);
			return documentChecklistngoBeneficiaries;
		} catch (Exception e) {
			log.error(
					"Exception in DocumentChecklistBeneficiaryServiceImpl::getDocumentChecklistBeneficiaryByTermLoanId======"
							+ e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteDocumentChecklistngoBeneficiary(Integer id) {
		try {
			DocumentChecklistNgoBeneficiary DocumentChecklistngoBeneficiary = getDocumentChecklistngoBeneficiary(id);
			// LoanType.setActive(Boolean.FALSE);
			// LoanDocumentChecklist.setDeletedOn(DateFunctions.getZonedServerDate());
			// LoanDocumentChecklist.setIsDeleted(Constants.IS_DELETED);
			DocumentChecklistNgoBeneficiary updatedDocumentChecklistngoBeneficiary = documentChecklistngoBeneficiaryRepository
					.save(DocumentChecklistngoBeneficiary);
			return updatedDocumentChecklistngoBeneficiary.getDocChecklistngoBeneficiaryId() != null
					? updatedDocumentChecklistngoBeneficiary.getDocChecklistngoBeneficiaryId()
					: -1;
		} catch (Exception e) {
			log.error("Exception in LDocumentChecklistBeneficiaryServiceImpl::deleteDocumentChecklistBeneficiary======"
					+ e.getMessage());
		}
		return null;
	}

	@Override
	public List<DocumentChecklistNgoBeneficiaryVO> getDocumentChecklistngoBeneficiaryList() {
		try {
			List<DocumentChecklistNgoBeneficiaryVO> documentChecklistngoBeneficiaryList = documentChecklistngoBeneficiaryRepository
					.getDocumentChecklistngoBeneficiaryList();
			return documentChecklistngoBeneficiaryList;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistBeneficiaryServiceImpl::getDocumentChecklistBeneficiaryList======"
					+ e.getMessage());
		}
		return null;
	}

	// @Override
	// public LoanDocumentChecklist
	// getLoanDocumentChecklistByLoanDocumentChecklistName(String
	// loanDocumentChecklistName) {
	// try {
	// LoanDocumentChecklist loanDocumentChecklist =
	// loanDocumentChecklistRepository.findByLoanDocumentChecklistName(loanDocumentChecklistName);
	// return loanDocumentChecklist;
	// } catch (Exception e) {
	// log.error("Exception in
	// LoanDocumentChecklistServiceImpl::getLoanDocumentChecklistByLoanDocumentChecklistName======"
	// + e.getMessage());
	// }
	// return null;
	// }
}