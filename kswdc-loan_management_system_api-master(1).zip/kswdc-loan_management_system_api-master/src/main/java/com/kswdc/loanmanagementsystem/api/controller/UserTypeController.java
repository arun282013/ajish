package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.UserType;
import com.kswdc.loanmanagementsystem.api.service.UserTypeService;
import com.kswdc.loanmanagementsystem.api.value.UserTypeVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class UserTypeController {

	private final Logger log = LoggerFactory.getLogger(UserTypeController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private UserTypeService userTypeService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param UserType UserType
	 * @return Map
	 */
	@RequestMapping(value = "/userType", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createUserType(@RequestBody UserType UserType) {
		log.info("In UserTypeController::createUserType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(UserType)) {
//						UserType.setActive(Boolean.TRUE);
						UserType.setCreatedOn(DateFunctions.getZonedServerDate());
						// UserType.setCreatedBy();
						UserType.setIsDeleted(0);
						Integer UserTypeId = userTypeService.createUserType(UserType);
						if (!UserTypeId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("UserTypeId", UserTypeId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in UserTypeController::createUserType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param UserType UserType
	 * @return Map
	 */
	@RequestMapping(value = "/userType", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateUserType(@RequestBody UserType userType) {
		log.info("In UserTypeController::updateUserType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (userType != null) { // && UserType.getId() != null
				if (checkValid(userType)) {
					UserType chkUserType = userTypeService.getUserType(userType.getUsertypeId());
					if (chkUserType!=null) {
//						if (chkUserType.getActive()) {
//							UserType.setActive(Boolean.TRUE);
							chkUserType.setUsertypeName(userType.getUsertypeName());							
							chkUserType.setIsActive(userType.getIsActive());							
							Integer UserTypeId = userTypeService.updateUserType(chkUserType);
							if (!UserTypeId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("UserTypeId:", UserTypeId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" UserType Id is deactivated:"+UserType.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in UserTypeController::updateUserType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/userType/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteUserType(@PathVariable Integer id) {
		log.info("In UserTypeController::deleteUserType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				UserType UserType = userTypeService.getUserType(id);
				if (UserType != null) {
//					if (!UserType.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " UserTypeId:" + id);
//					} else {
						Integer UserTypeId = userTypeService.deleteUserType(id);
						if (!UserTypeId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("UserTypeId", UserTypeId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in UserTypeController::deleteUserType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/userType/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneUserType(@PathVariable Integer id) {
		log.info("In UserTypeController::getOneUserType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				UserType UserType = userTypeService.getUserType(id);
				if (UserType != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("UserType", UserType);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in UserTypeController::getOneUserType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- UserType ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/userType-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getUserTypeList() {
		log.info("In UserTypeController::getUserTypeList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			UserTypeListReturnVO UserTypeListReturnVO = new UserTypeListReturnVO(UserTypeService.getUserTypeList());
			List<UserTypeVO> UserTypeListReturnVO = userTypeService.getUserTypeList();
			if (UserTypeListReturnVO != null && UserTypeListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("userTypes", UserTypeListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in UserTypeController::getUserTypeList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param UserTypeId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer UserTypeId) {
		return (userTypeService.getUserType(UserTypeId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param UserType
	 * @return Boolean
	 */
	private Boolean checkValid(UserType UserType) {
		Boolean isValid = true;
		invalidMsg = "";
		if (UserType != null) {
//			if(UserType.getId()==null || UserType.getId()<=0) {
//				invalidMsg+="UserTypeId is required and should be valid!";
//				isValid = false;
//			}
			if (UserType.getUsertypeName() == null || UserType.getUsertypeName().equalsIgnoreCase("")) {
				invalidMsg += "UserType Name is required and should not be empty!";
				isValid = false;
			}
//			if (UserType.getUserTypeName() == null || UserType.getUserTypeName().equalsIgnoreCase("")) {
//				invalidMsg += "UserType Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (UserType.getQuotaInMB() == null || UserType.getQuotaInMB().equals(0) || UserType.getQuotaInMB()<0) {
//				invalidMsg += "UserType Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (UserType.getChatHistoryDays() == null || UserType.getChatHistoryDays().equals(0) || UserType.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for UserType is required and should be valid!";
//				isValid = false;
//			}
//			if (UserType.getCdaTimeoutTime() == null || UserType.getCdaTimeoutTime().equals(0) || UserType.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for UserType!";
			isValid = false;
		}
		return isValid;
	}
	
}
