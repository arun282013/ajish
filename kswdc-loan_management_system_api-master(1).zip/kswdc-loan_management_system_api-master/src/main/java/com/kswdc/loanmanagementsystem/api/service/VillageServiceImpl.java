package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.Village;
import com.kswdc.loanmanagementsystem.api.repository.VillageRepository;
import com.kswdc.loanmanagementsystem.api.value.VillageVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class VillageServiceImpl implements VillageService {
	private final Logger log = LoggerFactory.getLogger(VillageServiceImpl.class);
	
	@Autowired
	private VillageRepository villageRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createVillage(Village Village) {
		try {
			Village savedVillage = villageRepository.save(Village);
			return savedVillage.getVillageId() != null ? savedVillage.getVillageId() : -1;
		} catch (Exception e) {
			log.error("Exception in VillageServiceImpl::createVillage======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateVillage(Village Village) {
		try {
			Village updateVillage = villageRepository.save(Village);
			return updateVillage.getVillageId() != null ? updateVillage.getVillageId() : -1;
		} catch (Exception e) {
			log.error("Exception in VillageServiceImpl::updateVillage======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Village getVillage(Integer id) {
		try {
			Village village = villageRepository.getVillageById(id);
			return village;
		} catch (Exception e) {
			log.error("Exception in VillageServiceImpl::getVillage======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteVillage(Integer id) {
		try {
			Village Village = getVillage(id);
//			Village.setActive(Boolean.FALSE);
			Village.setDeletedOn(DateFunctions.getZonedServerDate());
			Village.setIsDeleted(Constants.IS_DELETED);
			Village updatedVillage = villageRepository.save(Village);
			return updatedVillage.getVillageId() != null ? updatedVillage.getVillageId() : -1;
		} catch (Exception e) {
			log.error("Exception in VillageServiceImpl::deleteVillage======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<VillageVO> getVillageList() {
		try {
			List<VillageVO> villageList = villageRepository.getVillageList();
			return villageList;
		} catch (Exception e) {
			log.error("Exception in VillageServiceImpl::getVillageList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<VillageVO> getVillageListByTaluk(Integer talukId) {
		try {
			List<VillageVO> villageList = villageRepository.getVillageListByTaluk(talukId);
			return villageList;
		} catch (Exception e) {
			log.error("Exception in VillageServiceImpl::getVillageListByTaluk======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Village getVillageByVillageName(String villageName) {
		try {
			Village village = villageRepository.findByVillageName(villageName);
			return village;
		} catch (Exception e) {
			log.error("Exception in VillageServiceImpl::getVillageByVillageName======" + e.getMessage());
		}
		return null;
	}
}