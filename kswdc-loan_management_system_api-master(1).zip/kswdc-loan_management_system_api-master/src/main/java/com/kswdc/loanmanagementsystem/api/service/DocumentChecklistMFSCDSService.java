package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistMFSCDS;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistMFSCDSVO;


@Component
public interface DocumentChecklistMFSCDSService {

    Integer createDocumentChecklistMFSCDS(DocumentChecklistMFSCDS documentChecklistMFSCDS);

    Integer updateDocumentChecklistMFSCDS(DocumentChecklistMFSCDS documentChecklistMFSCDS);

    DocumentChecklistMFSCDS getDocumentChecklistMFSCDS(Integer id);

    DocumentChecklistMFSCDS getDocumentChecklistMFSCDSByDocumentChecklistMFSCDSName(String documentchecklistmfscdsName);

    Integer deleteDocumentChecklistMFSCDS(Integer id);

    List<DocumentChecklistMFSCDSVO> getDocumentChecklistMFSCDSList();

    List<DocumentChecklistMFSCDSVO> getDocumentChecklistMFSCDSListByLoanType();
}
