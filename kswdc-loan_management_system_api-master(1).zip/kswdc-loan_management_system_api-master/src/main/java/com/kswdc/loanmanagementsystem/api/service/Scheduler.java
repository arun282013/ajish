package com.kswdc.loanmanagementsystem.api.service;

import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class Scheduler {
	private final Logger log = LoggerFactory.getLogger(Scheduler.class);
	
	
	@Value(value = "${spring.application.name}")
	private String appName;
	
	// @Scheduled(fixedDelay = 60000, initialDelay = 3000)
	//    public void fetchNewVoiceMailsSch() {
	//       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	//       Date now = new Date();
	//       String strDate = sdf.format(now);
	//       log.info("Called fetchNewVoiceMailsSch scheduler:: " + strDate);
	//       try {
	// 			fracTELService.fetchVoiceMails();
	    	  
	//       }catch(Exception e) {
	//     	  log.error("Exception in Scheduler::fetchNewVoiceMailsSch======" + e.getMessage());
	//           rabbitMqService.sendEvent(appName,Constants.DB_FETCH_ERROR,"Exception in Scheduler::fetchNewVoiceMailsSch======" +e.getMessage());
	//           e.printStackTrace();
	//       }
	//    }
}
