package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistNgoBeneficiary;
import com.kswdc.loanmanagementsystem.api.service.DocumentChecklistNgoBeneficiaryService;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistNgoBeneficiaryVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class DocumentChecklistNgoBeneficiaryController {

	private final Logger log = LoggerFactory.getLogger(DocumentChecklistNgoBeneficiaryController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private DocumentChecklistNgoBeneficiaryService documentChecklistngoBeneficiaryService;
	

	@RequestMapping(value = "/documentChecklistngoBeneficiary", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createDocumentChecklistNgoBeneficiary(@RequestBody DocumentChecklistNgoBeneficiary DocumentChecklistngoBeneficiary) {
		log.info("In DocumentChecklistBeneficiaryController::createDocumentChecklistBeneficiary=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(DocumentChecklistngoBeneficiary)) {
					//						LoanType.setActive(Boolean.TRUE);
						//LoanDocumentChecklist.setCreatedOn(DateFunctions.getZonedServerDate());
						// LoanType.setCreatedBy();
						//LoanDocumentChecklist.setIsDeleted(0);
						Integer DocumentChecklistBeneficiaryId = documentChecklistngoBeneficiaryService.createDocumentChecklistngoBeneficiary(DocumentChecklistngoBeneficiary);
						if (!DocumentChecklistBeneficiaryId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("DocumentChecklistNgoBeneficiaryId", DocumentChecklistBeneficiaryId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistBeneficiaryController::createDocumentChecklistBeneficiary======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	@RequestMapping(value = "/documentChecklistngoBeneficiary", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateDocumentChecklistBeneficiary(@RequestBody DocumentChecklistNgoBeneficiary documentChecklistBeneficiary) {
		log.info("In DocumentChecklistBeneficiaryController::updateDocumentChecklistBeneficiary=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (documentChecklistBeneficiary != null) { // && LoanType.getId() != null
				if (checkValid(documentChecklistBeneficiary)) {
					DocumentChecklistNgoBeneficiary chkDocumentChecklistBeneficiary = documentChecklistngoBeneficiaryService.getDocumentChecklistngoBeneficiary(documentChecklistBeneficiary.getDocChecklistngoBeneficiaryId());
					if (chkDocumentChecklistBeneficiary!=null) {
//						if (chkLoanType.getActive()) {
//							LoanType.setActive(Boolean.TRUE);
							//chkLoanDocumentChecklist.setLoandocumentChecklistCode(loanDocumentChecklist.);
							//chkLoanDocumentChecklist.setLoandocumentChecklistName(loanDocumentChecklist.getLoantypeName());							
							//chkLoanDocumentChecklist.setIsActive(loanDocumentChecklist.getIsActive());							
							Integer DocumentChecklistBeneficiaryId = documentChecklistngoBeneficiaryService.updateDocumentChecklistngoBeneficiary(chkDocumentChecklistBeneficiary);
							if (!DocumentChecklistBeneficiaryId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("DocumentChecklistNgoBeneficiaryId:", DocumentChecklistBeneficiaryId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" LoanType Id is deactivated:"+LoanType.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistBeneficiaryController::updateDocumentChecklistBeneficiary======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	@RequestMapping(value = "/documentChecklistngoBeneficiary/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteDocumentChecklistBeneficiary(@PathVariable Integer id) {
		log.info("In DocumentChecklistBeneficiaryController::deleteDocumentChecklistBeneficiary=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				DocumentChecklistNgoBeneficiary DocumentChecklistBeneficiary = documentChecklistngoBeneficiaryService.getDocumentChecklistngoBeneficiary(id);
				if (DocumentChecklistBeneficiary != null) {
//					if (!LoanType.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " LoanTypeId:" + id);
//					} else {
						Integer DocumentChecklistBeneficiaryId = documentChecklistngoBeneficiaryService.deleteDocumentChecklistngoBeneficiary(id);
						if (!DocumentChecklistBeneficiaryId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("DocumentChecklistNgoBeneficiaryId", DocumentChecklistBeneficiaryId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistBeneficiaryController::deleteDocumentChecklistBeneficiary======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	@RequestMapping(value = "/documentChecklistngoBeneficiary/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneDocumentChecklistBeneficiary(@PathVariable Integer id) {
		log.info("In DocumentChecklistBeneficiaryController::getOneDocumentChecklistBeneficiary=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				DocumentChecklistNgoBeneficiary DocumentChecklistBeneficiary = documentChecklistngoBeneficiaryService.getDocumentChecklistngoBeneficiary(id);
				if (DocumentChecklistBeneficiary != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("DocumentChecklistBeneficiary", DocumentChecklistBeneficiary);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistBeneficiaryController::getOneDocumentChecklistBeneficiary======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	@RequestMapping(value = "/documentChecklistngoBeneficiary-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getDocumentChecklistBeneficiaryList() {
		log.info("In DocumentChecklistBeneficiaryController::getDocumentChecklistBeneficiaryList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			LoanTypeListReturnVO LoanTypeListReturnVO = new LoanTypeListReturnVO(LoanTypeService.getLoanTypeList());
			List<DocumentChecklistNgoBeneficiaryVO> DocumentChecklistBeneficiaryListReturnVO = documentChecklistngoBeneficiaryService.getDocumentChecklistngoBeneficiaryList();
			if (DocumentChecklistBeneficiaryListReturnVO != null && DocumentChecklistBeneficiaryListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("documentChecklistBeneficiarys", DocumentChecklistBeneficiaryListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistBeneficiaryController::getDocumentChecklistBeneficiaryList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	

	private Boolean checkIfExists(Integer DocumentChecklistBeneficiaryId) {
		return (documentChecklistngoBeneficiaryService.getDocumentChecklistngoBeneficiary(DocumentChecklistBeneficiaryId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	
	private Boolean checkValid(DocumentChecklistNgoBeneficiary documentChecklistBeneficiary) {
		Boolean isValid = true;
		invalidMsg = "";
		if (documentChecklistBeneficiary != null) {
//			if(LoanType.getId()==null || LoanType.getId()<=0) {
//				invalidMsg+="LoanTypeId is required and should be valid!";
//				isValid = false;
//			}
			// if (LoanDocumentChecklist.getLoandocumentChecklistName() == null || LoanDocumentChecklist.getLoandocumentChecklistName().equalsIgnoreCase("")) {
			// 	invalidMsg += "LoanDocumentChecklist Name is required and should not be empty!";
			// 	isValid = false;
			// }
//			if (LoanType.getLoanTypeName() == null || LoanType.getLoanTypeName().equalsIgnoreCase("")) {
//				invalidMsg += "LoanType Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (LoanType.getQuotaInMB() == null || LoanType.getQuotaInMB().equals(0) || LoanType.getQuotaInMB()<0) {
//				invalidMsg += "LoanType Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanType.getChatHistoryDays() == null || LoanType.getChatHistoryDays().equals(0) || LoanType.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for LoanType is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanType.getCdaTimeoutTime() == null || LoanType.getCdaTimeoutTime().equals(0) || LoanType.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for documentChecklistBeneficiary!";
			isValid = false;
		}
		return isValid;
	}
	
}
