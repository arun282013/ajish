package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistMFSCDSBeneficiary;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistMFSCDSBeneficiaryVO;

@Component
public interface DocumentChecklistMFSCDSBeneficiaryService {

    Integer createDocumentChecklistMFSCDSBeneficiary(DocumentChecklistMFSCDSBeneficiary documentChecklistMFSCDSBeneficiary);

    Integer updateDocumentChecklistMFSCDSBeneficiary(DocumentChecklistMFSCDSBeneficiary documentChecklistMFSCDSBeneficiary);

    DocumentChecklistMFSCDSBeneficiary getDocumentChecklistMFSCDSBeneficiary(Integer id);

    DocumentChecklistMFSCDSBeneficiaryVO getDocumentChecklistMFSCDSBeneficiaryVO(Integer id);

    List<DocumentChecklistMFSCDSBeneficiaryVO> getDocumentChecklistMFSCDSBeneficiaryByMFSCDSLoanId(Integer mfscdsLoanId);

    // LoanDocumentChecklist
    // geLoanDocumentChecklistByLoanDocumentChecklistName(String
    // loanDocumentChecklistName);

    Integer deleteDocumentChecklistMFSCDSBeneficiary(Integer id);

    List<DocumentChecklistMFSCDSBeneficiaryVO> getDocumentChecklistMFSCDSBeneficiaryList();

}
