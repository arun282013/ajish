package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.Bank;
import com.kswdc.loanmanagementsystem.api.repository.BankRepository;
import com.kswdc.loanmanagementsystem.api.value.BankVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class BankServiceImpl implements BankService {
	private final Logger log = LoggerFactory.getLogger(BankServiceImpl.class);
	
	@Autowired
	private BankRepository bankRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createBank(Bank Bank) {
		try {
			Bank savedBank = bankRepository.save(Bank);
			return savedBank.getBankId() != null ? savedBank.getBankId() : -1;
		} catch (Exception e) {
			log.error("Exception in BankServiceImpl::createBank======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateBank(Bank Bank) {
		try {
			Bank updateBank = bankRepository.save(Bank);
			return updateBank.getBankId() != null ? updateBank.getBankId() : -1;
		} catch (Exception e) {
			log.error("Exception in BankServiceImpl::updateBank======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Bank getBank(Integer id) {
		try {
			Bank bank = bankRepository.getBankById(id);
			return bank;
		} catch (Exception e) {
			log.error("Exception in BankServiceImpl::getBank======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteBank(Integer id) {
		try {
			Bank Bank = getBank(id);
//			Bank.setActive(Boolean.FALSE);
			Bank.setDeletedOn(DateFunctions.getZonedServerDate());
			Bank.setIsDeleted(Constants.IS_DELETED);
			Bank updatedBank = bankRepository.save(Bank);
			return updatedBank.getBankId() != null ? updatedBank.getBankId() : -1;
		} catch (Exception e) {
			log.error("Exception in BankServiceImpl::deleteBank======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<BankVO> getBankList() {
		try {
			List<BankVO> bankList = bankRepository.getBankList();
			return bankList;
		} catch (Exception e) {
			log.error("Exception in BankServiceImpl::getBankList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Bank getBankByBankName(String bankName) {
		try {
			Bank bank = bankRepository.findByBankName(bankName);
			return bank;
		} catch (Exception e) {
			log.error("Exception in BankServiceImpl::getBankByBankName======" + e.getMessage());
		}
		return null;
	}
}