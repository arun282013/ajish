package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class NgoFinanceVO implements Serializable {
    private Integer financeId;
    private String financeYear;
    private String programName;
    private String fundedBy;
    private Double amountReceived;
    private String achievements;
   

    public NgoFinanceVO(Integer financeId, 
    String financeYear,String programName,
    String fundedBy,Double amountReceived,
    String achievements
    ) {
        this.financeId = financeId;
        this.financeYear = financeYear;
        this.programName = programName;
        this.fundedBy = fundedBy;
        this.amountReceived = amountReceived;
        this.achievements = achievements;
      
    }
    
}
