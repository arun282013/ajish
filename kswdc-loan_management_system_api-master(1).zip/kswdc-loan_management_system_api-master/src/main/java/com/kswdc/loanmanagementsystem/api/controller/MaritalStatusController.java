package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.MaritalStatus;
import com.kswdc.loanmanagementsystem.api.service.MaritalStatusService;
import com.kswdc.loanmanagementsystem.api.value.MaritalStatusVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class MaritalStatusController {

	private final Logger log = LoggerFactory.getLogger(MaritalStatusController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private MaritalStatusService maritalStatusService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param MaritalStatus MaritalStatus
	 * @return Map
	 */
	@RequestMapping(value = "/maritalStatus", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createMaritalStatus(@RequestBody MaritalStatus MaritalStatus) {
		log.info("In MaritalStatusController::createMaritalStatus=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(MaritalStatus)) {
//						MaritalStatus.setActive(Boolean.TRUE);
						MaritalStatus.setCreatedOn(DateFunctions.getZonedServerDate());
						// MaritalStatus.setCreatedBy();
						MaritalStatus.setIsDeleted(0);
						Integer MaritalStatusId = maritalStatusService.createMaritalStatus(MaritalStatus);
						if (!MaritalStatusId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("MaritalStatusId", MaritalStatusId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MaritalStatusController::createMaritalStatus======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param MaritalStatus MaritalStatus
	 * @return Map
	 */
	@RequestMapping(value = "/maritalStatus", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateMaritalStatus(@RequestBody MaritalStatus maritalStatus) {
		log.info("In MaritalStatusController::updateMaritalStatus=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (maritalStatus != null) { // && MaritalStatus.getId() != null
				if (checkValid(maritalStatus)) {
					MaritalStatus chkMaritalStatus = maritalStatusService.getMaritalStatus(maritalStatus.getMaritalstatusId());
					if (chkMaritalStatus!=null) {
//						if (chkMaritalStatus.getActive()) {
//							MaritalStatus.setActive(Boolean.TRUE);
							chkMaritalStatus.setMaritalstatusName(maritalStatus.getMaritalstatusName());							
							chkMaritalStatus.setIsActive(maritalStatus.getIsActive());							
							Integer MaritalStatusId = maritalStatusService.updateMaritalStatus(chkMaritalStatus);
							if (!MaritalStatusId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("MaritalStatusId:", MaritalStatusId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" MaritalStatus Id is deactivated:"+MaritalStatus.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MaritalStatusController::updateMaritalStatus======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/maritalStatus/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteMaritalStatus(@PathVariable Integer id) {
		log.info("In MaritalStatusController::deleteMaritalStatus=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				MaritalStatus MaritalStatus = maritalStatusService.getMaritalStatus(id);
				if (MaritalStatus != null) {
//					if (!MaritalStatus.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " MaritalStatusId:" + id);
//					} else {
						Integer MaritalStatusId = maritalStatusService.deleteMaritalStatus(id);
						if (!MaritalStatusId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("MaritalStatusId", MaritalStatusId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MaritalStatusController::deleteMaritalStatus======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/maritalStatus/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneMaritalStatus(@PathVariable Integer id) {
		log.info("In MaritalStatusController::getOneMaritalStatus=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				MaritalStatus MaritalStatus = maritalStatusService.getMaritalStatus(id);
				if (MaritalStatus != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("MaritalStatus", MaritalStatus);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MaritalStatusController::getOneMaritalStatus======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- MaritalStatus ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/maritalStatus-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getMaritalStatusList() {
		log.info("In MaritalStatusController::getMaritalStatusList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			MaritalStatusListReturnVO MaritalStatusListReturnVO = new MaritalStatusListReturnVO(MaritalStatusService.getMaritalStatusList());
			List<MaritalStatusVO> MaritalStatusListReturnVO = maritalStatusService.getMaritalStatusList();
			if (MaritalStatusListReturnVO != null && MaritalStatusListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("maritalStatuss", MaritalStatusListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MaritalStatusController::getMaritalStatusList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param MaritalStatusId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer MaritalStatusId) {
		return (maritalStatusService.getMaritalStatus(MaritalStatusId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param MaritalStatus
	 * @return Boolean
	 */
	private Boolean checkValid(MaritalStatus MaritalStatus) {
		Boolean isValid = true;
		invalidMsg = "";
		if (MaritalStatus != null) {
//			if(MaritalStatus.getId()==null || MaritalStatus.getId()<=0) {
//				invalidMsg+="MaritalStatusId is required and should be valid!";
//				isValid = false;
//			}
			if (MaritalStatus.getMaritalstatusName() == null || MaritalStatus.getMaritalstatusName().equalsIgnoreCase("")) {
				invalidMsg += "MaritalStatus Name is required and should not be empty!";
				isValid = false;
			}
//			if (MaritalStatus.getMaritalStatusName() == null || MaritalStatus.getMaritalStatusName().equalsIgnoreCase("")) {
//				invalidMsg += "MaritalStatus Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (MaritalStatus.getQuotaInMB() == null || MaritalStatus.getQuotaInMB().equals(0) || MaritalStatus.getQuotaInMB()<0) {
//				invalidMsg += "MaritalStatus Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (MaritalStatus.getChatHistoryDays() == null || MaritalStatus.getChatHistoryDays().equals(0) || MaritalStatus.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for MaritalStatus is required and should be valid!";
//				isValid = false;
//			}
//			if (MaritalStatus.getCdaTimeoutTime() == null || MaritalStatus.getCdaTimeoutTime().equals(0) || MaritalStatus.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for MaritalStatus!";
			isValid = false;
		}
		return isValid;
	}
	
}
