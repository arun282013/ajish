package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistBeneficiary;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistBeneficiaryVO;

@Component
public interface DocumentChecklistBeneficiaryService {

    Integer createDocumentChecklistBeneficiary(DocumentChecklistBeneficiary documentChecklistBeneficiary);

    Integer updateDocumentChecklistBeneficiary(DocumentChecklistBeneficiary documentChecklistBeneficiary);

    DocumentChecklistBeneficiary getDocumentChecklistBeneficiary(Integer id);

    DocumentChecklistBeneficiaryVO getDocumentChecklistBeneficiaryVO(Integer id);

    List<DocumentChecklistBeneficiaryVO> getDocumentChecklistBeneficiaryByTermLoanId(Integer termLoanId);

    // LoanDocumentChecklist
    // geLoanDocumentChecklistByLoanDocumentChecklistName(String
    // loanDocumentChecklistName);

    Integer deleteDocumentChecklistBeneficiary(Integer id);

    List<DocumentChecklistBeneficiaryVO> getDocumentChecklistBeneficiaryList();

}
