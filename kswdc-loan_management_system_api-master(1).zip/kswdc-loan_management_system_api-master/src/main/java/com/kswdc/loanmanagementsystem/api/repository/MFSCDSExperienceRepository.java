package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.MFSCDSExperience;
import com.kswdc.loanmanagementsystem.api.value.MFSCDSExperienceVO;

@Repository
public interface MFSCDSExperienceRepository extends JpaRepository<MFSCDSExperience, Integer> {  
    @Query("SELECT a FROM MFSCDSExperience a WHERE a.id=:experienceId")
    MFSCDSExperience getMFSCDSExperienceById(@Param("experienceId") Integer experienceId);
 
    @Query("SELECT cl FROM MFSCDSExperience cl WHERE cl.experienceProjectdone=experienceProjectdone")
    MFSCDSExperience getMFSCDSExperienceByMFSCDSExperienceProjectdone(@Param("experienceProjectdone") String experienceProjectdone);

}
