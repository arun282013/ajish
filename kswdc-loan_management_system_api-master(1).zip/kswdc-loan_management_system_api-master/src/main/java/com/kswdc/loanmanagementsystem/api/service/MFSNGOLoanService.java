package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.MFSNGOLoan;
import com.kswdc.loanmanagementsystem.api.value.MFSNGOLoanVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface MFSNGOLoanService {

    Integer createMFSNGOLoan(MFSNGOLoan mfsngoloan);

    Integer updateMFSNGOLoan(MFSNGOLoan mfsngoloan);

    Integer updateSecondTabMFSNGOLoan(MFSNGOLoan mfsngoloan);

    MFSNGOLoan getMFSNGOLoan(Integer id);
  
    MFSNGOLoanVO getMFSNGOLoanByUser(Integer userId);

    Integer updateThirdTabMFSNGOLoan(MFSNGOLoan mfsngoloan);

    // // TermLoan getTermLoanByTermLoanName(String termLoanName);

    // Integer deleteTermLoan(Integer id);

    //  List<MFSNGOLoanVO> getMFSNGOLoanList();

    // // --modal view
    MFSNGOLoanVO getPreviewMFSNGOLoan(Integer mfsngoLoanId);
    // TermLoan getPreviewTermLoan(Integer id);
    // --modal view

    //--for photo
    Integer updateStampNgoLoan(MFSNGOLoan mfsngoloan);

    MFSNGOLoanVO getNgoLoanVOsignById(Integer mfsngoLoanId);
    //--for sign
    Integer updateSignNgoLoan(MFSNGOLoan mfsngoloan);

    // TermLoanVO getTermLoanVOSignById(Integer termLoanId);



    
}
