package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_Postoffice")
@EqualsAndHashCode()
public class Postoffice{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "POSTOFFICE_ID")
    private Integer postofficeId;

    @Column(name = "POSTOFFICE_NAME", columnDefinition = "varchar(100) not null")
    private String postofficeName;

    @ManyToOne()
    @JoinColumn(name= "District_ID",nullable = true)
    private District districtObj;
    
     @Column(name = "PINCODE", columnDefinition = "varchar(6) not null")
     private String pincode;
    
    
    @Column(name = "CREATED_ON")
    private ZonedDateTime createdOn;

    @ManyToOne()
    @JoinColumn(name= "CREATED_BY",nullable = true)
    private Postoffice createdBy;

    @Column(name = "MODIFIED_ON",nullable = true)
    private ZonedDateTime modifiedOn;

    @ManyToOne()
    @JoinColumn(name= "MODIFIED_BY",nullable = true)
    private Postoffice modifiedBy;

    @Column(name = "IS_DELETED",columnDefinition = "tinyint(1) not null default 0")
    private Integer isDeleted;
    
    @Column(name = "DELETED_ON",nullable = true)
    private ZonedDateTime deletedOn;

    @Column(name = "IS_ACTIVE",columnDefinition = "tinyint(1) not null default 0")
    private Integer isActive;
}
