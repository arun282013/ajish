package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.Ngofinance;
import com.kswdc.loanmanagementsystem.api.repository.NgoFinanceRepository;
import com.kswdc.loanmanagementsystem.api.value.NgoFinanceVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class NgoFinanceServiceImpl implements NgoFinanceService {
	private final Logger log = LoggerFactory.getLogger(NgoFinanceServiceImpl.class);
	
	@Autowired
	private NgoFinanceRepository NgoFinanceRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createNgoFinance(Ngofinance Ngofinance) {
		try {
			Ngofinance savedNgofinance = NgoFinanceRepository.save(Ngofinance);
			return savedNgofinance.getFinanceId() != null ? savedNgofinance.getFinanceId() : -1;
		} catch (Exception e) {
			log.error("Exception in NGoFinanceServiceImpl::createNgoFinance======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateNgoFinance(Ngofinance Ngofinance) {
		try {
			Ngofinance updateNgoFinance = NgoFinanceRepository.save(Ngofinance);
			return updateNgoFinance.getFinanceId() != null ? updateNgoFinance.getFinanceId() : -1;
		} catch (Exception e) {
			log.error("Exception in NgoFinanceServiceImpl::updateNgoFinance======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Ngofinance getNgofinance(Integer id) {
		try {
			Ngofinance NgoFinance = NgoFinanceRepository.getNgoFinanceById(id);
			return NgoFinance;
		} catch (Exception e) {
			log.error("Exception in TLFamilyMemberServiceImpl::getTLFamilyMember======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteNgofinance(Integer id) {
		try {
			Ngofinance Ngofinance = getNgofinance(id);
//			TLFamilyMember.setActive(Boolean.FALSE);
			// TLFamilyMember.setDeletedOn(DateFunctions.getZonedServerDate());
			// TLFamilyMember.setIsDeleted(Constants.IS_DELETED);
			Ngofinance updatedNgofinance = NgoFinanceRepository.save(Ngofinance);
			return updatedNgofinance.getFinanceId() != null ? updatedNgofinance.getFinanceId() : -1;
		} catch (Exception e) {
			log.error("Exception in NgofinanceServiceImpl::deleteNgofinance======" + e.getMessage());
		}
		return null;
	}

	// @Override
	// public List<TLFamilyMemberVO> getTLFamilyMemberList() {
	// 	try {
	// 		List<TLFamilyMemberVO> tlfamilymemberList = tlfamilymemberRepository.getTLFamilyMemberList();
	// 		return tlfamilymemberList;
	// 	} catch (Exception e) {
	// 		log.error("Exception in TLFamilyMemberServiceImpl::getTLFamilyMemberList======" + e.getMessage());
	// 	}
	// 	return null;
	// }

	// @Override
	// public TLFamilyMember getTLFamilyMemberByTLFamilyMemberName(String TLFamilyMemberName) {
	// 	try {
	// 		TLFamilyMember TLFamilyMember = TLFamilyMemberRepository.getTLFamilyMemberByTLFamilyMemberName(TLFamilyMemberName);
	// 		return TLFamilyMember;
	// 	} catch (Exception e) {
	// 		log.error("Exception in TLFamilyMemberServiceImpl::getTLFamilyMemberByTLFamilyMemberName======" + e.getMessage());
	// 	}
	// 	return null;
	// }
}