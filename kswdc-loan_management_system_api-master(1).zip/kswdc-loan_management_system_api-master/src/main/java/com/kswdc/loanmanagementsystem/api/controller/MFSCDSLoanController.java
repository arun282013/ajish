package com.kswdc.loanmanagementsystem.api.controller;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;


import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.ArrayList;


import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.MFSCDSLoan;
import com.kswdc.loanmanagementsystem.api.model.User;
import com.kswdc.loanmanagementsystem.api.service.MFSCDSLoanService;
import com.kswdc.loanmanagementsystem.api.service.UserService;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistBeneficiaryVO;
import com.kswdc.loanmanagementsystem.api.value.ResponseMessageVO;
import com.kswdc.loanmanagementsystem.api.value.MFSCDSLoanVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;
import com.kswdc.loanmanagementsystem.api.model.LoanCategory;
import com.kswdc.loanmanagementsystem.api.model.LocalbodyType;
import com.kswdc.loanmanagementsystem.api.service.LoanCategoryService;
import com.kswdc.loanmanagementsystem.api.model.LocalBody;
import com.kswdc.loanmanagementsystem.api.service.LocalBodyService;
import com.kswdc.loanmanagementsystem.api.service.LocalbodyTypeService;
import com.kswdc.loanmanagementsystem.api.model.Postoffice;
import com.kswdc.loanmanagementsystem.api.service.PostofficeService;
import com.kswdc.loanmanagementsystem.api.model.Taluk;
import com.kswdc.loanmanagementsystem.api.service.TalukService;
import com.kswdc.loanmanagementsystem.api.model.District;
import com.kswdc.loanmanagementsystem.api.service.DistrictService;
import com.kswdc.loanmanagementsystem.api.model.LoanType;
import com.kswdc.loanmanagementsystem.api.service.LoanTypeService;
import com.kswdc.loanmanagementsystem.api.model.MFSCDSProgram;
import com.kswdc.loanmanagementsystem.api.service.MFSCDSProgramService;
import com.kswdc.loanmanagementsystem.api.model.MFSCDSExperience;
import com.kswdc.loanmanagementsystem.api.model.MFSCDSBalancesheet;
import com.kswdc.loanmanagementsystem.api.value.MFSCDSProgramVO;
import com.kswdc.loanmanagementsystem.api.value.MFSCDSExperienceVO;
import com.kswdc.loanmanagementsystem.api.value.MFSCDSBalancesheetVO;
import com.kswdc.loanmanagementsystem.api.model.FileInfo;
import com.kswdc.loanmanagementsystem.api.service.FilesStorageService;
import com.kswdc.loanmanagementsystem.api.model.DocumentChecklist;
import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistBeneficiary;
import com.kswdc.loanmanagementsystem.api.service.DocumentChecklistBeneficiaryService;
import com.kswdc.loanmanagementsystem.api.service.DocumentChecklistService;
import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistMFSCDS;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistMFSCDSVO;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistMFSCDSBeneficiaryVO;
import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistMFSCDSBeneficiary;
import com.kswdc.loanmanagementsystem.api.service.DocumentChecklistMFSCDSService;
import com.kswdc.loanmanagementsystem.api.service.DocumentChecklistMFSCDSBeneficiaryService;
//File upload
import com.kswdc.loanmanagementsystem.api.model.FileInfoMFSCDS;




@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class MFSCDSLoanController {

	private final Logger log = LoggerFactory.getLogger(MFSCDSLoanController.class);
	private String invalidMsg = "";

	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private MFSCDSLoanService mfscdsloanService;

	@Autowired
	private LoanCategoryService loanCategoryService;
	
	@Autowired
	private DistrictService districtService;

	@Autowired
	private TalukService talukService;

	@Autowired
	private LocalBodyService localbodyService;

	@Autowired
	private PostofficeService postofficeService;

	@Autowired
	private LoanTypeService loanTypeService;

	@Autowired
	private UserService userService;

	@Autowired
	private LocalbodyTypeService localbodytypeService;

	@Autowired
	private MFSCDSProgramService mfscdsprogramService;

	
	@Autowired
	FilesStorageService storageService;

	@Autowired
	private DocumentChecklistMFSCDSService documentChecklistMFSCDSService;

	@Autowired
	private DocumentChecklistMFSCDSBeneficiaryService documentChecklistMFSCDSBeneficiaryService;


	/**
	 * @param MFSCDSLoan MFSCDSLoan
	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsloan", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createMFSCDSLoan(@RequestBody MFSCDSLoanVO mfscdsloanVO) {
		log.info("In MFSCDSLoanController::createMFSCDSLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (checkValidVO(mfscdsloanVO))  {
				MFSCDSLoan mfscdsloanObj = new MFSCDSLoan();
				mfscdsloanObj.setCdsName(mfscdsloanVO.getCdsName());
				LoanCategory loanCategoryObj = loanCategoryService.getLoanCategory(mfscdsloanVO.getLoancategoryId());
				mfscdsloanObj.setLoanCategoryObj(loanCategoryObj);
				mfscdsloanObj.setCdshouseName(mfscdsloanVO.getCdshouseName());
				mfscdsloanObj.setCdshouseNo(mfscdsloanVO.getCdshouseNo());
				District districtObj = districtService.getDistrict(mfscdsloanVO.getCdsdistrictId());
				mfscdsloanObj.setCdsdistrictObj(districtObj);
				Taluk talukObj = talukService.getTaluk(mfscdsloanVO.getCdstalukId());
				mfscdsloanObj.setCdstalukObj(talukObj);
				mfscdsloanObj.setCdslocationtypeId(mfscdsloanVO.getCdslocationtypeId());
				LocalbodyType localbodytypeObj = localbodytypeService.getLocalbodyType(mfscdsloanVO.getCdslocalbodytypeId());
				mfscdsloanObj.setCdslocalbodytypeObj(localbodytypeObj);
				LocalBody localbodyObj = localbodyService.getLocalBody(mfscdsloanVO.getCdslocalbodyId());
				mfscdsloanObj.setCdslocalbodyObj(localbodyObj);
				mfscdsloanObj.setCdsLocation(mfscdsloanVO.getCdsLocation());
				Postoffice cdspostofficeObj = postofficeService.getPostoffice(mfscdsloanVO.getCdspostofficeId());
				mfscdsloanObj.setCdspostofficeObj(cdspostofficeObj);
				mfscdsloanObj.setCdsPincode(mfscdsloanVO.getCdsPincode());
				mfscdsloanObj.setCdsemailId(mfscdsloanVO.getCdsemailId());
				mfscdsloanObj.setCdspanNo(mfscdsloanVO.getCdspanNo());
				mfscdsloanObj.setCdsregNo(mfscdsloanVO.getCdsregNo());
				mfscdsloanObj.setCdsregYear(mfscdsloanVO.getCdsregYear());
				mfscdsloanObj.setCdscpName(mfscdsloanVO.getCdscpName());
				mfscdsloanObj.setCdscpPhoneNo(mfscdsloanVO.getCdscpPhoneNo());
				mfscdsloanObj.setCdssecName(mfscdsloanVO.getCdscpName());
				mfscdsloanObj.setCdssecPhoneNo(mfscdsloanVO.getCdssecPhoneNo());
				mfscdsloanObj.setCdscpAadharNo(mfscdsloanVO.getCdscpAadharNo());
				mfscdsloanObj.setCdssecAadharNo(mfscdsloanVO.getCdssecAadharNo());
				mfscdsloanObj.setCdscphouseName(mfscdsloanVO.getCdscphouseName());
				mfscdsloanObj.setCdscphouseNo(mfscdsloanVO.getCdscphouseNo());
				District cdscpdistrictObj = districtService.getDistrict(mfscdsloanVO.getCdscpdistrictId());
				mfscdsloanObj.setCdscpdistrictObj(cdscpdistrictObj);
				Taluk cdscptalukObj = talukService.getTaluk(mfscdsloanVO.getCdscptalukId());
				mfscdsloanObj.setCdscptalukObj(cdscptalukObj);
				mfscdsloanObj.setCdscplocationtypeId(mfscdsloanVO.getCdscplocationtypeId());
				LocalbodyType cdscplocalbodytypeObj = localbodytypeService.getLocalbodyType(mfscdsloanVO.getCdscplocalbodytypeId());
				mfscdsloanObj.setCdscplocalbodytypeObj(cdscplocalbodytypeObj);
				LocalBody cdscplocalbodyObj = localbodyService.getLocalBody(mfscdsloanVO.getCdscplocalbodyId());
				mfscdsloanObj.setCdscplocalbodyObj(cdscplocalbodyObj);
				mfscdsloanObj.setCdscpLocation(mfscdsloanVO.getCdscpLocation());
				Postoffice cdscppostofficeObj = postofficeService.getPostoffice(mfscdsloanVO.getCdscppostofficeId());
				mfscdsloanObj.setCdscppostofficeObj(cdscppostofficeObj);
				mfscdsloanObj.setCdscpPincode(mfscdsloanVO.getCdscpPincode());
				mfscdsloanObj.setCdssechouseName(mfscdsloanVO.getCdssechouseName());
				mfscdsloanObj.setCdssechouseNo(mfscdsloanVO.getCdssechouseNo());
				District cdssecdistrictObj = districtService.getDistrict(mfscdsloanVO.getCdssecdistrictId());
				mfscdsloanObj.setCdssecdistrictObj(cdssecdistrictObj);
				Taluk cdssectalukObj = talukService.getTaluk(mfscdsloanVO.getCdssectalukId());
				mfscdsloanObj.setCdssectalukObj(cdssectalukObj);
				mfscdsloanObj.setCdsseclocationtypeId(mfscdsloanVO.getCdsseclocationtypeId());
				LocalbodyType cdsseclocalbodytypeObj = localbodytypeService.getLocalbodyType(mfscdsloanVO.getCdsseclocalbodytypeId());
				mfscdsloanObj.setCdsseclocalbodytypeObj(cdsseclocalbodytypeObj);
				LocalBody cdsseclocalbodyObj = localbodyService.getLocalBody(mfscdsloanVO.getCdsseclocalbodyId());
				mfscdsloanObj.setCdsseclocalbodyObj(cdsseclocalbodyObj);
				mfscdsloanObj.setCdssecLocation(mfscdsloanVO.getCdssecLocation());
				Postoffice cdssecpostofficeObj = postofficeService.getPostoffice(mfscdsloanVO.getCdssecpostofficeId());
				mfscdsloanObj.setCdssecpostofficeObj(cdssecpostofficeObj);
				mfscdsloanObj.setCdssecPincode(mfscdsloanVO.getCdssecPincode());
				// mfscdsloanObj.setMeunitsoneyearCount(1);
				mfscdsloanObj.setMeunitsoneyearCount(mfscdsloanVO.getMeunitsoneyearCount());
				mfscdsloanObj.setMeunitsoneyearaboveCount(mfscdsloanVO.getMeunitsoneyearaboveCount());
				mfscdsloanObj.setMeunitstotalCount(mfscdsloanVO.getMeunitstotalCount());
				// mfscdsloanObj.setCdsprojectName("prjnames");
				// mfscdsloanObj.setCdsloanAmount(1000.00);
				mfscdsloanObj.setIsActive(1);
				LoanType loantypeObj = loanTypeService.getLoanType(3);
				mfscdsloanObj.setLoantypeObj(loantypeObj);
				mfscdsloanObj.setCreatedOn(DateFunctions.getZonedServerDate());
				User createdBy = userService.getUser(mfscdsloanVO.getCreatedById());
				mfscdsloanObj.setCreatedBy(createdBy);
				mfscdsloanObj.setUserObj(createdBy);
				mfscdsloanObj.setIsDeleted(0);
				mfscdsloanObj.setCdsapplicationStatus(1);
				
				Integer MFSCDSLoanId = mfscdsloanService.createMFSCDSLoan(mfscdsloanObj);
				if (!MFSCDSLoanId.equals(-1)) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("MFSCDSLoanId", MFSCDSLoanId);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
					retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
			}

		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSLoanController::createMFSCDSLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 *  //@param TermLoan TermLoan
	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsloan", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateMFSCDSLoan(@RequestBody MFSCDSLoanVO mfscdsloanVO) {
		log.info("In MFSCDSLoanController::updateMFSCDSLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (mfscdsloanVO != null) {
				if (checkValidVO(mfscdsloanVO)) {
					MFSCDSLoan chkMFSCDSLoan = mfscdsloanService.getMFSCDSLoan(mfscdsloanVO.getMfscdsLoanId());
					if (chkMFSCDSLoan != null) {
						chkMFSCDSLoan.setCdsName(mfscdsloanVO.getCdsName());
				LoanCategory loanCategoryObj = loanCategoryService.getLoanCategory(mfscdsloanVO.getLoancategoryId());
				chkMFSCDSLoan.setLoanCategoryObj(loanCategoryObj);
				chkMFSCDSLoan.setCdshouseName(mfscdsloanVO.getCdshouseName());
				chkMFSCDSLoan.setCdshouseNo(mfscdsloanVO.getCdshouseNo());
				District districtObj = districtService.getDistrict(mfscdsloanVO.getCdsdistrictId());
				chkMFSCDSLoan.setCdsdistrictObj(districtObj);
				Taluk talukObj = talukService.getTaluk(mfscdsloanVO.getCdstalukId());
				chkMFSCDSLoan.setCdstalukObj(talukObj);
				chkMFSCDSLoan.setCdslocationtypeId(mfscdsloanVO.getCdslocationtypeId());
				LocalbodyType localbodytypeObj = localbodytypeService.getLocalbodyType(mfscdsloanVO.getCdslocalbodytypeId());
				chkMFSCDSLoan.setCdslocalbodytypeObj(localbodytypeObj);
				LocalBody localbodyObj = localbodyService.getLocalBody(mfscdsloanVO.getCdslocalbodyId());
				chkMFSCDSLoan.setCdslocalbodyObj(localbodyObj);
				chkMFSCDSLoan.setCdsLocation(mfscdsloanVO.getCdsLocation());
				Postoffice postofficeObj = postofficeService.getPostoffice(mfscdsloanVO.getCdspostofficeId());
				chkMFSCDSLoan.setCdspostofficeObj(postofficeObj);
				chkMFSCDSLoan.setCdsPincode(mfscdsloanVO.getCdsPincode());
				chkMFSCDSLoan.setCdsemailId(mfscdsloanVO.getCdsemailId());
				chkMFSCDSLoan.setCdspanNo(mfscdsloanVO.getCdspanNo());
				chkMFSCDSLoan.setCdsregNo(mfscdsloanVO.getCdsregNo());
				chkMFSCDSLoan.setCdsregYear(mfscdsloanVO.getCdsregYear());
				chkMFSCDSLoan.setCdscpName(mfscdsloanVO.getCdscpName());
				chkMFSCDSLoan.setCdscpPhoneNo(mfscdsloanVO.getCdscpPhoneNo());
				chkMFSCDSLoan.setCdssecName(mfscdsloanVO.getCdscpName());
				chkMFSCDSLoan.setCdssecPhoneNo(mfscdsloanVO.getCdssecPhoneNo());
				chkMFSCDSLoan.setCdscpAadharNo(mfscdsloanVO.getCdscpAadharNo());
				chkMFSCDSLoan.setCdssecAadharNo(mfscdsloanVO.getCdssecAadharNo());
				chkMFSCDSLoan.setCdscphouseName(mfscdsloanVO.getCdscphouseName());
				chkMFSCDSLoan.setCdscphouseNo(mfscdsloanVO.getCdscphouseNo());
				District cdscpdistrictObj = districtService.getDistrict(mfscdsloanVO.getCdscpdistrictId());
				chkMFSCDSLoan.setCdscpdistrictObj(cdscpdistrictObj);
				Taluk cdscptalukObj = talukService.getTaluk(mfscdsloanVO.getCdscptalukId());
				chkMFSCDSLoan.setCdscptalukObj(cdscptalukObj);
				chkMFSCDSLoan.setCdscplocationtypeId(mfscdsloanVO.getCdscplocationtypeId());
				LocalbodyType cdscplocalbodytypeObj = localbodytypeService.getLocalbodyType(mfscdsloanVO.getCdscplocalbodytypeId());
				chkMFSCDSLoan.setCdscplocalbodytypeObj(cdscplocalbodytypeObj);
				LocalBody cdscplocalbodyObj = localbodyService.getLocalBody(mfscdsloanVO.getCdscplocalbodyId());
				chkMFSCDSLoan.setCdscplocalbodyObj(cdscplocalbodyObj);
				chkMFSCDSLoan.setCdscpLocation(mfscdsloanVO.getCdscpLocation());
				Postoffice cdscppostofficeObj = postofficeService.getPostoffice(mfscdsloanVO.getCdscppostofficeId());
				chkMFSCDSLoan.setCdscppostofficeObj(cdscppostofficeObj);
				chkMFSCDSLoan.setCdscpPincode(mfscdsloanVO.getCdscpPincode());
				chkMFSCDSLoan.setCdssechouseName(mfscdsloanVO.getCdssechouseName());
				chkMFSCDSLoan.setCdssechouseNo(mfscdsloanVO.getCdssechouseNo());
				District cdssecdistrictObj = districtService.getDistrict(mfscdsloanVO.getCdssecdistrictId());
				chkMFSCDSLoan.setCdssecdistrictObj(cdssecdistrictObj);
				Taluk cdssectalukObj = talukService.getTaluk(mfscdsloanVO.getCdssectalukId());
				chkMFSCDSLoan.setCdssectalukObj(cdssectalukObj);
				chkMFSCDSLoan.setCdsseclocationtypeId(mfscdsloanVO.getCdsseclocationtypeId());
				LocalbodyType cdsseclocalbodytypeObj = localbodytypeService.getLocalbodyType(mfscdsloanVO.getCdsseclocalbodytypeId());
				chkMFSCDSLoan.setCdsseclocalbodytypeObj(cdsseclocalbodytypeObj);
				LocalBody cdsseclocalbodyObj = localbodyService.getLocalBody(mfscdsloanVO.getCdsseclocalbodyId());
				chkMFSCDSLoan.setCdsseclocalbodyObj(cdsseclocalbodyObj);
				chkMFSCDSLoan.setCdssecLocation(mfscdsloanVO.getCdssecLocation());
				Postoffice cdssecpostofficeObj = postofficeService.getPostoffice(mfscdsloanVO.getCdssecpostofficeId());
				chkMFSCDSLoan.setCdssecpostofficeObj(cdssecpostofficeObj);
				chkMFSCDSLoan.setCdssecPincode(mfscdsloanVO.getCdssecPincode());
				chkMFSCDSLoan.setMeunitsoneyearCount(mfscdsloanVO.getMeunitsoneyearCount());
				chkMFSCDSLoan.setMeunitsoneyearaboveCount(mfscdsloanVO.getMeunitsoneyearaboveCount());
				chkMFSCDSLoan.setMeunitstotalCount(mfscdsloanVO.getMeunitstotalCount());
				// chkMFSCDSLoan.setMeunitsoneyearCount(mfscdsloanVO.getMeunitsoneyearCount());
				LoanType loantypeObj = loanTypeService.getLoanType(3);
				chkMFSCDSLoan.setLoantypeObj(loantypeObj);
				User modifiedBy = userService.getUser(mfscdsloanVO.getModifiedById());
				chkMFSCDSLoan.setModifiedBy(modifiedBy);

				Integer MFSCDSLoanId = mfscdsloanService.updateMFSCDSLoan(chkMFSCDSLoan);
				if (!MFSCDSLoanId.equals(-1)) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("MFSCDSLoanId:", MFSCDSLoanId);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
					retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
				}
						

				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSLoanController::updateMFSCDSLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	/**
	 * //@param TermLoan TermLoan
	 * @return Map
	 */
	@RequestMapping(value = "/updateSecondTabMFSCDSLoan", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateSecondTabMFSCDSLoan(@RequestBody MFSCDSLoanVO mfscdsloanVO) {
		log.info("In MFSCDSLoanController::updateSecondTabMFSCDSLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (mfscdsloanVO != null) { 
				if (checkValidVO(mfscdsloanVO)) {
					MFSCDSLoan chkMFSCDSLoan = mfscdsloanService.getMFSCDSLoan(mfscdsloanVO.getMfscdsLoanId());
					if (chkMFSCDSLoan != null) {
						//for program pop up
						Set<MFSCDSProgram> programs = new HashSet<MFSCDSProgram>();
						String programsStr = mfscdsloanVO.getPrograms();
						if (programsStr != null && programsStr != "") {
							JSONArray jsonArray = new JSONArray(programsStr);
							for (int i = 0; i < jsonArray.length(); i++) {
								JSONObject jsonObject = jsonArray.getJSONObject(i);
								String programName = jsonObject.getString("prgm_name");
								String programinstName = jsonObject.getString("prgm_instname");
								Double programamountReceived = jsonObject.getDouble("prgm_amountreceived");
								String programYear = jsonObject.getString("prgm_year");
								String programBenefits = jsonObject.getString("prgm_benefits");
								
								MFSCDSProgram program = new MFSCDSProgram();
								program.setProgramName(programName);
								program.setPrograminstName(programinstName);
								program.setProgramYear(programYear);
								program.setProgramamountReceived(programamountReceived);
								program.setProgramBenefits(programBenefits);
								
								programs.add(program);
							}
							chkMFSCDSLoan.setPrograms(programs);
						}
						//for program pop up
						//for experience pop up
						Set<MFSCDSExperience> experiences = new HashSet<MFSCDSExperience>();
						String experiencesStr = mfscdsloanVO.getExperiences();
						if (experiencesStr != null && experiencesStr != "") {
							JSONArray jsonArray = new JSONArray(experiencesStr);
							for (int i = 0; i < jsonArray.length(); i++) {
								JSONObject jsonObject = jsonArray.getJSONObject(i);
								String experienceYear = jsonObject.getString("exp_year");
								Integer experienceNoofgroups = jsonObject.getInt("exp_numberofgroups");
								Double experienceamountReceived = jsonObject.getDouble("exp_totalamountreceived");
								String experienceProjectdone = jsonObject.getString("exp_projectdone");
								Double experiencePendingamount = jsonObject.getDouble("exp_pendingamount");
								
								MFSCDSExperience experience = new MFSCDSExperience();
								experience.setExperienceYear(experienceYear);
								experience.setExperienceNoofgroups(experienceNoofgroups);
								experience.setExperienceamountReceived(experienceamountReceived);
								experience.setExperienceProjectdone(experienceProjectdone);
								experience.setExperiencePendingamount(experiencePendingamount);
								
								experiences.add(experience);
							}
							chkMFSCDSLoan.setExperiences(experiences);
						}

						//for experience pop up

						//for balancesheet pop up
						Set<MFSCDSBalancesheet> balancesheets = new HashSet<MFSCDSBalancesheet>();
						String balancesheetsStr = mfscdsloanVO.getBalancesheets();
						if (balancesheetsStr != null && balancesheetsStr != "") {
							JSONArray jsonArray = new JSONArray(balancesheetsStr);
							for (int i = 0; i < jsonArray.length(); i++) {
								JSONObject jsonObject = jsonArray.getJSONObject(i);
								String balancesheetYear = jsonObject.getString("bal_finyear");
								Double balancesheetAmount = jsonObject.getDouble("bal_amount");
								
								MFSCDSBalancesheet balancesheet = new MFSCDSBalancesheet();
								balancesheet.setBalancesheetYear(balancesheetYear);
								balancesheet.setBalancesheetAmount(balancesheetAmount);
								balancesheets.add(balancesheet);
							}
							chkMFSCDSLoan.setBalancesheets(balancesheets);
						}

						//for balancesheet pop up

						chkMFSCDSLoan.setCdsprojectName(mfscdsloanVO.getCdsprojectName());
						chkMFSCDSLoan.setCdsloanAmount(mfscdsloanVO.getCdsloanAmount());

						Integer MFSCDSLoanId = mfscdsloanService.updateMFSCDSLoan(chkMFSCDSLoan);
						if (!MFSCDSLoanId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("MFSCDSLoanId:", MFSCDSLoanId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
						

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSLoanController::updateSecondTabMFSCDSLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	
	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsloan/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteMFSCDSLoan(@PathVariable Integer id) {
		log.info("In MFSCDSLoanController::deleteMFSCDSLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				MFSCDSLoan MFSCDSLoan = mfscdsloanService.getMFSCDSLoan(id);
				if (MFSCDSLoan != null) {
					
					Integer MFSCDSLoanId = mfscdsloanService.deleteMFSCDSLoan(id);
					if (!MFSCDSLoanId.equals(-1)) {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
						retMap.put("MFSCDSLoanId", MFSCDSLoanId);
						return retMap;
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
						retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
					}
					// }
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSLoanController::deleteMFSCDSLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsloan/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneMFSCDSLoan(@PathVariable Integer id) {
		log.info("In MFSCDSLoanController::getOneMFSCDSLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				MFSCDSLoan MFSCDSLoan = mfscdsloanService.getMFSCDSLoan(id);
				if (MFSCDSLoan != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("MFSCDSLoan", MFSCDSLoan);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSLoanController::getOneMFSCDSLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer userId
	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsloan-by-user/{userId}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneMFSCDSLoanByUser(@PathVariable Integer userId) {
		log.info("In MFSCDSLoanController::getOneMFSCDSLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (userId != null) {
				MFSCDSLoanVO MFSCDSLoanVo = mfscdsloanService.getMFSCDSLoanByUser(userId);
				if (MFSCDSLoanVo != null) {
					MFSCDSLoan mfscdsLoan = mfscdsloanService.getMFSCDSLoan(MFSCDSLoanVo.getMfscdsLoanId());
					Set<MFSCDSProgram> ProgramVOs = mfscdsLoan.getPrograms();
					Set<MFSCDSExperience> ExperienceVOs = mfscdsLoan.getExperiences();
					Set<MFSCDSBalancesheet> BalancesheetVOs = mfscdsLoan.getBalancesheets();
					MFSCDSLoanVo.setProgramLst(ProgramVOs);
					MFSCDSLoanVo.setExperienceLst(ExperienceVOs);
					MFSCDSLoanVo.setBalancesheetLst(BalancesheetVOs);
					// Set<TLFamilyMember> familyMemberVOs = termLoan.getFamilyMembers();
					// Set<TLFamilyProperty> familyPropertyVOs = termLoan.getFamilyPropertys();
					// TermLoanVo.setFamilyMemberLst(familyMemberVOs);
					// TermLoanVo.setFamilyPropertyLst(familyPropertyVOs);
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("MFSCDSLoan", MFSCDSLoanVo);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSLoanController::getOneMFSCDSLoanByUser======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}



	/**

	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsloan-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getMFSCDSLoanList() {
		log.info("In MFSCDSLoanController::getMFSCDSLoanList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {

			List<MFSCDSLoanVO> MFSCDSLoanListReturnVO = mfscdsloanService.getMFSCDSLoanList();
			if (MFSCDSLoanListReturnVO != null && MFSCDSLoanListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("mfscdsloans", MFSCDSLoanListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSLoanController::getMFSCDSLoanList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**

	 * @param MFSCDSLoanId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer MFSCDSLoanId) {
		return (mfscdsloanService.getMFSCDSLoan(MFSCDSLoanId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}

	/**

	 * @purpose For checking if mandatory data is passed
	 * @param MFSCDSLoan
	 * @return Boolean
	 */
	private Boolean checkValidVO(MFSCDSLoanVO MFSCDSLoanVO) {
		Boolean isValid = true;
		invalidMsg = "";
		if (MFSCDSLoanVO != null) {
			
		} else {
			invalidMsg = "Received data is not valid for MFSCDSLoan!";
			isValid = false;
		}
		return isValid;
	}

	// --for preview
	@RequestMapping(value = "/previewmfscdsloan/{mfscdsLoanId}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOnePreviewMFSCDSLoan(@PathVariable Integer mfscdsLoanId) {
		log.info("In MFSCDSLoanController::getOnePreviewMFSCDSLoan=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			MFSCDSLoanVO PreviewMFSCDSLoanReturnVO = mfscdsloanService.getPreviewMFSCDSLoan(mfscdsLoanId);
			if (PreviewMFSCDSLoanReturnVO != null) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("mfscdsloan", PreviewMFSCDSLoanReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSLoanController::getOnePreviewMFSCDSLoan======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// --for preview



// --modal view

@PostMapping("/mfscdsUpload")
public ResponseEntity<ResponseMessageVO> uploadmfscdsFile(@RequestParam("file") MultipartFile file,
		@RequestParam("docType") String docType, @RequestParam("docChecklistId") Integer docChecklistMFSCDSId,
		@RequestParam("loanTypeId") Integer loanTypeId, @RequestParam("mfscdsLoanId") Integer mfscdsLoanId) {
	String message = "";
	String fileName = "";
	try {
		if (docType.equals("MFSCDSCHK")) {
			String savedFileName = storageService.save(file, 2,
					loanTypeId + "_" + mfscdsLoanId + "_" + docChecklistMFSCDSId);
			if (savedFileName != null && !savedFileName.equals("")) {
				DocumentChecklistMFSCDSBeneficiary checklistMFSCDSBeneficiary = new DocumentChecklistMFSCDSBeneficiary();
				LoanType loanTypeObj = loanTypeService.getLoanType(loanTypeId);
				MFSCDSLoan mfscdsLoanObj = mfscdsloanService.getMFSCDSLoan(mfscdsLoanId);
				DocumentChecklistMFSCDS documentChecklistMFSCDS = documentChecklistMFSCDSService.getDocumentChecklistMFSCDS(docChecklistMFSCDSId);
				checklistMFSCDSBeneficiary.setLoanTypeObj(loanTypeObj);
				checklistMFSCDSBeneficiary.setMfscdsLoanObj(mfscdsLoanObj);
				checklistMFSCDSBeneficiary.setDocumentchecklistmfscdsObj(documentChecklistMFSCDS);
				checklistMFSCDSBeneficiary.setFilePath(savedFileName);
				documentChecklistMFSCDSBeneficiaryService.createDocumentChecklistMFSCDSBeneficiary(checklistMFSCDSBeneficiary);
			} else {
				return ResponseEntity.status(HttpStatus.NOT_MODIFIED)
						.body(new ResponseMessageVO("Could not upload document!", fileName));
			}
		} else {
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE)
					.body(new ResponseMessageVO("Loan type not got!", fileName));
		}
		message = "Uploaded the file successfully: " + file.getOriginalFilename();
		fileName = file.getOriginalFilename();
		return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessageVO(message, fileName));
	} catch (Exception e) {
		e.printStackTrace();
		message = "Could not upload the file: " + file.getOriginalFilename() + "! " + e.getMessage();
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessageVO(message, fileName));
	}
}

@GetMapping("/mfscdsChkDocs/{mfscdsLoanId}")
	public ResponseEntity<List<FileInfoMFSCDS>> getMFSCDSLoanChecklistDocs(@PathVariable Integer mfscdsLoanId) {
		// Map<String,String> docInfo = new HashMap<String,String>();
		List<FileInfoMFSCDS> docs = new ArrayList<FileInfoMFSCDS>();
		List<DocumentChecklistMFSCDSBeneficiaryVO> checklistMFSCDSDBeneficiaries = documentChecklistMFSCDSBeneficiaryService
				.getDocumentChecklistMFSCDSBeneficiaryByMFSCDSLoanId(mfscdsLoanId);
			if (checklistMFSCDSDBeneficiaries != null && checklistMFSCDSDBeneficiaries.size() > 0) {
			for (DocumentChecklistMFSCDSBeneficiaryVO documentChecklistMFSCDSBeneficiaryVo : checklistMFSCDSDBeneficiaries) {
				Integer docChkBenId = documentChecklistMFSCDSBeneficiaryVo.getDocChecklistMFSCDSBeneficiaryId();
				String name = documentChecklistMFSCDSBeneficiaryVo.getDocumentChecklistMFSCDSName();
				String url = MvcUriComponentsBuilder
						.fromMethodName(MFSCDSLoanController.class, "getDoc",
								documentChecklistMFSCDSBeneficiaryVo.getDocChecklistMFSCDSBeneficiaryId())
						.build()
						.toString();
						FileInfoMFSCDS docInfo = new FileInfoMFSCDS(docChkBenId, name, url);
				docs.add(docInfo);
			}
		} else {
			return ResponseEntity.status(HttpStatus.OK).body(docs);
		}
		// List<FileInfo> fileInfos = storageService.loadAll().map(path -> {
		// String filename = path.getFileName().toString();
		// String url = MvcUriComponentsBuilder
		// .fromMethodName(TermLoanController.class, "getFile",
		// path.getFileName().toString()).build()
		// .toString();
		// return new FileInfo(filename, url);
		// }).collect(Collectors.toList());
		 return ResponseEntity.status(HttpStatus.OK).body(docs);
	}

	@GetMapping("/getMFSCDSDoc/{docId}")
	@ResponseBody
	public ResponseEntity<Resource> getDoc(@PathVariable Integer docId) {
		DocumentChecklistMFSCDSBeneficiaryVO documentChecklistMFSCDSBeneficiary = documentChecklistMFSCDSBeneficiaryService
				.getDocumentChecklistMFSCDSBeneficiaryVO(docId);
		if (documentChecklistMFSCDSBeneficiary != null) {
			String fileName = documentChecklistMFSCDSBeneficiary.getFilePath();
			Resource file = storageService.loadmfscds(fileName,
					documentChecklistMFSCDSBeneficiary.getLoanTypeId());
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
					.body(file);
		} else {
			return ResponseEntity.notFound().build();
		}
	}
	

}
