package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.SuretyType;
import com.kswdc.loanmanagementsystem.api.value.SuretyTypeVO;

@Repository
public interface SuretyTypeRepository extends JpaRepository<SuretyType, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.SuretyTypeVO(s.suretytypeId,s.suretytypeName,"+
      "s.createdOn,u.fullName,s.modifiedOn,mu.fullName,s.isDeleted,s.deletedOn, s.isActive) " +
           " FROM SuretyType s LEFT JOIN User u ON s.createdBy=u.userId LEFT JOIN User mu ON s.modifiedBy=mu.userId "+
            " WHERE s.isDeleted=0 ORDER BY s.suretytypeName ASC")
   List<SuretyTypeVO> getSuretyTypeList();//Filter only active loanTypes

   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.SuretyTypeVO(s.suretytypeId,s.suretytypeName,"+
      "s.createdOn,u.fullName,s.modifiedOn,mu.fullName,s.isDeleted,s.deletedOn, s.isActive) " +
           " FROM SuretyType s LEFT JOIN User u ON s.createdBy=u.userId LEFT JOIN User mu ON s.modifiedBy=mu.userId "+
            " WHERE s.isDeleted=0 ORDER BY s.suretytypeName ASC")
   List<SuretyTypeVO> getSuretyTypeListByLoanType(@Param("loantypeId") Integer loantypeId);         
    
    @Query("SELECT a from SuretyType a WHERE a.id=:suretytypeId")
    SuretyType getSuretyTypeById(@Param("suretytypeId") Integer suretytypeId);

    @Query("SELECT cl FROM SuretyType cl WHERE cl.suretytypeName=:suretytypeName")
    SuretyType findBySuretyTypeName(@Param("suretytypeName") String suretytypeName);
}
