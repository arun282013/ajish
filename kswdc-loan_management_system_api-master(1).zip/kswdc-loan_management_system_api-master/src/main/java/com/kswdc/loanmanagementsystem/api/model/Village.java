package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_village")
@EqualsAndHashCode()
public class Village{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "VILLAGE_ID")
    private Integer villageId;

    @Column(name = "VILLAGE_NAME", columnDefinition = "varchar(100) not null")
    private String villageName;

    @ManyToOne()
    @JoinColumn(name= "DISTRICT_ID",columnDefinition = "tinyint(1) not null default 0")
    private District districtObj;

    @ManyToOne()
    @JoinColumn(name= "TALUK_ID",columnDefinition = "tinyint(1) not null default 0")
    private Taluk talukObj;

    @Column(name = "CREATED_ON")
    private ZonedDateTime createdOn;

    @ManyToOne()
    @JoinColumn(name= "CREATED_BY")
    private User createdBy;
    
    @Column(name = "MODIFIED_ON",nullable = true)
    private ZonedDateTime modifiedOn;

    @ManyToOne()
    @JoinColumn(name= "MODIFIED_BY",nullable = true)
    private User modifiedBy;
    
    @Column(name = "IS_DELETED",columnDefinition = "tinyint(1) not null default 0")
    private Integer isDeleted;
    
    @Column(name = "DELETED_ON",nullable = true)
    private ZonedDateTime deletedOn;
    
    @Column(name = "IS_ACTIVE",columnDefinition = "tinyint(1) not null default 0")
    private Integer isActive;
}
