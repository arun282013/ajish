package com.kswdc.loanmanagementsystem.api.model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

@Data
@Entity
@Table(name = "tbl_mfs_cds_loan")
@EqualsAndHashCode()
public class MFSCDSLoan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MFS_CDS_LOAN_ID")
    private Integer mfscdsLoanId;

    @ManyToOne()
    @JoinColumn(name = "USER_ID", nullable = true)
    private User userObj;

    @ManyToOne()
    @JoinColumn(name = "LOANCATEGORY_ID", nullable = true)
    private LoanCategory loanCategoryObj;

    @ManyToOne()
    @JoinColumn(name = "LOANTYPE_ID", nullable = true)
    private LoanType loantypeObj;

    @Column(name = "CDS_NAME", columnDefinition = "varchar(100) not null")
    private String cdsName;

    @Column(name = "CDS_HOUSENAME", columnDefinition = "varchar(100) not null")
    private String cdshouseName;

    @Column(name = "CDS_HOUSENO", columnDefinition = "varchar(50) not null")
    private String cdshouseNo;

    @ManyToOne()
    @JoinColumn(name = "CDS_DISTRICT_ID", nullable = true)
    private District cdsdistrictObj;

    @ManyToOne()
    @JoinColumn(name = "CDS_TALUK_ID", nullable = true)
    private Taluk cdstalukObj;

    @Column(name = "CDS_LOCATIONTYPEID", nullable = true)
    private Integer cdslocationtypeId;

    @ManyToOne()
    @JoinColumn(name = "CDS_LOCALBODYTYPE_ID", nullable = true)
    private LocalbodyType cdslocalbodytypeObj;

    @ManyToOne()
    @JoinColumn(name = "CDS_LOCALBODY_ID", nullable = true)
    private LocalBody cdslocalbodyObj;

    @Column(name = "CDS_LOCATION", columnDefinition = "varchar(100) not null")
    private String cdsLocation;

    @ManyToOne()
    @JoinColumn(name = "CDS_POSTOFFICE_ID", nullable = true)
    private Postoffice cdspostofficeObj;

    @Column(name = "CDS_PINCODE", columnDefinition = "int(11) not null")
    private Integer cdsPincode;

    @Column(name = "CDS_EMAILID", columnDefinition = "varchar(100) not null")
    private String cdsemailId;

    @Column(name = "CDS_PANNUMBER", columnDefinition = "varchar(100) not null")
    private String cdspanNo;

    @Column(name = "CDS_REGNO", columnDefinition = "varchar(50) not null")
    private String cdsregNo;

    @Column(name = "CDS_REGYEAR", columnDefinition = "int(11) not null")
    private Integer cdsregYear;

    @Column(name = "CDS_CP_NAME", columnDefinition = "varchar(100) not null")
    private String cdscpName;

    @Column(name = "CDS_CP_PHONENO", columnDefinition = "varchar(50) not null")
    private String cdscpPhoneNo;

    @Column(name = "CDS_SEC_NAME", columnDefinition = "varchar(100) not null")
    private String cdssecName;

    @Column(name = "CDS_SEC_PHONENO", columnDefinition = "varchar(50) not null")
    private String cdssecPhoneNo;

    @Column(name = "CDS_CP_AADHARNO", columnDefinition = "varchar(50) not null")
    private String cdscpAadharNo;

    @Column(name = "CDS_SEC_AADHARNO", columnDefinition = "varchar(50) not null")
    private String cdssecAadharNo;

    @Column(name = "CDS_CP_HOUSENAME", columnDefinition = "varchar(100) not null")
    private String cdscphouseName;

    @Column(name = "CDS_CP_HOUSENO", columnDefinition = "varchar(50) not null")
    private String cdscphouseNo;

    @ManyToOne()
    @JoinColumn(name = "CDS_CP_DISTRICT_ID", nullable = true)
    private District cdscpdistrictObj;

    @ManyToOne()
    @JoinColumn(name = "CDS_CP_TALUK_ID", nullable = true)
    private Taluk cdscptalukObj;

    @Column(name = "CDS_CP_LOCATIONTYPEID", nullable = true)
    private Integer cdscplocationtypeId;

    @ManyToOne()
    @JoinColumn(name = "CDS_CP_LOCALBODYTYPE_ID", nullable = true)
    private LocalbodyType cdscplocalbodytypeObj;

    @ManyToOne()
    @JoinColumn(name = "CDS_CP_LOCALBODY_ID", nullable = true)
    private LocalBody cdscplocalbodyObj;

    @Column(name = "CDS_CP_LOCATION", columnDefinition = "varchar(100) ", nullable = true)
    private String cdscpLocation;

    @ManyToOne()
    @JoinColumn(name = "CDS_CP_POSTOFFICE_ID", nullable = true)
    private Postoffice cdscppostofficeObj;

    @Column(name = "CDS_CP_PINCODE", columnDefinition = "int(11) not null")
    private Integer cdscpPincode;

    @Column(name = "CDS_SEC_HOUSENAME", columnDefinition = "varchar(100) not null")
    private String cdssechouseName;

    @Column(name = "CDS_SEC_HOUSENO", columnDefinition = "varchar(50) not null")
    private String cdssechouseNo;

    @ManyToOne()
    @JoinColumn(name = "CDS_SEC_DISTRICT_ID", nullable = true)
    private District cdssecdistrictObj;

    @ManyToOne()
    @JoinColumn(name = "CDS_SEC_TALUK_ID", nullable = true)
    private Taluk cdssectalukObj;

    @Column(name = "CDS_SEC_LOCATIONTYPEID", nullable = true)
    private Integer cdsseclocationtypeId;

    @ManyToOne()
    @JoinColumn(name = "CDS_SEC_LOCALBODYTYPE_ID", nullable = true)
    private LocalbodyType cdsseclocalbodytypeObj;

    @ManyToOne()
    @JoinColumn(name = "CDS_SEC_LOCALBODY_ID", nullable = true)
    private LocalBody cdsseclocalbodyObj;

    @Column(name = "CDS_SEC_LOCATION", columnDefinition = "varchar(100) ", nullable = true)
    private String cdssecLocation;

    @ManyToOne()
    @JoinColumn(name = "CDS_SEC_POSTOFFICE_ID", nullable = true)
    private Postoffice cdssecpostofficeObj;

    @Column(name = "CDS_SEC_PINCODE", columnDefinition = "int(11) not null")
    private Integer cdssecPincode;

    @Column(name = "MEUNITS_ONEYEAR_COUNT", columnDefinition = "int(11)", nullable = true)
    private Integer meunitsoneyearCount;

    @Column(name = "MEUNITS_ONEYEARABOVE_COUNT", columnDefinition = "int(11)", nullable = true)
    private Integer meunitsoneyearaboveCount;

    @Column(name = "MEUNITS_TOTAL_COUNT", columnDefinition = "int(11)", nullable = true)
    private Integer meunitstotalCount;

    @Column(name = "CDS_PROJECT_NAME", columnDefinition = "varchar(200) ", nullable = true)
    private String cdsprojectName;

    @Column(name = "CDS_LOAN_AMOUNT", columnDefinition = "double ", nullable = true)
    private Double cdsloanAmount;

    @Column(name = "CDS_APPLICATION_STATUS", columnDefinition = "tinyint(1) not null default 0")
    private Integer cdsapplicationStatus;

    @Column(name = "ENTERED_ON", nullable = true)
    private ZonedDateTime enteredOn;

    @OneToMany(cascade = { CascadeType.ALL })
    @JoinColumn(name = "MFS_CDS_LOAN_ID")
    private Set<MFSCDSProgram> programs = new HashSet<>(0);

    @OneToMany(cascade = { CascadeType.ALL })
    @JoinColumn(name = "MFS_CDS_LOAN_ID")
    private Set<MFSCDSExperience> experiences = new HashSet<>(0);

    @OneToMany(cascade = { CascadeType.ALL })
    @JoinColumn(name = "MFS_CDS_LOAN_ID")
    private Set<MFSCDSBalancesheet> balancesheets = new HashSet<>(0);

    @Column(name = "CREATED_ON")
    private ZonedDateTime createdOn;

    @ManyToOne()
    @JoinColumn(name = "CREATED_BY")
    private User createdBy;

    @Column(name = "MODIFIED_ON", nullable = true)
    private ZonedDateTime modifiedOn;

    @ManyToOne()
    @JoinColumn(name = "MODIFIED_BY", nullable = true)
    private User modifiedBy;

    @Column(name = "IS_DELETED", columnDefinition = "tinyint(1) not null default 0")
    private Integer isDeleted;

    @Column(name = "DELETED_ON", nullable = true)
    private ZonedDateTime deletedOn;

    @Column(name = "IS_ACTIVE", columnDefinition = "tinyint(1) not null default 0")
    private Integer isActive;

   
}
