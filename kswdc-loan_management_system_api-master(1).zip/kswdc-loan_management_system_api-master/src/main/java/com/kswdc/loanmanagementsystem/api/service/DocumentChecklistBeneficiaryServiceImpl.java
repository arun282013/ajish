package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistBeneficiary;
import com.kswdc.loanmanagementsystem.api.repository.DocumentChecklistBeneficiaryRepository;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistBeneficiaryVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

@Service
public class DocumentChecklistBeneficiaryServiceImpl implements DocumentChecklistBeneficiaryService {
	private final Logger log = LoggerFactory.getLogger(DocumentChecklistBeneficiaryServiceImpl.class);

	@Autowired
	private DocumentChecklistBeneficiaryRepository documentChecklistBeneficiaryRepository;

	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createDocumentChecklistBeneficiary(DocumentChecklistBeneficiary DocumentChecklistBeneficiary) {
		try {
			DocumentChecklistBeneficiary savedDocumentChecklistBeneficiary = documentChecklistBeneficiaryRepository
					.save(DocumentChecklistBeneficiary);
			return savedDocumentChecklistBeneficiary.getDocChecklistBeneficiaryId() != null
					? savedDocumentChecklistBeneficiary.getDocChecklistBeneficiaryId()
					: -1;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistBeneficiaryServiceImpl::createDocumentChecklistBeneficiary======"
					+ e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateDocumentChecklistBeneficiary(DocumentChecklistBeneficiary DocumentChecklistBeneficiary) {
		try {
			DocumentChecklistBeneficiary updateDocumentChecklistBeneficiary = documentChecklistBeneficiaryRepository
					.save(DocumentChecklistBeneficiary);
			return updateDocumentChecklistBeneficiary.getDocChecklistBeneficiaryId() != null
					? updateDocumentChecklistBeneficiary.getDocChecklistBeneficiaryId()
					: -1;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistBeneficiaryServiceImpl::updateDocumentChecklistBeneficiary======"
					+ e.getMessage());
		}
		return null;
	}

	@Override
	public DocumentChecklistBeneficiary getDocumentChecklistBeneficiary(Integer id) {
		try {
			DocumentChecklistBeneficiary documentChecklistBeneficiary = documentChecklistBeneficiaryRepository
					.getDocumentChecklistBeneficiaryById(id);
			return documentChecklistBeneficiary;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistBeneficiaryServiceImpl::getDocumentChecklistBeneficiary======"
					+ e.getMessage());
		}
		return null;
	}

	@Override
	public DocumentChecklistBeneficiaryVO getDocumentChecklistBeneficiaryVO(Integer id) {
		try {
			DocumentChecklistBeneficiaryVO documentChecklistBeneficiary = documentChecklistBeneficiaryRepository
					.getDocumentChecklistBeneficiaryVOById(id);
			return documentChecklistBeneficiary;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistBeneficiaryServiceImpl::getDocumentChecklistBeneficiaryVO======"
					+ e.getMessage());
		}
		return null;
	}

	@Override
	public List<DocumentChecklistBeneficiaryVO> getDocumentChecklistBeneficiaryByTermLoanId(Integer termLoanId) {
		try {
			List<DocumentChecklistBeneficiaryVO> documentChecklistBeneficiaries = documentChecklistBeneficiaryRepository
					.getDocumentChecklistBeneficiaryByTermLoanId(termLoanId);
			return documentChecklistBeneficiaries;
		} catch (Exception e) {
			log.error(
					"Exception in DocumentChecklistBeneficiaryServiceImpl::getDocumentChecklistBeneficiaryByTermLoanId======"
							+ e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteDocumentChecklistBeneficiary(Integer id) {
		try {
			DocumentChecklistBeneficiary DocumentChecklistBeneficiary = getDocumentChecklistBeneficiary(id);
			// LoanType.setActive(Boolean.FALSE);
			// LoanDocumentChecklist.setDeletedOn(DateFunctions.getZonedServerDate());
			// LoanDocumentChecklist.setIsDeleted(Constants.IS_DELETED);
			DocumentChecklistBeneficiary updatedDocumentChecklistBeneficiary = documentChecklistBeneficiaryRepository
					.save(DocumentChecklistBeneficiary);
			return updatedDocumentChecklistBeneficiary.getDocChecklistBeneficiaryId() != null
					? updatedDocumentChecklistBeneficiary.getDocChecklistBeneficiaryId()
					: -1;
		} catch (Exception e) {
			log.error("Exception in LDocumentChecklistBeneficiaryServiceImpl::deleteDocumentChecklistBeneficiary======"
					+ e.getMessage());
		}
		return null;
	}

	@Override
	public List<DocumentChecklistBeneficiaryVO> getDocumentChecklistBeneficiaryList() {
		try {
			List<DocumentChecklistBeneficiaryVO> documentChecklistBeneficiaryList = documentChecklistBeneficiaryRepository
					.getDocumentChecklistBeneficiaryList();
			return documentChecklistBeneficiaryList;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistBeneficiaryServiceImpl::getDocumentChecklistBeneficiaryList======"
					+ e.getMessage());
		}
		return null;
	}

	// @Override
	// public LoanDocumentChecklist
	// getLoanDocumentChecklistByLoanDocumentChecklistName(String
	// loanDocumentChecklistName) {
	// try {
	// LoanDocumentChecklist loanDocumentChecklist =
	// loanDocumentChecklistRepository.findByLoanDocumentChecklistName(loanDocumentChecklistName);
	// return loanDocumentChecklist;
	// } catch (Exception e) {
	// log.error("Exception in
	// LoanDocumentChecklistServiceImpl::getLoanDocumentChecklistByLoanDocumentChecklistName======"
	// + e.getMessage());
	// }
	// return null;
	// }
}