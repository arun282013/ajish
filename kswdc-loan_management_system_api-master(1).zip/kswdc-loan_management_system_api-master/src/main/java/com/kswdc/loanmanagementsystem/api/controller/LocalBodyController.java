package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.LocalBody;
import com.kswdc.loanmanagementsystem.api.service.LocalBodyService;
import com.kswdc.loanmanagementsystem.api.value.LocalBodyVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class LocalBodyController {

	private final Logger log = LoggerFactory.getLogger(LocalBodyController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private LocalBodyService localBodyService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param LocalBody LocalBody
	 * @return Map
	 */
	@RequestMapping(value = "/localBody", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createLocalBody(@RequestBody LocalBody LocalBody) {
		log.info("In LocalBodyController::createLocalBody=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(LocalBody)) {
//						LocalBody.setActive(Boolean.TRUE);
						LocalBody.setCreatedOn(DateFunctions.getZonedServerDate());
						// LocalBody.setCreatedBy();
						LocalBody.setIsDeleted(0);
						Integer LocalBodyId = localBodyService.createLocalBody(LocalBody);
						if (!LocalBodyId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("LocalBodyId", LocalBodyId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LocalBodyController::createLocalBody======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param LocalBody LocalBody
	 * @return Map
	 */
	@RequestMapping(value = "/localBody", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateLocalBody(@RequestBody LocalBody localBody) {
		log.info("In LocalBodyController::updateLocalBody=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (localBody != null) { // && LocalBody.getId() != null
				if (checkValid(localBody)) {
					LocalBody chkLocalBody = localBodyService.getLocalBody(localBody.getLocalbodyId());
					if (chkLocalBody!=null) {
//						if (chkLocalBody.getActive()) {
//							LocalBody.setActive(Boolean.TRUE);
							chkLocalBody.setLocalbodyName(localBody.getLocalbodyName());							
							chkLocalBody.setIsActive(localBody.getIsActive());							
							Integer LocalBodyId = localBodyService.updateLocalBody(chkLocalBody);
							if (!LocalBodyId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("LocalBodyId:", LocalBodyId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" LocalBody Id is deactivated:"+LocalBody.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LocalBodyController::updateLocalBody======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/localBody/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteLocalBody(@PathVariable Integer id) {
		log.info("In LocalBodyController::deleteLocalBody=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				LocalBody LocalBody = localBodyService.getLocalBody(id);
				if (LocalBody != null) {
//					if (!LocalBody.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " LocalBodyId:" + id);
//					} else {
						Integer LocalBodyId = localBodyService.deleteLocalBody(id);
						if (!LocalBodyId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("LocalBodyId", LocalBodyId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LocalBodyController::deleteLocalBody======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/localBody/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneLocalBody(@PathVariable Integer id) {
		log.info("In LocalBodyController::getOneLocalBody=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				LocalBody LocalBody = localBodyService.getLocalBody(id);
				if (LocalBody != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("LocalBody", LocalBody);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LocalBodyController::getOneLocalBody======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- LocalBody ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/localBody-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getLocalBodyList() {
		log.info("In LocalBodyController::getLocalBodyList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			LocalBodyListReturnVO LocalBodyListReturnVO = new LocalBodyListReturnVO(LocalBodyService.getLocalBodyList());
			List<LocalBodyVO> LocalBodyListReturnVO = localBodyService.getLocalBodyList();
			if (LocalBodyListReturnVO != null && LocalBodyListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("localBodys", LocalBodyListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LocalBodyController::getLocalBodyList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	@RequestMapping(value = "/localBody-list-by-disttype/{districtId}/{localbodyTypeId}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getLocalBodyListByDistrict(@PathVariable Integer districtId,@PathVariable Integer localbodyTypeId) {
		log.info("In LocalBodyController::getLocalBodyListByDistrict=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			LocalBodyListReturnVO LocalBodyListReturnVO = new LocalBodyListReturnVO(LocalBodyService.getLocalBodyList());
			List<LocalBodyVO> LocalBodyListReturnVO = localBodyService.getLocalBodyListByDistrict(districtId,localbodyTypeId);
			if (LocalBodyListReturnVO != null && LocalBodyListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("localBodys", LocalBodyListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LocalBodyController::getLocalBodyListByDistrict======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param LocalBodyId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer LocalBodyId) {
		return (localBodyService.getLocalBody(LocalBodyId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param LocalBody
	 * @return Boolean
	 */
	private Boolean checkValid(LocalBody LocalBody) {
		Boolean isValid = true;
		invalidMsg = "";
		if (LocalBody != null) {
//			if(LocalBody.getId()==null || LocalBody.getId()<=0) {
//				invalidMsg+="LocalBodyId is required and should be valid!";
//				isValid = false;
//			}
			if (LocalBody.getLocalbodyName() == null || LocalBody.getLocalbodyName().equalsIgnoreCase("")) {
				invalidMsg += "LocalBody Name is required and should not be empty!";
				isValid = false;
			}
//			if (LocalBody.getLocalBodyName() == null || LocalBody.getLocalBodyName().equalsIgnoreCase("")) {
//				invalidMsg += "LocalBody Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (LocalBody.getQuotaInMB() == null || LocalBody.getQuotaInMB().equals(0) || LocalBody.getQuotaInMB()<0) {
//				invalidMsg += "LocalBody Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (LocalBody.getChatHistoryDays() == null || LocalBody.getChatHistoryDays().equals(0) || LocalBody.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for LocalBody is required and should be valid!";
//				isValid = false;
//			}
//			if (LocalBody.getCdaTimeoutTime() == null || LocalBody.getCdaTimeoutTime().equals(0) || LocalBody.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for LocalBody!";
			isValid = false;
		}
		return isValid;
	}
	
}
