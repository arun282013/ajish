package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Religion;
import com.kswdc.loanmanagementsystem.api.value.ReligionVO;

@Repository
public interface ReligionRepository extends JpaRepository<Religion, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.ReligionVO(o.religionId,"+
      " o.religionName,o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM Religion o LEFT JOIN User u ON o.createdBy=u.userId LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 ORDER BY o.religionName ASC")
   List<ReligionVO> getReligionList();//Filter only active Religions
    
    @Query("SELECT a from Religion a WHERE a.id=:religionId")
    Religion getReligionById(@Param("religionId") Integer religionId);

    @Query("SELECT cl FROM Religion cl WHERE cl.religionName=:religionName")
    Religion findByReligionName(@Param("religionName") String religionName);
}
