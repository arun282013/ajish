package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistMFSCDSBeneficiary;
import com.kswdc.loanmanagementsystem.api.service.DocumentChecklistMFSCDSBeneficiaryService;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistMFSCDSBeneficiaryVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class DocumentChecklistMFSCDSBeneficiaryController {

	private final Logger log = LoggerFactory.getLogger(DocumentChecklistMFSCDSBeneficiaryController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private DocumentChecklistMFSCDSBeneficiaryService documentChecklistMFSCDSBeneficiaryService;
	

	@RequestMapping(value = "/documentChecklistMFSCDSBeneficiary", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createDocumentChecklistMFSCDSBeneficiary(@RequestBody DocumentChecklistMFSCDSBeneficiary DocumentChecklistMFSCDSBeneficiary) {
		log.info("In DocumentChecklistMFSCDSBeneficiaryController::createDocumentChecklistMFSCDSBeneficiary=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(DocumentChecklistMFSCDSBeneficiary)) {
					//						LoanType.setActive(Boolean.TRUE);
						//LoanDocumentChecklist.setCreatedOn(DateFunctions.getZonedServerDate());
						// LoanType.setCreatedBy();
						//LoanDocumentChecklist.setIsDeleted(0);
						Integer DocumentChecklistMFSCDSBeneficiaryId = documentChecklistMFSCDSBeneficiaryService.createDocumentChecklistMFSCDSBeneficiary(DocumentChecklistMFSCDSBeneficiary);
						if (!DocumentChecklistMFSCDSBeneficiaryId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("DocumentChecklistMFSCDSBeneficiaryId", DocumentChecklistMFSCDSBeneficiaryId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistMFSCDSBeneficiaryController::createDocumentChecklistMFSCDSBeneficiary======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	@RequestMapping(value = "/documentChecklistMFSCDSBeneficiary", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateDocumentChecklistMFSCDSBeneficiary(@RequestBody DocumentChecklistMFSCDSBeneficiary documentChecklistMFSCDSBeneficiary) {
		log.info("In DocumentChecklistMFSCDSBeneficiaryController::updateDocumentChecklistMFSCDSBeneficiary=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (documentChecklistMFSCDSBeneficiary != null) { // && LoanType.getId() != null
				if (checkValid(documentChecklistMFSCDSBeneficiary)) {
					DocumentChecklistMFSCDSBeneficiary chkDocumentChecklistMFSCDSBeneficiary = documentChecklistMFSCDSBeneficiaryService.getDocumentChecklistMFSCDSBeneficiary(documentChecklistMFSCDSBeneficiary.getDocChecklistMFSCDSBeneficiaryId());
					if (chkDocumentChecklistMFSCDSBeneficiary!=null) {
//						if (chkLoanType.getActive()) {
//							LoanType.setActive(Boolean.TRUE);
							//chkLoanDocumentChecklist.setLoandocumentChecklistCode(loanDocumentChecklist.);
							//chkLoanDocumentChecklist.setLoandocumentChecklistName(loanDocumentChecklist.getLoantypeName());							
							//chkLoanDocumentChecklist.setIsActive(loanDocumentChecklist.getIsActive());							
							Integer DocumentChecklistMFSCDSBeneficiaryId = documentChecklistMFSCDSBeneficiaryService.updateDocumentChecklistMFSCDSBeneficiary(chkDocumentChecklistMFSCDSBeneficiary);
							if (!DocumentChecklistMFSCDSBeneficiaryId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("DocumentChecklistMFSCDSBeneficiaryId:", DocumentChecklistMFSCDSBeneficiaryId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" LoanType Id is deactivated:"+LoanType.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistMFSCDSBeneficiaryController::updateDocumentChecklistMFSCDSBeneficiary======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	@RequestMapping(value = "/documentChecklistMFSCDSBeneficiary/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteDocumentChecklistMFSCDSBeneficiary(@PathVariable Integer id) {
		log.info("In DocumentChecklistMFSCDSBeneficiaryController::deleteDocumentChecklistMFSCDSBeneficiary=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				DocumentChecklistMFSCDSBeneficiary DocumentChecklistMFSCDSBeneficiary = documentChecklistMFSCDSBeneficiaryService.getDocumentChecklistMFSCDSBeneficiary(id);
				if (DocumentChecklistMFSCDSBeneficiary != null) {
//					if (!LoanType.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " LoanTypeId:" + id);
//					} else {
						Integer DocumentChecklistMFSCDSBeneficiaryId = documentChecklistMFSCDSBeneficiaryService.deleteDocumentChecklistMFSCDSBeneficiary(id);
						if (!DocumentChecklistMFSCDSBeneficiaryId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("DocumentChecklistMFSCDSBeneficiaryId", DocumentChecklistMFSCDSBeneficiaryId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistMFSCDSBeneficiaryController::deleteDocumentChecklistMFSCDSBeneficiary======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	@RequestMapping(value = "/documentChecklistMFSCDSBeneficiary/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneDocumentChecklistMFSCDSBeneficiary(@PathVariable Integer id) {
		log.info("In DocumentChecklistBeneficiaryController::getOneDocumentChecklistMFSCDSBeneficiary=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				DocumentChecklistMFSCDSBeneficiary DocumentChecklistMFSCDSBeneficiary = documentChecklistMFSCDSBeneficiaryService.getDocumentChecklistMFSCDSBeneficiary(id);
				if (DocumentChecklistMFSCDSBeneficiary != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("DocumentChecklistMFSCDSBeneficiary", DocumentChecklistMFSCDSBeneficiary);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistMFSCDSBeneficiaryController::getOneDocumentChecklistMFSCDSBeneficiary======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	@RequestMapping(value = "/documentChecklistMFSCDSBeneficiary-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getDocumentChecklistMFSCDSBeneficiaryList() {
		log.info("In DocumentChecklistBeneficiaryController::getDocumentChecklistMFSCDSBeneficiaryList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			LoanTypeListReturnVO LoanTypeListReturnVO = new LoanTypeListReturnVO(LoanTypeService.getLoanTypeList());
			List<DocumentChecklistMFSCDSBeneficiaryVO> DocumentChecklistMFSCDSBeneficiaryListReturnVO = documentChecklistMFSCDSBeneficiaryService.getDocumentChecklistMFSCDSBeneficiaryList();
			if (DocumentChecklistMFSCDSBeneficiaryListReturnVO != null && DocumentChecklistMFSCDSBeneficiaryListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("documentChecklistMFSCDSBeneficiarys", DocumentChecklistMFSCDSBeneficiaryListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistMFSCDSBeneficiaryController::getDocumentChecklistMFSCDSBeneficiaryList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	

	private Boolean checkIfExists(Integer DocumentChecklistMFSCDSBeneficiaryId) {
		return (documentChecklistMFSCDSBeneficiaryService.getDocumentChecklistMFSCDSBeneficiary(DocumentChecklistMFSCDSBeneficiaryId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	
	private Boolean checkValid(DocumentChecklistMFSCDSBeneficiary documentChecklistMFSCDSBeneficiary) {
		Boolean isValid = true;
		invalidMsg = "";
		if (documentChecklistMFSCDSBeneficiary != null) {
//			if(LoanType.getId()==null || LoanType.getId()<=0) {
//				invalidMsg+="LoanTypeId is required and should be valid!";
//				isValid = false;
//			}
			// if (LoanDocumentChecklist.getLoandocumentChecklistName() == null || LoanDocumentChecklist.getLoandocumentChecklistName().equalsIgnoreCase("")) {
			// 	invalidMsg += "LoanDocumentChecklist Name is required and should not be empty!";
			// 	isValid = false;
			// }
//			if (LoanType.getLoanTypeName() == null || LoanType.getLoanTypeName().equalsIgnoreCase("")) {
//				invalidMsg += "LoanType Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (LoanType.getQuotaInMB() == null || LoanType.getQuotaInMB().equals(0) || LoanType.getQuotaInMB()<0) {
//				invalidMsg += "LoanType Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanType.getChatHistoryDays() == null || LoanType.getChatHistoryDays().equals(0) || LoanType.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for LoanType is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanType.getCdaTimeoutTime() == null || LoanType.getCdaTimeoutTime().equals(0) || LoanType.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for documentChecklistMFSCDSBeneficiary!";
			isValid = false;
		}
		return isValid;
	}
	
}
