package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.TLFamilyProperty;
import com.kswdc.loanmanagementsystem.api.repository.TLFamilyPropertyRepository;
import com.kswdc.loanmanagementsystem.api.value.TLFamilyPropertyVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;



@Service
public class TLFamilyPropertyServiceImpl implements TLFamilyPropertyService {
	private final Logger log = LoggerFactory.getLogger(TLFamilyPropertyServiceImpl.class);
	
	@Autowired
	private TLFamilyPropertyRepository tlfamilypropertyRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createTLFamilyProperty(TLFamilyProperty TLFamilyProperty) {
		try {
			TLFamilyProperty savedTLFamilyProperty = tlfamilypropertyRepository.save(TLFamilyProperty);
			return savedTLFamilyProperty.getPropertyId() != null ? savedTLFamilyProperty.getPropertyId() : -1;
		} catch (Exception e) {
			log.error("Exception in TLFamilyPropertyServiceImpl::createTLFamilyProperty======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateTLFamilyProperty(TLFamilyProperty TLFamilyProperty) {
		try {
			TLFamilyProperty updateTLFamilyProperty = tlfamilypropertyRepository.save(TLFamilyProperty);
			return updateTLFamilyProperty.getPropertyId() != null ? updateTLFamilyProperty.getPropertyId() : -1;
		} catch (Exception e) {
			log.error("Exception in TLFamilyPropertyServiceImpl::updateTLFamilyProperty======" + e.getMessage());
		}
		return null;
	}

	@Override
	public TLFamilyProperty getTLFamilyProperty(Integer id) {
		try {
			TLFamilyProperty tlfamilyproperty = tlfamilypropertyRepository.getTLFamilyPropertyById(id);
			return tlfamilyproperty;
		} catch (Exception e) {
			log.error("Exception in TLFamilyPropertyServiceImpl::getTLFamilyProperty======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteTLFamilyProperty(Integer id) {
		try {
			TLFamilyProperty TLFamilyProperty = getTLFamilyProperty(id);
			TLFamilyProperty updatedTLFamilyProperty = tlfamilypropertyRepository.save(TLFamilyProperty);
			return updatedTLFamilyProperty.getPropertyId() != null ? updatedTLFamilyProperty.getPropertyId() : -1;
		} catch (Exception e) {
			log.error("Exception in TLFamilyPropertyServiceImpl::deleteTLFamilyProperty======" + e.getMessage());
		}
		return null;
	}

	//--
	@Override
	public List<TLFamilyProperty> getTLFamilyPropertyListByTLId(Integer termLoanId) {
		List<TLFamilyProperty> familyProperties = new ArrayList<TLFamilyProperty>();
		try {
			familyProperties = tlfamilypropertyRepository.getTLFamilyPropertyListByTLId(termLoanId);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception in TLFamilyPropertyServiceImpl::getTLFamilyPropertyListByTLId======" + e.getMessage());
		}
		return familyProperties;
	}
	//--

	// @Override
	// public List<TLFamilyPropertyVO> getTLFamilyPropertyList() {
	// 	try {
	// 		List<TLFamilyPropertyVO> tlfamilypropertyList = tlfamilypropertyRepository.getTLFamilyPropertyList();
	// 		return tlfamilypropertyList;
	// 	} catch (Exception e) {
	// 		log.error("Exception in TLFamilyPropertyServiceImpl::getTLFamilyPropertyList======" + e.getMessage());
	// 	}
	// 	return null;
	// }

	// @Override
	// public TLFamilyProperty getTLFamilyPropertyByTLFamilyPropertyName(String TLFamilyPropertyName) {
	// 	try {
	// 		TLFamilyProperty TLFamilyProperty = TLFamilyPropertyRepository.getTLFamilyPropertyByTLFamilyPropertyName(TLFamilyPropertyName);
	// 		return TLFamilyProperty;
	// 	} catch (Exception e) {
	// 		log.error("Exception in TLFamilyPropertyServiceImpl::getTLFamilyPropertyByTLFamilyPropertyName======" + e.getMessage());
	// 	}
	// 	return null;
	// }
}