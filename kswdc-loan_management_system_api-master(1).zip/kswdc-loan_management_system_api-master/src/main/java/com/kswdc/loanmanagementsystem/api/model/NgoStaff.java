package com.kswdc.loanmanagementsystem.api.model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

@Data
@Entity
@Table(name = "tbl_ngostaff")
@EqualsAndHashCode()
public class NgoStaff{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "STAFF_ID")
    private Integer staffId;

    @Column(name = "OFFICETRAINED", columnDefinition = "int(11) not null")
    private Integer officetrained;

    @Column(name = "OFFICEUNTRAINED", columnDefinition = "int(11) not null")
    private Integer officeuntrained;

    @Column(name = "FIELDTRAINED", columnDefinition = "int(11) not null")
    private Integer fieldtrained;

    @Column(name = "FIELDUNTRAINED", columnDefinition = "int(11) not null")
    private Integer fielduntrained;

    @Column(name = "OFFICESTAFFTOTAL", columnDefinition = "int(11) not null")
    private Integer officestafftotal;

    @Column(name = "FIELDSTAFFTOTAL", columnDefinition = "int(11) not null")
    private Integer fieldstafftotal;

       
}
