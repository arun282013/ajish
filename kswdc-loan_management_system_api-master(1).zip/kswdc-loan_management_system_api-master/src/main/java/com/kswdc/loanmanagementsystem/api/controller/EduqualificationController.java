package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.Eduqualification;
import com.kswdc.loanmanagementsystem.api.service.EduqualificationService;
import com.kswdc.loanmanagementsystem.api.value.EduqualificationVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class EduqualificationController {

	private final Logger log = LoggerFactory.getLogger(EduqualificationController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private EduqualificationService eduqualificationService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param Eduqualification Eduqualification
	 * @return Map
	 */
	@RequestMapping(value = "/eduqualification", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createEduqualification(@RequestBody Eduqualification Eduqualification) {
		log.info("In EduqualificationController::createEduqualification=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(Eduqualification)) {
//						Eduqualification.setActive(Boolean.TRUE);
						Eduqualification.setCreatedOn(DateFunctions.getZonedServerDate());
						// Eduqualification.setCreatedBy();
						Eduqualification.setIsDeleted(0);
						Integer EduqualificationId = eduqualificationService.createEduqualification(Eduqualification);
						if (!EduqualificationId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("EduqualificationId", EduqualificationId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in EduqualificationController::createEduqualification======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param Eduqualification Eduqualification
	 * @return Map
	 */
	@RequestMapping(value = "/eduqualification", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateEduqualification(@RequestBody Eduqualification eduqualification) {
		log.info("In EduqualificationController::updateEduqualification=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (eduqualification != null) { // && Eduqualification.getId() != null
				if (checkValid(eduqualification)) {
					Eduqualification chkEduqualification = eduqualificationService.getEduqualification(eduqualification.getEduqualificationId());
					if (chkEduqualification!=null) {
//						if (chkEduqualification.getActive()) {
//							Eduqualification.setActive(Boolean.TRUE);
							chkEduqualification.setEduqualificationName(eduqualification.getEduqualificationName());							
							chkEduqualification.setIsActive(eduqualification.getIsActive());							
							Integer EduqualificationId = eduqualificationService.updateEduqualification(chkEduqualification);
							if (!EduqualificationId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("EduqualificationId:", EduqualificationId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" Eduqualification Id is deactivated:"+Eduqualification.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in EduqualificationController::updateEduqualification======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/eduqualification/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteEduqualification(@PathVariable Integer id) {
		log.info("In EduqualificationController::deleteEduqualification=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Eduqualification Eduqualification = eduqualificationService.getEduqualification(id);
				if (Eduqualification != null) {
//					if (!Eduqualification.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " EduqualificationId:" + id);
//					} else {
						Integer EduqualificationId = eduqualificationService.deleteEduqualification(id);
						if (!EduqualificationId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("EduqualificationId", EduqualificationId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in EduqualificationController::deleteEduqualification======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/eduqualification/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneEduqualification(@PathVariable Integer id) {
		log.info("In EduqualificationController::getOneEduqualification=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Eduqualification Eduqualification = eduqualificationService.getEduqualification(id);
				if (Eduqualification != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("Eduqualification", Eduqualification);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in EduqualificationController::getOneEduqualification======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- Eduqualification ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/eduqualification-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getEduqualificationList() {
		log.info("In EduqualificationController::getEduqualificationList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			EduqualificationListReturnVO EduqualificationListReturnVO = new EduqualificationListReturnVO(EduqualificationService.getEduqualificationList());
			List<EduqualificationVO> EduqualificationListReturnVO = eduqualificationService.getEduqualificationList();
			if (EduqualificationListReturnVO != null && EduqualificationListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("eduqualifications", EduqualificationListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in EduqualificationController::getEduqualificationList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param EduqualificationId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer EduqualificationId) {
		return (eduqualificationService.getEduqualification(EduqualificationId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param Eduqualification
	 * @return Boolean
	 */
	private Boolean checkValid(Eduqualification Eduqualification) {
		Boolean isValid = true;
		invalidMsg = "";
		if (Eduqualification != null) {
//			if(Eduqualification.getId()==null || Eduqualification.getId()<=0) {
//				invalidMsg+="EduqualificationId is required and should be valid!";
//				isValid = false;
//			}
			if (Eduqualification.getEduqualificationName() == null || Eduqualification.getEduqualificationName().equalsIgnoreCase("")) {
				invalidMsg += "Eduqualification Name is required and should not be empty!";
				isValid = false;
			}
//			if (Eduqualification.getEduqualificationName() == null || Eduqualification.getEduqualificationName().equalsIgnoreCase("")) {
//				invalidMsg += "Eduqualification Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (Eduqualification.getQuotaInMB() == null || Eduqualification.getQuotaInMB().equals(0) || Eduqualification.getQuotaInMB()<0) {
//				invalidMsg += "Eduqualification Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (Eduqualification.getChatHistoryDays() == null || Eduqualification.getChatHistoryDays().equals(0) || Eduqualification.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for Eduqualification is required and should be valid!";
//				isValid = false;
//			}
//			if (Eduqualification.getCdaTimeoutTime() == null || Eduqualification.getCdaTimeoutTime().equals(0) || Eduqualification.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for Eduqualification!";
			isValid = false;
		}
		return isValid;
	}
	
}
