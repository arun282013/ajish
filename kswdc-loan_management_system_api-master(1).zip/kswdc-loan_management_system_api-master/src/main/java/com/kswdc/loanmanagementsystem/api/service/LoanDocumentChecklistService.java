package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.LoanDocumentChecklist;
import com.kswdc.loanmanagementsystem.api.value.LoanDocumentChecklistVO;


@Component
public interface LoanDocumentChecklistService {

    Integer createLoanDocumentChecklist(LoanDocumentChecklist loanDocumentChecklist);

    Integer updateLoanDocumentChecklist(LoanDocumentChecklist loanDocumentChecklist);

    LoanDocumentChecklist getLoanDocumentChecklist(Integer id);

    //LoanDocumentChecklist geLoanDocumentChecklistByLoanDocumentChecklistName(String loanDocumentChecklistName);

    Integer deleteLoanDocumentChecklist(Integer id);

    List<LoanDocumentChecklistVO> getLoanDocumentChecklistList();
}
