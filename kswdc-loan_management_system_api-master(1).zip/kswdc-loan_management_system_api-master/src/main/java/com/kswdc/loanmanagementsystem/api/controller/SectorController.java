package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.Sector;
import com.kswdc.loanmanagementsystem.api.service.SectorService;
import com.kswdc.loanmanagementsystem.api.value.SectorVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class SectorController {

	private final Logger log = LoggerFactory.getLogger(SectorController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private SectorService sectorService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param Sector Sector
	 * @return Map
	 */
	@RequestMapping(value = "/sector", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createSector(@RequestBody Sector Sector) {
		log.info("In SectorController::createSector=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(Sector)) {
//						Sector.setActive(Boolean.TRUE);
						Sector.setCreatedOn(DateFunctions.getZonedServerDate());
						// Sector.setCreatedBy();
						Sector.setIsDeleted(0);
						Integer SectorId = sectorService.createSector(Sector);
						if (!SectorId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("SectorId", SectorId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in SectorController::createSector======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param Sector Sector
	 * @return Map
	 */
	@RequestMapping(value = "/sector", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateSector(@RequestBody Sector sector) {
		log.info("In SectorController::updateSector=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (sector != null) { // && Sector.getId() != null
				if (checkValid(sector)) {
					Sector chkSector = sectorService.getSector(sector.getSectorId());
					if (chkSector!=null) {
//						if (chkSector.getActive()) {
//							Sector.setActive(Boolean.TRUE);
							chkSector.setSectorName(sector.getSectorName());							
							chkSector.setIsActive(sector.getIsActive());							
							Integer SectorId = sectorService.updateSector(chkSector);
							if (!SectorId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("SectorId:", SectorId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" Sector Id is deactivated:"+Sector.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in SectorController::updateSector======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/sector/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteSector(@PathVariable Integer id) {
		log.info("In SectorController::deleteSector=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Sector Sector = sectorService.getSector(id);
				if (Sector != null) {
//					if (!Sector.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " SectorId:" + id);
//					} else {
						Integer SectorId = sectorService.deleteSector(id);
						if (!SectorId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("SectorId", SectorId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in SectorController::deleteSector======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/sector/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneSector(@PathVariable Integer id) {
		log.info("In SectorController::getOneSector=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Sector Sector = sectorService.getSector(id);
				if (Sector != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("Sector", Sector);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in SectorController::getOneSector======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- Sector ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/sector-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getSectorList() {
		log.info("In SectorController::getSectorList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			SectorListReturnVO SectorListReturnVO = new SectorListReturnVO(SectorService.getSectorList());
			List<SectorVO> SectorListReturnVO = sectorService.getSectorList();
			if (SectorListReturnVO != null && SectorListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("sectors", SectorListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in SectorController::getSectorList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param SectorId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer SectorId) {
		return (sectorService.getSector(SectorId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param Sector
	 * @return Boolean
	 */
	private Boolean checkValid(Sector Sector) {
		Boolean isValid = true;
		invalidMsg = "";
		if (Sector != null) {
//			if(Sector.getId()==null || Sector.getId()<=0) {
//				invalidMsg+="SectorId is required and should be valid!";
//				isValid = false;
//			}
			if (Sector.getSectorName() == null || Sector.getSectorName().equalsIgnoreCase("")) {
				invalidMsg += "Sector Name is required and should not be empty!";
				isValid = false;
			}
//			if (Sector.getSectorName() == null || Sector.getSectorName().equalsIgnoreCase("")) {
//				invalidMsg += "Sector Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (Sector.getQuotaInMB() == null || Sector.getQuotaInMB().equals(0) || Sector.getQuotaInMB()<0) {
//				invalidMsg += "Sector Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (Sector.getChatHistoryDays() == null || Sector.getChatHistoryDays().equals(0) || Sector.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for Sector is required and should be valid!";
//				isValid = false;
//			}
//			if (Sector.getCdaTimeoutTime() == null || Sector.getCdaTimeoutTime().equals(0) || Sector.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for Sector!";
			isValid = false;
		}
		return isValid;
	}
	
}
