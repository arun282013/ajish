package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.SuretyType;
import com.kswdc.loanmanagementsystem.api.service.SuretyTypeService;
import com.kswdc.loanmanagementsystem.api.value.SuretyTypeVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;


@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class SuretyTypeController {

	private final Logger log = LoggerFactory.getLogger(SuretyTypeController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private SuretyTypeService suretyTypeService;
	
	/**
	 * @param SuretyType SuretyType
	 * @return Map
	 */
	@RequestMapping(value = "/suretyType", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createSuretyType(@RequestBody SuretyType SuretyType) {
		log.info("In SuretyTypeController::createSuretyType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(SuretyType)) {
//						LoanCategory.setActive(Boolean.TRUE);
						SuretyType.setCreatedOn(DateFunctions.getZonedServerDate());
						// LoanCategory.setCreatedBy();
						SuretyType.setIsDeleted(0);
						Integer SuretyTypeId = suretyTypeService.createSuretyType(SuretyType);
						if (!SuretyTypeId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("suretytypeId", SuretyTypeId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in SuretyTypeController::createSuretyType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * //@param SuretyType SuretyType
	 * @return Map
	 */
	@RequestMapping(value = "/suretyType", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateSuretyType(@RequestBody SuretyType suretyType) {
		log.info("In SuretyTypeController::updateSuretyType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (suretyType != null) { // && SuretyType.getId() != null
				if (checkValid(suretyType)) {
					SuretyType chkSuretyType = suretyTypeService.getSuretyType(suretyType.getSuretytypeId());
					if (chkSuretyType!=null) {
//						if (chkLoanCategory.getActive()) {
//							LoanCategory.setActive(Boolean.TRUE);
							chkSuretyType.setSuretytypeName(suretyType.getSuretytypeName());							
							chkSuretyType.setIsActive(suretyType.getIsActive());							
							Integer SuretyTypeId = suretyTypeService.updateSuretyType(chkSuretyType);
							if (!SuretyTypeId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("suretytypeId:", SuretyTypeId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" LoanCategory Id is deactivated:"+LoanCategory.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in SuretyTypeController::updateSuretyType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/suretyType/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteSuretyType(@PathVariable Integer id) {
		log.info("InSuretyTypeController::deleteSuretyType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				SuretyType SuretyType = suretyTypeService.getSuretyType(id);
				if (SuretyType != null) {
//					if (!LoanCategory.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " LoanCategoryId:" + id);
//					} else {
						Integer SuretyTypeId = suretyTypeService.deleteSuretyType(id);
						if (!SuretyTypeId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("suretytype", SuretyTypeId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in SuretyTypeController::deleteSuretyType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/suretyType/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneSuretyType(@PathVariable Integer id) {
		log.info("In SuretyTypeController::getOneSuretyType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				SuretyType SuretyType = suretyTypeService.getSuretyType(id);
				if (SuretyType != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("Suretytype", SuretyType);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in SuretyTypeController::getOneSuretyType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- LoanCategory ------------------------------

	/**
	 * @return Map
	 */
	@RequestMapping(value = "/suretyType-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getSuretyTypeList() {
		log.info("In SuretyTypeController::getSuretyTypeList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			LoanCategoryListReturnVO LoanCategoryListReturnVO = new LoanCategoryListReturnVO(LoanCategoryService.getLoanCategoryList());
			List<SuretyTypeVO> SuretyTypeListReturnVO = suretyTypeService.getSuretyTypeList();
			if (SuretyTypeListReturnVO != null && SuretyTypeListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("suretytypes",SuretyTypeListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in SuretyTypeController::getSuretyTypeList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// sreelekshmi 26.02.2022

	@RequestMapping(value = "/suretyType-list-by-loantype/{loantypeId}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getSuretyTypeListByLoanType(@PathVariable Integer loantypeId) {
		log.info("In SuretyTypeController::getSuretyTypeListByLoanType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			List<SuretyTypeVO> SuretyTypeListReturnVO = suretyTypeService.getSuretyTypeListByLoanType(loantypeId);
			if (SuretyTypeListReturnVO != null && SuretyTypeListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("suretytypes", SuretyTypeListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();	
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in SuretyTypeController::getSuretyTypeListByLoanType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param SuretyTypeId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer SuretyTypeId) {
		return (suretyTypeService.getSuretyType(SuretyTypeId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @purpose For checking if mandatory data is passed
	 * @param SuretyType
	 * @return Boolean
	 */
	private Boolean checkValid(SuretyType SuretyType) {
		Boolean isValid = true;
		invalidMsg = "";
		if (SuretyType != null) {
//			if(LoanCategory.getId()==null || LoanCategory.getId()<=0) {
//				invalidMsg+="LoanCategoryId is required and should be valid!";
//				isValid = false;
//			}
			if (SuretyType.getSuretytypeName() == null || SuretyType.getSuretytypeName().equalsIgnoreCase("")) {
				invalidMsg += "SuretyType Name is required and should not be empty!";
				isValid = false;
			}
//			if (LoanCategory.getLoanCategoryName() == null || LoanCategory.getLoanCategoryName().equalsIgnoreCase("")) {
//				invalidMsg += "LoanCategory Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (LoanCategory.getQuotaInMB() == null || LoanCategory.getQuotaInMB().equals(0) || LoanCategory.getQuotaInMB()<0) {
//				invalidMsg += "LoanCategory Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanCategory.getChatHistoryDays() == null || LoanCategory.getChatHistoryDays().equals(0) || LoanCategory.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for LoanCategory is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanCategory.getCdaTimeoutTime() == null || LoanCategory.getCdaTimeoutTime().equals(0) || LoanCategory.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for SuretyType!";
			isValid = false;
		}
		return isValid;
	}
	
}
