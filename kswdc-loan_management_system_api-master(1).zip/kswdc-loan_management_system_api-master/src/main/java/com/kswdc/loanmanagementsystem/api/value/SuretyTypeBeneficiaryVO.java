package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SuretyTypeBeneficiaryVO implements Serializable {
    private Integer suretytypeBeneficiaryId;
    private String suretytypeName;
    private String fullName;
    private String loantypeName;
    private Integer loanTypeId;
  
    public SuretyTypeBeneficiaryVO(Integer suretytypeBeneficiaryId, String suretytypeName, 
    String fullName, Integer loanTypeId, String loantypeName) {
        this.suretytypeBeneficiaryId = suretytypeBeneficiaryId;
        this.suretytypeName = suretytypeName;
        this.fullName = fullName;
        this.loanTypeId = loanTypeId;
        this.loantypeName = loantypeName;
        
    }
    
}
