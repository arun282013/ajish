package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklist;
import com.kswdc.loanmanagementsystem.api.repository.DocumentChecklistRepository;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;


@Service
public class DocumentChecklistServiceImpl implements DocumentChecklistService {
	private final Logger log = LoggerFactory.getLogger(DocumentChecklistServiceImpl.class);
	
	@Autowired
	private DocumentChecklistRepository documentChecklistRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createDocumentChecklist(DocumentChecklist DocumentChecklist) {
		try {
			DocumentChecklist savedDocumentChecklist = documentChecklistRepository.save(DocumentChecklist);
			return savedDocumentChecklist.getDocumentchecklistId() != null ? savedDocumentChecklist.getDocumentchecklistId() : -1;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistServiceImpl::createDocumentChecklist======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateDocumentChecklist(DocumentChecklist DocumentChecklist) {
		try {
			DocumentChecklist updateDocumentChecklist = documentChecklistRepository.save(DocumentChecklist);
			return updateDocumentChecklist.getDocumentchecklistId() != null ? updateDocumentChecklist.getDocumentchecklistId() : -1;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistServiceImpl::updateDocumentChecklist======" + e.getMessage());
		}
		return null;
	}

	@Override
	public DocumentChecklist getDocumentChecklist(Integer id) {
		try {
			DocumentChecklist documentChecklist = documentChecklistRepository.getDocumentChecklistById(id);
			return documentChecklist;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistServiceImpl::getDocumentChecklist======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteDocumentChecklist(Integer id) {
		try {
			DocumentChecklist DocumentChecklist = getDocumentChecklist(id);
//			LoanCategory.setActive(Boolean.FALSE);
			DocumentChecklist.setDeletedOn(DateFunctions.getZonedServerDate());
			DocumentChecklist.setIsDeleted(Constants.IS_DELETED);
			DocumentChecklist updatedDocumentChecklist = documentChecklistRepository.save(DocumentChecklist);
			return updatedDocumentChecklist.getDocumentchecklistId() != null ? updatedDocumentChecklist.getDocumentchecklistId() : -1;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistServiceImpl::deleteDocumentChecklist======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<DocumentChecklistVO> getDocumentChecklistList() {
		try {
			List<DocumentChecklistVO> documentChecklistList = documentChecklistRepository.getDocumentChecklistList();
			return documentChecklistList;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistServiceImpl::getDocumentChecklistList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<DocumentChecklistVO> getDocumentChecklistListByLoanType(Integer loantypeId) {
		try {
			List<DocumentChecklistVO> documentchecklistList = documentChecklistRepository.getDocumentChecklistListByLoanType(loantypeId);
			return documentchecklistList;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistServiceImpl::getDocumentChecklistListByLoanType======" + e.getMessage());
		}
		return null;
	}


	@Override
	public DocumentChecklist getDocumentChecklistByDocumentChecklistName(String documentchecklistName) {
		try {
			DocumentChecklist documentChecklist = documentChecklistRepository.findByDocumentChecklistName(documentchecklistName);
			return documentChecklist;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistServiceImpl::getDocumentChecklistByDocumentChecklistName======" + e.getMessage());
		}
		return null;
	}
}