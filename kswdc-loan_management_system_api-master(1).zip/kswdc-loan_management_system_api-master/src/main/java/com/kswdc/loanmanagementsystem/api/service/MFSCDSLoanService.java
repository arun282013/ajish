package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.MFSCDSLoan;
import com.kswdc.loanmanagementsystem.api.value.MFSCDSLoanVO;

/**
 */
@Component
public interface MFSCDSLoanService {

    Integer createMFSCDSLoan(MFSCDSLoan mfscdsloan);

    Integer updateMFSCDSLoan(MFSCDSLoan mfscdsloan);

    Integer updateSecondTabMFSCDSLoan(MFSCDSLoan mfscdsloan);

    MFSCDSLoan getMFSCDSLoan(Integer id);

    MFSCDSLoanVO getMFSCDSLoanByUser(Integer userId);

    Integer deleteMFSCDSLoan(Integer id);

    List<MFSCDSLoanVO> getMFSCDSLoanList();

    // --for preview
    MFSCDSLoanVO getPreviewMFSCDSLoan(Integer mfscdsLoanId);
    // --for preview
}
