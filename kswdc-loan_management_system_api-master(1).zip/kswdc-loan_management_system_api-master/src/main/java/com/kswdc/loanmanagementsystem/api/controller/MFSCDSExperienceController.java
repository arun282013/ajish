package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.MFSCDSExperience;
import com.kswdc.loanmanagementsystem.api.service.MFSCDSExperienceService;
import com.kswdc.loanmanagementsystem.api.value.MFSCDSExperienceVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;


@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class MFSCDSExperienceController {

	private final Logger log = LoggerFactory.getLogger(MFSCDSExperienceController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private MFSCDSExperienceService mfscdsexperienceService;
	
	/**
	 * @param MFSCDSExperience MFSCDSExperience
	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsexperience", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createMFSCDSExperience(@RequestBody MFSCDSExperience MFSCDSExperience) {
		log.info("In MFSCDSExperienceController::createMFSCDSExperience=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(MFSCDSExperience)) {
						Integer ExperienceId = mfscdsexperienceService.createMFSCDSExperience(MFSCDSExperience);
						if (!ExperienceId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("ExperienceId", ExperienceId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSExperienceController::createMFSCDSExperience======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * //@param MFSCDSExperience MFSCDSExperience
	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsexperience", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateMFSCDSExperience(@RequestBody MFSCDSExperience mfscdsexperience) {
		log.info("In MFSCDSExperienceController::updateMFSCDSExperience=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (mfscdsexperience != null) { // && MFSCDSExperience.getId() != null
				if (checkValid(mfscdsexperience)) {
					MFSCDSExperience chkMFSCDSExperience = mfscdsexperienceService.getMFSCDSExperience(mfscdsexperience.getExperienceId());
					if (chkMFSCDSExperience!=null) {						
							chkMFSCDSExperience.setExperienceId(mfscdsexperience.getExperienceId());
							
							Integer experienceId = mfscdsexperienceService.updateMFSCDSExperience(chkMFSCDSExperience);
							if (!experienceId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("ExperienceId:", experienceId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSExperienceController::updateMFSCDSExperience======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsexperience/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteMFSCDSExperience(@PathVariable Integer id) {
		log.info("In MFSCDSExperienceController::deleteMFSCDSExperience=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				MFSCDSExperience MFSCDSExperience = mfscdsexperienceService.getMFSCDSExperience(id);
				if (MFSCDSExperience != null) {
						Integer experienceId = mfscdsexperienceService.deleteMFSCDSExperience(id);
						if (!experienceId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("MFSCDSExperienceId", experienceId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSExperienceController::deleteMFSCDSExperience======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsexperience/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneMFSCDSExperience(@PathVariable Integer id) {
		log.info("In MFSCDSExperienceController::getOneMFSCDSExperience=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				MFSCDSExperience MFSCDSExperience = mfscdsexperienceService.getMFSCDSExperience(id);
				if (MFSCDSExperience != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("MFSCDSExperience", MFSCDSExperience);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSExperienceController::getOneMFSCDSExperience======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End


	/**
	 * @param MFSCDSExperienceId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer experienceId) {
		return (mfscdsexperienceService.getMFSCDSExperience(experienceId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @purpose For checking if mandatory data is passed
	 * @param MFSCDSExperience
	 * @return Boolean
	 */
	private Boolean checkValid(MFSCDSExperience MFSCDSExperience) {
		Boolean isValid = true;
		invalidMsg = "";
		if (MFSCDSExperience != null) {
			if (MFSCDSExperience.getExperienceProjectdone() == null || MFSCDSExperience.getExperienceProjectdone().equalsIgnoreCase("")) {
				invalidMsg += "MFSCDSExperience Projectdone is required and should not be empty!";
				isValid = false;
			}

		} else {
			invalidMsg = "Received data is not valid for MFSCDSExperience!";
			isValid = false;
		}
		return isValid;
	}
	
}
