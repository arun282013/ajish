package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.LoanCategory;
import com.kswdc.loanmanagementsystem.api.service.LoanCategoryService;
import com.kswdc.loanmanagementsystem.api.value.LoanCategoryVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class LoanCategoryController {

	private final Logger log = LoggerFactory.getLogger(LoanCategoryController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private LoanCategoryService loanCategoryService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param LoanCategory LoanCategory
	 * @return Map
	 */
	@RequestMapping(value = "/loanCategory", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createLoanCategory(@RequestBody LoanCategory LoanCategory) {
		log.info("In LoanCategoryController::createLoanCategory=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(LoanCategory)) {
//						LoanCategory.setActive(Boolean.TRUE);
						LoanCategory.setCreatedOn(DateFunctions.getZonedServerDate());
						// LoanCategory.setCreatedBy();
						LoanCategory.setIsDeleted(0);
						Integer LoanCategoryId = loanCategoryService.createLoanCategory(LoanCategory);
						if (!LoanCategoryId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("LoanCategoryId", LoanCategoryId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanCategoryController::createLoanCategory======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param LoanCategory LoanCategory
	 * @return Map
	 */
	@RequestMapping(value = "/loanCategory", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateLoanCategory(@RequestBody LoanCategory loanCategory) {
		log.info("In LoanCategoryController::updateLoanCategory=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (loanCategory != null) { // && LoanCategory.getId() != null
				if (checkValid(loanCategory)) {
					LoanCategory chkLoanCategory = loanCategoryService.getLoanCategory(loanCategory.getLoanCategoryId());
					if (chkLoanCategory!=null) {
//						if (chkLoanCategory.getActive()) {
//							LoanCategory.setActive(Boolean.TRUE);
							chkLoanCategory.setLoanCategoryCode(loanCategory.getLoanCategoryCode());
							chkLoanCategory.setLoanCategoryName(loanCategory.getLoanCategoryName());							
							chkLoanCategory.setIsActive(loanCategory.getIsActive());							
							Integer LoanCategoryId = loanCategoryService.updateLoanCategory(chkLoanCategory);
							if (!LoanCategoryId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("LoanCategoryId:", LoanCategoryId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" LoanCategory Id is deactivated:"+LoanCategory.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanCategoryController::updateLoanCategory======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/loanCategory/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteLoanCategory(@PathVariable Integer id) {
		log.info("In LoanCategoryController::deleteLoanCategory=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				LoanCategory LoanCategory = loanCategoryService.getLoanCategory(id);
				if (LoanCategory != null) {
//					if (!LoanCategory.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " LoanCategoryId:" + id);
//					} else {
						Integer LoanCategoryId = loanCategoryService.deleteLoanCategory(id);
						if (!LoanCategoryId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("LoanCategoryId", LoanCategoryId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanCategoryController::deleteLoanCategory======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/loanCategory/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneLoanCategory(@PathVariable Integer id) {
		log.info("In LoanCategoryController::getOneLoanCategory=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				LoanCategory LoanCategory = loanCategoryService.getLoanCategory(id);
				if (LoanCategory != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("LoanCategory", LoanCategory);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanCategoryController::getOneLoanCategory======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- LoanCategory ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/loanCategory-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getLoanCategoryList() {
		log.info("In LoanCategoryController::getLoanCategoryList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			LoanCategoryListReturnVO LoanCategoryListReturnVO = new LoanCategoryListReturnVO(LoanCategoryService.getLoanCategoryList());
			List<LoanCategoryVO> LoanCategoryListReturnVO = loanCategoryService.getLoanCategoryList();
			if (LoanCategoryListReturnVO != null && LoanCategoryListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("loanCategorys", LoanCategoryListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanCategoryController::getLoanCategoryList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param LoanCategoryId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer LoanCategoryId) {
		return (loanCategoryService.getLoanCategory(LoanCategoryId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param LoanCategory
	 * @return Boolean
	 */
	private Boolean checkValid(LoanCategory LoanCategory) {
		Boolean isValid = true;
		invalidMsg = "";
		if (LoanCategory != null) {
//			if(LoanCategory.getId()==null || LoanCategory.getId()<=0) {
//				invalidMsg+="LoanCategoryId is required and should be valid!";
//				isValid = false;
//			}
			if (LoanCategory.getLoanCategoryName() == null || LoanCategory.getLoanCategoryName().equalsIgnoreCase("")) {
				invalidMsg += "LoanCategory Name is required and should not be empty!";
				isValid = false;
			}
//			if (LoanCategory.getLoanCategoryName() == null || LoanCategory.getLoanCategoryName().equalsIgnoreCase("")) {
//				invalidMsg += "LoanCategory Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (LoanCategory.getQuotaInMB() == null || LoanCategory.getQuotaInMB().equals(0) || LoanCategory.getQuotaInMB()<0) {
//				invalidMsg += "LoanCategory Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanCategory.getChatHistoryDays() == null || LoanCategory.getChatHistoryDays().equals(0) || LoanCategory.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for LoanCategory is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanCategory.getCdaTimeoutTime() == null || LoanCategory.getCdaTimeoutTime().equals(0) || LoanCategory.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for LoanCategory!";
			isValid = false;
		}
		return isValid;
	}
	
}
