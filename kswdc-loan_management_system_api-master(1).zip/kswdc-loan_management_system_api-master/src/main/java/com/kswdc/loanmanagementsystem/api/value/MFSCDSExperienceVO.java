package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MFSCDSExperienceVO implements Serializable {
    private Integer experienceId;
    private String experienceYear;
    private Integer experienceNoofgroups;
    private Double experienceamountReceived;
    private String experienceProjectdone;
    private Double experiencePendingamount;
    
    public MFSCDSExperienceVO(Integer experienceId, 
    String experienceYear, Integer experienceNoofgroups,
    Double experienceamountReceived,String experienceProjectdone,
    Double experiencePendingamount) {
        this.experienceId = experienceId;
        this.experienceYear = experienceYear;
        this.experienceNoofgroups = experienceNoofgroups;
        this.experienceamountReceived = experienceamountReceived;
        this.experienceProjectdone = experienceProjectdone;
        this.experiencePendingamount = experiencePendingamount;
       
    }
    
}
