package com.kswdc.loanmanagementsystem.common;

import java.util.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.format.datetime.DateFormatter;

public class DateFunctions {
	
	private static final String DATE_FORMAT = "dd-M-yyyy hh:mm:ss a z";
	private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT);
	private static final String DATE_FORMAT_DDMMYYYY = "dd-MM-yyyy";
	private static final SimpleDateFormat formatterDDMMYYYY = new SimpleDateFormat(DATE_FORMAT_DDMMYYYY);
	private static final SimpleDateFormat sdfLong = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
	private static final DateFormat dt= new SimpleDateFormat("yyyy-MM-dd H:m:s");
	private static final DateFormat dtDDMMYYYY= new SimpleDateFormat(DATE_FORMAT_DDMMYYYY);
	private static final String TIME_FORMAT = "hh:mm:ss a z";
	private static final DateTimeFormatter timeformatter = DateTimeFormatter.ofPattern(TIME_FORMAT);
	
	@Value("${spring.application.name}")
	private static String appName;
		
	public static Date getyyyymmddhmsFormatedDate(String date) {
		try {
			return dt.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}
	public static Date getddmmyyyyFormatedDate(String date) {
		try {
			return dtDDMMYYYY.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}
	public static ZoneId getTimeZoneFromDate(String datewithTZ) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("uuuu-MM-dd'T'HH:mm:ssZ");
		ZonedDateTime dt = ZonedDateTime.parse(datewithTZ, formatter);
		ZoneId zone = dt.getZone();
		return zone;
	}
	public static String getFormatedDate(java.util.Date date) {
		StringBuffer stringBuffer = new StringBuffer();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ssZ");
		if(date!=null) {
			simpleDateFormat.format(date, stringBuffer, new FieldPosition(0));
		}
		return stringBuffer.toString();
	}
	public static String getFormatedDDMMYYYYDate(java.util.Date date) {
		return formatterDDMMYYYY.format(date);
	}
	public static String getFormatedYYYYMMDDhmsDate(java.util.Date date) {
		return dt.format(date);
	}
	public static String getFormatedDate(ZonedDateTime date) {
		return formatter.format(date);
	}
	public static String getFormatedTimeOnly(ZonedDateTime date) {
		return timeformatter.format(date);
	}
	public static LocalDate convertToLocalDateViaInstant(java.sql.Date dateToConvert) {
	    return dateToConvert.toInstant()
	      .atZone(ZoneId.systemDefault())
	      .toLocalDate();
	}
	
	public static LocalDate convertToLocalDateViaMilisecond(java.sql.Date dateToConvert) {
	    return Instant.ofEpochMilli(dateToConvert.getTime())
	      .atZone(ZoneId.systemDefault())
	      .toLocalDate();
	}
	
	public static LocalDate convertToLocalDateViaMilisecond(java.sql.Timestamp dateToConvert) {
	    return Instant.ofEpochMilli(dateToConvert.getTime())
	      .atZone(ZoneId.systemDefault())
	      .toLocalDate();
	}
	
	public static Date convertFromUtcToTimeZone(Date dateToConvert,String targetZone) {
		ZoneId fromTimeZone = ZoneId.of("UTC");    //Source timezone
        ZoneId toTimeZone = ZoneId.of(targetZone);  //Target timezone
        
        //Zoned date time at source timezone
        ZonedDateTime sourceTime = dateToConvert.toInstant().atZone(fromTimeZone);       
         
        //Zoned date time at target timezone
        ZonedDateTime targetTime = sourceTime.withZoneSameInstant(toTimeZone);
        Date convertedDate = Date.from(targetTime.toInstant());
        
        return convertedDate;
	}
	
	public static Date convertToUtcFromTimeZone(Date dateToConvert,String sourceZone) {
		ZoneId fromTimeZone = ZoneId.of(sourceZone);    //Source timezone
        ZoneId toTimeZone = ZoneId.of("UTC");  //Target timezone
        
        //Zoned date time at source timezone
        ZonedDateTime sourceTime = dateToConvert.toInstant().atZone(fromTimeZone);       
         
        //Zoned date time at target timezone
        ZonedDateTime targetTime = sourceTime.withZoneSameInstant(toTimeZone);
        Date convertedDate = Date.from(targetTime.toInstant());
        
        return convertedDate;
	}
	
	
	public static Date convertFromUtcToTimeZone(Date dateToConvert,ZoneId toTimeZone) {
		ZoneId fromTimeZone = ZoneId.of("UTC");    //Source timezone
        
		//Zoned date time at source timezone
        ZonedDateTime sourceTime = dateToConvert.toInstant().atZone(fromTimeZone);       
         
        //Zoned date time at target timezone
        ZonedDateTime targetTime = sourceTime.withZoneSameInstant(toTimeZone);
        Date convertedDate = Date.from(targetTime.toInstant());
        
        return convertedDate;
	}
	
	public static Date convertFromUtcToTimeZone(ZonedDateTime dateToConvert,ZoneId toTimeZone) {
		ZoneId fromTimeZone = ZoneId.of("UTC");    //Source timezone
        
		//Zoned date time at source timezone
        ZonedDateTime sourceTime = dateToConvert.toInstant().atZone(fromTimeZone);       
         
        //Zoned date time at target timezone
        ZonedDateTime targetTime = sourceTime.withZoneSameInstant(toTimeZone);
        Date convertedDate = Date.from(targetTime.toInstant());
        
        return convertedDate;
	}
	
	public static Date convertToUtcFromTimeZone(Date dateToConvert,ZoneId fromTimeZone) {
        ZoneId toTimeZone = ZoneId.of("UTC");  //Target timezone
        
        //Zoned date time at source timezone
        ZonedDateTime sourceTime = dateToConvert.toInstant().atZone(fromTimeZone);       
         
        //Zoned date time at target timezone
        ZonedDateTime targetTime = sourceTime.withZoneSameInstant(toTimeZone);
        Date convertedDate = Date.from(targetTime.toInstant());
        
        return convertedDate;
	}	
	
	public static ZonedDateTime convertFromUtcToTimeZoneZoned(ZonedDateTime dateToConvert,ZoneId toTimeZone) {
		ZoneId fromTimeZone = ZoneId.of("UTC");    //Source timezone
        
		//Zoned date time at source timezone
        ZonedDateTime sourceTime = dateToConvert.toInstant().atZone(fromTimeZone);       
         
        //Zoned date time at target timezone
        ZonedDateTime targetTime = sourceTime.withZoneSameInstant(toTimeZone);
        
        return targetTime;
	}
	
	public static ZonedDateTime convertToUtcFromTimeZoneZoned(Date dateToConvert,ZoneId fromTimeZone) {
        ZoneId toTimeZone = ZoneId.of("UTC");  //Target timezone
        
        //Zoned date time at source timezone
        ZonedDateTime sourceTime = dateToConvert.toInstant().atZone(fromTimeZone);       
         
        //Zoned date time at target timezone
        ZonedDateTime targetTime = sourceTime.withZoneSameInstant(toTimeZone);
        
        return targetTime;
	}
	
	public static ZonedDateTime convertFromUtcToTimeZone(String dateToConvertStr) throws ParseException {
		Date sourceDate = sdfLong.parse(dateToConvertStr);
		ZoneId toTimeZone = DateFunctions.getTimeZoneFromDate(dateToConvertStr);
		ZoneId fromTimeZone = ZoneId.of("UTC");    //Source timezone
        
		//Zoned date time at source timezone
        ZonedDateTime sourceTime = sourceDate.toInstant().atZone(fromTimeZone);       
         
        //Zoned date time at target timezone
        ZonedDateTime targetTime = sourceTime.withZoneSameInstant(toTimeZone);
        return targetTime;
	}
	
	public static ZonedDateTime convertToUtcFromTimeZone(String dateToConvertStr) throws ParseException {
		Date sourceDate = sdfLong.parse(dateToConvertStr);
		ZoneId fromTimeZone = DateFunctions.getTimeZoneFromDate(dateToConvertStr);
        ZoneId toTimeZone = ZoneId.of("UTC");  //Target timezone
        
        //Zoned date time at source timezone
        ZonedDateTime sourceTime = sourceDate.toInstant().atZone(fromTimeZone);       
         
        //Zoned date time at target timezone
        ZonedDateTime targetTime = sourceTime.withZoneSameInstant(toTimeZone);
        return targetTime;
	}
	
	public static ZonedDateTime getZonedServerDate() {
		ZoneId toTimeZone = ZoneId.of("UTC");
		Date serverDate = new Date();
		ZonedDateTime zonedDateTime = serverDate.toInstant().atZone(toTimeZone);
		return zonedDateTime;
	}
}
