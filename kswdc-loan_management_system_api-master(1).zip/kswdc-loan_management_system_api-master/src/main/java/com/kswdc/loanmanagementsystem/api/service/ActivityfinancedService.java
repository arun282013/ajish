package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Activityfinanced;
import com.kswdc.loanmanagementsystem.api.value.ActivityfinancedVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface ActivityfinancedService {

    Integer createActivityfinanced(Activityfinanced activityfinanced);

    Integer updateActivityfinanced(Activityfinanced activityfinanced);

    Activityfinanced getActivityfinanced(Integer id);

    Activityfinanced getActivityfinancedByActivityfinancedName(String activityfinancedName);

    Integer deleteActivityfinanced(Integer id);

    List<ActivityfinancedVO> getActivityfinancedList();
}
