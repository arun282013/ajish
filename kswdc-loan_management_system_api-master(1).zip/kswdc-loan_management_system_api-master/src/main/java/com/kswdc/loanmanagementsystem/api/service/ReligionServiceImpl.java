package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.Religion;
import com.kswdc.loanmanagementsystem.api.repository.ReligionRepository;
import com.kswdc.loanmanagementsystem.api.value.ReligionVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class ReligionServiceImpl implements ReligionService {
	private final Logger log = LoggerFactory.getLogger(ReligionServiceImpl.class);
	
	@Autowired
	private ReligionRepository ReligionRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createReligion(Religion religion) {
		try {
			Religion savedReligion = ReligionRepository.save(religion);
			return savedReligion.getReligionId() != null ? savedReligion.getReligionId() : -1;
		} catch (Exception e) {
			log.error("Exception in ReligionServiceImpl::createReligion======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateReligion(Religion Religion) {
		try {
			Religion updateReligion = ReligionRepository.save(Religion);
			return updateReligion.getReligionId() != null ? updateReligion.getReligionId() : -1;
		} catch (Exception e) {
			log.error("Exception in ReligionServiceImpl::updateReligion======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Religion getReligion(Integer id) {
		try {
			Religion Religion = ReligionRepository.getReligionById(id);
			return Religion;
		} catch (Exception e) {
			log.error("Exception in ReligionServiceImpl::getReligion======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteReligion(Integer id) {
		try {
			Religion Religion = getReligion(id);
//			Religion.setActive(Boolean.FALSE);
			Religion.setDeletedOn(DateFunctions.getZonedServerDate());
			Religion.setIsDeleted(Constants.IS_DELETED);
			Religion updatedReligion = ReligionRepository.save(Religion);
			return updatedReligion.getReligionId() != null ? updatedReligion.getReligionId() : -1;
		} catch (Exception e) {
			log.error("Exception in ReligionServiceImpl::deleteReligion======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<ReligionVO> getReligionList() {
		try {
			List<ReligionVO> ReligionList = ReligionRepository.getReligionList();
			return ReligionList;
		} catch (Exception e) {
			log.error("Exception in ReligionServiceImpl::getReligionList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Religion getReligionByReligionName(String ReligionName) {
		try {
			Religion Religion = ReligionRepository.findByReligionName(ReligionName);
			return Religion;
		} catch (Exception e) {
			log.error("Exception in ReligionServiceImpl::getReligionByReligionName======" + e.getMessage());
		}
		return null;
	}
}