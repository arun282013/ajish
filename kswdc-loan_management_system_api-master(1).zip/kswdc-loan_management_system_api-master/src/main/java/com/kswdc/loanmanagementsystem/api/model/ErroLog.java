package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "error_log")
@EqualsAndHashCode()
public class ErroLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "EVENTNAME" , columnDefinition = "varchar(50)",nullable = false)
    private String eventName;
    
   @Column(name = "ERRORTYPE",nullable = false)
    private Integer errorType;

    @Column(name = "ERRORMESSAGE",columnDefinition = "text")
    private String errorMessage;
    
    @Column(name = "TIMESTAMP")
    private Date timeStamp;
}
