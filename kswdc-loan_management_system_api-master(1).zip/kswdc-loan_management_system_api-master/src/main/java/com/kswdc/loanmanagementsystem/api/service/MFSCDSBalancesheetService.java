package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.MFSCDSBalancesheet;
import com.kswdc.loanmanagementsystem.api.value.MFSCDSBalancesheetVO;


@Component
public interface MFSCDSBalancesheetService {

    Integer createMFSCDSBalancesheet(MFSCDSBalancesheet mfscdsbalancesheet);

    Integer updateMFSCDSBalancesheet(MFSCDSBalancesheet mfscdsbalancesheet);
    
    MFSCDSBalancesheet getMFSCDSBalancesheet(Integer id);

    Integer deleteMFSCDSBalancesheet(Integer id);
}
