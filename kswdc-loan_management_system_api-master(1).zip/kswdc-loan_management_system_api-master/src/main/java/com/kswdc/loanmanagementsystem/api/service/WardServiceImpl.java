package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.Ward;
import com.kswdc.loanmanagementsystem.api.repository.WardRepository;
import com.kswdc.loanmanagementsystem.api.value.WardVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class WardServiceImpl implements WardService {
	private final Logger log = LoggerFactory.getLogger(WardServiceImpl.class);
	
	@Autowired
	private WardRepository wardRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createWard(Ward Ward) {
		try {
			Ward savedWard = wardRepository.save(Ward);
			return savedWard.getWardId() != null ? savedWard.getWardId() : -1;
		} catch (Exception e) {
			log.error("Exception in WardServiceImpl::createWard======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateWard(Ward Ward) {
		try {
			Ward updateWard = wardRepository.save(Ward);
			return updateWard.getWardId() != null ? updateWard.getWardId() : -1;
		} catch (Exception e) {
			log.error("Exception in WardServiceImpl::updateWard======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Ward getWard(Integer id) {
		try {
			Ward ward = wardRepository.getWardById(id);
			return ward;
		} catch (Exception e) {
			log.error("Exception in WardServiceImpl::getWard======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteWard(Integer id) {
		try {
			Ward Ward = getWard(id);
//			Ward.setActive(Boolean.FALSE);
			Ward.setDeletedOn(DateFunctions.getZonedServerDate());
			Ward.setIsDeleted(Constants.IS_DELETED);
			Ward updatedWard = wardRepository.save(Ward);
			return updatedWard.getWardId() != null ? updatedWard.getWardId() : -1;
		} catch (Exception e) {
			log.error("Exception in WardServiceImpl::deleteWard======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<WardVO> getWardList() {
		try {
			List<WardVO> wardList = wardRepository.getWardList();
			return wardList;
		} catch (Exception e) {
			log.error("Exception in WardServiceImpl::getWardList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Ward getWardByWardName(String wardName) {
		try {
			Ward ward = wardRepository.findByWardName(wardName);
			return ward;
		} catch (Exception e) {
			log.error("Exception in WardServiceImpl::getWardByWardName======" + e.getMessage());
		}
		return null;
	}
}