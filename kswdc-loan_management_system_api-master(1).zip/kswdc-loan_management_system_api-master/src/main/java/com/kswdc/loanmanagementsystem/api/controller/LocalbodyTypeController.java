package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.LocalbodyType;
import com.kswdc.loanmanagementsystem.api.service.LocalbodyTypeService;
import com.kswdc.loanmanagementsystem.api.value.LocalbodyTypeVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class LocalbodyTypeController {

	private final Logger log = LoggerFactory.getLogger(LocalbodyTypeController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private LocalbodyTypeService localbodyTypeService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param LocalbodyType LocalbodyType
	 * @return Map
	 */
	@RequestMapping(value = "/localbodyType", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createLocalbodyType(@RequestBody LocalbodyType LocalbodyType) {
		log.info("In LocalbodyTypeController::createLocalbodyType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(LocalbodyType)) {
//						LocalbodyType.setActive(Boolean.TRUE);
						LocalbodyType.setCreatedOn(DateFunctions.getZonedServerDate());
						// LocalbodyType.setCreatedBy();
						LocalbodyType.setIsDeleted(0);
						Integer LocalbodyTypeId = localbodyTypeService.createLocalbodyType(LocalbodyType);
						if (!LocalbodyTypeId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("LocalbodyTypeId", LocalbodyTypeId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LocalbodyTypeController::createLocalbodyType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param LocalbodyType LocalbodyType
	 * @return Map
	 */
	@RequestMapping(value = "/localbodyType", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateLocalbodyType(@RequestBody LocalbodyType localbodyType) {
		log.info("In LocalbodyTypeController::updateLocalbodyType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (localbodyType != null) { // && LocalbodyType.getId() != null
				if (checkValid(localbodyType)) {
					LocalbodyType chkLocalbodyType = localbodyTypeService.getLocalbodyType(localbodyType.getLocalbodyTypeId());
					if (chkLocalbodyType!=null) {
//						if (chkLocalbodyType.getActive()) {
//							LocalbodyType.setActive(Boolean.TRUE);
							chkLocalbodyType.setLocalbodyTypeName(localbodyType.getLocalbodyTypeName());							
							chkLocalbodyType.setIsActive(localbodyType.getIsActive());							
							Integer LocalbodyTypeId = localbodyTypeService.updateLocalbodyType(chkLocalbodyType);
							if (!LocalbodyTypeId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("LocalbodyTypeId:", LocalbodyTypeId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" LocalbodyType Id is deactivated:"+LocalbodyType.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LocalbodyTypeController::updateLocalbodyType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/localbodyType/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteLocalbodyType(@PathVariable Integer id) {
		log.info("In LocalbodyTypeController::deleteLocalbodyType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				LocalbodyType LocalbodyType = localbodyTypeService.getLocalbodyType(id);
				if (LocalbodyType != null) {
//					if (!LocalbodyType.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " LocalbodyTypeId:" + id);
//					} else {
						Integer LocalbodyTypeId = localbodyTypeService.deleteLocalbodyType(id);
						if (!LocalbodyTypeId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("LocalbodyTypeId", LocalbodyTypeId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LocalbodyTypeController::deleteLocalbodyType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/localbodyType/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneLocalbodyType(@PathVariable Integer id) {
		log.info("In LocalbodyTypeController::getOneLocalbodyType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				LocalbodyType LocalbodyType = localbodyTypeService.getLocalbodyType(id);
				if (LocalbodyType != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("LocalbodyType", LocalbodyType);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LocalbodyTypeController::getOneLocalbodyType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- LocalbodyType ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/localbodyType-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getLocalbodyTypeList() {
		log.info("In LocalbodyTypeController::getLocalbodyTypeList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			LocalbodyTypeListReturnVO LocalbodyTypeListReturnVO = new LocalbodyTypeListReturnVO(LocalbodyTypeService.getLocalbodyTypeList());
			List<LocalbodyTypeVO> LocalbodyTypeListReturnVO = localbodyTypeService.getLocalbodyTypeList();
			if (LocalbodyTypeListReturnVO != null && LocalbodyTypeListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("localbodyTypes", LocalbodyTypeListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LocalbodyTypeController::getLocalbodyTypeList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param LocalbodyTypeId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer LocalbodyTypeId) {
		return (localbodyTypeService.getLocalbodyType(LocalbodyTypeId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param LocalbodyType
	 * @return Boolean
	 */
	private Boolean checkValid(LocalbodyType LocalbodyType) {
		Boolean isValid = true;
		invalidMsg = "";
		if (LocalbodyType != null) {
//			if(LocalbodyType.getId()==null || LocalbodyType.getId()<=0) {
//				invalidMsg+="LocalbodyTypeId is required and should be valid!";
//				isValid = false;
//			}
			if (LocalbodyType.getLocalbodyTypeName() == null || LocalbodyType.getLocalbodyTypeName().equalsIgnoreCase("")) {
				invalidMsg += "LocalbodyType Name is required and should not be empty!";
				isValid = false;
			}
//			if (LocalbodyType.getLocalbodyTypeName() == null || LocalbodyType.getLocalbodyTypeName().equalsIgnoreCase("")) {
//				invalidMsg += "LocalbodyType Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (LocalbodyType.getQuotaInMB() == null || LocalbodyType.getQuotaInMB().equals(0) || LocalbodyType.getQuotaInMB()<0) {
//				invalidMsg += "LocalbodyType Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (LocalbodyType.getChatHistoryDays() == null || LocalbodyType.getChatHistoryDays().equals(0) || LocalbodyType.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for LocalbodyType is required and should be valid!";
//				isValid = false;
//			}
//			if (LocalbodyType.getCdaTimeoutTime() == null || LocalbodyType.getCdaTimeoutTime().equals(0) || LocalbodyType.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for LocalbodyType!";
			isValid = false;
		}
		return isValid;
	}
	
}
