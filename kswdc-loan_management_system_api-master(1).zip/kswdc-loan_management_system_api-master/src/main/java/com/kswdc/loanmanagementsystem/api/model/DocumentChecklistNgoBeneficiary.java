package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_document_checklistngo_beneficiary")
@EqualsAndHashCode()
public class DocumentChecklistNgoBeneficiary{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DOC_CHECKLISTNGO_BENEFICIARY_ID")
    private Integer docChecklistngoBeneficiaryId;

    @ManyToOne()
    @JoinColumn(name= "DOCUMENT_CHECKLISTNGO_ID")
    private DocumentChecklistNgo documentChecklistngoObj;

    @ManyToOne()
    @JoinColumn(name= "MFSNGO_LOAN_ID")
    private MFSNGOLoan mfsngoLoanObj;

    @ManyToOne()
    @JoinColumn(name= "LOANTYPE_ID")
    private LoanType loanTypeObj;

    @Column(name = "FILE_PATH", columnDefinition = "varchar(300) not null")
    private String filePath;
}
