package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.LoanType;
import com.kswdc.loanmanagementsystem.api.value.LoanTypeVO;

@Repository
public interface LoanTypeRepository extends JpaRepository<LoanType, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.LoanTypeVO(o.loantypeId,o.loantypeCode,"+
      " o.loantypeName,o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM LoanType o LEFT JOIN User u ON o.createdBy=u.userId LEFT JOIN User mu ON o.createdBy=mu.userId "+
            " WHERE o.isDeleted=0 ORDER BY o.loantypeName ASC")
   List<LoanTypeVO> getLoanTypeList();//Filter only active loanTypes
    
    @Query("SELECT a from LoanType a WHERE a.id=:loanTypeId")
    LoanType getLoanTypeById(@Param("loanTypeId") Integer loanTypeId);

    @Query("SELECT cl FROM LoanType cl WHERE cl.loantypeName=:loanTypeName")
    LoanType findByLoanTypeName(@Param("loanTypeName") String loanTypeName);
}
