package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistNgo;
import com.kswdc.loanmanagementsystem.api.service.DocumentChecklistngoService;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistNgoVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;


@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class DocumentChecklistNgoController {

	private final Logger log = LoggerFactory.getLogger(DocumentChecklistNgoController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private DocumentChecklistngoService documentChecklistngoService;
	
	/**
	 * @param DocumentChecklist DocumentChecklist
	 * @return Map
	 */
	@RequestMapping(value = "/documentChecklistngo", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createDocumentChecklistngo(@RequestBody DocumentChecklistNgo DocumentChecklistngo) {
		log.info("In DocumentChecklistController::createDocumentChecklist=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(DocumentChecklistngo)) {
//						LoanCategory.setActive(Boolean.TRUE);
						DocumentChecklistngo.setCreatedOn(DateFunctions.getZonedServerDate());
						// LoanCategory.setCreatedBy();
						DocumentChecklistngo.setIsDeleted(0);
						Integer DocumentChecklistId = documentChecklistngoService.createDocumentChecklistngo(DocumentChecklistngo);
						if (!DocumentChecklistId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("DocumentChecklistId", DocumentChecklistId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistController::createDocumentChecklist======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * //@param DocumentChecklist DocumentChecklist
	 * @return Map
	 */
	@RequestMapping(value = "/documentChecklistngo", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateDocumentChecklistngo(@RequestBody DocumentChecklistNgo documentChecklistngo) {
		log.info("In DocumentChecklistController::updateDocumentChecklist=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (documentChecklistngo != null) { // && DocumentChecklist.getId() != null
				if (checkValid(documentChecklistngo)) {
					DocumentChecklistNgo chkDocumentChecklistngo = documentChecklistngoService.getDocumentChecklistngo(documentChecklistngo.getDocumentchecklistngoId());
					if (chkDocumentChecklistngo!=null) {
//						if (chkLoanCategory.getActive()) {
//							LoanCategory.setActive(Boolean.TRUE);
							chkDocumentChecklistngo.setDocumentchecklistngoName(chkDocumentChecklistngo.getDocumentchecklistngoName());							
							chkDocumentChecklistngo.setIsActive(documentChecklistngo.getIsActive());							
							Integer DocumentChecklistngoId = documentChecklistngoService.updateDocumentChecklistngo(chkDocumentChecklistngo);
							if (!DocumentChecklistngoId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("DocumentChecklistngoId:", DocumentChecklistngoId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" LoanCategory Id is deactivated:"+LoanCategory.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistController::updateDocumentChecklist======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/documentChecklistngo/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteDocumentChecklistngo(@PathVariable Integer id) {
		log.info("In DocumentChecklistController::deleteDocumentChecklist=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				DocumentChecklistNgo DocumentChecklistngo = documentChecklistngoService.getDocumentChecklistngo(id);
				if (DocumentChecklistngo != null) {
//					if (!LoanCategory.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " LoanCategoryId:" + id);
//					} else {
						Integer DocumentChecklistngoId = documentChecklistngoService.deleteDocumentChecklistngo(id);
						if (!DocumentChecklistngoId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("DocumentChecklistngoId", DocumentChecklistngoId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistController::deleteDocumentChecklist======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/documentChecklistngo/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneDocumentChecklistngo(@PathVariable Integer id) {
		log.info("In DocumentChecklistController::getOneDocumentChecklist=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				DocumentChecklistNgo DocumentChecklistngo = documentChecklistngoService.getDocumentChecklistngo(id);
				if (DocumentChecklistngo != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("DocumentChecklistngo", DocumentChecklistngo);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistController::getOneDocumentChecklist======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- LoanCategory ------------------------------

	/**
	 * @return Map
	 */
	@RequestMapping(value = "/documentChecklist-listngo", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getDocumentChecklistListngo() {
		log.info("In DocumentChecklistNgoController::DocumentChecklistListngo=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			LoanCategoryListReturnVO LoanCategoryListReturnVO = new LoanCategoryListReturnVO(LoanCategoryService.getLoanCategoryList());
			List<DocumentChecklistNgoVO> DocumentChecklistListReturnVO = documentChecklistngoService.getDocumentChecklistListngo();
			if (DocumentChecklistListReturnVO != null && DocumentChecklistListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("documentChecklists", DocumentChecklistListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistNgoController::getDocumentChecklistListngo======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// sreelekshmi 26.02.2022

	@RequestMapping(value = "/documentchecklist-list-by-loantypengo/{loantypeId}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getDocumentChecklistListByLoanType(@PathVariable Integer loantypeId) {
		log.info("In DocumentChecklistController::getDocumentChecklistListByLoanType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			List<DocumentChecklistNgoVO> DocumentChecklistListReturnVO = documentChecklistngoService.getDocumentChecklistListngoByLoanType(loantypeId);
			if (DocumentChecklistListReturnVO != null && DocumentChecklistListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("documentchecklists", DocumentChecklistListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();	
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistController::getDocumentChecklistListByLoanType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param DocumentChecklistId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer DocumentChecklistngoId) {
		return (documentChecklistngoService.getDocumentChecklistngo(DocumentChecklistngoId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @purpose For checking if mandatory data is passed
	 * @param DocumentChecklist
	 * @return Boolean
	 */
	private Boolean checkValid(DocumentChecklistNgo DocumentChecklistngo) {
		Boolean isValid = true;
		invalidMsg = "";
		if (DocumentChecklistngo != null) {
//			if(LoanCategory.getId()==null || LoanCategory.getId()<=0) {
//				invalidMsg+="LoanCategoryId is required and should be valid!";
//				isValid = false;
//			}
			if (DocumentChecklistngo.getDocumentchecklistngoName() == null || DocumentChecklistngo.getDocumentchecklistngoName().equalsIgnoreCase("")) {
				invalidMsg += "DocumentChecklist Name is required and should not be empty!";
				isValid = false;
			}
//			if (LoanCategory.getLoanCategoryName() == null || LoanCategory.getLoanCategoryName().equalsIgnoreCase("")) {
//				invalidMsg += "LoanCategory Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (LoanCategory.getQuotaInMB() == null || LoanCategory.getQuotaInMB().equals(0) || LoanCategory.getQuotaInMB()<0) {
//				invalidMsg += "LoanCategory Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanCategory.getChatHistoryDays() == null || LoanCategory.getChatHistoryDays().equals(0) || LoanCategory.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for LoanCategory is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanCategory.getCdaTimeoutTime() == null || LoanCategory.getCdaTimeoutTime().equals(0) || LoanCategory.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for DocumentChecklist!";
			isValid = false;
		}
		return isValid;
	}
	
}
