package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentChecklistBeneficiaryVO implements Serializable {
    private Integer docChecklistBeneficiaryId;
    private String documentChecklistName;
    private String termLoanFullname;
    private String loanTypeName;
    private String filePath;
    private Integer loanTypeId;

    public DocumentChecklistBeneficiaryVO(Integer docChecklistBeneficiaryId, String documentChecklistName,
            String termLoanFullname, Integer loanTypeId, String loanTypeName, String filePath) {
        this.docChecklistBeneficiaryId = docChecklistBeneficiaryId;
        this.documentChecklistName = documentChecklistName;
        this.termLoanFullname = termLoanFullname;
        this.loanTypeId = loanTypeId;
        this.loanTypeName = loanTypeName;
        this.filePath = filePath;
    }

}
