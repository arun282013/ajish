package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistBeneficiary;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistBeneficiaryVO;

@Repository
public interface DocumentChecklistBeneficiaryRepository extends JpaRepository<DocumentChecklistBeneficiary, Integer> {
        @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.DocumentChecklistBeneficiaryVO(cb.docChecklistBeneficiaryId,dc.documentchecklistName,"
                        +
                        "tl.fullName,l.loantypeId,l.loantypeName,cb.filePath) " +
                        "FROM DocumentChecklistBeneficiary cb LEFT JOIN DocumentChecklist dc on cb.documentChecklistObj=dc.documentchecklistId "
                        +
                        "LEFT JOIN TermLoan tl ON cb.termLoanObj=tl.termLoanId LEFT JOIN LoanType l ON cb.loanTypeObj=l.loantypeId "
                        +
                        "ORDER BY cb.docChecklistBeneficiaryId ASC")
        List<DocumentChecklistBeneficiaryVO> getDocumentChecklistBeneficiaryList();// Filter only active data

        @Query("SELECT a from DocumentChecklistBeneficiary a WHERE a.id=:docChecklistBeneficiaryId")
        DocumentChecklistBeneficiary getDocumentChecklistBeneficiaryById(
                        @Param("docChecklistBeneficiaryId") Integer docChecklistBeneficiaryId);

        @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.DocumentChecklistBeneficiaryVO(cb.docChecklistBeneficiaryId,dc.documentchecklistName,"
                        +
                        "tl.fullName,l.loantypeId, l.loantypeName,cb.filePath) " +
                        "FROM DocumentChecklistBeneficiary cb LEFT JOIN DocumentChecklist dc on cb.documentChecklistObj=dc.documentchecklistId "
                        +
                        "LEFT JOIN TermLoan tl ON cb.termLoanObj=tl.termLoanId LEFT JOIN LoanType l ON cb.loanTypeObj=l.loantypeId "
                        +
                        " WHERE cb.id=:docChecklistBeneficiaryId")
        DocumentChecklistBeneficiaryVO getDocumentChecklistBeneficiaryVOById(
                        @Param("docChecklistBeneficiaryId") Integer docChecklistBeneficiaryId);

        // @Query("SELECT a from DocumentChecklistBeneficiary a LEFT JOIN TermLoan t ON
        // a.termLoanObj=t.termLoanId WHERE t.termLoanId=:termLoanId")
        // List<DocumentChecklistBeneficiary>
        // getDocumentChecklistBeneficiaryByTermLoanId(
        // @Param("termLoanId") Integer termLoanId);

        @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.DocumentChecklistBeneficiaryVO(cb.docChecklistBeneficiaryId,dc.documentchecklistName,"
                        +
                        "tl.fullName,l.loantypeId,l.loantypeName,cb.filePath) " +
                        "FROM DocumentChecklistBeneficiary cb LEFT JOIN DocumentChecklist dc on cb.documentChecklistObj=dc.documentchecklistId "
                        +
                        "LEFT JOIN TermLoan tl ON cb.termLoanObj=tl.termLoanId LEFT JOIN LoanType l ON cb.loanTypeObj=l.loantypeId "
                        +
                        "WHERE tl.termLoanId=:termLoanId ORDER BY cb.docChecklistBeneficiaryId ASC")
        List<DocumentChecklistBeneficiaryVO> getDocumentChecklistBeneficiaryByTermLoanId(
                        @Param("termLoanId") Integer termLoanId);

        // @Query("SELECT cl FROM LoanDocumentChecklist cl WHERE cl.userName=:userName")
        // LoanDocumentChecklist findByLoanDocumentChecklistName(@Param("userName")
        // String userName);
}
