package com.kswdc.loanmanagementsystem.api.value;

import lombok.Data;

@Data
public class ApiResult {

	private String status;
	private String message;
	private String errorCode;
	
}
