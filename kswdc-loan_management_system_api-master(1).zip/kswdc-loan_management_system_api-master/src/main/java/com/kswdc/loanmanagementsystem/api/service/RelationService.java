package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Relation;
import com.kswdc.loanmanagementsystem.api.value.RelationVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface RelationService {

    Integer createRelation(Relation relation);

    Integer updateRelation(Relation relation);

    Relation getRelation(Integer id);

    Relation getRelationByRelationName(String relationName);

    Integer deleteRelation(Integer id);

    List<RelationVO> getRelationList();
}
