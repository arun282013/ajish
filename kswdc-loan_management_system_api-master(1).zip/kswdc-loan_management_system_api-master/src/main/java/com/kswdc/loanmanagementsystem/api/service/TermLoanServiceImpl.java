package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.TermLoan;
import com.kswdc.loanmanagementsystem.api.repository.TermLoanRepository;
import com.kswdc.loanmanagementsystem.api.value.TermLoanVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class TermLoanServiceImpl implements TermLoanService {
	private final Logger log = LoggerFactory.getLogger(TermLoanServiceImpl.class);

	@Autowired
	private TermLoanRepository termloanRepository;

	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createTermLoan(TermLoan TermLoan) {
		try {
			TermLoan savedTermLoan = termloanRepository.save(TermLoan);
			return savedTermLoan.getTermLoanId() != null ? savedTermLoan.getTermLoanId() : -1;
		} catch (Exception e) {
			log.error("Exception in TermLoanServiceImpl::createTermLoan======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateTermLoan(TermLoan TermLoan) {
		try {
			TermLoan updateTermLoan = termloanRepository.save(TermLoan);
			return updateTermLoan.getTermLoanId() != null ? updateTermLoan.getTermLoanId() : -1;
		} catch (Exception e) {
			log.error("Exception in TermLoanServiceImpl::updateTermLoan======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateSecondTabTermLoan(TermLoan TermLoan) {
		try {
			TermLoan updateSecondTabTermLoan = termloanRepository.save(TermLoan);
			return updateSecondTabTermLoan.getTermLoanId() != null ? updateSecondTabTermLoan.getTermLoanId() : -1;
		} catch (Exception e) {
			log.error("Exception in TermLoanServiceImpl::updateSecondTabTermLoan======" + e.getMessage());
		}
		return null;
	}

	@Override
	public TermLoan getTermLoan(Integer id) {
		try {
			TermLoan termloan = termloanRepository.getTermLoanById(id);
			return termloan;
		} catch (Exception e) {
			log.error("Exception in TermLoanServiceImpl::getTermLoan======" + e.getMessage());
		}
		return null;
	}

	@Override
	public TermLoanVO getTermLoanByUser(Integer userId) {
		try {
			TermLoanVO termloan = termloanRepository.getTermLoanByUserId(userId);
			return termloan;
		} catch (Exception e) {
			log.error("Exception in TermLoanServiceImpl::getTermLoanByUser======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteTermLoan(Integer id) {
		try {
			TermLoan TermLoan = getTermLoan(id);
			// TermLoan.setActive(Boolean.FALSE);
			TermLoan.setDeletedOn(DateFunctions.getZonedServerDate());
			TermLoan.setIsDeleted(Constants.IS_DELETED);
			TermLoan updatedTermLoan = termloanRepository.save(TermLoan);
			return updatedTermLoan.getTermLoanId() != null ? updatedTermLoan.getTermLoanId() : -1;
		} catch (Exception e) {
			log.error("Exception in TermLoanServiceImpl::deleteTermLoan======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<TermLoanVO> getTermLoanList() {
		try {
			List<TermLoanVO> termloanList = termloanRepository.getTermLoanList();
			return termloanList;
		} catch (Exception e) {
			log.error("Exception in TermLoanServiceImpl::getTermLoanList======" + e.getMessage());
		}
		return null;
	}

	// @Override
	// public TermLoan getTermLoanByTermLoanName(String termloanName) {
	// try {
	// TermLoan termloan = termloanRepository.findByTermLoanName(termloanName);
	// return termloan;
	// } catch (Exception e) {
	// log.error("Exception in TermLoanServiceImpl::getTermLoanByTermLoanName======"
	// + e.getMessage());
	// }
	// return null;
	// }
	// -modal view
	@Override
	public TermLoanVO getPreviewTermLoan(Integer termLoanId) {
		try {
			TermLoanVO termloan = termloanRepository.getPreviewTermLoanById(termLoanId);
			return termloan;
		} catch (Exception e) {
			log.error("Exception in TermLoanServiceImpl::getPreviewTermLoan======" + e.getMessage());
		}
		return null;
	}
	// -modal view

	//--for photo
	@Override
	public Integer updatePhotoTermLoan(TermLoan TermLoan) {
		try {
			TermLoan updatePhotoTermLoan = termloanRepository.save(TermLoan);
			return updatePhotoTermLoan.getTermLoanId() != null ? updatePhotoTermLoan.getTermLoanId() : -1;
		} catch (Exception e) {
			log.error("Exception in TermLoanServiceImpl::updatePhotoTermLoan======" + e.getMessage());
		}
		return null;
	}
	
	@Override
	public TermLoanVO getTermLoanVOPhotoById(Integer id) {
		try {
			TermLoanVO termLoan = termloanRepository.getTermLoanVOPhotoById(id);
			return termLoan;
		} catch (Exception e) {
			log.error("Exception in TermLoanServiceImpl::getTermLoanVO======"
					+ e.getMessage());
		}
		return null;
	}
	//--for sign
	@Override
	public Integer updateSignTermLoan(TermLoan TermLoan) {
		try {
			TermLoan updateSignTermLoan = termloanRepository.save(TermLoan);
			return updateSignTermLoan.getTermLoanId() != null ? updateSignTermLoan.getTermLoanId() : -1;
		} catch (Exception e) {
			log.error("Exception in TermLoanServiceImpl::updateSignTermLoan======" + e.getMessage());
		}
		return null;
	}
	
	// @Override
	// public TermLoanVO getTermLoanVOSignById(Integer id) {
	// 	try {
	// 		TermLoanVO termLoan = termloanRepository.getTermLoanVOPhotoById(id);
	// 		return termLoan;
	// 	} catch (Exception e) {
	// 		log.error("Exception in TermLoanServiceImpl::getTermLoanVOSignById======"
	// 				+ e.getMessage());
	// 	}
	// 	return null;
	// }
}