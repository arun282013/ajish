package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.Activityfinanced;
import com.kswdc.loanmanagementsystem.api.service.ActivityfinancedService;
import com.kswdc.loanmanagementsystem.api.value.ActivityfinancedVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class ActivityfinancedController {

	private final Logger log = LoggerFactory.getLogger(ActivityfinancedController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private ActivityfinancedService activityfinancedService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param Activityfinanced Activityfinanced
	 * @return Map
	 */
	@RequestMapping(value = "/activityfinanced", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createActivityfinanced(@RequestBody Activityfinanced Activityfinanced) {
		log.info("In ActivityfinancedController::createActivityfinanced=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(Activityfinanced)) {
//						Activityfinanced.setActive(Boolean.TRUE);
						Activityfinanced.setCreatedOn(DateFunctions.getZonedServerDate());
						// Activityfinanced.setCreatedBy();
						Activityfinanced.setIsDeleted(0);
						Integer ActivityfinancedId = activityfinancedService.createActivityfinanced(Activityfinanced);
						if (!ActivityfinancedId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("ActivityfinancedId", ActivityfinancedId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in ActivityfinancedController::createActivityfinanced======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param Activityfinanced Activityfinanced
	 * @return Map
	 */
	@RequestMapping(value = "/activityfinanced", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateActivityfinanced(@RequestBody Activityfinanced activityfinanced) {
		log.info("In ActivityfinancedController::updateActivityfinanced=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (activityfinanced != null) { // && Activityfinanced.getId() != null
				if (checkValid(activityfinanced)) {
					Activityfinanced chkActivityfinanced = activityfinancedService.getActivityfinanced(activityfinanced.getActivityfinancedId());
					if (chkActivityfinanced!=null) {
//						if (chkActivityfinanced.getActive()) {
//							Activityfinanced.setActive(Boolean.TRUE);
							chkActivityfinanced.setActivityfinancedName(activityfinanced.getActivityfinancedName());							
							chkActivityfinanced.setIsActive(activityfinanced.getIsActive());							
							Integer ActivityfinancedId = activityfinancedService.updateActivityfinanced(chkActivityfinanced);
							if (!ActivityfinancedId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("ActivityfinancedId:", ActivityfinancedId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" Activityfinanced Id is deactivated:"+Activityfinanced.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in ActivityfinancedController::updateActivityfinanced======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/activityfinanced/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteActivityfinanced(@PathVariable Integer id) {
		log.info("In ActivityfinancedController::deleteActivityfinanced=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Activityfinanced Activityfinanced = activityfinancedService.getActivityfinanced(id);
				if (Activityfinanced != null) {
//					if (!Activityfinanced.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " ActivityfinancedId:" + id);
//					} else {
						Integer ActivityfinancedId = activityfinancedService.deleteActivityfinanced(id);
						if (!ActivityfinancedId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("ActivityfinancedId", ActivityfinancedId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in ActivityfinancedController::deleteActivityfinanced======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/activityfinanced/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneActivityfinanced(@PathVariable Integer id) {
		log.info("In ActivityfinancedController::getOneActivityfinanced=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Activityfinanced Activityfinanced = activityfinancedService.getActivityfinanced(id);
				if (Activityfinanced != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("Activityfinanced", Activityfinanced);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in ActivityfinancedController::getOneActivityfinanced======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- Activityfinanced ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/activityfinanced-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getActivityfinancedList() {
		log.info("In ActivityfinancedController::getActivityfinancedList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			ActivityfinancedListReturnVO ActivityfinancedListReturnVO = new ActivityfinancedListReturnVO(ActivityfinancedService.getActivityfinancedList());
			List<ActivityfinancedVO> ActivityfinancedListReturnVO = activityfinancedService.getActivityfinancedList();
			if (ActivityfinancedListReturnVO != null && ActivityfinancedListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("activityfinanceds", ActivityfinancedListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in ActivityfinancedController::getActivityfinancedList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param ActivityfinancedId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer ActivityfinancedId) {
		return (activityfinancedService.getActivityfinanced(ActivityfinancedId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param Activityfinanced
	 * @return Boolean
	 */
	private Boolean checkValid(Activityfinanced Activityfinanced) {
		Boolean isValid = true;
		invalidMsg = "";
		if (Activityfinanced != null) {
//			if(Activityfinanced.getId()==null || Activityfinanced.getId()<=0) {
//				invalidMsg+="ActivityfinancedId is required and should be valid!";
//				isValid = false;
//			}
			if (Activityfinanced.getActivityfinancedName() == null || Activityfinanced.getActivityfinancedName().equalsIgnoreCase("")) {
				invalidMsg += "Activityfinanced Name is required and should not be empty!";
				isValid = false;
			}
//			if (Activityfinanced.getActivityfinancedName() == null || Activityfinanced.getActivityfinancedName().equalsIgnoreCase("")) {
//				invalidMsg += "Activityfinanced Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (Activityfinanced.getQuotaInMB() == null || Activityfinanced.getQuotaInMB().equals(0) || Activityfinanced.getQuotaInMB()<0) {
//				invalidMsg += "Activityfinanced Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (Activityfinanced.getChatHistoryDays() == null || Activityfinanced.getChatHistoryDays().equals(0) || Activityfinanced.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for Activityfinanced is required and should be valid!";
//				isValid = false;
//			}
//			if (Activityfinanced.getCdaTimeoutTime() == null || Activityfinanced.getCdaTimeoutTime().equals(0) || Activityfinanced.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for Activityfinanced!";
			isValid = false;
		}
		return isValid;
	}
	
}
