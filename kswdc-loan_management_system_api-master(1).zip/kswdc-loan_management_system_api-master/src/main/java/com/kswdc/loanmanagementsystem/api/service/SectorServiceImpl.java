package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.Sector;
import com.kswdc.loanmanagementsystem.api.repository.SectorRepository;
import com.kswdc.loanmanagementsystem.api.value.SectorVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class SectorServiceImpl implements SectorService {
	private final Logger log = LoggerFactory.getLogger(SectorServiceImpl.class);
	
	@Autowired
	private SectorRepository sectorRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createSector(Sector Sector) {
		try {
			Sector savedSector = sectorRepository.save(Sector);
			return savedSector.getSectorId() != null ? savedSector.getSectorId() : -1;
		} catch (Exception e) {
			log.error("Exception in SectorServiceImpl::createSector======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateSector(Sector Sector) {
		try {
			Sector updateSector = sectorRepository.save(Sector);
			return updateSector.getSectorId() != null ? updateSector.getSectorId() : -1;
		} catch (Exception e) {
			log.error("Exception in SectorServiceImpl::updateSector======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Sector getSector(Integer id) {
		try {
			Sector sector = sectorRepository.getSectorById(id);
			return sector;
		} catch (Exception e) {
			log.error("Exception in SectorServiceImpl::getSector======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteSector(Integer id) {
		try {
			Sector Sector = getSector(id);
//			Sector.setActive(Boolean.FALSE);
			Sector.setDeletedOn(DateFunctions.getZonedServerDate());
			Sector.setIsDeleted(Constants.IS_DELETED);
			Sector updatedSector = sectorRepository.save(Sector);
			return updatedSector.getSectorId() != null ? updatedSector.getSectorId() : -1;
		} catch (Exception e) {
			log.error("Exception in SectorServiceImpl::deleteSector======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<SectorVO> getSectorList() {
		try {
			List<SectorVO> sectorList = sectorRepository.getSectorList();
			return sectorList;
		} catch (Exception e) {
			log.error("Exception in SectorServiceImpl::getSectorList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Sector getSectorBySectorName(String sectorName) {
		try {
			Sector sector = sectorRepository.findBySectorName(sectorName);
			return sector;
		} catch (Exception e) {
			log.error("Exception in SectorServiceImpl::getSectorBySectorName======" + e.getMessage());
		}
		return null;
	}
}