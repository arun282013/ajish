package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PostofficeVO implements Serializable {

    private Integer postofficeId;
    private String postofficeName;
    private String districtName;
    private  String pincode;
    private ZonedDateTime createdOn;
    private String createdBy;
    private ZonedDateTime modifiedOn;
    private String modifiedBy;
    private Integer isDeleted;
    private ZonedDateTime deletedOn;
    private String deletedStr;
    private Integer isActive;
    private String activeStr;


    public PostofficeVO(Integer postofficeId,String postofficeName, String districtName, 
         String pincode, ZonedDateTime createdOn, String createdBy, 
        ZonedDateTime modifiedOn, String modifiedBy, Integer isDeleted, 
      ZonedDateTime deletedOn, Integer isActive) {
        this.postofficeId = postofficeId;
        this.postofficeName = postofficeName;
        this.districtName = districtName;
        this.pincode = pincode;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.modifiedOn = modifiedOn;
        this.modifiedBy = modifiedBy;
        this.isDeleted = isDeleted;
        this.deletedOn = deletedOn;
        this.deletedStr = isDeleted.equals(1)?Constants.IS_DELETED_STR:Constants.IS_NOT_DELETED_STR;
        this.isActive = isActive;
        this.activeStr = isActive.equals(1)?Constants.IS_ACTIVE_STR:Constants.IS_NOT_ACTIVE_STR;
    }
    
}
