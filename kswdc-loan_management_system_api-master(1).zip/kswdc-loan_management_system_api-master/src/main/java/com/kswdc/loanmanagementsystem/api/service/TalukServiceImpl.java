package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.Taluk;
import com.kswdc.loanmanagementsystem.api.repository.TalukRepository;
import com.kswdc.loanmanagementsystem.api.value.TalukVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class TalukServiceImpl implements TalukService {
	private final Logger log = LoggerFactory.getLogger(TalukServiceImpl.class);
	
	@Autowired
	private TalukRepository talukRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createTaluk(Taluk Taluk) {
		try {
			Taluk savedTaluk = talukRepository.save(Taluk);
			return savedTaluk.getTalukId() != null ? savedTaluk.getTalukId() : -1;
		} catch (Exception e) {
			log.error("Exception in TalukServiceImpl::createTaluk======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateTaluk(Taluk Taluk) {
		try {
			Taluk updateTaluk = talukRepository.save(Taluk);
			return updateTaluk.getTalukId() != null ? updateTaluk.getTalukId() : -1;
		} catch (Exception e) {
			log.error("Exception in TalukServiceImpl::updateTaluk======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Taluk getTaluk(Integer id) {
		try {
			Taluk taluk = talukRepository.getTalukById(id);
			return taluk;
		} catch (Exception e) {
			log.error("Exception in TalukServiceImpl::getTaluk======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteTaluk(Integer id) {
		try {
			Taluk Taluk = getTaluk(id);
//			Taluk.setActive(Boolean.FALSE);
			Taluk.setDeletedOn(DateFunctions.getZonedServerDate());
			Taluk.setIsDeleted(Constants.IS_DELETED);
			Taluk updatedTaluk = talukRepository.save(Taluk);
			return updatedTaluk.getTalukId() != null ? updatedTaluk.getTalukId() : -1;
		} catch (Exception e) {
			log.error("Exception in TalukServiceImpl::deleteTaluk======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<TalukVO> getTalukList() {
		try {
			List<TalukVO> talukList = talukRepository.getTalukList();
			return talukList;
		} catch (Exception e) {
			log.error("Exception in TalukServiceImpl::getTalukList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<TalukVO> getTalukListByDistrict(Integer districtId) {
		try {
			List<TalukVO> talukList = talukRepository.getTalukListByDistrict(districtId);
			return talukList;
		} catch (Exception e) {
			log.error("Exception in TalukServiceImpl::getTalukListByDistrict======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Taluk getTalukByTalukName(String talukName) {
		try {
			Taluk taluk = talukRepository.findByTalukName(talukName);
			return taluk;
		} catch (Exception e) {
			log.error("Exception in TalukServiceImpl::getTalukByTalukName======" + e.getMessage());
		}
		return null;
	}
}