package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.MFSCDSLoan;
import com.kswdc.loanmanagementsystem.api.value.MFSCDSLoanVO;

@Repository
public interface MFSCDSLoanRepository extends JpaRepository<MFSCDSLoan, Integer> {
  @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.MFSCDSLoanVO(m.mfscdsLoanId, ur.fullName, lc.loanCategoryName, lt.loantypeName, "
      +
      " m.cdsName, m.cdshouseName, m.cdshouseNo, cdsd.districtName, cdst.talukName, m.cdslocationtypeId, cdslt.localbodyTypeName, cdsl.localbodyName, "
      +
      " m.cdsLocation, cdsp.postofficeName, m.cdsPincode, m.cdsemailId, m.cdspanNo, m.cdsregNo, "
      +
      " m.cdsregYear, m.cdscpName, m.cdscpPhoneNo, m.cdssecName, m.cdssecPhoneNo, " 
      +
      " m.cdscpAadharNo, m.cdssecAadharNo, m.cdscphouseName, m.cdscphouseNo, cdscpd.districtName, cdscpt.talukName, m.cdscplocationtypeId, cdscplbt.localbodyTypeName, "
      +
      " cdscplb.localbodyName, m.cdscpLocation, cdscpp.postofficeName, m.cdscpPincode, m.cdssechouseName, m.cdssechouseNo, "
      +
      " cdssd.districtName, cdsst.talukName, m.cdsseclocationtypeId, cdsslbt.localbodyTypeName, " 
      +
      " cdsslb.localbodyName, m.cdssecLocation, cdssp.postofficeName, m.cdssecPincode, m.meunitsoneyearCount, m.meunitsoneyearaboveCount, "
      +
      " m.meunitstotalCount, m.cdsprojectName, m.cdsloanAmount, m.cdsapplicationStatus, "
      +
       " m.enteredOn, m.createdOn, u.fullName, m.modifiedOn, mu.fullName, m.isDeleted, m.deletedOn, m.isActive) "
      + 
      " FROM MFSCDSLoan m LEFT JOIN User ur ON m.userObj = ur.userId LEFT JOIN LoanCategory lc ON m.loanCategoryObj = lc.loanCategoryId "
      +
      " LEFT JOIN LoanType lt ON m.loantypeObj = lt.loantypeId LEFT JOIN District cdsd ON m.cdsdistrictObj = cdsd.districtId "
      +
      " LEFT JOIN Taluk cdst ON m.cdstalukObj = cdst.talukId LEFT JOIN LocalbodyType cdslt ON m.cdslocalbodytypeObj = cdslt.localbodyTypeId " 
      + 
      " LEFT JOIN LocalBody cdsl ON m.cdslocalbodyObj = cdsl.localbodyId LEFT JOIN Postoffice cdsp ON m.cdspostofficeObj = cdsp.postofficeId "
      +
      " LEFT JOIN District cdscpd ON m.cdscpdistrictObj = cdscpd.districtId LEFT JOIN Taluk cdscpt ON m.cdscptalukObj = cdscpt.talukId "
      +
      " LEFT JOIN LocalbodyType cdscplbt ON m.cdscplocalbodytypeObj = cdscplbt.localbodyTypeId LEFT JOIN LocalBody cdscplb ON m.cdscplocalbodyObj = cdscplb.localbodyId "
      +
      " LEFT JOIN Postoffice cdscpp ON m.cdscppostofficeObj = cdscpp.postofficeId "
      +
      " LEFT JOIN District cdssd ON m.cdssecdistrictObj= cdssd.districtId LEFT JOIN Taluk cdsst ON m.cdssectalukObj= cdsst.talukId "
      + 
      " LEFT JOIN LocalbodyType cdsslbt ON m.cdsseclocalbodytypeObj = cdsslbt.localbodyTypeId LEFT JOIN LocalBody cdsslb ON m.cdsseclocalbodyObj = cdsslb.localbodyId "
      +
      " LEFT JOIN Postoffice cdssp ON m.cdssecpostofficeObj = cdssp.postofficeId "
      +
      " LEFT JOIN User u ON m.createdBy = u.userId LEFT JOIN User mu ON m.modifiedBy = mu.userId " 
      +
      " WHERE m.isDeleted=0 and m.isActive=1 ORDER BY m.mfscdsLoanId ASC")

  List<MFSCDSLoanVO> getMFSCDSLoanList();// Filter only active termloans

  @Query("SELECT m from MFSCDSLoan m WHERE m.id=:mfscdsLoanId")
  MFSCDSLoan getMFSCDSLoanById(@Param("mfscdsLoanId") Integer mfscdsLoanId);

  @Query("SELECT cl FROM MFSCDSLoan cl WHERE cl.cdsName=:cdsName")
  MFSCDSLoan findByMFSCDSLoanName(@Param("cdsName") String cdsName);

  // --modal view
  @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.MFSCDSLoanVO(m.mfscdsLoanId, ur.fullName, lc.loanCategoryId, lc.loanCategoryName, lt.loantypeName, "
  +
  " m.cdsName, m.cdshouseName, m.cdshouseNo, cdsd.districtId, cdsd.districtName, cdst.talukId, cdst.talukName, m.cdslocationtypeId, cdslt.localbodyTypeId, cdslt.localbodyTypeName, cdsl.localbodyId, cdsl.localbodyName, "
  +
  " m.cdsLocation, cdsp.postofficeId, cdsp.postofficeName, m.cdsPincode, m.cdsemailId, m.cdspanNo, m.cdsregNo, "
  +
  " m.cdsregYear, m.cdscpName, m.cdscpPhoneNo, m.cdssecName, m.cdssecPhoneNo, " 
  +
  " m.cdscpAadharNo, m.cdssecAadharNo, m.cdscphouseName, m.cdscphouseNo, cdscpd.districtId, cdscpd.districtName, cdscpt.talukId, cdscpt.talukName, m.cdscplocationtypeId, cdscplbt.localbodyTypeId, cdscplbt.localbodyTypeName, "
  +
  " cdscplb.localbodyId, cdscplb.localbodyName, m.cdscpLocation, cdscpp.postofficeId, cdscpp.postofficeName, m.cdscpPincode, m.cdssechouseName, m.cdssechouseNo, "
  +
  " cdssd.districtId, cdssd.districtName, cdsst.talukId, cdsst.talukName, m.cdsseclocationtypeId, cdsslbt.localbodyTypeId, cdsslbt.localbodyTypeName, " 
  +
  " cdsslb.localbodyId, cdsslb.localbodyName, m.cdssecLocation, cdssp.postofficeId, cdssp.postofficeName, m.cdssecPincode, m.meunitsoneyearCount, m.meunitsoneyearaboveCount, "
  +
  " m.meunitstotalCount, m.cdsprojectName, m.cdsloanAmount, m.cdsapplicationStatus, "
  +
   " m.enteredOn, m.createdOn, u.fullName, m.modifiedOn, mu.fullName, m.isDeleted, m.deletedOn, m.isActive) "
  + 
  " FROM MFSCDSLoan m LEFT JOIN User ur ON m.userObj = ur.userId LEFT JOIN LoanCategory lc ON m.loanCategoryObj = lc.loanCategoryId "
  +
  " LEFT JOIN LoanType lt ON m.loantypeObj = lt.loantypeId LEFT JOIN District cdsd ON m.cdsdistrictObj = cdsd.districtId "
  +
  " LEFT JOIN Taluk cdst ON m.cdstalukObj = cdst.talukId LEFT JOIN LocalbodyType cdslt ON m.cdslocalbodytypeObj = cdslt.localbodyTypeId " 
  + 
  " LEFT JOIN LocalBody cdsl ON m.cdslocalbodyObj = cdsl.localbodyId LEFT JOIN Postoffice cdsp ON m.cdspostofficeObj = cdsp.postofficeId "
  +
  " LEFT JOIN District cdscpd ON m.cdscpdistrictObj = cdscpd.districtId LEFT JOIN Taluk cdscpt ON m.cdscptalukObj = cdscpt.talukId "
  +
  " LEFT JOIN LocalbodyType cdscplbt ON m.cdscplocalbodytypeObj = cdscplbt.localbodyTypeId LEFT JOIN LocalBody cdscplb ON m.cdscplocalbodyObj = cdscplb.localbodyId "
  +
  " LEFT JOIN Postoffice cdscpp ON m.cdscppostofficeObj = cdscpp.postofficeId "
  +
  " LEFT JOIN District cdssd ON m.cdssecdistrictObj= cdssd.districtId LEFT JOIN Taluk cdsst ON m.cdssectalukObj= cdsst.talukId "
  + 
  " LEFT JOIN LocalbodyType cdsslbt ON m.cdsseclocalbodytypeObj = cdsslbt.localbodyTypeId LEFT JOIN LocalBody cdsslb ON m.cdsseclocalbodyObj = cdsslb.localbodyId "
  +
  " LEFT JOIN Postoffice cdssp ON m.cdssecpostofficeObj = cdssp.postofficeId "
  +
  " LEFT JOIN User u ON m.createdBy = u.userId LEFT JOIN User mu ON m.modifiedBy = mu.userId " 
  +
  " WHERE m.isDeleted=0 and m.isActive=1 and m.mfscdsLoanId=:mfscdsLoanId")
MFSCDSLoanVO getPreviewMFSCDSLoanById(@Param("mfscdsLoanId") Integer mfscdsLoanId);


@Query("SELECT new com.kswdc.loanmanagementsystem.api.value.MFSCDSLoanVO(m.mfscdsLoanId, ur.fullName, lc.loanCategoryId, lc.loanCategoryName, lt.loantypeName, "
+
" m.cdsName, m.cdshouseName, m.cdshouseNo, cdsd.districtId, cdsd.districtName, cdst.talukId, cdst.talukName, m.cdslocationtypeId, cdslt.localbodyTypeId, cdslt.localbodyTypeName, cdsl.localbodyId, cdsl.localbodyName, "
+
" m.cdsLocation, cdsp.postofficeId, cdsp.postofficeName, m.cdsPincode, m.cdsemailId, m.cdspanNo, m.cdsregNo, "
+
" m.cdsregYear, m.cdscpName, m.cdscpPhoneNo, m.cdssecName, m.cdssecPhoneNo, " 
+
" m.cdscpAadharNo, m.cdssecAadharNo, m.cdscphouseName, m.cdscphouseNo, cdscpd.districtId, cdscpd.districtName, cdscpt.talukId, cdscpt.talukName, m.cdscplocationtypeId, cdscplbt.localbodyTypeId, cdscplbt.localbodyTypeName, "
+
" cdscplb.localbodyId, cdscplb.localbodyName, m.cdscpLocation, cdscpp.postofficeId, cdscpp.postofficeName, m.cdscpPincode, m.cdssechouseName, m.cdssechouseNo, "
+
" cdssd.districtId, cdssd.districtName, cdsst.talukId, cdsst.talukName, m.cdsseclocationtypeId, cdsslbt.localbodyTypeId, cdsslbt.localbodyTypeName, " 
+
" cdsslb.localbodyId, cdsslb.localbodyName, m.cdssecLocation, cdssp.postofficeId, cdssp.postofficeName, m.cdssecPincode, m.meunitsoneyearCount, m.meunitsoneyearaboveCount, "
+
" m.meunitstotalCount, m.cdsprojectName, m.cdsloanAmount, m.cdsapplicationStatus, "
+
 " m.enteredOn, m.createdOn, u.fullName, m.modifiedOn, mu.fullName, m.isDeleted, m.deletedOn, m.isActive) "
+ 
" FROM MFSCDSLoan m LEFT JOIN User ur ON m.userObj = ur.userId LEFT JOIN LoanCategory lc ON m.loanCategoryObj = lc.loanCategoryId "
+
" LEFT JOIN LoanType lt ON m.loantypeObj = lt.loantypeId LEFT JOIN District cdsd ON m.cdsdistrictObj = cdsd.districtId "
+
" LEFT JOIN Taluk cdst ON m.cdstalukObj = cdst.talukId LEFT JOIN LocalbodyType cdslt ON m.cdslocalbodytypeObj = cdslt.localbodyTypeId " 
+ 
" LEFT JOIN LocalBody cdsl ON m.cdslocalbodyObj = cdsl.localbodyId LEFT JOIN Postoffice cdsp ON m.cdspostofficeObj = cdsp.postofficeId "
+
" LEFT JOIN District cdscpd ON m.cdscpdistrictObj = cdscpd.districtId LEFT JOIN Taluk cdscpt ON m.cdscptalukObj = cdscpt.talukId "
+
" LEFT JOIN LocalbodyType cdscplbt ON m.cdscplocalbodytypeObj = cdscplbt.localbodyTypeId LEFT JOIN LocalBody cdscplb ON m.cdscplocalbodyObj = cdscplb.localbodyId "
+
" LEFT JOIN Postoffice cdscpp ON m.cdscppostofficeObj = cdscpp.postofficeId "
+
" LEFT JOIN District cdssd ON m.cdssecdistrictObj= cdssd.districtId LEFT JOIN Taluk cdsst ON m.cdssectalukObj= cdsst.talukId "
+ 
" LEFT JOIN LocalbodyType cdsslbt ON m.cdsseclocalbodytypeObj = cdsslbt.localbodyTypeId LEFT JOIN LocalBody cdsslb ON m.cdsseclocalbodyObj = cdsslb.localbodyId "
+
" LEFT JOIN Postoffice cdssp ON m.cdssecpostofficeObj = cdssp.postofficeId "
+
" LEFT JOIN User u ON m.createdBy = u.userId LEFT JOIN User mu ON m.modifiedBy = mu.userId " 
+
" WHERE m.isDeleted=0 and m.isActive=1 and u.userId=:userId")
  MFSCDSLoanVO getMFSCDSLoanByUserId(@Param("userId") Integer userId);
// // //   // --modal view
}
