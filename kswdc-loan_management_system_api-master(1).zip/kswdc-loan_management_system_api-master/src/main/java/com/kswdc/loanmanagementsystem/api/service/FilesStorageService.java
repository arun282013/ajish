package com.kswdc.loanmanagementsystem.api.service;

import java.nio.file.Path;
import java.util.stream.Stream;
import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

public interface FilesStorageService {
    public void init();

    public String save(MultipartFile file, Integer fileType, String filePrefix);

    public Resource load(String filename, Integer fileType);

    public Resource loadngo(String filename, Integer fileType);

    public Resource loadmfscds(String filename, Integer fileType);


    public void deleteAll();

    public Stream<Path> loadAll();

    //--save and load photo
    public String savephoto(MultipartFile file, Integer fileType, String filePrefix);

    public Resource loadphoto(String filename, Integer fileType);
    //--save and load photo
    //--save and load sign
    public String savesign(MultipartFile file, Integer fileType, String filePrefix);

    public Resource loadsign(String filename, Integer fileType);
    //--save and load sign


     //--save and load Stamp for NGO
     public String savestampngo(MultipartFile file, Integer fileType, String filePrefix);
     public Resource loadstampngo(String filename, Integer fileType);
     //----------//
     //--save and load sign for Ngo
     public String savesignngo(MultipartFile file, Integer fileType, String filePrefix);
     public Resource loadsignngo(String filename, Integer fileType);
    //---------//

    
}