package com.kswdc.loanmanagementsystem;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

import javax.annotation.PreDestroy;

@SpringBootApplication
@EnableScheduling
public class KSWDCLoanManagerApplication implements ExitCodeGenerator {

	private final Logger log = LoggerFactory.getLogger(KSWDCLoanManagerApplication.class);
	@Value("${spring.application.name}")
	private String appName;

	public static void main(String[] args) {
		SpringApplication.run(KSWDCLoanManagerApplication.class, args);
	}

	@PreDestroy
	public void onExit() {
		log.info("###STOPing###");
		try {
			Thread.sleep(5 * 1000);
		} catch (InterruptedException e) {
			log.error("", e);
			;
		}
		log.info("###STOP FROM THE LIFECYCLE###");
	}

	@Override
	public int getExitCode() {
		// TODO Auto-generated method stub
		return 0;
	}


}
