package com.kswdc.loanmanagementsystem.api.model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

@Data
@Entity
@Table(name = "tbl_ngothrift")
@EqualsAndHashCode()
public class NgoThrift{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "THRIFT_ID")
    private Integer thriftId;

    @Column(name = "NAMEANDADDRESS", columnDefinition = "varchar(300) not null")
    private String nameandaddress;
    
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(name = "DTEFORMATION", nullable = true, unique = false)
    private Date dteformation;
    
    @Column(name = "MEMBERS", columnDefinition = "int(11) not null")
    private Integer members;

     @Column(name = "SAVINGS", columnDefinition = "varchar(200)",nullable = true)
     private String savings;

     @Column(name = "OUTOFSAVINGS", columnDefinition = "varchar(200)",nullable = true)
     private String outofsavings;

     @Column(name = "AMTRECOVERED", columnDefinition = "int(11) not null")
     private Integer amtrecovered;

     @Column(name = "AMTOUTSTANDING", columnDefinition = "int(11) not null")
     private Integer amtoutstanding;

       
}
