package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.Village;
import com.kswdc.loanmanagementsystem.api.service.VillageService;
import com.kswdc.loanmanagementsystem.api.value.VillageVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class VillageController {

	private final Logger log = LoggerFactory.getLogger(VillageController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private VillageService villageService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param Village Village
	 * @return Map
	 */
	@RequestMapping(value = "/village", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createVillage(@RequestBody Village Village) {
		log.info("In VillageController::createVillage=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(Village)) {
//						Village.setActive(Boolean.TRUE);
						Village.setCreatedOn(DateFunctions.getZonedServerDate());
						// Village.setCreatedBy();
						Village.setIsDeleted(0);
						Integer VillageId = villageService.createVillage(Village);
						if (!VillageId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("VillageId", VillageId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in VillageController::createVillage======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param Village Village
	 * @return Map
	 */
	@RequestMapping(value = "/village", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateVillage(@RequestBody Village village) {
		log.info("In VillageController::updateVillage=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (village != null) { // && Village.getId() != null
				if (checkValid(village)) {
					Village chkVillage = villageService.getVillage(village.getVillageId());
					if (chkVillage!=null) {
//						if (chkVillage.getActive()) {
//							Village.setActive(Boolean.TRUE);
							chkVillage.setVillageName(village.getVillageName());							
							chkVillage.setIsActive(village.getIsActive());							
							Integer VillageId = villageService.updateVillage(chkVillage);
							if (!VillageId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("VillageId:", VillageId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" Village Id is deactivated:"+Village.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in VillageController::updateVillage======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/village/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteVillage(@PathVariable Integer id) {
		log.info("In VillageController::deleteVillage=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Village Village = villageService.getVillage(id);
				if (Village != null) {
//					if (!Village.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " VillageId:" + id);
//					} else {
						Integer VillageId = villageService.deleteVillage(id);
						if (!VillageId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("VillageId", VillageId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in VillageController::deleteVillage======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/village/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneVillage(@PathVariable Integer id) {
		log.info("In VillageController::getOneVillage=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Village Village = villageService.getVillage(id);
				if (Village != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("Village", Village);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in VillageController::getOneVillage======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- Village ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/village-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getVillageList() {
		log.info("In VillageController::getVillageList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			VillageListReturnVO VillageListReturnVO = new VillageListReturnVO(VillageService.getVillageList());
			List<VillageVO> VillageListReturnVO = villageService.getVillageList();
			if (VillageListReturnVO != null && VillageListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("villages", VillageListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in VillageController::getVillageList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	@RequestMapping(value = "/village-list-by-taluk/{talukId}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getVillageListByTaluk(@PathVariable Integer talukId) {
		log.info("In VillageController::getVillageListByTaluk=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			List<VillageVO> VillageListReturnVO = villageService.getVillageListByTaluk(talukId);
			if (VillageListReturnVO != null && VillageListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("villages", VillageListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in VillageController::getVillageListByTaluk======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param VillageId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer VillageId) {
		return (villageService.getVillage(VillageId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param Village
	 * @return Boolean
	 */
	private Boolean checkValid(Village Village) {
		Boolean isValid = true;
		invalidMsg = "";
		if (Village != null) {
//			if(Village.getId()==null || Village.getId()<=0) {
//				invalidMsg+="VillageId is required and should be valid!";
//				isValid = false;
//			}
			if (Village.getVillageName() == null || Village.getVillageName().equalsIgnoreCase("")) {
				invalidMsg += "Village Name is required and should not be empty!";
				isValid = false;
			}
//			if (Village.getVillageName() == null || Village.getVillageName().equalsIgnoreCase("")) {
//				invalidMsg += "Village Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (Village.getQuotaInMB() == null || Village.getQuotaInMB().equals(0) || Village.getQuotaInMB()<0) {
//				invalidMsg += "Village Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (Village.getChatHistoryDays() == null || Village.getChatHistoryDays().equals(0) || Village.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for Village is required and should be valid!";
//				isValid = false;
//			}
//			if (Village.getCdaTimeoutTime() == null || Village.getCdaTimeoutTime().equals(0) || Village.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for Village!";
			isValid = false;
		}
		return isValid;
	}
	
}
