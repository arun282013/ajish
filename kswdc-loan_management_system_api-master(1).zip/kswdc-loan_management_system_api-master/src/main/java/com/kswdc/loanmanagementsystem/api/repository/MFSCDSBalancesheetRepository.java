package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.MFSCDSBalancesheet;
import com.kswdc.loanmanagementsystem.api.value.MFSCDSBalancesheetVO;

@Repository
public interface MFSCDSBalancesheetRepository extends JpaRepository<MFSCDSBalancesheet, Integer> {
    
    @Query("SELECT a FROM MFSCDSBalancesheet a WHERE a.id=:balancesheetId")
    MFSCDSBalancesheet getMFSCDSBalancesheetById(@Param("balancesheetId") Integer balancesheetId);
 
    @Query("SELECT cl FROM MFSCDSBalancesheet cl WHERE cl.balancesheetYear=balancesheetYear")
    MFSCDSBalancesheet getMFSCDSBalancesheetByMFSCDSBalancesheetProjectdone(@Param("balancesheetYear") String balancesheetYear);

}
