package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.MFSCDSProgram;
import com.kswdc.loanmanagementsystem.api.service.MFSCDSProgramService;
import com.kswdc.loanmanagementsystem.api.value.MFSCDSProgramVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;


@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class MFSCDSProgramController {

	private final Logger log = LoggerFactory.getLogger(MFSCDSProgramController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private MFSCDSProgramService mfscdsprogramService;
	
	/**
	 * @param MFSCDSProgram MFSCDSProgram
	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsprogram", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createMFSCDSProgram(@RequestBody MFSCDSProgram MFSCDSProgram) {
		log.info("In MFSCDSProgramController::createMFSCDSProgram=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(MFSCDSProgram)) {
						Integer ProgramId = mfscdsprogramService.createMFSCDSProgram(MFSCDSProgram);
						if (!ProgramId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("ProgramId", ProgramId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSProgramController::createMFSCDSProgram======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * //@param MFSCDSProgram MFSCDSProgram
	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsprogram", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateMFSCDSProgram(@RequestBody MFSCDSProgram mfscdsprogram) {
		log.info("In MFSCDSProgramController::updateMFSCDSProgram=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (mfscdsprogram != null) { 
				if (checkValid(mfscdsprogram)) {
					MFSCDSProgram chkMFSCDSProgram = mfscdsprogramService.getMFSCDSProgram(mfscdsprogram.getProgramId());
					if (chkMFSCDSProgram!=null) {						
							chkMFSCDSProgram.setProgramId(mfscdsprogram.getProgramId());
							
							Integer programId = mfscdsprogramService.updateMFSCDSProgram(chkMFSCDSProgram);
							if (!programId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("ProgramId:", programId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSProgramController::updateMFSCDSProgram======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsprogram/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteMFSCDSProgram(@PathVariable Integer id) {
		log.info("In MFSCDSProgramController::deleteMFSCDSProgram=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				MFSCDSProgram MFSCDSProgram = mfscdsprogramService.getMFSCDSProgram(id);
				if (MFSCDSProgram != null) {
						Integer programId = mfscdsprogramService.deleteMFSCDSProgram(id);
						if (!programId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("MFSCDSProgramId", programId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSProgramController::deleteMFSCDSProgram======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/mfscdsprogram/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneMFSCDSProgram(@PathVariable Integer id) {
		log.info("In MFSCDSProgramController::getOneMFSCDSProgram=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				MFSCDSProgram MFSCDSProgram = mfscdsprogramService.getMFSCDSProgram(id);
				if (MFSCDSProgram != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("MFSCDSProgram", MFSCDSProgram);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in MFSCDSProgramController::getOneMFSCDSProgram======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End:



	/**
	 * @param MFSCDSProgramId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer programId) {
		return (mfscdsprogramService.getMFSCDSProgram(programId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @purpose For checking if mandatory data is passed
	 * @param MFSCDSProgram
	 * @return Boolean
	 */
	private Boolean checkValid(MFSCDSProgram MFSCDSProgram) {
		Boolean isValid = true;
		invalidMsg = "";
		if (MFSCDSProgram != null) {
			if (MFSCDSProgram.getProgramName() == null || MFSCDSProgram.getProgramName().equalsIgnoreCase("")) {
				invalidMsg += "MFSCDSProgram Name is required and should not be empty!";
				isValid = false;
			}
		} else {
			invalidMsg = "Received data is not valid for MFSCDSProgram!";
			isValid = false;
		}
		return isValid;
	}
	
}
