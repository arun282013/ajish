package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.MaritalStatus;
import com.kswdc.loanmanagementsystem.api.value.MaritalStatusVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface MaritalStatusService {

    Integer createMaritalStatus(MaritalStatus maritalStatus);

    Integer updateMaritalStatus(MaritalStatus maritalStatus);

    MaritalStatus getMaritalStatus(Integer id);

    MaritalStatus getMaritalStatusByMaritalStatusName(String maritalstatusName);

    Integer deleteMaritalStatus(Integer id);

    List<MaritalStatusVO> getMaritalStatusList();
}
