package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.SuretyTypeBeneficiary;
import com.kswdc.loanmanagementsystem.api.service.SuretyTypeBeneficiaryService;
import com.kswdc.loanmanagementsystem.api.value.SuretyTypeBeneficiaryVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class SuretyTypeBeneficiaryController {

	private final Logger log = LoggerFactory.getLogger(SuretyTypeBeneficiaryController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private SuretyTypeBeneficiaryService SuretyTypeBeneficiaryService;
	

	@RequestMapping(value = "/suretyTypeBeneficiary", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createSuretyTypeBeneficiary(@RequestBody SuretyTypeBeneficiary SuretyTypeBeneficiary) {
		log.info("In SuretyTypeBeneficiaryController::createSuretyTypeBeneficiary=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(SuretyTypeBeneficiary)) {
					//						LoanType.setActive(Boolean.TRUE);
						//LoanSuretyType.setCreatedOn(DateFunctions.getZonedServerDate());
						// LoanType.setCreatedBy();
						//LoanSuretyType.setIsDeleted(0);
						Integer SuretyTypeBeneficiaryId = SuretyTypeBeneficiaryService.createSuretyTypeBeneficiary(SuretyTypeBeneficiary);
						if (!SuretyTypeBeneficiaryId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("SuretyTypeBeneficiaryId", SuretyTypeBeneficiaryId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in SuretyTypeBeneficiaryController::createSuretyTypeBeneficiary======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	@RequestMapping(value = "/suretyTypeBeneficiary", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateSuretyTypeBeneficiary(@RequestBody SuretyTypeBeneficiary suretyTypeBeneficiary) {
		log.info("In SuretyTypeBeneficiaryController::updateSuretyTypeBeneficiary=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (suretyTypeBeneficiary != null) { // && LoanType.getId() != null
				if (checkValid(suretyTypeBeneficiary)) {
					SuretyTypeBeneficiary chkSuretyTypeBeneficiary = SuretyTypeBeneficiaryService.getSuretyTypeBeneficiary(suretyTypeBeneficiary.getSuretytypeBeneficiaryId());
					if (chkSuretyTypeBeneficiary!=null) {
//						if (chkLoanType.getActive()) {
//							LoanType.setActive(Boolean.TRUE);
							//chkLoanSuretyType.setLoanSuretyTypeCode(loanSuretyType.);
							//chkLoanSuretyType.setLoanSuretyTypeName(loanSuretyType.getLoantypeName());							
							//chkLoanSuretyType.setIsActive(loanSuretyType.getIsActive());							
							Integer SuretyTypeBeneficiaryId = SuretyTypeBeneficiaryService.updateSuretyTypeBeneficiary(chkSuretyTypeBeneficiary);
							if (!SuretyTypeBeneficiaryId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("SuretyTypeBeneficiaryId:", SuretyTypeBeneficiaryId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" LoanType Id is deactivated:"+LoanType.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in SuretyTypeBeneficiaryController::updateSuretyTypeBeneficiary======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	@RequestMapping(value = "/suretyTypeBeneficiary/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteSuretyTypeBeneficiary(@PathVariable Integer id) {
		log.info("In SuretyTypeBeneficiaryController::deleteSuretyTypeBeneficiary=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				SuretyTypeBeneficiary SuretyTypeBeneficiary = SuretyTypeBeneficiaryService.getSuretyTypeBeneficiary(id);
				if (SuretyTypeBeneficiary != null) {
//					if (!LoanType.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " LoanTypeId:" + id);
//					} else {
						Integer SuretyTypeBeneficiaryId = SuretyTypeBeneficiaryService.deleteSuretyTypeBeneficiary(id);
						if (!SuretyTypeBeneficiaryId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("SuretyTypeBeneficiaryId", SuretyTypeBeneficiaryId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in SuretyTypeBeneficiaryController::deleteSuretyTypeBeneficiary======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	@RequestMapping(value = "/suretyTypeBeneficiary/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneSuretyTypeBeneficiary(@PathVariable Integer id) {
		log.info("In SuretyTypeBeneficiaryController::getOneSuretyTypeBeneficiary=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				SuretyTypeBeneficiary SuretyTypeBeneficiary = SuretyTypeBeneficiaryService.getSuretyTypeBeneficiary(id);
				if (SuretyTypeBeneficiary != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("SuretyTypeBeneficiary", SuretyTypeBeneficiary);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in SuretyTypeBeneficiaryController::getOneSuretyTypeBeneficiary======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	@RequestMapping(value = "/suretyTypeBeneficiary-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getSuretyTypeBeneficiaryList() {
		log.info("In SuretyTypeBeneficiaryController::getSuretyTypeBeneficiaryList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			LoanTypeListReturnVO LoanTypeListReturnVO = new LoanTypeListReturnVO(LoanTypeService.getLoanTypeList());
			List<SuretyTypeBeneficiaryVO> SuretyTypeBeneficiaryListReturnVO = SuretyTypeBeneficiaryService.getSuretyTypeBeneficiaryList();
			if (SuretyTypeBeneficiaryListReturnVO != null && SuretyTypeBeneficiaryListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("suretyTypeBeneficiarys", SuretyTypeBeneficiaryListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in SuretyTypeBeneficiaryController::getSuretyTypeBeneficiaryList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	

	private Boolean checkIfExists(Integer SuretyTypeBeneficiaryId) {
		return (SuretyTypeBeneficiaryService.getSuretyTypeBeneficiary(SuretyTypeBeneficiaryId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	
	private Boolean checkValid(SuretyTypeBeneficiary suretyTypeBeneficiary) {
		Boolean isValid = true;
		invalidMsg = "";
		if (suretyTypeBeneficiary != null) {
//			if(LoanType.getId()==null || LoanType.getId()<=0) {
//				invalidMsg+="LoanTypeId is required and should be valid!";
//				isValid = false;
//			}
			// if (LoanSuretyType.getLoanSuretyTypeName() == null || LoanSuretyType.getLoanSuretyTypeName().equalsIgnoreCase("")) {
			// 	invalidMsg += "LoanSuretyType Name is required and should not be empty!";
			// 	isValid = false;
			// }
//			if (LoanType.getLoanTypeName() == null || LoanType.getLoanTypeName().equalsIgnoreCase("")) {
//				invalidMsg += "LoanType Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (LoanType.getQuotaInMB() == null || LoanType.getQuotaInMB().equals(0) || LoanType.getQuotaInMB()<0) {
//				invalidMsg += "LoanType Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanType.getChatHistoryDays() == null || LoanType.getChatHistoryDays().equals(0) || LoanType.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for LoanType is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanType.getCdaTimeoutTime() == null || LoanType.getCdaTimeoutTime().equals(0) || LoanType.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for SuretyTypeBeneficiary!";
			isValid = false;
		}
		return isValid;
	}
	
}
