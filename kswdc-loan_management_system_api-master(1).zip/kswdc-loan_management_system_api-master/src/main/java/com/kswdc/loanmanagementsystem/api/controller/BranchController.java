package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.Branch;
import com.kswdc.loanmanagementsystem.api.service.BranchService;
import com.kswdc.loanmanagementsystem.api.value.BranchVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class BranchController {

	private final Logger log = LoggerFactory.getLogger(BranchController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private BranchService branchService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param Branch Branch
	 * @return Map
	 */
	@RequestMapping(value = "/branch", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createBranch(@RequestBody Branch Branch) {
		log.info("In BranchController::createBranch=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(Branch)) {
//						Branch.setActive(Boolean.TRUE);
						Branch.setCreatedOn(DateFunctions.getZonedServerDate());
						// Branch.setCreatedBy();
						Branch.setIsDeleted(0);
						Integer BranchId = branchService.createBranch(Branch);
						if (!BranchId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("BranchId", BranchId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in BranchController::createBranch======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param Branch Branch
	 * @return Map
	 */
	@RequestMapping(value = "/branch", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateBranch(@RequestBody Branch branch) {
		log.info("In BranchController::updateBranch=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (branch != null) { // && Branch.getId() != null
				if (checkValid(branch)) {
					Branch chkBranch = branchService.getBranch(branch.getBranchId());
					if (chkBranch!=null) {
//						if (chkBranch.getActive()) {
//							Branch.setActive(Boolean.TRUE);
							chkBranch.setBranchId(branch.getBranchId());
							chkBranch.setBranchName(branch.getBranchName());
							chkBranch.setBranchIFSC(branch.getBranchIFSC());
							chkBranch.setIsActive(branch.getIsActive());							
							Integer BranchId = branchService.updateBranch(chkBranch);
							if (!BranchId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("BranchId:", BranchId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" Branch Id is deactivated:"+Branch.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in BranchController::updateBranch======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/branch/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteBranch(@PathVariable Integer id) {
		log.info("In BranchController::deleteBranch=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Branch Branch = branchService.getBranch(id);
				if (Branch != null) {
//					if (!Branch.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " BranchId:" + id);
//					} else {
						Integer BranchId = branchService.deleteBranch(id);
						if (!BranchId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("BranchId", BranchId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in BranchController::deleteBranch======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/branch/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneBranch(@PathVariable Integer id) {
		log.info("In BranchController::getOneBranch=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Branch Branch = branchService.getBranch(id);
				if (Branch != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("Branch", Branch);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in BranchController::getOneBranch======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- Branch ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/branch-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getBranchList() {
		log.info("In BranchController::getBranchList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			BranchListReturnVO BranchListReturnVO = new BranchListReturnVO(BranchService.getBranchList());
			List<BranchVO> BranchListReturnVO = branchService.getBranchList();
			if (BranchListReturnVO != null && BranchListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("branchs", BranchListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in BranchController::getBranchList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	@RequestMapping(value = "/branch-list-by-bank/{bankId}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getBranchListByBank(@PathVariable Integer bankId) {
		log.info("In BranchController::BranchListByBank=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			List<BranchVO> BranchListReturnVO = branchService.getBranchListByBank(bankId);
			if (BranchListReturnVO != null && BranchListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("branchs", BranchListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in BranchController::getBranchListByBank======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param BranchId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer BranchId) {
		return (branchService.getBranch(BranchId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param Branch
	 * @return Boolean
	 */
	private Boolean checkValid(Branch Branch) {
		Boolean isValid = true;
		invalidMsg = "";
		if (Branch != null) {
//			if(Branch.getId()==null || Branch.getId()<=0) {
//				invalidMsg+="BranchId is required and should be valid!";
//				isValid = false;
//			}
			if (Branch.getBranchName() == null || Branch.getBranchName().equalsIgnoreCase("")) {
				invalidMsg += "Branch Name is required and should not be empty!";
				isValid = false;
			}
//			if (Branch.getBranchName() == null || Branch.getBranchName().equalsIgnoreCase("")) {
//				invalidMsg += "Branch Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (Branch.getQuotaInMB() == null || Branch.getQuotaInMB().equals(0) || Branch.getQuotaInMB()<0) {
//				invalidMsg += "Branch Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (Branch.getChatHistoryDays() == null || Branch.getChatHistoryDays().equals(0) || Branch.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for Branch is required and should be valid!";
//				isValid = false;
//			}
//			if (Branch.getCdaTimeoutTime() == null || Branch.getCdaTimeoutTime().equals(0) || Branch.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for Branch!";
			isValid = false;
		}
		return isValid;
	}
	
}
