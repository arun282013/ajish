package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.MaritalStatus;
import com.kswdc.loanmanagementsystem.api.repository.MaritalStatusRepository;
import com.kswdc.loanmanagementsystem.api.value.MaritalStatusVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class MaritalStatusServiceImpl implements MaritalStatusService {
	private final Logger log = LoggerFactory.getLogger(MaritalStatusServiceImpl.class);
	
	@Autowired
	private MaritalStatusRepository maritalStatusRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createMaritalStatus(MaritalStatus MaritalStatus) {
		try {
			MaritalStatus savedMaritalStatus = maritalStatusRepository.save(MaritalStatus);
			return savedMaritalStatus.getMaritalstatusId() != null ? savedMaritalStatus.getMaritalstatusId() : -1;
		} catch (Exception e) {
			log.error("Exception in MaritalStatusServiceImpl::createMaritalStatus======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateMaritalStatus(MaritalStatus MaritalStatus) {
		try {
			MaritalStatus updateMaritalStatus = maritalStatusRepository.save(MaritalStatus);
			return updateMaritalStatus.getMaritalstatusId() != null ? updateMaritalStatus.getMaritalstatusId() : -1;
		} catch (Exception e) {
			log.error("Exception in MaritalStatusServiceImpl::updateMaritalStatus======" + e.getMessage());
		}
		return null;
	}

	@Override
	public MaritalStatus getMaritalStatus(Integer id) {
		try {
			MaritalStatus maritalStatus = maritalStatusRepository.getMaritalStatusById(id);
			return maritalStatus;
		} catch (Exception e) {
			log.error("Exception in MaritalStatusServiceImpl::getMaritalStatus======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteMaritalStatus(Integer id) {
		try {
			MaritalStatus MaritalStatus = getMaritalStatus(id);
//			MaritalStatus.setActive(Boolean.FALSE);
			MaritalStatus.setDeletedOn(DateFunctions.getZonedServerDate());
			MaritalStatus.setIsDeleted(Constants.IS_DELETED);
			MaritalStatus updatedMaritalStatus = maritalStatusRepository.save(MaritalStatus);
			return updatedMaritalStatus.getMaritalstatusId() != null ? updatedMaritalStatus.getMaritalstatusId() : -1;
		} catch (Exception e) {
			log.error("Exception in MaritalStatusServiceImpl::deleteMaritalStatus======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<MaritalStatusVO> getMaritalStatusList() {
		try {
			List<MaritalStatusVO> maritalStatusList = maritalStatusRepository.getMaritalStatusList();
			return maritalStatusList;
		} catch (Exception e) {
			log.error("Exception in MaritalStatusServiceImpl::getMaritalStatusList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public MaritalStatus getMaritalStatusByMaritalStatusName(String maritalStatusName) {
		try {
			MaritalStatus maritalStatus = maritalStatusRepository.findByMaritalStatusName(maritalStatusName);
			return maritalStatus;
		} catch (Exception e) {
			log.error("Exception in MaritalStatusServiceImpl::getMaritalStatusByMaritalStatusName======" + e.getMessage());
		}
		return null;
	}
}