package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.MFSNGOLoan;
import com.kswdc.loanmanagementsystem.api.value.MFSNGOLoanVO;

@Repository
public interface MFSNGOLoanRepository extends JpaRepository<MFSNGOLoan, Integer> {
  @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.MFSNGOLoanVO(m.mfsngoLoanId, ur.fullName,  lt.loantypeName, "
      +
      " m.mfsngoname, m.mfsngobuildingnumber,d.districtName,tk.talukName, m.mfsngolocation,lb.localbodyName,lbt.localbodyTypeName,m.mfsngoplace, p.postofficeName,  "
      +
      "  m.mfsngoPincode,m.mfsngophonenumber, m.mfsngofaxnumber, m.mfsngoregistrationnumber, "
      +
      " m.mfsngodor, m.mfsngodorenewal, m.mfsngoareaofoperation, m.mfsngoaccountnumber, " +
      " m.mfsngochieffunctionary, m.mfsngodesigchieffunctionary,m.createdOn,u.fullName,m.modifiedOn,mu.fullName, m.isDeleted, m.deletedOn, m.isActive,b.bankName,br.branchName,m.ifsc, m.mfsngodofinancialbalance, m.mfsngofixedasset, m.mfsngocurrentasset, m.mfsngoborrowings, m.mfsngootherliability) "
      +
      "FROM MFSNGOLoan m LEFT JOIN User ur ON m.userObj = ur.userId   "
      +
      "LEFT JOIN LoanType lt ON m.loantypeObj= lt.loantypeId "
      +
      " LEFT JOIN Postoffice p ON m.mfsngopostofficeObj= p.postofficeId "
      +
      "LEFT JOIN District d ON m.mfsngodistrictObj= d.districtId LEFT JOIN Taluk tk ON m.mfsngotalukObj= tk.talukId "
      +
      "LEFT JOIN LocalBody lb ON m.mfsngolocalbodyObj= lb.localbodyId "
     
      +
      "LEFT JOIN LocalbodyType lbt ON m.mfsngolocalbodytypeObj= lbt.localbodyTypeId  "
      +
     "LEFT JOIN User u ON m.createdBy=u.userId LEFT JOIN User mu ON m.modifiedBy=mu.userId "
      +
      "LEFT JOIN Bank b ON m.bankObj=b.bankId LEFT JOIN Branch br ON m.branchObj= br.branchId " 
      +
      "WHERE m.isDeleted=0 and m.isActive=1 ORDER BY m.mfsngoLoanId ASC")
  List<MFSNGOLoanVO> getMFSNGOLoanList();

  @Query("SELECT t from MFSNGOLoan t WHERE t.id=:mfsngoLoanId")
  MFSNGOLoan getMFSNGOLoanById(@Param("mfsngoLoanId") Integer mfsngoLoanId);

  @Query("SELECT cl FROM MFSNGOLoan cl WHERE cl.mfsngoname=:mfsngoname")
  MFSNGOLoan findByMFSNGOLoanName(@Param("mfsngoname") String mfsngoname);

  // --modal view
  @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.MFSNGOLoanVO(m.mfsngoLoanId, ur.fullName, lt.loantypeId, lt.loantypeName, "
  +
  " m.mfsngoname, m.mfsngobuildingnumber,d.districtId, d.districtName,tk.talukId, tk.talukName, m.mfsngolocation,lb.localbodyId, lb.localbodyName,lbt.localbodyTypeId, lbt.localbodyTypeName,m.mfsngoplace,p.postofficeId, p.postofficeName,  "
  +
  "  m.mfsngoPincode,m.mfsngophonenumber, m.mfsngofaxnumber, m.mfsngoregistrationnumber, "
  +
  " m.mfsngodor, m.mfsngodorenewal, m.mfsngoareaofoperation, m.mfsngoaccountnumber, " +
  " m.mfsngochieffunctionary, m.mfsngodesigchieffunctionary,m.createdOn,u.fullName,m.modifiedOn,mu.fullName, m.isDeleted, m.deletedOn, m.isActive,b.bankId, b.bankName,br.branchId, br.branchName,m.ifsc, m.mfsngodofinancialbalance, m.mfsngofixedasset, m.mfsngocurrentasset, m.mfsngoborrowings, m.mfsngootherliability) "
  +
  "FROM MFSNGOLoan m LEFT JOIN User ur ON m.userObj = ur.userId   "
  +
  "LEFT JOIN LoanType lt ON m.loantypeObj= lt.loantypeId "
  +
  " LEFT JOIN Postoffice p ON m.mfsngopostofficeObj= p.postofficeId "
  +
  "LEFT JOIN District d ON m.mfsngodistrictObj= d.districtId LEFT JOIN Taluk tk ON m.mfsngotalukObj= tk.talukId "
  +
  "LEFT JOIN LocalBody lb ON m.mfsngolocalbodyObj= lb.localbodyId "
 
  +
  "LEFT JOIN LocalbodyType lbt ON m.mfsngolocalbodytypeObj= lbt.localbodyTypeId  "
  +
 "LEFT JOIN User u ON m.createdBy=u.userId LEFT JOIN User mu ON m.modifiedBy=mu.userId "
  +
  "LEFT JOIN Bank b ON m.bankObj=b.bankId LEFT JOIN Branch br ON m.branchObj= br.branchId " 
  +
  "WHERE m.isDeleted=0 and m.isActive=1 and m.mfsngoLoanId=:mfsngoLoanId")
  MFSNGOLoanVO getPreviewMFSNGOLoanById(@Param("mfsngoLoanId") Integer mfsngoLoanId);
  @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.MFSNGOLoanVO(m.mfsngoLoanId, ur.fullName, lt.loantypeId, lt.loantypeName, "
  +
  " m.mfsngoname, m.mfsngobuildingnumber,d.districtId, d.districtName,tk.talukId, tk.talukName, m.mfsngolocation,lb.localbodyId, lb.localbodyName,lbt.localbodyTypeId, lbt.localbodyTypeName,m.mfsngoplace,p.postofficeId, p.postofficeName,  "
  +
  "  m.mfsngoPincode,m.mfsngophonenumber, m.mfsngofaxnumber, m.mfsngoregistrationnumber, "
  +
  " m.mfsngodor, m.mfsngodorenewal, m.mfsngoareaofoperation, m.mfsngoaccountnumber, " +
  " m.mfsngochieffunctionary, m.mfsngodesigchieffunctionary,m.createdOn,u.fullName,m.modifiedOn,mu.fullName, m.isDeleted, m.deletedOn, m.isActive,b.bankId, b.bankName,br.branchId, br.branchName,m.ifsc, m.mfsngodofinancialbalance, m.mfsngofixedasset, m.mfsngocurrentasset, m.mfsngoborrowings, m.mfsngootherliability) "
  +
  "FROM MFSNGOLoan m LEFT JOIN User ur ON m.userObj = ur.userId   "
  +
  "LEFT JOIN LoanType lt ON m.loantypeObj= lt.loantypeId "
  +
  " LEFT JOIN Postoffice p ON m.mfsngopostofficeObj= p.postofficeId "
  +
  "LEFT JOIN District d ON m.mfsngodistrictObj= d.districtId LEFT JOIN Taluk tk ON m.mfsngotalukObj= tk.talukId "
  +
  "LEFT JOIN LocalBody lb ON m.mfsngolocalbodyObj= lb.localbodyId "
 
  +
  "LEFT JOIN LocalbodyType lbt ON m.mfsngolocalbodytypeObj= lbt.localbodyTypeId  "
  +
 "LEFT JOIN User u ON m.createdBy=u.userId LEFT JOIN User mu ON m.modifiedBy=mu.userId "
  +
  "LEFT JOIN Bank b ON m.bankObj=b.bankId LEFT JOIN Branch br ON m.branchObj= br.branchId " 
  +
  "WHERE m.isDeleted=0 and m.isActive=1 and u.userId=:userId")
  
   MFSNGOLoanVO getMFSNGOLoanByUserId(@Param("userId") Integer userId);
  // --modal view

  //Sign and stamp

  @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.MFSNGOLoanVO(cb.mfsngoLoanId,"
  +
  "cb.mfsngoname,l.loantypeId,l.loantypeName,cb.stampPath,cb.signPath) " +
  "FROM MFSNGOLoan cb "
  +
  " LEFT JOIN LoanType l ON cb.loantypeObj=l.loantypeId "
  +
  " WHERE cb.id=:mfsngoLoanId")
  MFSNGOLoanVO getNgoLoanVOsignById(
  @Param("mfsngoLoanId") Integer mfsngoLoanId);

 
}
