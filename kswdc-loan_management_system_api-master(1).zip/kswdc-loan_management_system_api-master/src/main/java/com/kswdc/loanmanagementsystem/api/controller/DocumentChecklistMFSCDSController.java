package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistMFSCDS;
import com.kswdc.loanmanagementsystem.api.service.DocumentChecklistMFSCDSService;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistMFSCDSVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;


@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class DocumentChecklistMFSCDSController {

	private final Logger log = LoggerFactory.getLogger(DocumentChecklistMFSCDSController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private DocumentChecklistMFSCDSService documentChecklistMFSCDSService;
	
	/**
	 * @param DocumentChecklistMFSCDS DocumentChecklistMFSCDS
	 * @return Map
	 */
	@RequestMapping(value = "/documentChecklistMFSCDS", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createDocumentChecklistMFSCDS(@RequestBody DocumentChecklistMFSCDS DocumentChecklistMFSCDS) {
		log.info("In DocumentChecklistMFSCDSController::createDocumentChecklistMFSCDS=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(DocumentChecklistMFSCDS)) {
//						LoanCategory.setActive(Boolean.TRUE);
						DocumentChecklistMFSCDS.setCreatedOn(DateFunctions.getZonedServerDate());
						// LoanCategory.setCreatedBy();
						DocumentChecklistMFSCDS.setIsDeleted(0);
						Integer DocumentChecklistMFSCDSId = documentChecklistMFSCDSService.createDocumentChecklistMFSCDS(DocumentChecklistMFSCDS);
						if (!DocumentChecklistMFSCDSId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("DocumentChecklistMFSCDSId", DocumentChecklistMFSCDSId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistMFSCDSController::createDocumentChecklistMFSCDS======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * //@param DocumentChecklistMFSCDS DocumentChecklistMFSCDS
	 * @return Map
	 */
	@RequestMapping(value = "/documentChecklistMFSCDS", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateDocumentChecklistMFSCDS(@RequestBody DocumentChecklistMFSCDS documentChecklistMFSCDS) {
		log.info("In DocumentChecklistMFSCDSController::updateDocumentChecklistMFSCDS=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (documentChecklistMFSCDS != null) { // && DocumentChecklistMFSCDS.getId() != null
				if (checkValid(documentChecklistMFSCDS)) {
					DocumentChecklistMFSCDS chkDocumentChecklistMFSCDS = documentChecklistMFSCDSService.getDocumentChecklistMFSCDS(documentChecklistMFSCDS.getDocumentchecklistmfscdsId());
					if (chkDocumentChecklistMFSCDS!=null) {
//						if (chkLoanCategory.getActive()) {
//							LoanCategory.setActive(Boolean.TRUE);
							chkDocumentChecklistMFSCDS.setDocumentchecklistmfscdsName(documentChecklistMFSCDS.getDocumentchecklistmfscdsName());							
							chkDocumentChecklistMFSCDS.setIsActive(documentChecklistMFSCDS.getIsActive());							
							Integer DocumentChecklistMFSCDSId = documentChecklistMFSCDSService.updateDocumentChecklistMFSCDS(chkDocumentChecklistMFSCDS);
							if (!DocumentChecklistMFSCDSId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("DocumentChecklistMFSCDSId:", DocumentChecklistMFSCDSId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" LoanCategory Id is deactivated:"+LoanCategory.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistMFSCDSController::updateDocumentChecklistMFSCDS======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/documentChecklistMFSCDS/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteDocumentChecklistMFSCDS(@PathVariable Integer id) {
		log.info("In DocumentChecklistMFSCDSController::deleteDocumentChecklistMFSCDS=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				DocumentChecklistMFSCDS DocumentChecklistMFSCDS = documentChecklistMFSCDSService.getDocumentChecklistMFSCDS(id);
				if (DocumentChecklistMFSCDS != null) {
//					if (!LoanCategory.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " LoanCategoryId:" + id);
//					} else {
						Integer DocumentChecklistMFSCDSId = documentChecklistMFSCDSService.deleteDocumentChecklistMFSCDS(id);
						if (!DocumentChecklistMFSCDSId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("DocumentChecklistMFSCDSId", DocumentChecklistMFSCDSId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistMFSCDSController::deleteDocumentChecklistMFSCDS======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/documentChecklistMFSCDS/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneDocumentChecklistMFSCDS(@PathVariable Integer id) {
		log.info("In DocumentChecklistMFSCDSController::getOneDocumentChecklistMFSCDS=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				DocumentChecklistMFSCDS DocumentChecklistMFSCDS = documentChecklistMFSCDSService.getDocumentChecklistMFSCDS(id);
				if (DocumentChecklistMFSCDS != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("DocumentChecklistMFSCDS", DocumentChecklistMFSCDS);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistMFSCDSController::getOneDocumentChecklistMFSCDS======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- LoanCategory ------------------------------

	/**
	 * @return Map
	 */
	@RequestMapping(value = "/documentChecklistMFSCDS-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getDocumentChecklistMFSCDSList() {
		log.info("In DocumentChecklistMFSCDSController::getDocumentChecklistMFSCDSList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			LoanCategoryListReturnVO LoanCategoryListReturnVO = new LoanCategoryListReturnVO(LoanCategoryService.getLoanCategoryList());
			List<DocumentChecklistMFSCDSVO> DocumentChecklistMFSCDSListReturnVO = documentChecklistMFSCDSService.getDocumentChecklistMFSCDSList();
			if (DocumentChecklistMFSCDSListReturnVO != null && DocumentChecklistMFSCDSListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("documentChecklistMFSCDSs", DocumentChecklistMFSCDSListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistMFSCDSController::getDocumentChecklistMFSCDSList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// sreelekshmi 26.02.2022

	@RequestMapping(value = "/documentchecklistmfscds-list-by-loantype}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getDocumentChecklistMFSCDSListByLoanType() {
		log.info("In DocumentChecklistMFSCDSController::getDocumentChecklistMFSCDSListByLoanType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			List<DocumentChecklistMFSCDSVO> DocumentChecklistMFSCDSListReturnVO = documentChecklistMFSCDSService.getDocumentChecklistMFSCDSListByLoanType();
			if (DocumentChecklistMFSCDSListReturnVO != null && DocumentChecklistMFSCDSListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("documentchecklistmfscdss", DocumentChecklistMFSCDSListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();	
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DocumentChecklistMFSCDSController::getDocumentChecklistMFSCDSListByLoanType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param DocumentChecklistId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer DocumentChecklistMFSCDSId) {
		return (documentChecklistMFSCDSService.getDocumentChecklistMFSCDS(DocumentChecklistMFSCDSId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @purpose For checking if mandatory data is passed
	 * @param DocumentChecklist
	 * @return Boolean
	 */
	private Boolean checkValid(DocumentChecklistMFSCDS DocumentChecklistMFSCDS) {
		Boolean isValid = true;
		invalidMsg = "";
		if (DocumentChecklistMFSCDS != null) {
//			if(LoanCategory.getId()==null || LoanCategory.getId()<=0) {
//				invalidMsg+="LoanCategoryId is required and should be valid!";
//				isValid = false;
//			}
			if (DocumentChecklistMFSCDS.getDocumentchecklistmfscdsName() == null || DocumentChecklistMFSCDS.getDocumentchecklistmfscdsName().equalsIgnoreCase("")) {
				invalidMsg += "DocumentChecklistMFSCDS Name is required and should not be empty!";
				isValid = false;
			}
//			if (LoanCategory.getLoanCategoryName() == null || LoanCategory.getLoanCategoryName().equalsIgnoreCase("")) {
//				invalidMsg += "LoanCategory Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (LoanCategory.getQuotaInMB() == null || LoanCategory.getQuotaInMB().equals(0) || LoanCategory.getQuotaInMB()<0) {
//				invalidMsg += "LoanCategory Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanCategory.getChatHistoryDays() == null || LoanCategory.getChatHistoryDays().equals(0) || LoanCategory.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for LoanCategory is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanCategory.getCdaTimeoutTime() == null || LoanCategory.getCdaTimeoutTime().equals(0) || LoanCategory.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for DocumentChecklistMFSCDS!";
			isValid = false;
		}
		return isValid;
	}
	
}
