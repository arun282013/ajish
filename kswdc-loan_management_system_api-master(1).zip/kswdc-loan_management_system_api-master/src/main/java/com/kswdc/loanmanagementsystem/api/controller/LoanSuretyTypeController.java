package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.LoanSuretyType;
import com.kswdc.loanmanagementsystem.api.service.LoanSuretyTypeService;
import com.kswdc.loanmanagementsystem.api.value.LoanSuretyTypeVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class LoanSuretyTypeController {

	private final Logger log = LoggerFactory.getLogger(LoanSuretyTypeController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private LoanSuretyTypeService loanSuretyTypeService;
	

	@RequestMapping(value = "/loanSuretyType", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createLoanSuretyType(@RequestBody LoanSuretyType LoanSuretyType) {
		log.info("In LoanSuretyTypeController::createLoanSuretyType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(LoanSuretyType)) {
					//						LoanType.setActive(Boolean.TRUE);
						//LoanSuretyType.setCreatedOn(DateFunctions.getZonedServerDate());
						// LoanType.setCreatedBy();
						//LoanSuretyType.setIsDeleted(0);
						Integer LoanSuretyTypeId = loanSuretyTypeService.createLoanSuretyType(LoanSuretyType);
						if (!LoanSuretyTypeId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("LoanSuretyTypeId", LoanSuretyTypeId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanSuretyTypeController::createLoanSuretyType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	@RequestMapping(value = "/loanSuretyType", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateLoanSuretyType(@RequestBody LoanSuretyType loanSuretyType) {
		log.info("In LoanSuretyTypeController::updateLoanSuretyType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (loanSuretyType != null) { // && LoanType.getId() != null
				if (checkValid(loanSuretyType)) {
					LoanSuretyType chkLoanSuretyType = loanSuretyTypeService.getLoanSuretyType(loanSuretyType.getLoan_suretytypeId());
					if (chkLoanSuretyType!=null) {
//						if (chkLoanType.getActive()) {
//							LoanType.setActive(Boolean.TRUE);
							//chkLoanSuretyType.setLoanSuretyTypeCode(loanSuretyType.);
							//chkLoanSuretyType.setLoanSuretyTypeName(loanSuretyType.getLoantypeName());							
							//chkLoanSuretyType.setIsActive(loanSuretyType.getIsActive());							
							Integer LoanSuretyTypeId = loanSuretyTypeService.updateLoanSuretyType(chkLoanSuretyType);
							if (!LoanSuretyTypeId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("LoanSuretyTypeId:", LoanSuretyTypeId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" LoanType Id is deactivated:"+LoanType.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanSuretyTypeController::updateLoanSuretyType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	@RequestMapping(value = "/loanSuretyType/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteLoanSuretyType(@PathVariable Integer id) {
		log.info("In LoanSuretyTypeController::deleteLoanSuretyType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				LoanSuretyType LoanSuretyType = loanSuretyTypeService.getLoanSuretyType(id);
				if (LoanSuretyType != null) {
//					if (!LoanType.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " LoanTypeId:" + id);
//					} else {
						Integer LoanSuretyTypeId = loanSuretyTypeService.deleteLoanSuretyType(id);
						if (!LoanSuretyTypeId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("LoanSuretyTypeId", LoanSuretyTypeId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanSuretyTypeController::deleteLoanSuretyType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	@RequestMapping(value = "/loanSuretyType/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneLoanSuretyType(@PathVariable Integer id) {
		log.info("In LoanSuretyTypeController::getOneLoanSuretyType=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				LoanSuretyType LoanSuretyType = loanSuretyTypeService.getLoanSuretyType(id);
				if (LoanSuretyType != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("LoanSuretyType", LoanSuretyType);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanSuretyTypeController::getOneLoanSuretyType======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}


	@RequestMapping(value = "/loanSuretyType-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getLoanSuretyTypeList() {
		log.info("In LoanSuretyTypeController::getLoanSuretyTypeList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			LoanTypeListReturnVO LoanTypeListReturnVO = new LoanTypeListReturnVO(LoanTypeService.getLoanTypeList());
			List<LoanSuretyTypeVO> LoanSuretyTypeListReturnVO = loanSuretyTypeService.getLoanSuretyTypeList();
			if (LoanSuretyTypeListReturnVO != null && LoanSuretyTypeListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("loanSuretyTypes", LoanSuretyTypeListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in LoanSuretyTypeController::getLoanSuretyTypeList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	

	private Boolean checkIfExists(Integer LoanSuretyTypeId) {
		return (loanSuretyTypeService.getLoanSuretyType(LoanSuretyTypeId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	
	private Boolean checkValid(LoanSuretyType loanSuretyType) {
		Boolean isValid = true;
		invalidMsg = "";
		if (loanSuretyType != null) {
//			if(LoanType.getId()==null || LoanType.getId()<=0) {
//				invalidMsg+="LoanTypeId is required and should be valid!";
//				isValid = false;
//			}
			// if (LoanSuretyType.getLoanSuretyTypeName() == null || LoanSuretyType.getLoanSuretyTypeName().equalsIgnoreCase("")) {
			// 	invalidMsg += "LoanSuretyType Name is required and should not be empty!";
			// 	isValid = false;
			// }
//			if (LoanType.getLoanTypeName() == null || LoanType.getLoanTypeName().equalsIgnoreCase("")) {
//				invalidMsg += "LoanType Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (LoanType.getQuotaInMB() == null || LoanType.getQuotaInMB().equals(0) || LoanType.getQuotaInMB()<0) {
//				invalidMsg += "LoanType Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanType.getChatHistoryDays() == null || LoanType.getChatHistoryDays().equals(0) || LoanType.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for LoanType is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanType.getCdaTimeoutTime() == null || LoanType.getCdaTimeoutTime().equals(0) || LoanType.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for loanSuretyType!";
			isValid = false;
		}
		return isValid;
	}
	
}
