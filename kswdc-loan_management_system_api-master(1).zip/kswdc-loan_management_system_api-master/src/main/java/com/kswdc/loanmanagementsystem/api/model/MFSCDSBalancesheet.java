package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_mfscds_balancesheet")
@EqualsAndHashCode()
public class MFSCDSBalancesheet{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BALANCESHEET_ID")
    private Integer balancesheetId;

    @Column(name = "BALANCESHEET_YEAR", columnDefinition = "varchar(100) not null")
     private String balancesheetYear;
       
    @Column(name = "BALANCESHEET_AMOUNT", columnDefinition = "decimal(15,2) not null default 0.00")
     private Double balancesheetAmount;    
      
}
