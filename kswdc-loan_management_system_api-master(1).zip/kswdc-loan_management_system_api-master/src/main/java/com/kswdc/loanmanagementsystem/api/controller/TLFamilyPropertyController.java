package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.TLFamilyProperty;
import com.kswdc.loanmanagementsystem.api.service.TLFamilyPropertyService;
import com.kswdc.loanmanagementsystem.api.value.TLFamilyPropertyVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;


@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class TLFamilyPropertyController {

	private final Logger log = LoggerFactory.getLogger(TLFamilyPropertyController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private TLFamilyPropertyService tLfamilypropertyService;
	
	/**
	 * @param TLFamilyProperty TLFamilyProperty
	 * @return Map
	 */
	@RequestMapping(value = "/tlfamilyproperty", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createTLFamilyProperty(@RequestBody TLFamilyProperty TLFamilyProperty) {
		log.info("In TLFamilyPropertyController::createTLFamilyProperty=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(TLFamilyProperty)) {
//						LoanCategory.setActive(Boolean.TRUE);
						// TLFamilyProperty.setCreatedOn(DateFunctions.getZonedServerDate());
						// LoanCategory.setCreatedBy();
						// TLFamilyProperty.setIsDeleted(0);
						Integer PropertyId = tLfamilypropertyService.createTLFamilyProperty(TLFamilyProperty);
						if (!PropertyId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("PropertyId", PropertyId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TLFamilyPropertyController::createTLFamilyProperty======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * //@param TLFamilyProperty TLFamilyProperty
	 * @return Map
	 */
	@RequestMapping(value = "/tlfamilyproperty", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateTLFamilyProperty(@RequestBody TLFamilyProperty tlfamilyproperty) {
		log.info("In TLFamilyPropertyController::updateTLFamilyProperty=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (tlfamilyproperty != null) { // && TLFamilyProperty.getId() != null
				if (checkValid(tlfamilyproperty)) {
					TLFamilyProperty chkTLFamilyProperty = tLfamilypropertyService.getTLFamilyProperty(tlfamilyproperty.getPropertyId());
					if (chkTLFamilyProperty!=null) {
//						if (chkLoanCategory.getActive()) {
//							LoanCategory.setActive(Boolean.TRUE);
							// chkTLFamilyProperty.setTLFamilyPropertyName(tLFamilyProperty.getTLFamilyPropertyName());							
							// chkTLFamilyProperty.setIsActive(tLFamilyProperty.getIsActive());							
							chkTLFamilyProperty.setPropertyId(tlfamilyproperty.getPropertyId());
							
							Integer propertyId = tLfamilypropertyService.updateTLFamilyProperty(chkTLFamilyProperty);
							if (!propertyId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("PropertyId:", propertyId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" LoanCategory Id is deactivated:"+LoanCategory.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TLFamilyPropertyController::updateTLFamilyProperty======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/tlfamilyproperty/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteTLFamilyProperty(@PathVariable Integer id) {
		log.info("In TLFamilyPropertyController::deleteTLFamilyProperty=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				TLFamilyProperty TLFamilyProperty = tLfamilypropertyService.getTLFamilyProperty(id);
				if (TLFamilyProperty != null) {
//					if (!LoanCategory.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " LoanCategoryId:" + id);
//					} else {
						Integer propertyId = tLfamilypropertyService.deleteTLFamilyProperty(id);
						if (!propertyId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("TLFamilyPropertyId", propertyId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TLFamilyPropertyController::deleteTLFamilyProperty======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/tlfamilyproperty/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneTLFamilyProperty(@PathVariable Integer id) {
		log.info("In TLFamilyPropertyController::getOneTLFamilyProperty=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				TLFamilyProperty TLFamilyProperty = tLfamilypropertyService.getTLFamilyProperty(id);
				if (TLFamilyProperty != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("TLFamilyProperty", TLFamilyProperty);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in TLFamilyPropertyController::getOneTLFamilyProperty======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- LoanCategory ------------------------------



	/**
	 * @param TLFamilyPropertyId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer propertyId) {
		return (tLfamilypropertyService.getTLFamilyProperty(propertyId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @purpose For checking if mandatory data is passed
	 * @param TLFamilyProperty
	 * @return Boolean
	 */
	private Boolean checkValid(TLFamilyProperty TLFamilyProperty) {
		Boolean isValid = true;
		invalidMsg = "";
		if (TLFamilyProperty != null) {
//			if(LoanCategory.getId()==null || LoanCategory.getId()<=0) {
//				invalidMsg+="LoanCategoryId is required and should be valid!";
//				isValid = false;
//			}
			if (TLFamilyProperty.getPropertyName() == null || TLFamilyProperty.getPropertyName().equalsIgnoreCase("")) {
				invalidMsg += "TLFamilyProperty Name is required and should not be empty!";
				isValid = false;
			}
//			if (LoanCategory.getLoanCategoryName() == null || LoanCategory.getLoanCategoryName().equalsIgnoreCase("")) {
//				invalidMsg += "LoanCategory Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (LoanCategory.getQuotaInMB() == null || LoanCategory.getQuotaInMB().equals(0) || LoanCategory.getQuotaInMB()<0) {
//				invalidMsg += "LoanCategory Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanCategory.getChatHistoryDays() == null || LoanCategory.getChatHistoryDays().equals(0) || LoanCategory.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for LoanCategory is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanCategory.getCdaTimeoutTime() == null || LoanCategory.getCdaTimeoutTime().equals(0) || LoanCategory.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for TLFamilyProperty!";
			isValid = false;
		}
		return isValid;
	}
	
}
