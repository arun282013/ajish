package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Activityfinanced;
import com.kswdc.loanmanagementsystem.api.value.ActivityfinancedVO;

@Repository
public interface ActivityfinancedRepository extends JpaRepository<Activityfinanced, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.ActivityfinancedVO(o.activityfinancedId,"+
      " o.activityfinancedName, s.sectorName,o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM Activityfinanced o LEFT JOIN Sector s ON o.sectorObj=s.sectorId LEFT JOIN User u ON o.createdBy=u.userId "+
            "LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 ORDER BY o.activityfinancedName ASC")
   List<ActivityfinancedVO> getActivityfinancedList();//Filter only active activityfinanced
    
    @Query("SELECT a from Activityfinanced a WHERE a.id=:activityfinancedId")
    Activityfinanced getActivityfinancedById(@Param("activityfinancedId") Integer activityfinancedId);

    @Query("SELECT cl FROM Activityfinanced cl WHERE cl.activityfinancedName=:activityfinancedName")
    Activityfinanced findByActivityfinancedName(@Param("activityfinancedName") String activityfinancedName);
}
