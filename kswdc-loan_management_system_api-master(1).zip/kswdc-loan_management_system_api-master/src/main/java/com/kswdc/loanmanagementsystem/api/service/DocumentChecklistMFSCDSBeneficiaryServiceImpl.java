package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistMFSCDSBeneficiary;
import com.kswdc.loanmanagementsystem.api.repository.DocumentChecklistMFSCDSBeneficiaryRepository;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistMFSCDSBeneficiaryVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

@Service
public class DocumentChecklistMFSCDSBeneficiaryServiceImpl implements DocumentChecklistMFSCDSBeneficiaryService {
	private final Logger log = LoggerFactory.getLogger(DocumentChecklistMFSCDSBeneficiaryServiceImpl.class);

	@Autowired
	private DocumentChecklistMFSCDSBeneficiaryRepository documentChecklistMFSCDSBeneficiaryRepository;

	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createDocumentChecklistMFSCDSBeneficiary(DocumentChecklistMFSCDSBeneficiary DocumentChecklistMFSCDSBeneficiary) {
		try {
			DocumentChecklistMFSCDSBeneficiary savedDocumentChecklistMFSCDSBeneficiary = documentChecklistMFSCDSBeneficiaryRepository
					.save(DocumentChecklistMFSCDSBeneficiary);
			return savedDocumentChecklistMFSCDSBeneficiary.getDocChecklistMFSCDSBeneficiaryId() != null
					? savedDocumentChecklistMFSCDSBeneficiary.getDocChecklistMFSCDSBeneficiaryId()
					: -1;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistMFSCDSBeneficiaryServiceImpl::createDocumentChecklistMFSCDSBeneficiary======"
					+ e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateDocumentChecklistMFSCDSBeneficiary(DocumentChecklistMFSCDSBeneficiary DocumentChecklistMFSCDSBeneficiary) {
		try {
			DocumentChecklistMFSCDSBeneficiary updateDocumentChecklistMFSCDSBeneficiary = documentChecklistMFSCDSBeneficiaryRepository
					.save(DocumentChecklistMFSCDSBeneficiary);
			return updateDocumentChecklistMFSCDSBeneficiary.getDocChecklistMFSCDSBeneficiaryId() != null
					? updateDocumentChecklistMFSCDSBeneficiary.getDocChecklistMFSCDSBeneficiaryId()
					: -1;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistMFSCDSBeneficiaryServiceImpl::updateDocumentChecklistMFSCDSBeneficiary======"
					+ e.getMessage());
		}
		return null;
	}

	@Override
	public DocumentChecklistMFSCDSBeneficiary getDocumentChecklistMFSCDSBeneficiary(Integer id) {
		try {
			DocumentChecklistMFSCDSBeneficiary documentChecklistMFSCDSBeneficiary = documentChecklistMFSCDSBeneficiaryRepository
					.getDocumentChecklistMFSCDSBeneficiaryById(id);
			return documentChecklistMFSCDSBeneficiary;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistMFSCDSBeneficiaryServiceImpl::getDocumentChecklistMFSCDSBeneficiary======"
					+ e.getMessage());
		}
		return null;
	}

	@Override
	public DocumentChecklistMFSCDSBeneficiaryVO getDocumentChecklistMFSCDSBeneficiaryVO(Integer id) {
		try {
			DocumentChecklistMFSCDSBeneficiaryVO documentChecklistMFSCDSBeneficiary = documentChecklistMFSCDSBeneficiaryRepository
					.getDocumentChecklistMFSCDSBeneficiaryVOById(id);
			return documentChecklistMFSCDSBeneficiary;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistMFSCDSBeneficiaryServiceImpl::getDocumentChecklistMFSCDSBeneficiaryVO======"
					+ e.getMessage());
		}
		return null;
	}

	@Override
	public List<DocumentChecklistMFSCDSBeneficiaryVO> getDocumentChecklistMFSCDSBeneficiaryByMFSCDSLoanId(Integer mfscdsLoanId) {
		try {
			List<DocumentChecklistMFSCDSBeneficiaryVO> documentChecklistMFSCDSBeneficiaries = documentChecklistMFSCDSBeneficiaryRepository
					.getDocumentChecklistMFSCDSBeneficiaryByMFSCDSLoanId(mfscdsLoanId);
			return documentChecklistMFSCDSBeneficiaries;
		} catch (Exception e) {
			log.error(
					"Exception in DocumentChecklistMFSCDSBeneficiaryServiceImpl::getDocumentChecklistMFSCDSBeneficiaryByMFSCDSLoanId======"
							+ e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteDocumentChecklistMFSCDSBeneficiary(Integer id) {
		try {
			DocumentChecklistMFSCDSBeneficiary DocumentChecklistMFSCDSBeneficiary = getDocumentChecklistMFSCDSBeneficiary(id);
			// LoanType.setActive(Boolean.FALSE);
			// LoanDocumentChecklist.setDeletedOn(DateFunctions.getZonedServerDate());
			// LoanDocumentChecklist.setIsDeleted(Constants.IS_DELETED);
			DocumentChecklistMFSCDSBeneficiary updatedDocumentChecklistMFSCDSBeneficiary = documentChecklistMFSCDSBeneficiaryRepository
					.save(DocumentChecklistMFSCDSBeneficiary);
			return updatedDocumentChecklistMFSCDSBeneficiary.getDocChecklistMFSCDSBeneficiaryId() != null
					? updatedDocumentChecklistMFSCDSBeneficiary.getDocChecklistMFSCDSBeneficiaryId()
					: -1;
		} catch (Exception e) {
			log.error("Exception in LDocumentChecklistMFSCDSBeneficiaryServiceImpl::deleteDocumentChecklistMFSCDSBeneficiary======"
					+ e.getMessage());
		}
		return null;
	}

	@Override
	public List<DocumentChecklistMFSCDSBeneficiaryVO> getDocumentChecklistMFSCDSBeneficiaryList() {
		try {
			List<DocumentChecklistMFSCDSBeneficiaryVO> documentChecklistMFSCDSBeneficiaryList = documentChecklistMFSCDSBeneficiaryRepository
					.getDocumentChecklistMFSCDSBeneficiaryList();
			return documentChecklistMFSCDSBeneficiaryList;
		} catch (Exception e) {
			log.error("Exception in DocumentChecklistMFSCDSBeneficiaryServiceImpl::getDocumentChecklistMFSCDSBeneficiaryList======"
					+ e.getMessage());
		}
		return null;
	}

	// @Override
	// public LoanDocumentChecklist
	// getLoanDocumentChecklistByLoanDocumentChecklistName(String
	// loanDocumentChecklistName) {
	// try {
	// LoanDocumentChecklist loanDocumentChecklist =
	// loanDocumentChecklistRepository.findByLoanDocumentChecklistName(loanDocumentChecklistName);
	// return loanDocumentChecklist;
	// } catch (Exception e) {
	// log.error("Exception in
	// LoanDocumentChecklistServiceImpl::getLoanDocumentChecklistByLoanDocumentChecklistName======"
	// + e.getMessage());
	// }
	// return null;
	// }
}