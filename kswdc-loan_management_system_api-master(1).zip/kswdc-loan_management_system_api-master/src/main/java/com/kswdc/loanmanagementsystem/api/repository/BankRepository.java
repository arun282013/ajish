package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Bank;
import com.kswdc.loanmanagementsystem.api.value.BankVO;

@Repository
public interface BankRepository extends JpaRepository<Bank, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.BankVO(o.bankId,"+
      " o.bankName,o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM Bank o LEFT JOIN User u ON o.createdBy=u.userId LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 ORDER BY o.bankName ASC")
   List<BankVO> getBankList();//Filter only active banks
    
    @Query("SELECT a from Bank a WHERE a.id=:bankId")
    Bank getBankById(@Param("bankId") Integer bankId);

    @Query("SELECT cl FROM Bank cl WHERE cl.bankName=:bankName")
    Bank findByBankName(@Param("bankName") String bankName);
}
