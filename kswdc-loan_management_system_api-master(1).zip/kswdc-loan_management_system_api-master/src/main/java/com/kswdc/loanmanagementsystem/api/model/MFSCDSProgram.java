package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_mfscds_program")
@EqualsAndHashCode()
public class MFSCDSProgram{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PROGRAM_ID")
    private Integer programId;

    @Column(name = "PROGRAM_YEAR", columnDefinition = "varchar(100) not null")
     private String programYear;

    @Column(name = "PROGRAM_NAME", columnDefinition = "varchar(100) not null")
    private String programName;
       
    @Column(name = "PROGRAM_INSTNAME", columnDefinition = "varchar(200) not null")
     private String programinstName;

    @Column(name = "PROGRAM_AMOUNTRECEIVED", columnDefinition = "decimal(15,2) not null default 0.00")
     private Double programamountReceived;

    @Column(name = "PROGRAM_BENEFITS", columnDefinition = "varchar(200) not null")
     private String programBenefits;
      
}
