package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.MaritalStatus;
import com.kswdc.loanmanagementsystem.api.value.MaritalStatusVO;

@Repository
public interface MaritalStatusRepository extends JpaRepository<MaritalStatus, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.MaritalStatusVO(o.maritalstatusId,"+
      " o.maritalstatusName,o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM MaritalStatus o LEFT JOIN User u ON o.createdBy=u.userId LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 ORDER BY o.maritalstatusName ASC")
   List<MaritalStatusVO> getMaritalStatusList();//Filter only active maritalStatuss
    
    @Query("SELECT a from MaritalStatus a WHERE a.id=:maritalStatusId")
    MaritalStatus getMaritalStatusById(@Param("maritalStatusId") Integer maritalStatusId);

    @Query("SELECT cl FROM MaritalStatus cl WHERE cl.maritalstatusName=:maritalStatusName")
    MaritalStatus findByMaritalStatusName(@Param("maritalStatusName") String maritalStatusName);
}
