package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class NgoAssistanceVO implements Serializable {
    private Integer assistanceId;
    private String category;
    private String activities;
    private Integer noofshgs;
    private Integer noofborrowers;
    private Double avgamt;
    private Double amtrequired;
   

    public NgoAssistanceVO(Integer assistanceId, String category,
    String activities,Integer noofshgs,
    Integer noofborrowers,Double avgamt,
    Double amtrequired
    ) {
        this.assistanceId = assistanceId;
        this.category= category;
        this.activities = activities;
        this.noofshgs = noofshgs;
        this.noofborrowers = noofborrowers;
        this.avgamt = avgamt;
        this.amtrequired = amtrequired;
        


    }
    
}
