package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Religion;
import com.kswdc.loanmanagementsystem.api.value.ReligionVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface ReligionService {

    Integer createReligion(Religion religion);

    Integer updateReligion(Religion religion);

    Religion getReligion(Integer id);

    Religion getReligionByReligionName(String religionName);

    Integer deleteReligion(Integer id);

    List<ReligionVO> getReligionList();
}
