package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.LoanSuretyType;
import com.kswdc.loanmanagementsystem.api.value.LoanSuretyTypeVO;


@Component
public interface LoanSuretyTypeService {

    Integer createLoanSuretyType(LoanSuretyType loanSuretyType);

    Integer updateLoanSuretyType(LoanSuretyType loanSuretyType);

    LoanSuretyType getLoanSuretyType(Integer id);

    //LoanSuretyType geLoanSuretyTypeByLoanSuretyTypeName(String loanSuretyTypeName);

    Integer deleteLoanSuretyType(Integer id);

    List<LoanSuretyTypeVO> getLoanSuretyTypeList();
}
