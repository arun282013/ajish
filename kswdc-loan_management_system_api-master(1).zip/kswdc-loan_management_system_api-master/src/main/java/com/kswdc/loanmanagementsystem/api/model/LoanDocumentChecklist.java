package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_loan_document_checklist")
@EqualsAndHashCode()
public class LoanDocumentChecklist{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LOAN_DOC_CHECKLIST_ID")
    private Integer loanDocChecklistId;

    @ManyToOne()
    @JoinColumn(name= "LOANTYPE_ID")
    private LoanType loanTypeObj;

    @ManyToOne()
    @JoinColumn(name= "DOCUMENT_CHECKLIST_ID")
    private DocumentChecklist documentChecklistObj;
}
