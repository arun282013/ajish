package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CasteVO implements Serializable {

    private Integer casteId;
    private String casteName;
    private String religionName;
    private ZonedDateTime createdOn;
    private String createdBy;
    private ZonedDateTime modifiedOn;
    private String modifiedBy;
    private Integer isDeleted;
    private String deletedStr;
    private ZonedDateTime deletedOn;
    private Integer isActive;
    private String activeStr;


    public CasteVO(Integer casteId, String casteName, String religionName,
     ZonedDateTime createdOn, String createdBy, ZonedDateTime modifiedOn, String modifiedBy, Integer isDeleted, 
      ZonedDateTime deletedOn, Integer isActive) {
        this.casteId = casteId;
        this.casteName = casteName;
        this.religionName = religionName;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.modifiedOn = modifiedOn;
        this.modifiedBy = modifiedBy;
        this.isDeleted = isDeleted;
        this.deletedStr = isDeleted.equals(1)?Constants.IS_DELETED_STR:Constants.IS_NOT_DELETED_STR;
        this.deletedOn = deletedOn;
        this.isActive = isActive;
        this.activeStr = isActive.equals(1)?Constants.IS_ACTIVE_STR:Constants.IS_NOT_ACTIVE_STR;
    }
    
}
