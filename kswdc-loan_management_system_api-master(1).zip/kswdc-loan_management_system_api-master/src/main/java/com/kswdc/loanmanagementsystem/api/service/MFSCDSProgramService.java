package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.MFSCDSProgram;
import com.kswdc.loanmanagementsystem.api.value.MFSCDSProgramVO;


@Component
public interface MFSCDSProgramService {

    Integer createMFSCDSProgram(MFSCDSProgram mfscdsprogram);

    Integer updateMFSCDSProgram(MFSCDSProgram mfscdsprogram);

    MFSCDSProgram getMFSCDSProgram(Integer id);

    Integer deleteMFSCDSProgram(Integer id);

}
