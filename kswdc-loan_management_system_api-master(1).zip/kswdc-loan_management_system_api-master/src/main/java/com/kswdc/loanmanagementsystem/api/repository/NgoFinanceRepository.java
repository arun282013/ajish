package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Ngofinance;
import com.kswdc.loanmanagementsystem.api.value.NgoFinanceVO;

@Repository
public interface NgoFinanceRepository extends JpaRepository<Ngofinance, Integer> {
   // @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TLFamilyMemberVO(f.tlfamilyMemberId,"+
   //    " f.tlfamilyMemberName,f.tlfamilyMemberAge,f.tlfamilyMemberEduqualification,f.tlfamilyMemberJob,"+
   //       "f.tlfamilyMemberAnnualIncome,t.fullName,r.relationName)"+ 
   //       "FROM TLFamilyMember f LEFT JOIN TermLoan t ON f.termLoanObj= t.termLoanId "+
   //       " LEFT JOIN Relation r ON f.relationObj = r.relationId "+
   //         " ORDER BY f.tlfamilyMemberName ASC")
   // @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.TLFamilyMemberVO(f.tlfamilyMemberId,"+
   //    " f.tlfamilyMemberName,f.tlfamilyMemberAge,f.tlfamilyMemberEduqualification,f.tlfamilyMemberJob,"+
   //       "f.tlfamilyMemberAnnualIncome,t.fullName,r.relationName)"+ 
   //       "FROM TLFamilyMember f "+
   //       " LEFT JOIN Relation r ON f.relationObj = r.relationId "+
   //         " ORDER BY f.tlfamilyMemberName ASC")
//    List<TLFamilyMemberVO> getTLFamilyMemberList();//Filter only active familymember
    
    @Query("SELECT a FROM Ngofinance a WHERE a.id=:financeId")
    Ngofinance getNgoFinanceById(@Param("financeId") Integer financeId);
 
    @Query("SELECT cl FROM Ngofinance cl WHERE cl.programName=programName")
    Ngofinance getNgoFinanceByNgoFinanceName(@Param("programName") String programName);

}
