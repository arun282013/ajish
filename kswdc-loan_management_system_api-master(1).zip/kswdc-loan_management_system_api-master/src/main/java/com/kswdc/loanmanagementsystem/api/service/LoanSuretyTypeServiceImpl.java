package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.LoanSuretyType;
import com.kswdc.loanmanagementsystem.api.repository.LoanSuretyTypeRepository;
import com.kswdc.loanmanagementsystem.api.value.LoanSuretyTypeVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;


@Service
public class LoanSuretyTypeServiceImpl implements LoanSuretyTypeService {
	private final Logger log = LoggerFactory.getLogger(LoanSuretyTypeServiceImpl.class);
	
	@Autowired
	private LoanSuretyTypeRepository loanSuretyTypeRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createLoanSuretyType(LoanSuretyType LoanSuretyType) {
		try {
			LoanSuretyType savedLoanSuretyType = loanSuretyTypeRepository.save(LoanSuretyType);
			return savedLoanSuretyType.getLoan_suretytypeId() != null ? savedLoanSuretyType.getLoan_suretytypeId() : -1;
		} catch (Exception e) {
			log.error("Exception in LoanSuretyTypeServiceImpl::createLoanSuretyType======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateLoanSuretyType(LoanSuretyType LoanSuretyType) {
		try {
			LoanSuretyType updateLoanSuretyType = loanSuretyTypeRepository.save(LoanSuretyType);
			return updateLoanSuretyType.getLoan_suretytypeId() != null ? updateLoanSuretyType.getLoan_suretytypeId() : -1;
		} catch (Exception e) {
			log.error("Exception in LoanSuretyTypeServiceImpl::updateLoanSuretyType======" + e.getMessage());
		}
		return null;
	}

	@Override
	public LoanSuretyType getLoanSuretyType(Integer id) {
		try {
			LoanSuretyType loanSuretyType = loanSuretyTypeRepository.getLoanSuretyTypeById(id);
			return loanSuretyType;
		} catch (Exception e) {
			log.error("Exception in LoanSuretyTypeServiceImpl::getLoanSuretyType======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteLoanSuretyType(Integer id) {
		try {
			LoanSuretyType LoanSuretyType = getLoanSuretyType(id);
//			LoanType.setActive(Boolean.FALSE);
			// LoanSuretyType.setDeletedOn(DateFunctions.getZonedServerDate());
			//LoanSuretyType.setIsDeleted(Constants.IS_DELETED);
			LoanSuretyType updatedLoanSuretyType = loanSuretyTypeRepository.save(LoanSuretyType);
			return updatedLoanSuretyType.getLoan_suretytypeId() != null ? updatedLoanSuretyType.getLoan_suretytypeId() : -1;
		} catch (Exception e) {
			log.error("Exception in LoanSuretyTypeServiceImpl::deleteLoanSuretyType======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<LoanSuretyTypeVO> getLoanSuretyTypeList() {
		try {
			List<LoanSuretyTypeVO> loanSuretyTypeList = loanSuretyTypeRepository.getLoanSuretyTypeList();
			return loanSuretyTypeList;
		} catch (Exception e) {
			log.error("Exception in LoanSuretyTypeServiceImpl::getLoanSuretyTypeList======" + e.getMessage());
		}
		return null;
	}

	// @Override
	// public LoanSuretyType getLoanSuretyTypeByLoanSuretyTypeName(String loanSuretyTypeName) {
	// 	try {
	// 		LoanSuretyType loanSuretyType = loanSuretyTypeRepository.findByLoanSuretyTypeName(loanSuretyTypeName);
	// 		return loanSuretyType;
	// 	} catch (Exception e) {
	// 		log.error("Exception in LoanSuretyTypeServiceImpl::getLoanSuretyTypeByLoanSuretyTypeName======" + e.getMessage());
	// 	}
	// 	return null;
	// }
}