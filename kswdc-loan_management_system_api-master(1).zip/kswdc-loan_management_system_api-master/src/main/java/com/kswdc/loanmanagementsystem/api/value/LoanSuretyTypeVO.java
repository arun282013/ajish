package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class LoanSuretyTypeVO implements Serializable {

    private Integer loan_suretytypeId;
    private String loanTypeName;
    private String suretytypeName;

    public LoanSuretyTypeVO(Integer loan_suretytypeId,  String loanTypeName, 
    String suretytypeName) {
        this.loan_suretytypeId = loan_suretytypeId;
        this.loanTypeName = loanTypeName;
        this.suretytypeName = suretytypeName;
    }
    
}
