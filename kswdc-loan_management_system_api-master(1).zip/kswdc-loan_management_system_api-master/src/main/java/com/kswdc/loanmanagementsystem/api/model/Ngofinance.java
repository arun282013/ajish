package com.kswdc.loanmanagementsystem.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.ZonedDateTime;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tbl_ngo_finance")
@EqualsAndHashCode()
public class Ngofinance{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "finance_ID")
    private Integer financeId;

    @Column(name = "financeYear",columnDefinition ="int not null")
    private String financeYear;
    
    @Column(name = "programName", columnDefinition = "varchar(100) not null")
     private String programName;
    
     @Column(name = "fundedBy", columnDefinition = "varchar(100) not null")
     private String fundedBy;

     @Column(name = "amountreceived", columnDefinition = "decimal(15,2) not null default 0.00")
     private Double amountReceived;

     @Column(name = "achievements", columnDefinition = "varchar(200) not null")
     private String achievements;


       
}
