package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.TLFamilyMember;
import com.kswdc.loanmanagementsystem.api.repository.TLFamilyMemberRepository;
import com.kswdc.loanmanagementsystem.api.value.TLFamilyMemberVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class TLFamilyMemberServiceImpl implements TLFamilyMemberService {
	private final Logger log = LoggerFactory.getLogger(TLFamilyMemberServiceImpl.class);

	@Autowired
	private TLFamilyMemberRepository tlfamilymemberRepository;

	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createTLFamilyMember(TLFamilyMember TLFamilyMember) {
		try {
			TLFamilyMember savedTLFamilyMember = tlfamilymemberRepository.save(TLFamilyMember);
			return savedTLFamilyMember.getMemberId() != null ? savedTLFamilyMember.getMemberId() : -1;
		} catch (Exception e) {
			log.error("Exception in TLFamilyMemberServiceImpl::createTLFamilyMember======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateTLFamilyMember(TLFamilyMember TLFamilyMember) {
		try {
			TLFamilyMember updateTLFamilyMember = tlfamilymemberRepository.save(TLFamilyMember);
			return updateTLFamilyMember.getMemberId() != null ? updateTLFamilyMember.getMemberId() : -1;
		} catch (Exception e) {
			log.error("Exception in TLFamilyMemberServiceImpl::updateTLFamilyMember======" + e.getMessage());
		}
		return null;
	}

	@Override
	public TLFamilyMember getTLFamilyMember(Integer id) {
		try {
			TLFamilyMember tlfamilymember = tlfamilymemberRepository.getTLFamilyMemberById(id);
			return tlfamilymember;
		} catch (Exception e) {
			log.error("Exception in TLFamilyMemberServiceImpl::getTLFamilyMember======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteTLFamilyMember(Integer id) {
		try {
			TLFamilyMember TLFamilyMember = getTLFamilyMember(id);
			// TLFamilyMember.setActive(Boolean.FALSE);
			// TLFamilyMember.setDeletedOn(DateFunctions.getZonedServerDate());
			// TLFamilyMember.setIsDeleted(Constants.IS_DELETED);
			TLFamilyMember updatedTLFamilyMember = tlfamilymemberRepository.save(TLFamilyMember);
			return updatedTLFamilyMember.getMemberId() != null ? updatedTLFamilyMember.getMemberId() : -1;
		} catch (Exception e) {
			log.error("Exception in TLFamilyMemberServiceImpl::deleteTLFamilyMember======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<TLFamilyMember> getTLFamilyMemberListByTLId(Integer termLoanId) {
		List<TLFamilyMember> familyMembers = new ArrayList<TLFamilyMember>();
		try {
			familyMembers = tlfamilymemberRepository.getTLFamilyMemberListByTLId(termLoanId);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception in TLFamilyMemberServiceImpl::getTLFamilyMemberListByTLId======" + e.getMessage());
		}
		return familyMembers;
	}

	// @Override
	// public List<TLFamilyMemberVO> getTLFamilyMemberList() {
	// try {
	// List<TLFamilyMemberVO> tlfamilymemberList =
	// tlfamilymemberRepository.getTLFamilyMemberList();
	// return tlfamilymemberList;
	// } catch (Exception e) {
	// log.error("Exception in
	// TLFamilyMemberServiceImpl::getTLFamilyMemberList======" + e.getMessage());
	// }
	// return null;
	// }

	// @Override
	// public TLFamilyMember getTLFamilyMemberByTLFamilyMemberName(String
	// TLFamilyMemberName) {
	// try {
	// TLFamilyMember TLFamilyMember =
	// TLFamilyMemberRepository.getTLFamilyMemberByTLFamilyMemberName(TLFamilyMemberName);
	// return TLFamilyMember;
	// } catch (Exception e) {
	// log.error("Exception in
	// TLFamilyMemberServiceImpl::getTLFamilyMemberByTLFamilyMemberName======" +
	// e.getMessage());
	// }
	// return null;
	// }
}