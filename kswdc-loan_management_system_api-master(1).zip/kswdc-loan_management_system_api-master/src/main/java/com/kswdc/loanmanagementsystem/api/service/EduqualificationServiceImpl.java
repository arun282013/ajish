package com.kswdc.loanmanagementsystem.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.kswdc.loanmanagementsystem.api.model.Eduqualification;
import com.kswdc.loanmanagementsystem.api.repository.EduqualificationRepository;
import com.kswdc.loanmanagementsystem.api.value.EduqualificationVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */

@Service
public class EduqualificationServiceImpl implements EduqualificationService {
	private final Logger log = LoggerFactory.getLogger(EduqualificationServiceImpl.class);
	
	@Autowired
	private EduqualificationRepository eduqualificationRepository;
	
	@Value("${spring.application.name}")
	private String appName;

	@Override
	public Integer createEduqualification(Eduqualification Eduqualification) {
		try {
			Eduqualification savedEduqualification = eduqualificationRepository.save(Eduqualification);
			return savedEduqualification.getEduqualificationId() != null ? savedEduqualification.getEduqualificationId() : -1;
		} catch (Exception e) {
			log.error("Exception in EduqualificationServiceImpl::createEduqualification======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer updateEduqualification(Eduqualification Eduqualification) {
		try {
			Eduqualification updateEduqualification = eduqualificationRepository.save(Eduqualification);
			return updateEduqualification.getEduqualificationId() != null ? updateEduqualification.getEduqualificationId() : -1;
		} catch (Exception e) {
			log.error("Exception in EduqualificationServiceImpl::updateEduqualification======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Eduqualification getEduqualification(Integer id) {
		try {
			Eduqualification eduqualification = eduqualificationRepository.getEduqualificationById(id);
			return eduqualification;
		} catch (Exception e) {
			log.error("Exception in EduqualificationServiceImpl::getEduqualification======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Integer deleteEduqualification(Integer id) {
		try {
			Eduqualification Eduqualification = getEduqualification(id);
//			Eduqualification.setActive(Boolean.FALSE);
			Eduqualification.setDeletedOn(DateFunctions.getZonedServerDate());
			Eduqualification.setIsDeleted(Constants.IS_DELETED);
			Eduqualification updatedEduqualification = eduqualificationRepository.save(Eduqualification);
			return updatedEduqualification.getEduqualificationId() != null ? updatedEduqualification.getEduqualificationId() : -1;
		} catch (Exception e) {
			log.error("Exception in EduqualificationServiceImpl::deleteEduqualification======" + e.getMessage());
		}
		return null;
	}

	@Override
	public List<EduqualificationVO> getEduqualificationList() {
		try {
			List<EduqualificationVO> eduqualificationList = eduqualificationRepository.getEduqualificationList();
			return eduqualificationList;
		} catch (Exception e) {
			log.error("Exception in EduqualificationServiceImpl::getEduqualificationList======" + e.getMessage());
		}
		return null;
	}

	@Override
	public Eduqualification getEduqualificationByEduqualificationName(String eduqualificationName) {
		try {
			Eduqualification eduqualification = eduqualificationRepository.findByEduqualificationName(eduqualificationName);
			return eduqualification;
		} catch (Exception e) {
			log.error("Exception in EduqualificationServiceImpl::getEduqualificationByEduqualificationName======" + e.getMessage());
		}
		return null;
	}
}