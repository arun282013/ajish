package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.Caste;
import com.kswdc.loanmanagementsystem.api.service.CasteService;
import com.kswdc.loanmanagementsystem.api.value.CasteVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class CasteController {

	private final Logger log = LoggerFactory.getLogger(CasteController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private CasteService casteService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param Caste Caste
	 * @return Map
	 */
	@RequestMapping(value = "/caste", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createCaste(@RequestBody Caste Caste) {
		log.info("In CasteController::createCaste=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(Caste)) {
//						Caste.setActive(Boolean.TRUE);
						Caste.setCreatedOn(DateFunctions.getZonedServerDate());
						// Caste.setCreatedBy();
						Caste.setIsDeleted(0);
						Integer casteId = casteService.createCaste(Caste);
						if (!casteId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("casteId", casteId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in CasteController::createCaste======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param Caste Caste
	 * @return Map
	 */
	@RequestMapping(value = "/caste", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateCaste(@RequestBody Caste caste) {
		log.info("In CasteController::updateCaste=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (caste != null) { // && Caste.getId() != null
				if (checkValid(caste)) {
					Caste chkCaste = casteService.getCaste(caste.getCasteId());
					if (chkCaste!=null) {
//						if (chkCaste.getActive()) {
//							Caste.setActive(Boolean.TRUE);
							chkCaste.setCasteName(caste.getCasteName());							
							chkCaste.setIsActive(caste.getIsActive());							
							Integer casteId = casteService.updateCaste(chkCaste);
							if (!casteId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("casteId:", casteId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" Caste Id is deactivated:"+Caste.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in CasteController::updateCaste======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/caste/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteCaste(@PathVariable Integer id) {
		log.info("In CasteController::deleteCaste=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Caste Caste = casteService.getCaste(id);
				if (Caste != null) {
//					if (!Caste.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " CasteId:" + id);
//					} else {
						Integer casteId = casteService.deleteCaste(id);
						if (!casteId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("CasteId", casteId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in CasteController::deleteCaste======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/caste/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneCaste(@PathVariable Integer id) {
		log.info("In CasteController::getOneCaste=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				Caste Caste = casteService.getCaste(id);
				if (Caste != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("Caste", Caste);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in CasteController::getOneCaste======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- Caste ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/caste-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getCasteList() {
		log.info("In CasteController::getCasteList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			CasteListReturnVO CasteListReturnVO = new CasteListReturnVO(CasteService.getCasteList());
			List<CasteVO> CasteListReturnVO = casteService.getCasteList();
			if (CasteListReturnVO != null && CasteListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("castes", CasteListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in CasteController::getCasteList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/caste-list-by-religion/{religionId}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getCasteListByReligion(@PathVariable Integer religionId) {
		log.info("In CasteController::getCasteListByReligion=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			List<CasteVO> CasteListReturnVO = casteService.getCasteListByReligion(religionId);
			if (CasteListReturnVO != null && CasteListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("castes", CasteListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in CasteController::getCasteListByReligion======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param CasteId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer casteId) {
		return (casteService.getCaste(casteId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param Caste
	 * @return Boolean
	 */
	private Boolean checkValid(Caste Caste) {
		Boolean isValid = true;
		invalidMsg = "";
		if (Caste != null) {
//			if(Caste.getId()==null || Caste.getId()<=0) {
//				invalidMsg+="CasteId is required and should be valid!";
//				isValid = false;
//			}
			if (Caste.getCasteName() == null || Caste.getCasteName().equalsIgnoreCase("")) {
				invalidMsg += "Caste Name is required and should not be empty!";
				isValid = false;
			}
//			if (Caste.getCasteName() == null || Caste.getCasteName().equalsIgnoreCase("")) {
//				invalidMsg += "Caste Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (Caste.getQuotaInMB() == null || Caste.getQuotaInMB().equals(0) || Caste.getQuotaInMB()<0) {
//				invalidMsg += "Caste Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (Caste.getChatHistoryDays() == null || Caste.getChatHistoryDays().equals(0) || Caste.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for Caste is required and should be valid!";
//				isValid = false;
//			}
//			if (Caste.getCdaTimeoutTime() == null || Caste.getCdaTimeoutTime().equals(0) || Caste.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for Caste!";
			isValid = false;
		}
		return isValid;
	}
	
}
