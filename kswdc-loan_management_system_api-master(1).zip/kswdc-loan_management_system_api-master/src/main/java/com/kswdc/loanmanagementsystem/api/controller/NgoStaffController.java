package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.NgoStaff;
import com.kswdc.loanmanagementsystem.api.service.NgoStaffService;
import com.kswdc.loanmanagementsystem.api.value.NgoStaffVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;


@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class NgoStaffController {

	private final Logger log = LoggerFactory.getLogger(NgoStaffController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private NgoStaffService ngostaffService;
	
	/**
	 * @param NgoStaff NgoStaff
	 * @return Map
	 */
	@RequestMapping(value = "/ngostaff", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createNgoStaff(@RequestBody NgoStaff NgoStaff) {
		log.info("In NgoStaffController::createNgoStaff=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(NgoStaff)) {
//						LoanCategory.setActive(Boolean.TRUE);
						// TLFamilyMember.setCreatedOn(DateFunctions.getZonedServerDate());
						// LoanCategory.setCreatedBy();
						// TLFamilyMember.setIsDeleted(0);
						Integer StaffId = ngostaffService.createNgoStaff(NgoStaff);
						if (!StaffId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("StaffId", StaffId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in NgoStaffController::createNgoStaff======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * //@param NgoStaff NgoStaff
	 * @return Map
	 */
	@RequestMapping(value = "/ngostaff", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateNgoStaff(@RequestBody NgoStaff ngostaff) {
		log.info("In NgoStaffController::updateNgoStaff=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (ngostaff != null) { // && TLFamilyMember.getId() != null
				if (checkValid(ngostaff)) {
					NgoStaff chkNgoStaff = ngostaffService.getNgoStaff(ngostaff.getStaffId());
					if (chkNgoStaff!=null) {
//						if (chkLoanCategory.getActive()) {
//							LoanCategory.setActive(Boolean.TRUE);
							// chkTLFamilyMember.setTLFamilyMemberName(tLFamilyMember.getTLFamilyMemberName());							
							// chkTLFamilyMember.setIsActive(tLFamilyMember.getIsActive());							
							chkNgoStaff.setStaffId(ngostaff.getStaffId());
							
							Integer staffId = ngostaffService.updateNgoStaff(chkNgoStaff);
							if (!staffId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("staffId:", staffId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" LoanCategory Id is deactivated:"+LoanCategory.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in ngoStaffController::updatengoStaff======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/ngostaff/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteNgoStaff(@PathVariable Integer id) {
		log.info("In staffIdController::deletestaffId=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				NgoStaff NgoStaff = ngostaffService.getNgoStaff(id);
				if (NgoStaff != null) {
//					if (!LoanCategory.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " LoanCategoryId:" + id);
//					} else {
						Integer staffId = ngostaffService.deleteNgoStaff(id);
						if (!staffId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("staffId", staffId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in NgoStaffController::deleteNgoStaff======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/staff-by-loan/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneNgoStaff(@PathVariable Integer id) {
		log.info("In NgoStaffController::getOneNgoStaff=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				NgoStaff NgoStaff = ngostaffService.getNgoStaff(id);
				if (NgoStaff != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("NgoStaff", NgoStaff);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in NgoThriftController::getOneNgoThrift======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- LoanCategory ------------------------------



	/**
	 * @param TLFamilyMemberId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer staffId) {
		return (ngostaffService.getNgoStaff(staffId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @purpose For checking if mandatory data is passed
	 * @param NgoThrift
	 * @return Boolean
	 */
	private Boolean checkValid(NgoStaff NgoStaff) {
		Boolean isValid = true;
		invalidMsg = "";
		if (NgoStaff != null) {
//			if(LoanCategory.getId()==null || LoanCategory.getId()<=0) {
//				invalidMsg+="LoanCategoryId is required and should be valid!";
//				isValid = false;
//			}
			if (NgoStaff.getOfficetrained() == null ) {
				invalidMsg += "NgoStaff office is required and should not be empty!";
				isValid = false;
			}
//			if (LoanCategory.getLoanCategoryName() == null || LoanCategory.getLoanCategoryName().equalsIgnoreCase("")) {
//				invalidMsg += "LoanCategory Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (LoanCategory.getQuotaInMB() == null || LoanCategory.getQuotaInMB().equals(0) || LoanCategory.getQuotaInMB()<0) {
//				invalidMsg += "LoanCategory Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanCategory.getChatHistoryDays() == null || LoanCategory.getChatHistoryDays().equals(0) || LoanCategory.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for LoanCategory is required and should be valid!";
//				isValid = false;
//			}
//			if (LoanCategory.getCdaTimeoutTime() == null || LoanCategory.getCdaTimeoutTime().equals(0) || LoanCategory.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for NgoStaff!";
			isValid = false;
		}
		return isValid;
	}
	
}
