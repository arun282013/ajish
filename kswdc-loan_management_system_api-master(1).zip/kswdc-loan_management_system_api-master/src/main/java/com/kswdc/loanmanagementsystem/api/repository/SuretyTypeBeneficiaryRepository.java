package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.SuretyTypeBeneficiary;
import com.kswdc.loanmanagementsystem.api.value.SuretyTypeBeneficiaryVO;

@Repository
public interface SuretyTypeBeneficiaryRepository extends JpaRepository<SuretyTypeBeneficiary, Integer> {
    @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.SuretyTypeBeneficiaryVO(sb.suretytypeBeneficiaryId,st.suretytypeName,"+
    "tl.fullName,l.loantypeId,l.loantypeName) " +
         "FROM SuretyTypeBeneficiary sb LEFT JOIN SuretyType st on sb.suretyTypeObj=st.suretytypeId " +
         "LEFT JOIN TermLoan tl ON sb.termLoanObj=tl.termLoanId LEFT JOIN LoanType l ON sb.loanTypeObj=l.loantypeId "+
          "ORDER BY sb.suretytypeBeneficiaryId ASC") 
 List<SuretyTypeBeneficiaryVO> getSuretyTypeBeneficiaryList();//Filter only active data
  
  @Query("SELECT a from SuretyTypeBeneficiary a WHERE a.id=:suretytypeBeneficiaryId")
  SuretyTypeBeneficiary getSuretyTypeBeneficiaryById(@Param("suretytypeBeneficiaryId") Integer suretytypeBeneficiaryId);

  @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.SuretyTypeBeneficiaryVO(sb.suretytypeBeneficiaryId,st.suretytypeName,"+
    "tl.fullName,l.loantypeId,l.loantypeName) " +
         "FROM SuretyTypeBeneficiary sb LEFT JOIN SuretyType st on sb.suretyTypeObj=st.suretytypeId " +
         "LEFT JOIN TermLoan tl ON sb.termLoanObj=tl.termLoanId LEFT JOIN LoanType l ON sb.loanTypeObj=l.loantypeId "+
         " WHERE sb.id=:suretytypeBeneficiaryId")
  SuretyTypeBeneficiaryVO getSuretyTypeBeneficiaryVOById(@Param("suretytypeBeneficiaryId") Integer suretytypeBeneficiaryId);

  // @Query("SELECT cl FROM LoanSuretyType cl WHERE cl.userName=:userName")
  // LoanSuretyType findByLoanSuretyTypeName(@Param("userName") String userName);

  @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.SuretyTypeBeneficiaryVO(sb.suretytypeBeneficiaryId,st.suretytypeName,"+
    "tl.fullName,l.loantypeId,l.loantypeName) " +
         "FROM SuretyTypeBeneficiary sb LEFT JOIN SuretyType st on sb.suretyTypeObj=st.suretytypeId " +
         "LEFT JOIN TermLoan tl ON sb.termLoanObj=tl.termLoanId LEFT JOIN LoanType l ON sb.loanTypeObj=l.loantypeId "+
         "WHERE tl.termLoanId=:termLoanId ORDER BY sb.suretytypeBeneficiaryId ASC")
  List<SuretyTypeBeneficiaryVO> getSuretyTypeBeneficiaryByTermLoanId(@Param("termLoanId") Integer termLoanId);
}
