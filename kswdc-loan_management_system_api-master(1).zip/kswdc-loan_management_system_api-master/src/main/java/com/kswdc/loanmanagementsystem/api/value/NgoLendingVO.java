package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class NgoLendingVO implements Serializable {
    private Integer lendingId;
    private String category;
    private String activities;
    private Integer noofshgs;
    private Integer noofborrowers;
    private Double avgloanamt;
    private Double totamt;
   

    public NgoLendingVO(Integer lendingId, 
    String category,String activities, Integer noofshgs,
    Integer noofborrowers,Double  avgloanamt,
    Double totamt 
    ) {
        this.lendingId = lendingId;
        this.category = category;
        this.activities = activities;
        this.noofshgs = noofshgs;
        this.noofborrowers = noofborrowers;
        this.avgloanamt = avgloanamt;
        this.totamt = totamt;
    }
    
}
