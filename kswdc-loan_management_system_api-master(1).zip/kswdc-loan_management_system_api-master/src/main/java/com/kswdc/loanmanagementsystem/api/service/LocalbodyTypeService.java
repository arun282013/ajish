package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.LocalbodyType;
import com.kswdc.loanmanagementsystem.api.value.LocalbodyTypeVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface LocalbodyTypeService {

    Integer createLocalbodyType(LocalbodyType localbodyType);

    Integer updateLocalbodyType(LocalbodyType localbodyType);

    LocalbodyType getLocalbodyType(Integer id);

    LocalbodyType getLocalbodyTypeByLocalbodyTypeName(String localbodyTypeName);

    Integer deleteLocalbodyType(Integer id);

    List<LocalbodyTypeVO> getLocalbodyTypeList();
}
