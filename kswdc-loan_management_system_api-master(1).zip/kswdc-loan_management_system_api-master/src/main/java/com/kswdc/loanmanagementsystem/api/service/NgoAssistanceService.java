package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.NgoAssistance;
import com.kswdc.loanmanagementsystem.api.value.NgoAssistanceVO;


@Component
public interface NgoAssistanceService {

    Integer createNgoAssistance(NgoAssistance ngoAssistance);

    Integer updateNgoAssistance(NgoAssistance ngoAssistance);
    NgoAssistance getNgoAssistance(Integer id);

    // TLFamilyMember getTLFamilyMemberByTLFamilyMemberName(String tlfamilymemberName);

    Integer deleteNgoAssistance(Integer id);

    // List<TLFamilyMemberVO> getTLFamilyMemberList();
}
