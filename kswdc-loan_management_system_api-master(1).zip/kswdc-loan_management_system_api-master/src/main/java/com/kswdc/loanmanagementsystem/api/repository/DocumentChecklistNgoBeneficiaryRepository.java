package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.DocumentChecklistNgoBeneficiary;
import com.kswdc.loanmanagementsystem.api.value.DocumentChecklistNgoBeneficiaryVO;

@Repository
public interface DocumentChecklistNgoBeneficiaryRepository extends JpaRepository<DocumentChecklistNgoBeneficiary, Integer> {
        @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.DocumentChecklistNgoBeneficiaryVO(dc_ben.docChecklistngoBeneficiaryId,dc.documentchecklistngoName,"
                        +
                        "ng.mfsngoname,l.loantypeId,l.loantypeName,dc_ben.filePath) " +
                        "FROM DocumentChecklistNgoBeneficiary dc_ben LEFT JOIN DocumentChecklistNgo dc on dc_ben.documentChecklistngoObj=dc.documentchecklistngoId "
                        +
                        "LEFT JOIN MFSNGOLoan ng ON dc_ben.mfsngoLoanObj=ng.mfsngoLoanId LEFT JOIN LoanType l ON dc_ben.loanTypeObj=l.loantypeId "
                        +
                        "ORDER BY dc_ben.docChecklistngoBeneficiaryId ASC")
        List<DocumentChecklistNgoBeneficiaryVO> getDocumentChecklistngoBeneficiaryList();// Filter only active data

        @Query("SELECT a from DocumentChecklistNgoBeneficiary a WHERE a.id=:docChecklistngoBeneficiaryId")
        DocumentChecklistNgoBeneficiary getDocumentChecklistngoBeneficiaryById(
                        @Param("docChecklistngoBeneficiaryId") Integer docChecklistngoBeneficiaryId);
                        @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.DocumentChecklistNgoBeneficiaryVO(dc_ben.docChecklistngoBeneficiaryId,dc.documentchecklistngoName,"
                        +
                        "ng.mfsngoname,l.loantypeId,l.loantypeName,dc_ben.filePath) " +
                        "FROM DocumentChecklistNgoBeneficiary dc_ben LEFT JOIN DocumentChecklistNgo dc on dc_ben.documentChecklistngoObj=dc.documentchecklistngoId "
                        +
                        "LEFT JOIN MFSNGOLoan ng ON dc_ben.mfsngoLoanObj=ng.mfsngoLoanId LEFT JOIN LoanType l ON dc_ben.loanTypeObj=l.loantypeId "
                        +
                        " WHERE dc_ben.id=:docChecklistngoBeneficiaryId")
        DocumentChecklistNgoBeneficiaryVO getDocumentChecklistngoBeneficiaryVOById(
                        @Param("docChecklistngoBeneficiaryId") Integer docChecklistngoBeneficiaryId);

        // @Query("SELECT a from DocumentChecklistBeneficiary a LEFT JOIN TermLoan t ON
        // a.termLoanObj=t.termLoanId WHERE t.termLoanId=:termLoanId")
        // List<DocumentChecklistBeneficiary>
        // getDocumentChecklistBeneficiaryByTermLoanId(
        // @Param("termLoanId") Integer termLoanId);

        @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.DocumentChecklistNgoBeneficiaryVO(dc_ben.docChecklistngoBeneficiaryId,dc.documentchecklistngoName,"
        +
        "ng.mfsngoname,l.loantypeId,l.loantypeName,dc_ben.filePath) " +
        "FROM DocumentChecklistNgoBeneficiary dc_ben LEFT JOIN DocumentChecklistNgo dc on dc_ben.documentChecklistngoObj=dc.documentchecklistngoId "
        +
        "LEFT JOIN MFSNGOLoan ng ON dc_ben.mfsngoLoanObj=ng.mfsngoLoanId LEFT JOIN LoanType l ON dc_ben.loanTypeObj=l.loantypeId "
        +
                        "WHERE ng.mfsngoLoanId=:mfsngoLoanId ORDER BY dc_ben.docChecklistngoBeneficiaryId ASC")
        List<DocumentChecklistNgoBeneficiaryVO> getDocumentChecklistngoBeneficiaryByMFSNGOLoanId(
                        @Param("mfsngoLoanId") Integer mfsngoLoanId);

        // @Query("SELECT cl FROM LoanDocumentChecklist cl WHERE cl.userName=:userName")
        // LoanDocumentChecklist findByLoanDocumentChecklistName(@Param("userName")
        // String userName);
}
