package com.kswdc.loanmanagementsystem.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.LocalbodyType;
import com.kswdc.loanmanagementsystem.api.value.LocalbodyTypeVO;

@Repository
public interface LocalbodyTypeRepository extends JpaRepository<LocalbodyType, Integer> {
   @Query("SELECT new com.kswdc.loanmanagementsystem.api.value.LocalbodyTypeVO(o.localbodyTypeId,"+
      " o.localbodyTypeName,o.createdOn,u.fullName,o.modifiedOn,mu.fullName,o.isDeleted,o.deletedOn, o.isActive) " +
           " FROM LocalbodyType o LEFT JOIN User u ON o.createdBy=u.userId LEFT JOIN User mu ON o.modifiedBy=mu.userId "+
            " WHERE o.isDeleted=0 ORDER BY o.localbodyTypeName ASC")
   List<LocalbodyTypeVO> getLocalbodyTypeList();//Filter only active localbodyTypes
    
    @Query("SELECT a from LocalbodyType a WHERE a.localbodyTypeId=:localbodyTypeId")
    LocalbodyType getLocalbodyTypeById(@Param("localbodyTypeId") Integer localbodyTypeId);

    @Query("SELECT cl FROM LocalbodyType cl WHERE cl.localbodyTypeName=:localbodyTypeName")
    LocalbodyType findByLocalbodyTypeName(@Param("localbodyTypeName") String localbodyTypeName);
}
