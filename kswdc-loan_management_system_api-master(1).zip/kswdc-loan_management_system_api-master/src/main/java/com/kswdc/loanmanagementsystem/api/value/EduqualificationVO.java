package com.kswdc.loanmanagementsystem.api.value;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.kswdc.loanmanagementsystem.common.Constants;

import lombok.Data;

import java.io.Serializable;
import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EduqualificationVO implements Serializable {

    private Integer eduqualificationId;
    private String eduqualificationName;
    private Integer eduqualificationStatus;
    private String eduqualificationStatusStr;
    private ZonedDateTime createdOn;
    private String createdBy;
    private ZonedDateTime modifiedOn;
    private String modifiedBy;
    private Integer isDeleted;
    private String deletedStr;
    private ZonedDateTime deletedOn;
    private Integer isActive;
    private String activeStr;


    public EduqualificationVO(Integer eduqualificationId, String eduqualificationName, 
     ZonedDateTime createdOn, String createdBy, ZonedDateTime modifiedOn, String modifiedBy, Integer isDeleted, 
      ZonedDateTime deletedOn, Integer isActive) {
        this.eduqualificationId = eduqualificationId;
        this.eduqualificationName = eduqualificationName;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.modifiedOn = modifiedOn;
        this.modifiedBy = modifiedBy;
        this.isDeleted = isDeleted;
        this.deletedStr = isDeleted.equals(1)?Constants.IS_DELETED_STR:Constants.IS_NOT_DELETED_STR;
        this.deletedOn = deletedOn;
        this.isActive = isActive;
        this.activeStr = isActive.equals(1)?Constants.IS_ACTIVE_STR:Constants.IS_NOT_ACTIVE_STR;
    }
    
}
