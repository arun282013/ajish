package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.LocalBody;
import com.kswdc.loanmanagementsystem.api.value.LocalBodyVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface LocalBodyService {

    Integer createLocalBody(LocalBody localBody);

    Integer updateLocalBody(LocalBody localBody);

    LocalBody getLocalBody(Integer id);

    LocalBody getLocalBodyByLocalBodyName(String localbodyName);

    Integer deleteLocalBody(Integer id);

    List<LocalBodyVO> getLocalBodyList();

    List<LocalBodyVO> getLocalBodyListByDistrict(Integer districtId,Integer localbodyTypeId);
}
