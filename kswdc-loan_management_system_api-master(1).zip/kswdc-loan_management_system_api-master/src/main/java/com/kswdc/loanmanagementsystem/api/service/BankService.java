package com.kswdc.loanmanagementsystem.api.service;

import org.springframework.stereotype.Component;

import java.util.List;

import com.kswdc.loanmanagementsystem.api.model.Bank;
import com.kswdc.loanmanagementsystem.api.value.BankVO;

/**
 * Created by arunbalaraj@gmail.com on 24/12/2021.
 */
@Component
public interface BankService {

    Integer createBank(Bank bank);

    Integer updateBank(Bank bank);

    Bank getBank(Integer id);

    Bank getBankByBankName(String bankName);

    Integer deleteBank(Integer id);

    List<BankVO> getBankList();
}
