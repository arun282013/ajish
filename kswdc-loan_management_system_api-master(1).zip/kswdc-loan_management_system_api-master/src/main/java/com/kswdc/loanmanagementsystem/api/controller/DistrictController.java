package com.kswdc.loanmanagementsystem.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kswdc.loanmanagementsystem.api.model.District;
import com.kswdc.loanmanagementsystem.api.service.DistrictService;
import com.kswdc.loanmanagementsystem.api.value.DistrictVO;
import com.kswdc.loanmanagementsystem.common.Constants;
import com.kswdc.loanmanagementsystem.common.DateFunctions;

/**
 * Created by Arun on 05/09/2021.
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/api")
public class DistrictController {

	private final Logger log = LoggerFactory.getLogger(DistrictController.class);
	private String invalidMsg = "";
	
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private DistrictService DistrictService;
	
	/**
	 * @author Arun
	 * @since 05-Sep-2021
	 * @param District District
	 * @return Map
	 */
	@RequestMapping(value = "/district", method = RequestMethod.POST)
	@Produces("application/json")
	public Map createDistrict(@RequestBody District District) {
		log.info("In DistrictController::createDistrict=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
					if (checkValid(District)) {
//						District.setActive(Boolean.TRUE);
						District.setCreatedOn(DateFunctions.getZonedServerDate());
						// District.setCreatedBy();
						District.setIsDeleted(0);
						Integer DistrictId = DistrictService.createDistrict(District);
						if (!DistrictId.equals(-1)) {
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("DistrictId", DistrictId);
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_SAVE);
						}
					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
					}
				
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DistrictController::createDistrict======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * //@param District District
	 * @return Map
	 */
	@RequestMapping(value = "/District", method = RequestMethod.PUT)
	@Produces("application/json")
	public Map updateDistrict(@RequestBody District District) {
		log.info("In DistrictController::updateDistrict=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (District != null) { // && District.getId() != null
				if (checkValid(District)) {
					District chkDistrict = DistrictService.getDistrict(District.getDistrictId());
					if (chkDistrict!=null) {
//						if (chkDistrict.getActive()) {
//							District.setActive(Boolean.TRUE);
							chkDistrict.setDistrictName(District.getDistrictName());							
							chkDistrict.setIsActive(District.getIsActive());							
							Integer DistrictId = DistrictService.updateDistrict(chkDistrict);
							if (!DistrictId.equals(-1)) {
								retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
								retMap.put("DistrictId:", DistrictId);
							} else {
								retMap = new HashMap<String, Object>();
								retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
								retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
								retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
							}
//						} else {
//							retMap = new HashMap<String, Object>();
//							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//							retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
//							retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
//							rabbitMqService.sendEvent(appName,Constants.NOT_FOUND,Constants.MSG_DATA_NOT_FOUND+" District Id is deactivated:"+District.getId());
//						}

					} else {
						retMap = new HashMap<String, Object>();
						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
						retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_ACCEPTABLE);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID + " " + invalidMsg);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DistrictController::updateDistrict======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/District/{id}", method = RequestMethod.DELETE)
	@Produces("application/json")
	public Map deleteDistrict(@PathVariable Integer id) {
		log.info("In DistrictController::deleteDistrict=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				District District = DistrictService.getDistrict(id);
				if (District != null) {
//					if (!District.getActive()) {
//						retMap = new HashMap<String, Object>();
//						retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
//						retMap.put(Constants.ERROR_CODE, Constants.DATA_ALREADY_DELETED);
//						retMap.put(Constants.MESSAGE, Constants.MSG_DATA_ALREADY_DELETED);
//						rabbitMqService.sendEvent(appName, Constants.DATA_ALREADY_DELETED,Constants.MSG_DATA_ALREADY_DELETED + " DistrictId:" + id);
//					} else {
						Integer DistrictId = DistrictService.deleteDistrict(id);
						if (!DistrictId.equals(-1)) {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
							retMap.put("DistrictId", DistrictId);
							return retMap;
						} else {
							retMap = new HashMap<String, Object>();
							retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
							retMap.put(Constants.ERROR_CODE, Constants.INTERNAL_SERVER_ERROR);
							retMap.put(Constants.MESSAGE, Constants.MSG_ERROR_DATA_UPDATE);
						}
//					}
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DistrictController::deleteDistrict======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param Integer id
	 * @return Map
	 */
	@RequestMapping(value = "/District/{id}", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getOneDistrict(@PathVariable Integer id) {
		log.info("In DistrictController::getOneDistrict=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
			if (id != null) {
				District District = DistrictService.getDistrict(id);
				if (District != null) {
					retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
					retMap.put("District", District);
				} else {
					retMap = new HashMap<String, Object>();
					retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
					retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
					retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
				}
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NO_CONTENT);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_RECV_NOT_VALID);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DistrictController::getOneDistrict======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	// End: ---------- District ------------------------------

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @return Map
	 */
	@RequestMapping(value = "/district-list", method = RequestMethod.GET)
	@Produces("application/json")
	public Map getDistrictList() {
		log.info("In DistrictController::getDistrictList=============");
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {
//			DistrictListReturnVO DistrictListReturnVO = new DistrictListReturnVO(DistrictService.getDistrictList());
			List<DistrictVO> DistrictListReturnVO = DistrictService.getDistrictList();
			if (DistrictListReturnVO != null && DistrictListReturnVO.size() > 0) {
				retMap.put(Constants.STATUS, Constants.STATUS_SUCCESS);
				retMap.put("Districts", DistrictListReturnVO);
			} else {
				retMap = new HashMap<String, Object>();
				retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
				retMap.put(Constants.ERROR_CODE, Constants.NOT_FOUND);
				retMap.put(Constants.MESSAGE, Constants.MSG_DATA_NOT_FOUND);
			}
		} catch (Exception e) {
			retMap = new HashMap<String, Object>();
			retMap.put(Constants.STATUS, Constants.STATUS_ERROR);
			retMap.put(Constants.ERROR_CODE, Constants.ERROR_EVENTS);
			retMap.put(Constants.MESSAGE, Constants.MSG_ERROR + e.getMessage());
			log.error("Exception in DistrictController::getDistrictList======" + e.getMessage());
			e.printStackTrace();
		}
		return retMap;
	}

	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @param DistrictId
	 * @return Boolean
	 */

	private Boolean checkIfExists(Integer DistrictId) {
		return (DistrictService.getDistrict(DistrictId) != null) ? Boolean.TRUE : Boolean.FALSE;
	}
	/**
	 * @author Arun
	 * @since 22-Apr-2021
	 * @purpose For checking if mandatory data is passed
	 * @param District
	 * @return Boolean
	 */
	private Boolean checkValid(District District) {
		Boolean isValid = true;
		invalidMsg = "";
		if (District != null) {
//			if(District.getId()==null || District.getId()<=0) {
//				invalidMsg+="DistrictId is required and should be valid!";
//				isValid = false;
//			}
			if (District.getDistrictName() == null || District.getDistrictName().equalsIgnoreCase("")) {
				invalidMsg += "District Name is required and should not be empty!";
				isValid = false;
			}
//			if (District.getDistrictName() == null || District.getDistrictName().equalsIgnoreCase("")) {
//				invalidMsg += "District Name is required and should not be empty!";
//				isValid = false;
//			}
//			if (District.getQuotaInMB() == null || District.getQuotaInMB().equals(0) || District.getQuotaInMB()<0) {
//				invalidMsg += "District Quota is required and should be valid!";
//				isValid = false;
//			}
//			if (District.getChatHistoryDays() == null || District.getChatHistoryDays().equals(0) || District.getChatHistoryDays()<0) {
//				invalidMsg += "Chat history days for District is required and should be valid!";
//				isValid = false;
//			}
//			if (District.getCdaTimeoutTime() == null || District.getCdaTimeoutTime().equals(0) || District.getCdaTimeoutTime()<0) {
//				invalidMsg += "CDA Timeout time is required and should be valid!";
//				isValid = false;
//			}
		} else {
			invalidMsg = "Received data is not valid for District!";
			isValid = false;
		}
		return isValid;
	}
	
}
