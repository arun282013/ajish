-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 26, 2022 at 01:04 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kswdclmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `error_log`
--

CREATE TABLE `error_log` (
  `id` bigint(20) NOT NULL,
  `errormessage` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `errortype` int(11) NOT NULL,
  `eventname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timestamp` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_activityfinanced`
--

CREATE TABLE `tbl_activityfinanced` (
  `activityfinanced_id` int(11) NOT NULL,
  `activityfinanced_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `modified_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `sector_id` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bank`
--

CREATE TABLE `tbl_bank` (
  `bank_id` int(11) NOT NULL,
  `bank_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `modified_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_bank`
--

INSERT INTO `tbl_bank` (`bank_id`, `bank_name`, `created_on`, `deleted_on`, `is_active`, `is_deleted`, `modified_on`, `created_by`, `modified_by`) VALUES
(1, 'Canara Bank', '2022-02-18 08:25:30', '2022-02-18 08:25:30', 1, 0, '2022-02-18 08:25:30', NULL, NULL),
(2, 'State Bank of India', '2022-02-18 08:25:30', '2022-02-18 08:25:30', 1, 0, '2022-02-18 08:25:30', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_branch`
--

CREATE TABLE `tbl_branch` (
  `branch_id` int(11) NOT NULL,
  `branch_ifsc` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `branch_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `modified_on` datetime DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `district_id` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_branch`
--

INSERT INTO `tbl_branch` (`branch_id`, `branch_ifsc`, `branch_name`, `created_on`, `deleted_on`, `is_active`, `is_deleted`, `modified_on`, `bank_id`, `created_by`, `district_id`, `modified_by`) VALUES
(1, 'CNRB00001', 'Vanchiyoor', '2022-02-23 10:49:51', '2022-02-23 10:49:51', 1, 0, '2022-02-23 10:49:51', 1, NULL, 1, NULL),
(2, 'SBIN00034', 'Oachira', '2022-02-23 10:49:51', '2022-02-23 10:49:51', 1, 0, '2022-02-23 10:49:51', 2, NULL, 2, NULL),
(3, 'CNRB00002', 'Pettah', '2022-02-26 07:07:17', '2022-02-26 07:07:17', 1, 0, '2022-02-26 07:07:17', 1, NULL, 1, NULL),
(4, 'SBIN00006', 'Karikkakom', '2022-02-26 07:08:29', '2022-02-26 07:08:29', 1, 0, '2022-02-26 07:08:29', 2, NULL, 1, NULL),
(5, 'SBIN00009', 'Karunagappally', '2022-02-26 07:09:29', '2022-02-26 07:09:29', 1, 0, '2022-02-26 07:09:29', 2, NULL, 2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_caste`
--

CREATE TABLE `tbl_caste` (
  `caste_id` int(11) NOT NULL,
  `caste_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `modified_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `religion_id` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_caste`
--

INSERT INTO `tbl_caste` (`caste_id`, `caste_name`, `created_on`, `deleted_on`, `is_active`, `is_deleted`, `modified_on`, `created_by`, `modified_by`, `religion_id`) VALUES
(1, 'Ezhava', '2022-02-19 12:53:43', '2022-02-19 12:53:43', 1, 0, '2022-02-19 12:53:43', 1, NULL, 1),
(2, 'Nair', '2022-02-22 11:17:47', '2022-02-22 11:17:47', 1, 0, '2022-02-22 11:17:47', 1, NULL, 1),
(3, 'Thiyya', '2022-02-22 11:17:47', '2022-02-22 11:17:47', 1, 0, '2022-02-22 11:17:47', 1, NULL, 1),
(4, 'Roman Catholic', '2022-02-22 11:18:24', '2022-02-22 11:18:24', 1, 0, '2022-02-22 11:18:24', 1, NULL, 2),
(5, 'Nadar', '2022-02-22 11:18:49', '2022-02-22 11:18:49', 1, 0, '2022-02-22 11:18:49', 1, NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_district`
--

CREATE TABLE `tbl_district` (
  `district_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `district_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `modified_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_district`
--

INSERT INTO `tbl_district` (`district_id`, `created_on`, `deleted_on`, `district_name`, `is_active`, `is_deleted`, `modified_on`, `created_by`, `modified_by`) VALUES
(1, '2022-02-16 18:14:59', '2022-02-16 18:14:59', 'Thiruvananthapuram', 1, 0, '2022-02-16 18:14:59', NULL, NULL),
(2, '2022-02-16 18:14:59', '2022-02-16 18:14:59', 'Kollam', 2, 0, '2022-02-16 18:14:59', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_document_checklist`
--

CREATE TABLE `tbl_document_checklist` (
  `document_checklist_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `document_checklist_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `modified_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_document_checklist`
--

INSERT INTO `tbl_document_checklist` (`document_checklist_id`, `created_on`, `deleted_on`, `document_checklist_name`, `is_active`, `is_deleted`, `modified_on`, `created_by`, `modified_by`) VALUES
(1, '2022-01-27 10:53:07', '2022-01-27 10:53:07', 'Proof of Identity', 1, 0, '2022-01-27 10:53:07', NULL, NULL),
(2, '2022-01-27 11:03:39', '2022-01-27 11:03:39', 'Copy of Ration Card', 1, 0, '2022-01-27 11:03:39', NULL, NULL),
(3, '2022-01-28 10:09:16', '2022-01-28 10:09:16', 'Copy of SSLC book', 1, 0, '2022-01-28 10:09:16', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_document_checklist_beneficiary`
--

CREATE TABLE `tbl_document_checklist_beneficiary` (
  `doc_checklist_beneficiary_id` int(11) NOT NULL,
  `file_path` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `document_checklist_id` int(11) DEFAULT NULL,
  `loantype_id` int(11) DEFAULT NULL,
  `term_loan_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_document_checklist_beneficiary`
--

INSERT INTO `tbl_document_checklist_beneficiary` (`doc_checklist_beneficiary_id`, `file_path`, `document_checklist_id`, `loantype_id`, `term_loan_id`) VALUES
(1, 'D:/sample1.pdf', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_eduqualification`
--

CREATE TABLE `tbl_eduqualification` (
  `eduqualification_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `eduqualification_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `modified_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_eduqualification`
--

INSERT INTO `tbl_eduqualification` (`eduqualification_id`, `created_on`, `deleted_on`, `eduqualification_name`, `is_active`, `is_deleted`, `modified_on`, `created_by`, `modified_by`) VALUES
(1, '2022-02-19 07:15:54', '2022-02-19 07:15:54', 'SSLC', 1, 0, '2022-02-19 07:15:54', NULL, NULL),
(2, '2022-02-19 07:15:54', '2022-02-19 07:15:54', 'PLUS TWO', 1, 0, '2022-02-19 07:15:54', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_loancategory`
--

CREATE TABLE `tbl_loancategory` (
  `loancategory_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `loancategory_code` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loancategory_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_loancategory`
--

INSERT INTO `tbl_loancategory` (`loancategory_id`, `created_on`, `deleted_on`, `is_active`, `is_deleted`, `loancategory_code`, `loancategory_name`, `modified_on`, `created_by`, `modified_by`) VALUES
(1, '2021-12-29 13:59:36', '2021-12-29 13:59:36', 1, 0, 'GEN', 'General', '2021-12-29 13:59:36', 1, NULL),
(2, '2021-12-29 13:59:36', '2021-12-29 13:59:36', 1, 0, 'MC', 'Minority Community', '2021-12-29 13:59:36', 1, NULL),
(3, '2022-02-26 07:11:17', '2022-02-26 07:11:17', 1, 0, 'SC', 'Scheduled Caste', '2022-02-26 07:11:17', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_loantype`
--

CREATE TABLE `tbl_loantype` (
  `loantype_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `loantype_code` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loantype_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_loantype`
--

INSERT INTO `tbl_loantype` (`loantype_id`, `created_on`, `deleted_on`, `is_active`, `is_deleted`, `loantype_code`, `loantype_name`, `modified_on`, `created_by`, `modified_by`) VALUES
(1, '2021-12-24 13:05:20', '2021-12-24 13:05:20', 1, 0, 'TL', 'Term Loan', '2021-12-24 13:05:20', NULL, NULL),
(2, '2021-12-24 13:05:20', '2021-12-24 13:05:20', 1, 0, 'EL', 'Education Loan', '2021-12-24 13:05:20', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_loan_document_checklist`
--

CREATE TABLE `tbl_loan_document_checklist` (
  `loan_doc_checklist_id` int(11) NOT NULL,
  `document_checklist_id` int(11) DEFAULT NULL,
  `loantype_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_loan_document_checklist`
--

INSERT INTO `tbl_loan_document_checklist` (`loan_doc_checklist_id`, `document_checklist_id`, `loantype_id`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 2),
(4, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_loan_suretytype`
--

CREATE TABLE `tbl_loan_suretytype` (
  `loan_suretytype_id` int(11) NOT NULL,
  `loantype_id` int(11) DEFAULT NULL,
  `suretytype_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_loan_suretytype`
--

INSERT INTO `tbl_loan_suretytype` (`loan_suretytype_id`, `loantype_id`, `suretytype_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_localbody`
--

CREATE TABLE `tbl_localbody` (
  `localbody_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `localbody_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `localbodytype_id` tinyint(1) NOT NULL DEFAULT 0,
  `modified_by` int(11) DEFAULT NULL,
  `district_id` tinyint(1) NOT NULL DEFAULT 0,
  `taluk_id` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_localbody`
--

INSERT INTO `tbl_localbody` (`localbody_id`, `created_on`, `deleted_on`, `is_active`, `is_deleted`, `localbody_name`, `modified_on`, `created_by`, `localbodytype_id`, `modified_by`, `district_id`, `taluk_id`) VALUES
(1, '2022-02-21 07:06:08', '2022-02-21 07:06:08', 1, 0, 'thiruvananthapuram', '2022-02-21 07:06:08', NULL, 1, NULL, 1, 1),
(2, '2022-02-26 11:37:21', '2022-02-26 11:37:21', 1, 0, 'Oachira', '2022-02-26 11:37:21', NULL, 1, NULL, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_localbodytype`
--

CREATE TABLE `tbl_localbodytype` (
  `localbodytype_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `localbodytype_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_localbodytype`
--

INSERT INTO `tbl_localbodytype` (`localbodytype_id`, `created_on`, `deleted_on`, `is_active`, `is_deleted`, `localbodytype_name`, `modified_on`, `created_by`, `modified_by`) VALUES
(1, '2022-02-17 15:29:01', '2022-02-17 15:29:01', 1, 0, 'Panchayat', '2022-02-17 15:29:01', NULL, NULL),
(2, '2022-02-17 15:29:01', '2022-02-17 15:29:01', 1, 0, 'Municipality', '2022-02-17 15:29:01', NULL, NULL),
(3, '2022-02-17 15:29:01', '2022-02-17 15:29:01', 1, 0, 'Corporation', '2022-02-17 15:29:01', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_maritalstatus`
--

CREATE TABLE `tbl_maritalstatus` (
  `maritalstatus_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `maritalstatus_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_maritalstatus`
--

INSERT INTO `tbl_maritalstatus` (`maritalstatus_id`, `created_on`, `deleted_on`, `is_active`, `is_deleted`, `maritalstatus_name`, `modified_on`, `created_by`, `modified_by`) VALUES
(1, '2022-02-16 07:53:08', '2022-02-16 07:53:08', 1, 0, 'Married', '2022-02-16 07:53:08', NULL, NULL),
(2, '2022-02-16 07:53:08', '2022-02-16 07:53:08', 1, 0, 'Single', '2022-02-16 07:53:08', NULL, NULL),
(3, '2022-02-16 07:53:08', '2022-02-16 07:53:08', 1, 0, 'Widowed', '2022-02-16 07:53:08', NULL, NULL),
(4, '2022-02-16 07:53:08', '2022-02-16 07:53:08', 1, 0, 'Divorced', '2022-02-16 07:53:08', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_postoffice`
--

CREATE TABLE `tbl_postoffice` (
  `postoffice_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `modified_on` datetime DEFAULT NULL,
  `pincode` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postoffice_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `district_id` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_relation`
--

CREATE TABLE `tbl_relation` (
  `relation_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `modified_on` datetime DEFAULT NULL,
  `relation_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_relation`
--

INSERT INTO `tbl_relation` (`relation_id`, `created_on`, `deleted_on`, `is_active`, `is_deleted`, `modified_on`, `relation_name`, `created_by`, `modified_by`) VALUES
(1, '2022-02-19 10:44:12', '2022-02-19 10:44:12', 1, 0, '2022-02-19 10:44:12', 'Father', NULL, NULL),
(2, '2022-02-19 10:44:12', '2022-02-19 10:44:12', 1, 0, '2022-02-19 10:44:12', 'Mother', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_religion`
--

CREATE TABLE `tbl_religion` (
  `religion_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `modified_on` datetime DEFAULT NULL,
  `religion_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_religion`
--

INSERT INTO `tbl_religion` (`religion_id`, `created_on`, `deleted_on`, `is_active`, `is_deleted`, `modified_on`, `religion_name`, `created_by`, `modified_by`) VALUES
(1, '2022-02-16 11:37:59', '2022-02-16 11:37:59', 1, 0, '2022-02-16 11:37:59', 'Hindu', NULL, NULL),
(2, '2022-02-16 11:37:59', '2022-02-16 11:37:59', 1, 0, '2022-02-16 11:37:59', 'Christian', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sector`
--

CREATE TABLE `tbl_sector` (
  `sector_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `modified_on` datetime DEFAULT NULL,
  `sector_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_surety_type`
--

CREATE TABLE `tbl_surety_type` (
  `suretytype_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `modified_on` datetime DEFAULT NULL,
  `suretytype_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_surety_type`
--

INSERT INTO `tbl_surety_type` (`suretytype_id`, `created_on`, `deleted_on`, `is_active`, `is_deleted`, `modified_on`, `suretytype_name`, `created_by`, `modified_by`) VALUES
(1, '2022-02-26 07:18:33', '2022-02-26 07:18:33', 1, 0, '2022-02-26 07:18:33', 'Land', NULL, NULL),
(2, '2022-02-26 07:18:33', '2022-02-26 07:18:33', 1, 0, '2022-02-26 07:18:33', 'Employee', NULL, NULL),
(3, '2022-02-26 07:18:33', '2022-02-26 07:18:33', 1, 0, '2022-02-26 07:18:33', 'Gold', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_surety_type_beneficiary`
--

CREATE TABLE `tbl_surety_type_beneficiary` (
  `suretytype_beneficiary_id` int(11) NOT NULL,
  `loan_suretytype_id` int(11) DEFAULT NULL,
  `loantype_id` int(11) DEFAULT NULL,
  `term_loan_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_taluk`
--

CREATE TABLE `tbl_taluk` (
  `taluk_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `modified_on` datetime DEFAULT NULL,
  `taluk_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `district_id` tinyint(1) NOT NULL DEFAULT 0,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_taluk`
--

INSERT INTO `tbl_taluk` (`taluk_id`, `created_on`, `deleted_on`, `is_active`, `is_deleted`, `modified_on`, `taluk_name`, `created_by`, `district_id`, `modified_by`) VALUES
(1, '2022-02-23 06:12:53', '2022-02-23 06:12:53', 1, 0, '2022-02-23 06:12:53', 'Neyyattinkara', NULL, 1, NULL),
(2, '2022-02-23 06:12:53', '2022-02-23 06:12:53', 1, 0, '2022-02-23 06:12:53', 'Karunagapally', NULL, 2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term_loan`
--

CREATE TABLE `tbl_term_loan` (
  `term_loan_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `loantype_code` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loantype_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `entered_on` datetime DEFAULT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permanent_location` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permanent_pincode` char(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `present_location` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `present_pincode` char(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tl_age` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tl_dob` datetime DEFAULT NULL,
  `tl_experience` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tl_annual_income` double NOT NULL,
  `tl_application_status` tinyint(1) NOT NULL DEFAULT 0,
  `tl_bank_account_no` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tl_estimated_loan_amount` double NOT NULL,
  `tl_guardian_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tl_permanent_housename` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tl_permanent_houseno` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tl_permanent_locationtypeid` int(11) DEFAULT NULL,
  `tl_present_housename` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tl_present_houseno` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tl_present_locationtypeid` int(11) DEFAULT NULL,
  `tl_project_cost` double NOT NULL,
  `tl_project_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tl_rationcard_no` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tl_technical_qualification` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `caste_id` int(11) DEFAULT NULL,
  `eduqualification_id` int(11) DEFAULT NULL,
  `loancategory_id` int(11) DEFAULT NULL,
  `loantype_id` int(11) DEFAULT NULL,
  `maritalstatus_id` int(11) DEFAULT NULL,
  `permanent_district_id` int(11) DEFAULT NULL,
  `permanent_localbody_id` int(11) DEFAULT NULL,
  `permanent_postoffice_id` int(11) DEFAULT NULL,
  `permanent_taluk_id` int(11) DEFAULT NULL,
  `present_district_id` int(11) DEFAULT NULL,
  `present_localbody_id` int(11) DEFAULT NULL,
  `present_postoffice_id` int(11) DEFAULT NULL,
  `present_taluk_id` int(11) DEFAULT NULL,
  `relation_id` int(11) DEFAULT NULL,
  `religion_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_term_loan`
--

INSERT INTO `tbl_term_loan` (`term_loan_id`, `created_on`, `deleted_on`, `is_active`, `is_deleted`, `loantype_code`, `loantype_name`, `modified_on`, `created_by`, `modified_by`, `entered_on`, `full_name`, `permanent_location`, `permanent_pincode`, `present_location`, `present_pincode`, `tl_age`, `tl_dob`, `tl_experience`, `tl_annual_income`, `tl_application_status`, `tl_bank_account_no`, `tl_estimated_loan_amount`, `tl_guardian_name`, `tl_permanent_housename`, `tl_permanent_houseno`, `tl_permanent_locationtypeid`, `tl_present_housename`, `tl_present_houseno`, `tl_present_locationtypeid`, `tl_project_cost`, `tl_project_name`, `tl_rationcard_no`, `tl_technical_qualification`, `bank_id`, `branch_id`, `caste_id`, `eduqualification_id`, `loancategory_id`, `loantype_id`, `maritalstatus_id`, `permanent_district_id`, `permanent_localbody_id`, `permanent_postoffice_id`, `permanent_taluk_id`, `present_district_id`, `present_localbody_id`, `present_postoffice_id`, `present_taluk_id`, `relation_id`, `religion_id`, `user_id`) VALUES
(1, '2022-02-01 09:47:48', '2022-02-01 09:47:48', 1, 0, 'TL', 'Term Loan', '2022-02-01 09:47:48', NULL, NULL, NULL, '', '', '', '', '', '', NULL, '', 0, 0, '', 0, '', '', '', NULL, '', '', NULL, 0, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tl_family_member`
--

CREATE TABLE `tbl_tl_family_member` (
  `member_id` int(11) NOT NULL,
  `age` int(11) NOT NULL,
  `annual_income` decimal(15,2) NOT NULL DEFAULT 0.00,
  `eduqualification` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `member_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `relation_id` int(11) DEFAULT NULL,
  `term_loan_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tl_family_property`
--

CREATE TABLE `tbl_tl_family_property` (
  `property_id` int(11) NOT NULL,
  `property_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `survey_number` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district_id` int(11) DEFAULT NULL,
  `taluk_id` int(11) DEFAULT NULL,
  `village_id` int(11) DEFAULT NULL,
  `term_loan_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(11) NOT NULL,
  `aadhar_no` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aadhar_validated` tinyint(1) NOT NULL DEFAULT 0,
  `account_type` tinyint(1) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `email_id` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `mobile_no` int(11) NOT NULL,
  `modified_on` datetime DEFAULT NULL,
  `user_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_otp` int(11) DEFAULT NULL,
  `user_password` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_status` tinyint(1) NOT NULL DEFAULT 0,
  `validation_time` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `loan_category` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `usertype_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `aadhar_no`, `aadhar_validated`, `account_type`, `created_on`, `deleted_on`, `email_id`, `full_name`, `is_deleted`, `mobile_no`, `modified_on`, `user_name`, `user_otp`, `user_password`, `user_status`, `validation_time`, `created_by`, `deleted_by`, `loan_category`, `modified_by`, `usertype_id`) VALUES
(1, '345678901234', 0, 1, '2022-02-14 14:49:35', NULL, 'bc@gmil.com', 'Ajish', 0, 1234567890, NULL, 'bc@gmil.com', NULL, 'wer', 1, NULL, NULL, NULL, NULL, NULL, NULL),
(2, '234567890123', 0, 1, '2022-02-14 14:58:51', NULL, 'bc@gmail.com', 'Ajish', 0, 1234567890, NULL, 'bc@gmail.com', NULL, 'qwer', 1, NULL, NULL, NULL, 1, NULL, 2),
(3, '123456789012', 0, 1, '2022-02-14 15:33:49', NULL, 'remyavis@gmail.com', 'shiny', 0, 94475876, NULL, 'remyavis@gmail.com', NULL, '234', 1, NULL, NULL, NULL, 2, NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_usertype`
--

CREATE TABLE `tbl_usertype` (
  `usertype_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `modified_on` datetime DEFAULT NULL,
  `usertype_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_usertype`
--

INSERT INTO `tbl_usertype` (`usertype_id`, `created_on`, `deleted_on`, `is_active`, `is_deleted`, `modified_on`, `usertype_name`, `created_by`, `modified_by`) VALUES
(1, '2021-12-29 12:33:39', '2021-12-29 12:33:39', 1, 0, '2021-12-29 12:33:39', 'Admin', NULL, NULL),
(2, '2021-12-29 12:33:39', '2021-12-29 12:33:39', 1, 0, '2021-12-29 12:33:39', 'Beneficiary', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_village`
--

CREATE TABLE `tbl_village` (
  `village_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `modified_on` datetime DEFAULT NULL,
  `village_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `district_id` tinyint(1) NOT NULL DEFAULT 0,
  `modified_by` int(11) DEFAULT NULL,
  `taluk_id` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ward`
--

CREATE TABLE `tbl_ward` (
  `ward_id` int(11) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted_on` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `modified_on` datetime DEFAULT NULL,
  `ward_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ward_number` int(3) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `localbody_id` tinyint(1) NOT NULL DEFAULT 0,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `error_log`
--
ALTER TABLE `error_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_activityfinanced`
--
ALTER TABLE `tbl_activityfinanced`
  ADD PRIMARY KEY (`activityfinanced_id`),
  ADD KEY `FK9l995aarg6e0bgj8of09u3iyi` (`created_by`),
  ADD KEY `FKruqpqdompcu2o5kgi3f9h78p8` (`modified_by`),
  ADD KEY `FKa58gpi4kdpun6apsfwa32w6sr` (`sector_id`);

--
-- Indexes for table `tbl_bank`
--
ALTER TABLE `tbl_bank`
  ADD PRIMARY KEY (`bank_id`),
  ADD KEY `FKn7catjxui8b61xo4ds7qtwj06` (`created_by`),
  ADD KEY `FKnrx7o6wkk5shqu3mxqvke65k2` (`modified_by`);

--
-- Indexes for table `tbl_branch`
--
ALTER TABLE `tbl_branch`
  ADD PRIMARY KEY (`branch_id`),
  ADD KEY `FK8xhnkh0p9hf3jba6a18prabjb` (`bank_id`),
  ADD KEY `FKm5y06cpbnqtbytm15p4mwkcqp` (`created_by`),
  ADD KEY `FK8b2b71heb53a7fvcnhr0rdfq2` (`district_id`),
  ADD KEY `FKqyxg4fa59a7jc0u9hx2k871rp` (`modified_by`);

--
-- Indexes for table `tbl_caste`
--
ALTER TABLE `tbl_caste`
  ADD PRIMARY KEY (`caste_id`),
  ADD KEY `FK9ty9m6k36ukk08v9gylx5ovoy` (`created_by`),
  ADD KEY `FKhk6fv5rbslvi8ytg6bsq8r2tk` (`modified_by`),
  ADD KEY `FKec00c2qsk4v6ykjeg0alv752e` (`religion_id`);

--
-- Indexes for table `tbl_district`
--
ALTER TABLE `tbl_district`
  ADD PRIMARY KEY (`district_id`),
  ADD KEY `FK89lg998dt1gm2ddjsmrqp24bt` (`created_by`),
  ADD KEY `FK2gum1i1oygdirylujfjhfl6uo` (`modified_by`);

--
-- Indexes for table `tbl_document_checklist`
--
ALTER TABLE `tbl_document_checklist`
  ADD PRIMARY KEY (`document_checklist_id`),
  ADD KEY `FKmnu54ao4lt2wy9qisrfn8ek3v` (`created_by`),
  ADD KEY `FKcvxx7ag99l8cnp91cjojawlsn` (`modified_by`);

--
-- Indexes for table `tbl_document_checklist_beneficiary`
--
ALTER TABLE `tbl_document_checklist_beneficiary`
  ADD PRIMARY KEY (`doc_checklist_beneficiary_id`),
  ADD KEY `FKcpxq6pkcfxajyvx2fj45mhtb7` (`document_checklist_id`),
  ADD KEY `FKpgy5hvofuxum233b4hrybbmhe` (`loantype_id`),
  ADD KEY `FKbpvwwaw3mhki8tf8nrk5nv2kh` (`term_loan_id`);

--
-- Indexes for table `tbl_eduqualification`
--
ALTER TABLE `tbl_eduqualification`
  ADD PRIMARY KEY (`eduqualification_id`),
  ADD KEY `FKj6y7kfpgd51lcyxgayevd5s1w` (`created_by`),
  ADD KEY `FKrewljj6oq4v4h19f5o25gh6ik` (`modified_by`);

--
-- Indexes for table `tbl_loancategory`
--
ALTER TABLE `tbl_loancategory`
  ADD PRIMARY KEY (`loancategory_id`),
  ADD KEY `FKoendtkr2ud32eskvitlfj1n95` (`created_by`),
  ADD KEY `FKrfti2tlfnpogn3jl7q4rq2ipv` (`modified_by`);

--
-- Indexes for table `tbl_loantype`
--
ALTER TABLE `tbl_loantype`
  ADD PRIMARY KEY (`loantype_id`),
  ADD KEY `FKoegm6y9y763u2jiqf3i1og23s` (`created_by`),
  ADD KEY `FK777poesgxcate42lylbswh878` (`modified_by`);

--
-- Indexes for table `tbl_loan_document_checklist`
--
ALTER TABLE `tbl_loan_document_checklist`
  ADD PRIMARY KEY (`loan_doc_checklist_id`),
  ADD KEY `FK5c5uo3s5la5up2puy8leofpif` (`document_checklist_id`),
  ADD KEY `FKpwehd3t6i67cytlv3g5wr7h7q` (`loantype_id`);

--
-- Indexes for table `tbl_loan_suretytype`
--
ALTER TABLE `tbl_loan_suretytype`
  ADD PRIMARY KEY (`loan_suretytype_id`),
  ADD KEY `FKfmfkpffkrjcmvd8csur996ioh` (`loantype_id`),
  ADD KEY `FKl2g65m8ph995s8cngmafwlhhc` (`suretytype_id`);

--
-- Indexes for table `tbl_localbody`
--
ALTER TABLE `tbl_localbody`
  ADD PRIMARY KEY (`localbody_id`),
  ADD KEY `FKbu1vxcpre8dlao83e5eo72ce` (`created_by`),
  ADD KEY `FKdkn8l4xs2ys5me2b78yio9k7x` (`district_id`),
  ADD KEY `FK5ilbuivn4mw5kp7otnfdv8h89` (`localbodytype_id`),
  ADD KEY `FKb22od92igg1i3q1g4rv6kliwk` (`modified_by`),
  ADD KEY `FK8y280wumhwl7dtm8rdtnl9pvr` (`taluk_id`);

--
-- Indexes for table `tbl_localbodytype`
--
ALTER TABLE `tbl_localbodytype`
  ADD PRIMARY KEY (`localbodytype_id`),
  ADD KEY `FKn3umxqehsfu3ykl2br87enptf` (`created_by`),
  ADD KEY `FKl4linxqcpqbpmkjwvm9j0i4ks` (`modified_by`);

--
-- Indexes for table `tbl_maritalstatus`
--
ALTER TABLE `tbl_maritalstatus`
  ADD PRIMARY KEY (`maritalstatus_id`),
  ADD KEY `FK32pfwu0rowf6hrq4kburdg50r` (`created_by`),
  ADD KEY `FKq809xej8knhj1y1ceqh9k2t19` (`modified_by`);

--
-- Indexes for table `tbl_postoffice`
--
ALTER TABLE `tbl_postoffice`
  ADD PRIMARY KEY (`postoffice_id`),
  ADD KEY `FKqvecajcsutdv8shfv2psa35w1` (`created_by`),
  ADD KEY `FKs16wuy0j5ujosft5frfb3ekrc` (`district_id`),
  ADD KEY `FKhma994ou60l8rjgcw548t5okf` (`modified_by`);

--
-- Indexes for table `tbl_relation`
--
ALTER TABLE `tbl_relation`
  ADD PRIMARY KEY (`relation_id`),
  ADD KEY `FK6bqsfbhjw296jbrisw92spsgs` (`created_by`),
  ADD KEY `FK3brbi8t4x4voosp5vaflvkqwg` (`modified_by`);

--
-- Indexes for table `tbl_religion`
--
ALTER TABLE `tbl_religion`
  ADD PRIMARY KEY (`religion_id`),
  ADD KEY `FKmw9qduhc4qn9w2me1l40vij7w` (`created_by`),
  ADD KEY `FKd43rn370hdjy7fmrvkji6lx4o` (`modified_by`);

--
-- Indexes for table `tbl_sector`
--
ALTER TABLE `tbl_sector`
  ADD PRIMARY KEY (`sector_id`),
  ADD KEY `FKewd6cihj5p66c0kxq9qm715wd` (`created_by`),
  ADD KEY `FKd5tliy27fccccoarbb0ug5a8h` (`modified_by`);

--
-- Indexes for table `tbl_surety_type`
--
ALTER TABLE `tbl_surety_type`
  ADD PRIMARY KEY (`suretytype_id`),
  ADD KEY `FKl6v0snbhejf1h6dvd72k1c8gs` (`created_by`),
  ADD KEY `FKc9hm2c1fxn0ofswifkngxyvvs` (`modified_by`);

--
-- Indexes for table `tbl_surety_type_beneficiary`
--
ALTER TABLE `tbl_surety_type_beneficiary`
  ADD PRIMARY KEY (`suretytype_beneficiary_id`),
  ADD KEY `FKnh8c8t0d2mxj4iffhp7khnsis` (`loan_suretytype_id`),
  ADD KEY `FKr8hk34fgropspqqu3r92abrm7` (`loantype_id`),
  ADD KEY `FKpkkkdk7u8udhncvhr6ko5epb2` (`term_loan_id`);

--
-- Indexes for table `tbl_taluk`
--
ALTER TABLE `tbl_taluk`
  ADD PRIMARY KEY (`taluk_id`),
  ADD KEY `FK3pb2hkxy1nrrlvmu2t21y0t40` (`created_by`),
  ADD KEY `FK6agaiyxo7cie95ody99w1bu0i` (`district_id`),
  ADD KEY `FKph13nlf3a4bkhy19fsqixq4vo` (`modified_by`);

--
-- Indexes for table `tbl_term_loan`
--
ALTER TABLE `tbl_term_loan`
  ADD PRIMARY KEY (`term_loan_id`),
  ADD KEY `FKf1xva8bfqwb7cm8xm55r0xlxl` (`bank_id`),
  ADD KEY `FKpvmvsewcfnfhltp0t0qyw4epv` (`branch_id`),
  ADD KEY `FKr1x3nusox0qcysyrw4jxv1jbu` (`caste_id`),
  ADD KEY `FKk1l5o11mfno0l2rpiaog9agsm` (`created_by`),
  ADD KEY `FKo7hdksd3fa7g69any4eaqfdc2` (`eduqualification_id`),
  ADD KEY `FKe6p6jdg9wajmua4o2gvbqelg6` (`loancategory_id`),
  ADD KEY `FK724uxkxb8g4m2k0v30ld4jlnx` (`loantype_id`),
  ADD KEY `FK4my5w0qxlsic1l08npqfr3gqh` (`maritalstatus_id`),
  ADD KEY `FK1k80b8po1dhqedannoxu7ffj2` (`modified_by`),
  ADD KEY `FK8eduoc7yvo3ln9i2daml3bv4m` (`permanent_district_id`),
  ADD KEY `FKkcrnywcjlnovaox7ej2wok9gj` (`permanent_localbody_id`),
  ADD KEY `FK8yrevhjs8sw3dfbmdwdhugbt8` (`permanent_postoffice_id`),
  ADD KEY `FKhvf8wccnwumogomksev5h2vvj` (`permanent_taluk_id`),
  ADD KEY `FK9lypetywn2ow1noanx5jhl3r0` (`present_district_id`),
  ADD KEY `FK6hfbr5i158t670mg37biqvwrt` (`present_localbody_id`),
  ADD KEY `FKliducjabsgae9xihuwfi9b3y5` (`present_postoffice_id`),
  ADD KEY `FKg7o6w7a8mgs4ygmdvvuseqdme` (`present_taluk_id`),
  ADD KEY `FKq2xcabvlgh5q0eehd7rwhxoop` (`relation_id`),
  ADD KEY `FK99jckqu9adwrm5hiay0rxc0yt` (`religion_id`),
  ADD KEY `FK963uduuh3uvntr0b5cxhxv1yy` (`user_id`);

--
-- Indexes for table `tbl_tl_family_member`
--
ALTER TABLE `tbl_tl_family_member`
  ADD PRIMARY KEY (`member_id`),
  ADD KEY `FKrxo46d2n62qnxcrkt7j88pkl8` (`relation_id`),
  ADD KEY `FKj0wrmkuuwcs3ux9sx7qfix26o` (`term_loan_id`);

--
-- Indexes for table `tbl_tl_family_property`
--
ALTER TABLE `tbl_tl_family_property`
  ADD PRIMARY KEY (`property_id`),
  ADD KEY `FKsn2roubifo7gmfg49adul1xq6` (`district_id`),
  ADD KEY `FK7tsyat3jcohxr8wdbc6qdd4kr` (`taluk_id`),
  ADD KEY `FKqxum2tj58vlb80kvpaxn541k4` (`village_id`),
  ADD KEY `FK7v4ey5ilt3afgpryhamuupu8s` (`term_loan_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `FK57d6qw65f00445olmps2xi9jl` (`created_by`),
  ADD KEY `FKsqw1d6duokf4n1w9px90flbiy` (`deleted_by`),
  ADD KEY `FK567dmhd98nh1uwgeuw83mjmdh` (`loan_category`),
  ADD KEY `FKo626ctlv23vob17jgrp8um3c8` (`modified_by`),
  ADD KEY `FKp6m31htm28n1m0bb2mgsci6cu` (`usertype_id`);

--
-- Indexes for table `tbl_usertype`
--
ALTER TABLE `tbl_usertype`
  ADD PRIMARY KEY (`usertype_id`),
  ADD KEY `FK5vhfn13axac2yxig5nbnc14ix` (`created_by`),
  ADD KEY `FKihlg5pqpffx6iu5qmrkjdei46` (`modified_by`);

--
-- Indexes for table `tbl_village`
--
ALTER TABLE `tbl_village`
  ADD PRIMARY KEY (`village_id`),
  ADD KEY `FK4in6ei5rsl8xrql1scyxg8m27` (`created_by`),
  ADD KEY `FKikv8q4afyr3xa01ll7jvwxll9` (`district_id`),
  ADD KEY `FKi7gnjos80tvhxy487c683fitx` (`modified_by`),
  ADD KEY `FKamf72oyho7s01w1fnvta98obe` (`taluk_id`);

--
-- Indexes for table `tbl_ward`
--
ALTER TABLE `tbl_ward`
  ADD PRIMARY KEY (`ward_id`),
  ADD KEY `FKgniurab53anjwtn2699ojux5e` (`created_by`),
  ADD KEY `FK6itqax9sf4bun8ewn3fji2hjq` (`localbody_id`),
  ADD KEY `FK74rn06b5m6sc4b83mbnhn1p29` (`modified_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `error_log`
--
ALTER TABLE `error_log`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_activityfinanced`
--
ALTER TABLE `tbl_activityfinanced`
  MODIFY `activityfinanced_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_bank`
--
ALTER TABLE `tbl_bank`
  MODIFY `bank_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_branch`
--
ALTER TABLE `tbl_branch`
  MODIFY `branch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_caste`
--
ALTER TABLE `tbl_caste`
  MODIFY `caste_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_district`
--
ALTER TABLE `tbl_district`
  MODIFY `district_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_document_checklist`
--
ALTER TABLE `tbl_document_checklist`
  MODIFY `document_checklist_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_document_checklist_beneficiary`
--
ALTER TABLE `tbl_document_checklist_beneficiary`
  MODIFY `doc_checklist_beneficiary_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_eduqualification`
--
ALTER TABLE `tbl_eduqualification`
  MODIFY `eduqualification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_loancategory`
--
ALTER TABLE `tbl_loancategory`
  MODIFY `loancategory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_loantype`
--
ALTER TABLE `tbl_loantype`
  MODIFY `loantype_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_loan_document_checklist`
--
ALTER TABLE `tbl_loan_document_checklist`
  MODIFY `loan_doc_checklist_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_loan_suretytype`
--
ALTER TABLE `tbl_loan_suretytype`
  MODIFY `loan_suretytype_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_localbody`
--
ALTER TABLE `tbl_localbody`
  MODIFY `localbody_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_localbodytype`
--
ALTER TABLE `tbl_localbodytype`
  MODIFY `localbodytype_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_maritalstatus`
--
ALTER TABLE `tbl_maritalstatus`
  MODIFY `maritalstatus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_postoffice`
--
ALTER TABLE `tbl_postoffice`
  MODIFY `postoffice_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_relation`
--
ALTER TABLE `tbl_relation`
  MODIFY `relation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_religion`
--
ALTER TABLE `tbl_religion`
  MODIFY `religion_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_sector`
--
ALTER TABLE `tbl_sector`
  MODIFY `sector_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_surety_type`
--
ALTER TABLE `tbl_surety_type`
  MODIFY `suretytype_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_surety_type_beneficiary`
--
ALTER TABLE `tbl_surety_type_beneficiary`
  MODIFY `suretytype_beneficiary_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_taluk`
--
ALTER TABLE `tbl_taluk`
  MODIFY `taluk_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_term_loan`
--
ALTER TABLE `tbl_term_loan`
  MODIFY `term_loan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_tl_family_member`
--
ALTER TABLE `tbl_tl_family_member`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_tl_family_property`
--
ALTER TABLE `tbl_tl_family_property`
  MODIFY `property_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_usertype`
--
ALTER TABLE `tbl_usertype`
  MODIFY `usertype_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_village`
--
ALTER TABLE `tbl_village`
  MODIFY `village_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_ward`
--
ALTER TABLE `tbl_ward`
  MODIFY `ward_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
